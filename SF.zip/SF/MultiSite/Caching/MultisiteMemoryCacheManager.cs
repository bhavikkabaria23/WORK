using System;
using System.Collections.Generic;
using System.Runtime.Caching;
using System.Text.RegularExpressions;
using Nop.Core.Data;
using System.Linq;

namespace Nop.Core.Caching
{
    /// <summary>
    /// Represents a multisite memory cache
    /// </summary>
    public partial class MultisiteMemoryCacheManager : ICacheManager
    {
        protected ObjectCache Cache
        {
            get
            {
                return MemoryCache.Default;
            }
        }

        /// <summary>
        /// Gets or sets the value associated with the specified key.
        /// </summary>
        /// <typeparam name="T">Type</typeparam>
        /// <param name="key">The key of the value to get.</param>
        /// <returns>The value associated with the specified key.</returns>
        public T Get<T>(string key)
        {
            key = ComposeKey(key);
            return (T)Cache[key];
        }

        /// <summary>
        /// Adds the specified key and object to the cache.
        /// </summary>
        /// <param name="key">key</param>
        /// <param name="data">Data</param>
        /// <param name="cacheTime">Cache time</param>
        public void Set(string key, object data, int cacheTime)
        {
            if (data == null)
                return;

            key = ComposeKey(key);
            var policy = new CacheItemPolicy();
            policy.AbsoluteExpiration = DateTime.Now + TimeSpan.FromMinutes(cacheTime);
            Cache.Add(new CacheItem(key, data), policy);
        }

        /// <summary>
        /// Gets a value indicating whether the value associated with the specified key is cached
        /// </summary>
        /// <param name="key">key</param>
        /// <returns>Result</returns>
        public bool IsSet(string key)
        {
            key = ComposeKey(key);
            return (Cache.Contains(key));
        }

        /// <summary>
        /// Removes the value with the specified key from the cache
        /// </summary>
        /// <param name="key">/key</param>
        public void Remove(string key)
        {
            //key = ComposeKey(key);
            Cache.Remove(key);
        }

        /// <summary>
        /// Removes items by pattern
        /// </summary>
        /// <param name="pattern">pattern</param>
        public void RemoveByPattern(string pattern)
        {
            var regex = new Regex(pattern, RegexOptions.Singleline | RegexOptions.Compiled | RegexOptions.IgnoreCase);
            var keysToRemove = new List<String>();

            foreach (var item in Cache)
            {

                if (item.Key.StartsWith(MultisiteHelper.SubDomain))
                {
                    //var key = DecomposeKey(item.Key);
                    if (regex.IsMatch(item.Key))
                        keysToRemove.Add(item.Key);
                }
            }

            foreach (string key in keysToRemove)
            {
                Cache.Remove(key);
            }
        }

        /// <summary>
        /// Clear all cache data
        /// </summary>
        public void Clear()
        {
            if (Cache.Any())
            {
                foreach (var item in Cache.Where(c => c.Key.Contains(MultisiteHelper.SubDomain)))
                    Remove(item.Key);
            }
        }

        string ComposeKey(string key)
        {
            return string.Format("{0}_{1}", MultisiteHelper.SubDomain, key);
        }

        string DecomposeKey(string key)
        {
            if (key.StartsWith(MultisiteHelper.SubDomain))
            {
                return key.Substring(MultisiteHelper.SubDomain.Length + 1);
            }
            throw new ArgumentException(string.Format("key {0} does not match current subdomain {1}", key, MultisiteHelper.SubDomain));
        }

        /// <summary>
        /// Dispose
        /// </summary>
        public virtual void Dispose()
        {
        }
    }
}