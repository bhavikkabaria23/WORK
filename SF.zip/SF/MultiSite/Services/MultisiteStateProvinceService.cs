﻿using Nop.Core.Caching;
using Nop.Core.Data;
using Nop.Core.Domain.Directory;
using Nop.Core.Infrastructure;
using Nop.Services.Directory;
using Nop.Services.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiSite.Services
{
    public class MultisiteStateProvinceService : StateProvinceService
    {
        public MultisiteStateProvinceService() :
            base(
            EngineContext.Current.Resolve<ICacheManager>(),
            EngineContext.Current.Resolve<IRepository<StateProvince>>(),                            
            EngineContext.Current.Resolve<IEventPublisher>()                                       
            )
        { }

        /// <summary>
        /// Gets a state/province collection by country identifier, this is used in Multisite project
        /// </summary>
        /// <param name="CountryName">Country identifier</param>
        /// <param name="showHidden">A value indicating whether to show hidden records</param>
        /// <returns>State/province collection</returns>
        public virtual IList<StateProvince> GetStateProvincesByCountryName(string CountryName, bool showHidden = false)
        {
            var _stateProvinceRepository = EngineContext.Current.Resolve<IRepository<StateProvince>>();
            var query = from sp in _stateProvinceRepository.Table
                        orderby sp.DisplayOrder
                        where sp.Country.Name == CountryName &&
                        (showHidden || sp.Published)
                        select sp;
            var stateProvinces = query.ToList();
            return stateProvinces;

        }

        public virtual IList<StateProvince> GetStateProvincesByNumericIsoCode(int NumericIsoCode, bool showHidden = false)
        {
            var _stateProvinceRepository = EngineContext.Current.Resolve<IRepository<StateProvince>>();
            var query = from sp in _stateProvinceRepository.Table
                        orderby sp.DisplayOrder
                        where sp.Country.NumericIsoCode == NumericIsoCode &&
                        (showHidden || sp.Published)
                        select sp;
            var stateProvinces = query.ToList();
            return stateProvinces;

        }
    }
}
