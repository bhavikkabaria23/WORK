﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nop.Services.Customers;
using Nop.Core.Domain.Customers;
using Nop.Core;
using Nop.Core.Infrastructure;
using Nop.Core.Caching;
using Nop.Core.Data;
using Nop.Core.Domain.Common;
using Nop.Services.Common;
using Nop.Core.Events;
using Nop.Services.Events;
//upgrade_2.80_3.1
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Forums;
using Nop.Core.Domain.Blogs;
using Nop.Core.Domain.News;
using Nop.Core.Domain.Polls;
using Nop.Core.Domain.Catalog;
using Nop.Data;
//------------------------------------------------

namespace MultiSite.Services
{
    public class MultisiteCustomerService : CustomerService
    {
        public MultisiteCustomerService() :
            base(
            EngineContext.Current.Resolve<ICacheManager>(),
            EngineContext.Current.Resolve<IRepository<Customer>>(),
            EngineContext.Current.Resolve<IRepository<CustomerPassword>>(),
            EngineContext.Current.Resolve<IRepository<CustomerRole>>(),
            EngineContext.Current.Resolve<IRepository<GenericAttribute>>(),                
            EngineContext.Current.Resolve<IRepository<Order>>(),
            EngineContext.Current.Resolve<IRepository<ForumPost>>(),
            EngineContext.Current.Resolve<IRepository<ForumTopic>>(),
            EngineContext.Current.Resolve<IRepository<BlogComment>>(),
            EngineContext.Current.Resolve<IRepository<NewsComment>>(),
            EngineContext.Current.Resolve<IRepository<PollVotingRecord>>(),
            EngineContext.Current.Resolve<IRepository<ProductReview>>(),
            EngineContext.Current.Resolve<IRepository<ProductReviewHelpfulness>>(),                
            EngineContext.Current.Resolve<IGenericAttributeService>(),                
            EngineContext.Current.Resolve<IDataProvider>(),
            EngineContext.Current.Resolve<IDbContext>(),            
            EngineContext.Current.Resolve<IEventPublisher>(),
            EngineContext.Current.Resolve<CustomerSettings>(),                
            EngineContext.Current.Resolve<CommonSettings>()            
            )
        { }

        public virtual Customer InsertAdminCustomer(string UserName = "superadmin")
        {
            var customer = new Customer()
            {
                CustomerGuid = Guid.NewGuid(),
                Active = true,
                CreatedOnUtc = DateTime.UtcNow,
                LastActivityDateUtc = DateTime.UtcNow
            };

            //add to 'Administrators' role
            var adminRole = GetCustomerRoleBySystemName(SystemCustomerRoleNames.Administrators);            
            if (adminRole == null)
                throw new NopException("'Administrators' role could not be loaded");
            customer.CustomerRoles.Add(adminRole);
            var _customerRepository = EngineContext.Current.Resolve<IRepository<Customer>>();
            _customerRepository.Insert(customer);

            return customer;
        }

        public virtual Customer GetFirstAdminCustomer()
        {
            var adminRole = GetCustomerRoleBySystemName(SystemCustomerRoleNames.Administrators);
            if (adminRole == null)
                throw new NopException("'Administrators' role could not be loaded");
            List<int> RolesIds = new List<int>();
            RolesIds.Add(adminRole.Id);
            var customer = GetAllCustomers(customerRoleIds: RolesIds.ToArray())
                .Where(c => !c.Email.Contains("superadmin") || !c.Username.Contains("superadmin")).OrderBy(c => c.Id).FirstOrDefault();
            return customer;
        }
    }
}
