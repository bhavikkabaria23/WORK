﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nop.Services.Security;
using Nop.Data;
using Nop.Core.Data;
using Nop.Services.Customers;
using Nop.Core.Infrastructure;
using Nop.Core.Domain.Security;
using Nop.Core;
using Nop.Core.Caching;
using Nop.Core.Domain.Customers;
using Nop.Services.Localization;


namespace MultiSite.Security {
    public class MultisitePermissionService : PermissionService {
        public MultisitePermissionService(IRepository<PermissionRecord> permissionPecordRepository,
            ICustomerService customerService,
            IWorkContext workContext,
             ILocalizationService localizationService,
            ILanguageService languageService,
            ICacheManager cacheManager)
            : base(permissionPecordRepository, customerService, workContext,
                    localizationService, languageService, cacheManager) { }

        public override bool Authorize(Nop.Core.Domain.Security.PermissionRecord permission, Customer customer) {
            if (permission == null)
                return false;

            if (customer == null)
                return false;

            var superadminUsername = string.Format("{0}@{1}", "superadmin", MultisiteHelper.Domain);

            if (customer.IsAdmin() && MultiSiteDataProvider.IsTrial() && customer.Email != superadminUsername) {
                var daysLeft = MultiSiteDataProvider.GetLeftDaysOfTrial();
                if (daysLeft <= 0) {
                    return false;
                }
            }

            return Authorize(permission.SystemName, customer);
        }
    }
}
