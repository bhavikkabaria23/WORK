﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Configuration;
using MultiSite.Data;
using MultiSite.Extension;
using MultiSite.Files;
using MultiSite.Infrastructure.Cache;
using MultiSite.Models;
using MultiSite.Models.SiteTheme;
using Nop.Core.Caching;
using Nop.Core.Configuration;
using Nop.Core.Infrastructure;
using Nop.Services.Logging;
using System.Web.Hosting;
using System.IO;

namespace Nop.Core.Data
{
    public static class MultisiteHelper
    {
        #region Fields

        public const string MainStoreName = "store";

#if (DEBUG)
        public static string overrideSubdomain;
#endif        
        private static List<SiteModel> _allSites;

        private static Dictionary<string, string> _connectionStringMapping = new Dictionary<string, string>();
        private static Dictionary<Guid, LoginInfo> _tempLoginGuids = new Dictionary<Guid, LoginInfo>();

        #endregion

        #region Properties

        public static string SubDomain
        {
            get
            {
                try
                {
                    #if (DEBUG)
                    if (overrideSubdomain != null)
                    {
                        return overrideSubdomain;
                    }
                    var subDomainFile = Path.Combine(HostingEnvironment.MapPath("~/App_Data"), "subdomain.txt");
                    if (File.Exists(subDomainFile))
                    {
                        return File.ReadAllText(subDomainFile);
                    }
                    return MainStoreName;
#else                
                    if (HttpContext.Current != null)
                    {
                        if (HttpContext.Current.Items["subdomain"] == null)
                        {
                            var serverName = HttpContext.Current.Request.ServerVariables["SERVER_NAME"];
                            if (serverName.StartsWith("www.", StringComparison.InvariantCultureIgnoreCase))
                            {
                                serverName = serverName.Substring(4);
                            }
                            if (serverName.Equals(string.Format("{0}.{1}", MainStoreName, Domain), StringComparison.InvariantCultureIgnoreCase))
                            {
                                return MainStoreName;
                            }
                            var subDomain = AllSites.SingleOrDefault(s => s.storeUrl.Equals(serverName, StringComparison.InvariantCultureIgnoreCase));
                            HttpContext.Current.Items["subdomain"] = subDomain != null ? subDomain.storeName : MainStoreName;
                        }
                        return (string)HttpContext.Current.Items["subdomain"];
                    }
                    else
                    {
                        return MainStoreName;
                    }
#endif
                }
                catch
                {
                    return MainStoreName;
                }
            }

        }

//        public static string SubDomain
//        {
//            get
//            {
//                try
//                {
//#if (DEBUG)
//                    if (overrideSubdomain != null)
//                    {
//                        return overrideSubdomain;
//                    }
//                    var subDomainFile = Path.Combine(HostingEnvironment.MapPath("~/App_Data"), "subdomain.txt");
//                    if (File.Exists(subDomainFile))
//                    {
//                        return File.ReadAllText(subDomainFile);
//                    }
//                    return MainStoreName;
//#else
//                    return MainStoreName;
//                    if (HttpContext.Current != null)
//                    {
//                        if (HttpContext.Current.Items["subdomain"] == null)
//                        {
//                            var serverName = HttpContext.Current.Request.ServerVariables["SERVER_NAME"];
//                            /*var cacheManager = EngineContext.Current.Resolve<ICacheManager>();
//                            string cacheKey = string.Format(ModelCacheEventConsumer.MULTISITE_SUBDOMAIN_MODEL_KEY,
//                                serverName);*/
//                            //return cacheManager.Get(cacheKey, () =>
//                            {
//                                if (serverName.StartsWith("www.", StringComparison.InvariantCultureIgnoreCase))
//                                {
//                                    serverName = serverName.Substring(4);
//                                }
//                                if (serverName.Equals(string.Format("{0}.{1}", MainStoreName, Domain),
//                                    StringComparison.InvariantCultureIgnoreCase))
//                                {
//                                    return MainStoreName;
//                                }
//                                //get subdomain by host value
//                                var subDomain =
//                                    AllSites.SingleOrDefault(
//                                        s => s.storeUrl.Equals(serverName, StringComparison.InvariantCultureIgnoreCase));
//                                if (subDomain != null)
//                                    HttpContext.Current.Items["subdomain"] = subDomain.storeName;
//                                else
//                                {
//                                    serverName = serverName.ToLower();
//                                    var domains = GetAvailableDomains;
//                                    string storeName = null;
//                                    foreach (var domain in domains)
//                                    {
//                                        if (!String.IsNullOrEmpty(domain.Hosts) &&
//                                            domain.Hosts.StartWithDomain(serverName))
//                                        {
//                                            storeName = domain.StoreName;
//                                        }
//                                    }
//                                    /*var logger = EngineContext.Current.Resolve<ILogger>();
//                                    logger.Information("dbname:" + dbname + " serverName:" + serverName + " " +
//                                                       domains.Count);*/
//                                    HttpContext.Current.Items["subdomain"] = storeName ?? MainStoreName;
//                                }
//                                return (string)HttpContext.Current.Items["subdomain"];
//                            }
//                            //});
//                        }
//                        return (string)HttpContext.Current.Items["subdomain"];
//                    }
//                    return MainStoreName;
//#endif
//                }
//                catch
//                {
//                    return MainStoreName;
//                }
//            }

//        }

        public static string Domain
        {
            get
            {
                return MultisiteSettings.Domain;
            }
        }

        public static string FullAdminStoreAddress
        {
            get
            {
#if (DEBUG)
                return HttpContext.Current.Request.ApplicationPath;
#else
                return string.Format(@"http://{0}", Domain);
#endif
            }
        }

        public static string CurrentUrl
        {
            get
            {
                return SubDomain.Contains('.') ? SubDomain : string.Format(@"{0}.{1}", SubDomain, Domain);
            }
        }

        public static string CurrentConnectionString
        {
            get
            {
                if (!_connectionStringMapping.ContainsKey(SubDomain))
                {
                    var settings = new MultisiteDataSettingsManager().LoadSettings();
                    _connectionStringMapping[SubDomain] = settings.DataConnectionString;
                }
                /*var logger = EngineContext.Current.Resolve<ILogger>();
                logger.Information("SubDomain:" + SubDomain);*/
                var mapping = _connectionStringMapping[SubDomain];
                if (string.IsNullOrEmpty(mapping))
                {
                    if (HttpContext.Current != null)
                    {
                        if (!HttpContext.Current.Response.IsRequestBeingRedirected)
                            HttpContext.Current.Response.Redirect(FullAdminStoreAddress, true);
                    }
                    if (!_connectionStringMapping.ContainsKey(MainStoreName))
                    {
                        var settings = new MultisiteDataSettingsManager().LoadMainSettings();
                        _connectionStringMapping[MainStoreName] = settings.DataConnectionString;
                    }
                    return _connectionStringMapping[MainStoreName];
                }
                return mapping;
            }
        }

        public static string AdminConnectionString
        {
            get
            {
                if (!_connectionStringMapping.ContainsKey(MainStoreName))
                {
                    var settings = new MultisiteDataSettingsManager().LoadMainSettings();
                    _connectionStringMapping[MainStoreName] = settings.DataConnectionString;
                }
                return _connectionStringMapping[MainStoreName];
            }
        }

        public static bool IsAdminSite
        {
            get
            {
                return SubDomain.Equals(MainStoreName, StringComparison.OrdinalIgnoreCase);
            }
        }

        internal static List<Domains> GetAvailableDomains
        {
            get
            {
                var cacheManager = EngineContext.Current.Resolve<ICacheManager>();
                string cacheKey = string.Format(ModelCacheEventConsumer.MULTISITE_MODEL_KEY);
                return cacheManager.Get(cacheKey, () =>
                {
                    var connStr = new Sites4Entities().Database.Connection.ConnectionString;
                    var result = new List<Domains>();
                    using (var conn = new SqlConnection(connStr))
                    {
                        conn.Open();

                        //using (var sqlTxn = conn.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
                        {
                            try
                            {
                                var sqlCommand = new SqlCommand
                                {
                                    Connection = conn,
                                    //Transaction = sqlTxn,
                                    CommandText = @"sp_GetAvailableDomains"
                                };
                                var reader = sqlCommand.ExecuteReader();
                                while (reader.Read())
                                {
                                    result.Add(new Domains
                                    {
                                        siteid = int.Parse(reader[0].ToString()),
                                        StoreName = reader[1].ToString(),
                                        dbname = reader[2].ToString(),
                                        Hosts = reader[3].ToString(),
                                    });
                                }

                                //sqlTxn.Commit()
                            }
                            catch (Exception)
                            {
                                //sqlTxn.Rollback();
                            }
                        }
                    }

                    return result;
                });

            }
        }

        internal static List<SiteModel> AllSites
        {
            get
            {
                if (_allSites == null)
                {
                    using (var dbContext = new Sites4Entities())
                    {
                        _allSites = dbContext.Sites.ToList().Select(s => new SiteModel
                        {
                            Id = s.Id,
                            storeName = s.StoreName,
                            isExternalUrl = s.StoreName.Contains('.'),
                            storeUrl = s.StoreName.Contains('.') ? s.StoreName : string.Format(@"{0}.{1}", s.StoreName, Domain)
                        }).ToList();
                    }
                }
                return _allSites;
            }
        }

        public static MultisiteConfig MultisiteSettings = (MultisiteConfig)WebConfigurationManager.GetSection("MultisiteConfig");

        public static string ApplicationName
        {
            get { return MultisiteSettings.ApplicationName; }
        }

        public static string DefaultTheme
        {
            get { return MultisiteSettings.DefaultTheme; }
        }

        public static string NewsFeedUrl
        {
            get { return MultisiteSettings.NewsFeedUrl; }
        }

        public static TimeSpan ShowPopupInterval
        {
            get { return TimeSpan.FromMinutes(MultisiteSettings.ShowPopupIntervalInMinutes); }
        }

        public static int TrialDayCount
        {
            get { return MultisiteSettings.TrialDayCount; }
        }

        public static int TrialLeftDaysStartShowPopup
        {
            get { return MultisiteSettings.ShowPopupWhenLeftDays; }
        }

        public static Dictionary<Guid, LoginInfo> TempLoginGuids
        {
            get { return _tempLoginGuids; }
        }

        public static string ConfigDomain
        {
            get
            {
                return MultisiteSettings.Domain;
            }
        }

        #endregion

        #region Methods

        public static string ExpandStoreNameToUrl(string storeName)
        {
            return storeName.Contains('.') ? storeName : string.Format(@"{0}.{1}", storeName, Domain);
        }

        public static string GetConnectionString(string storeName)
        {
            if (!_connectionStringMapping.ContainsKey(storeName))
            {
                var settings = new MultisiteDataSettingsManager().LoadSettings(storeName);
                _connectionStringMapping[storeName] = settings.DataConnectionString;
            }
            return _connectionStringMapping[storeName];
        }

        public static string GetDatabaseTemplateName(string industryType)
        {
            var templateMapping = MultisiteSettings.TemplateMappings.OfType<TemplateMappingConfig>()
                                        .SingleOrDefault(m => m.IndustryType.Equals(industryType, StringComparison.InvariantCultureIgnoreCase));

            return templateMapping != null ? templateMapping.DatabaseFilename : "Template";
        }

        public static IEnumerable<string> GetStoresForEmail(string email)
        {
            using (var dbContext = new Sites4Entities())
            {
                var stores = dbContext.Sites.Include("Owner").Where(site => site.Owner.email == email).ToList()
                                                             .Select(site => ExpandStoreNameToUrl(site.StoreName));
                return stores.ToList();
            }
        }

        public static void RemoveConnectionString(string subdomain)
        {
            if (_connectionStringMapping.ContainsKey(subdomain))
            {
                _connectionStringMapping.Remove(subdomain);
            }
        }

        public static void ResetSites()
        {
            _allSites = null;
        }

        public static string SanitazeStoreName(this string storeName)
        {
            storeName = storeName.Trim().TrimEnd('/');
            if (storeName.StartsWith("http://", StringComparison.InvariantCultureIgnoreCase))
            {
                storeName = storeName.Substring(7);
            }
            storeName = storeName.Split('.')[0];
            return storeName;
        }

        public static string GetHeaders()
        {
            /* var headers = System.Web.HttpContext.Current.Request.Headers.ToString(); */

            /* If you want it formated in some other way. */
            var headers1 = String.Empty;
            foreach (var key in HttpContext.Current.Request.Headers.AllKeys)
                headers1 += key + "=" + HttpContext.Current.Request.Headers[key] + Environment.NewLine;

            return headers1.ToString();
        }

        public static string GetDbName(string storeName = null)
        {
            storeName = storeName ?? SubDomain;
            return string.Format("{0}_{1}", ApplicationName, storeName);
        }

        internal static void FillAllDbNames()
        {
            DbConnectionStringBuilder builder = new DbConnectionStringBuilder();
            using (var dc = new Sites4Entities())
            {
                foreach (var s in dc.Sites)
                {
                    builder.ConnectionString = GetConnectionString(s.StoreName);
                    var dbName = builder["initial catalog"] as string;
                    s.DbName = dbName;
                }
                dc.SaveChanges();
            }
        }

        // For package details
        public static bool CheckPackageDetailsByCriteria(string criteria, string compareValue = "")
        {
            using (var dbContext = new Sites4Entities())
            {
                var sites = dbContext.Sites.Where(s => s.StoreName == SubDomain && s.PackageProductId > 0).FirstOrDefault();
                if (sites != null)
                {
                    var packageDetails = dbContext.Packages.Where(p => p.PackageProductId == sites.PackageProductId).ToList();

                    //         var packageDetails = dbContext.Database.SqlQuery<Package>(
                    // "sp_GetPackageDetailsByStoreName @StoreName",
                    // new SqlParameter("@StoreName", MultisiteHelper.SubDomain)
                    //).ToList();
                    if (packageDetails != null && packageDetails.Count() > 0)
                    {
                        Package objPackage = new Package();
                        objPackage = packageDetails.FirstOrDefault();
                        switch (criteria)
                        {
                            case "PackageProductLimit":
                                if (objPackage.PackageIsProductLimit)
                                {
                                    if (Convert.ToInt64(compareValue) >= objPackage.PackageProductLimit)
                                    {
                                        return true;
                                    }
                                }
                                return false;
                            case "PackageStoreLimit":
                                if (objPackage.PackageIsStoreLimit)
                                {
                                    if (Convert.ToInt64(compareValue) >= objPackage.PackageStoreLimit)
                                    {
                                        return true;
                                    }
                                }
                                return false;
                            case "PackageIsPOSApiLimit":
                                if (Convert.ToInt64(compareValue) >= objPackage.PackagePOSApiLimit)
                                {
                                    return true;
                                }
                                return false;
                            case "PackageIsAllowQuickBook":
                                // if objPackage.PackageIsAllowQuickBook == true i.e. always show quick book plugin.
                                // So need to hide it so its return false otherwise return true
                                if (objPackage.PackageIsAllowQuickBook)
                                    return false;
                                else
                                    return true;
                            case "PackageIsAllowCustomTheme":
                                if (objPackage.PackageIsAllowCustomTheme)
                                    return false;
                                else
                                    return true;
                            case "PackageIsEmailSupport":
                                if (objPackage.PackageIsEmailSupport)
                                    return false;
                                else
                                    return true;
                            case "PackageIsLiveSupport":
                                if (objPackage.PackageIsLiveSupport)
                                    return false;
                                else
                                    return true;
                            case "PackageIsAllowFrontWebsite":
                                // If "PackageIsAllowFrontWebsite = false" then Apply condition for front website.So here return true
                                // otherwise no condition applied
                                if (objPackage.PackageIsAllowFrontWebsite)
                                    return false;
                                else
                                    return true;
                            default:
                                return false;
                        }
                    }
                }
                return false;
            }
        }
        //------------------------

        //Update admin customer emailId to Sites Table
        public static void UpdateCustomerEmailId(string oldEmailId, string newEmailId, string storeName)
        {
            using (var dbContext = new Sites4Entities())
            {
                var sites = dbContext.Sites.SingleOrDefault(s => s.StoreName.ToLower().Trim().Equals(storeName.ToLower().Trim()));
                if (sites != null)
                {
                    var owner = dbContext.Owners.Where(o => o.Id == sites.Owner_Id && o.email.Equals(oldEmailId.Trim())).FirstOrDefault();
                    if (owner != null)
                    {
                        owner.email = newEmailId;
                        dbContext.SaveChanges();
                    }
                }
            }
        }

        //--------------------------------------

        //Store Template Theme
        public static List<SitesTheme> GetAllSiteThemes(string storeName, bool IsMobileTheme)
        {
            using (var dbContext = new Sites4Entities())
            {
                return dbContext.SitesThemes.Where(s => s.StoreName == storeName
                    && s.IsMobileTheme == IsMobileTheme).ToList();
            }
        }
        //-----------------------------------------
        //Store Template Theme
        public static void SaveSiteThemes(SiteModel model, int Id = 0)
        {
            using (var dbContext = new Sites4Entities())
            {
                #region Save Desktop theme
                List<string> postedDesktopThemeValues = new List<string>();
                if (model.PostedDesktopThemes == null) model.PostedDesktopThemes = new PostedThemes();

                // if a view model array of posted Themes values exists
                // and is not empty,save selected ids
                if (model.PostedDesktopThemes.ThemesValues != null && model.PostedDesktopThemes.ThemesValues.Any())
                {
                    postedDesktopThemeValues = model.PostedDesktopThemes.ThemesValues.ToList();
                }
                var AvailableStoreDesktopTheme = dbContext.SitesThemes
                        .Where(st => st.StoreName == model.storeName && st.IsMobileTheme == false).ToList();
                foreach (var item in AvailableStoreDesktopTheme)
                {
                    if (item != null)
                    {
                        if (!postedDesktopThemeValues.Contains(item.ThemeName))
                        {
                            dbContext.Entry(item).State = EntityState.Deleted;
                            dbContext.SaveChanges();
                        }
                    }
                }
                for (int i = 0; i < postedDesktopThemeValues.Count(); i++)
                {
                    if (!AvailableStoreDesktopTheme.Exists(t => t.ThemeName == postedDesktopThemeValues[i]))
                    {
                        SitesTheme sitetheme = new SitesTheme
                        {
                            StoreName = model.storeName,
                            TemplateName = model.industryType,
                            ThemeName = postedDesktopThemeValues[i],
                            IsMobileTheme = false,
                            CreationDate = DateTime.Now
                        };
                        dbContext.SitesThemes.Add(sitetheme);
                        dbContext.SaveChanges();
                    }
                }
                #endregion

                #region Save Mopbile theme
                List<string> postedMobileThemeValues = new List<string>();
                if (model.PostedMobileThemes == null) model.PostedMobileThemes = new PostedThemes();

                // if a view model array of posted Themes values exists
                // and is not empty,save selected ids
                if (model.PostedMobileThemes.ThemesValues != null && model.PostedMobileThemes.ThemesValues.Any())
                {
                    postedMobileThemeValues = model.PostedMobileThemes.ThemesValues.ToList();
                }
                var AvailableStoreMobileTheme = dbContext.SitesThemes
                        .Where(st => st.StoreName == model.storeName && st.IsMobileTheme == true).ToList();
                foreach (var item in AvailableStoreMobileTheme)
                {
                    if (item != null)
                    {
                        if (!postedMobileThemeValues.Contains(item.ThemeName))
                        {
                            dbContext.Entry(item).State = EntityState.Deleted;
                            dbContext.SaveChanges();
                        }
                    }
                }
                for (int i = 0; i < postedMobileThemeValues.Count(); i++)
                {
                    if (!AvailableStoreMobileTheme.Exists(t => t.ThemeName == postedMobileThemeValues[i]))
                    {
                        SitesTheme sitetheme = new SitesTheme
                        {
                            StoreName = model.storeName,
                            TemplateName = model.industryType,
                            ThemeName = postedMobileThemeValues[i],
                            IsMobileTheme = true,
                            CreationDate = DateTime.Now
                        };
                        dbContext.SitesThemes.Add(sitetheme);
                        dbContext.SaveChanges();
                    }
                }
                #endregion
            }
        }

        public static void SaveSiteThemeByStoreName(string storeName, string themeName)
        {
            using (var dbContext = new Sites4Entities())
            {
                var site = dbContext.Sites.Where(s => s.StoreName.ToLower().Trim().Equals(storeName.ToLower().Trim())).SingleOrDefault();
                var owner = dbContext.Owners.Where(o => o.Id == site.Owner_Id).SingleOrDefault();
                if (site != null)
                {
                    SitesTheme sitetheme = new SitesTheme
                    {
                        StoreName = site.StoreName,
                        TemplateName = owner.industryType,
                        ThemeName = themeName,
                        IsMobileTheme = false,
                        CreationDate = DateTime.Now
                    };
                    dbContext.SitesThemes.Add(sitetheme);
                    dbContext.SaveChanges();
                }
            }

        }
        //-----------------------------------
        #endregion

        public static string ExpandMessage(this Exception ex)
        {
            var msg = string.Format("{0} {1}", ex.Message, ex.InnerException == null ? "" : ex.InnerException.ExpandMessage());
            return msg;
        }

        public struct LoginInfo
        {
            public string StoreName, Email, Password, ReturnUrl;
        }

        public static int UpdateCustomerByStore(string oldEmailId, string email, string username)
        {
            using (var dbContext = new Sites4Entities())
            {
                dbContext.Database.ExecuteSqlCommand(
        "sp_UpdateCustomerByStore @dbPrefix, @oldEmailId, @storeName, @email, @username",
        new SqlParameter("@dbPrefix", ApplicationName),
                new SqlParameter("@oldEmailId", oldEmailId),
                new SqlParameter("@storeName", SubDomain),
                new SqlParameter("@email", email),
                new SqlParameter("@username", username));
                return 1;
            }
        }
        public static ChangePasswordSettings GetMainSitePasswordInfo(string email)
        {
            ChangePasswordSettings changePasswordSettings = new ChangePasswordSettings();
            try
            {
                using (var dbContext = new Sites4Entities())
                {
                    changePasswordSettings = dbContext.Database.SqlQuery<ChangePasswordSettings>("GetMainSitePasswordInfo @email,@dbPrefix",
                         new SqlParameter("@dbPrefix", MultisiteHelper.ApplicationName),
                    new SqlParameter("@email", email)).FirstOrDefault();
                    return changePasswordSettings;
                }
            }
            catch
            {
                return changePasswordSettings;
            }
        }

        public static int UpdateMainSitePasswordByEmail(string email, string password)
        {
            try
            {
                using (var dbContext = new Sites4Entities())
                {
                    dbContext.Database.ExecuteSqlCommand(
            "UpdateMainSitePasswordByEmail @email, @dbPrefix, @password",
            new SqlParameter("@dbPrefix", MultisiteHelper.ApplicationName),
                    new SqlParameter("@email", email),
                    new SqlParameter("@password", password));
                    return 1;
                }
            }
            catch
            {
                return 0;
            }
        }

        public static int GetStoreTrialDaysLeft(DateTime storeCreatedDate)
        {
            int StoreTrialDaysLeft = 14;
            if (!string.IsNullOrEmpty(System.Configuration.ConfigurationManager.AppSettings["StoreTrialDaysLeft"]))
            {
                StoreTrialDaysLeft = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["StoreTrialDaysLeft"]);
            }

             var totalDays = DateTime.UtcNow.Subtract(storeCreatedDate).TotalDays;
            int resultDays = (int)Math.Ceiling(StoreTrialDaysLeft - totalDays);
            return (resultDays) > 0 ? resultDays : 0;
        }

        // latest
        public static int GetStorePlanDaysLeft(DateTime PlanExpirationDate)
        {
            if (PlanExpirationDate != null)
            {
                var resultDays = (int)PlanExpirationDate.Subtract(DateTime.UtcNow).TotalDays;
                return (resultDays) > 0 ? resultDays : 0;
            }
            return 0;
        }

    }
}