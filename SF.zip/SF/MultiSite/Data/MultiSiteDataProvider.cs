﻿using System;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Hosting;
using System.Web.Security;
using MultiSite.Data;
using Nop.Core.Data;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Configuration;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Logging;
using Nop.Core.Domain.Media;
using Nop.Core.Domain.Stores;
using Nop.Core.Infrastructure;
using Nop.Services.Customers;

namespace Nop.Data
{
    public class MultiSiteDataProvider
    {
        #region Fields

        public static readonly string App_data = HostingEnvironment.MapPath("~/App_Data/");
        public static readonly string settingsFilename = "Settings.txt";

        #endregion

        #region Methods

        public static void ConfigureStoreDatabase(string storeName, string connectionString, string adminEmail, string adminPassword, string theme, HttpPostedFileBase logo)
        {
            int logoPictureId = 0;
            // For print Logo
            //int logopictureidforprinting = 0;
            //------------------------
            theme = string.IsNullOrEmpty(theme) ? MultisiteHelper.DefaultTheme : theme;
            using (var dbContext = new MultisiteObjectContext(connectionString, true))
            {
                /* Sets admin customer details */
                //var admin = dbContext.Set<Customer>().Single(c => c.Id == 1);
                var admin = dbContext.Set<Customer>().FirstOrDefault();
                admin.Email = admin.Username = adminEmail;
                var passwordObj = dbContext.Set<CustomerPassword>().FirstOrDefault();
                //passwordObj.Password = CreatePasswordHash(adminPassword, passwordObj.PasswordSalt);

                if(string.IsNullOrEmpty(adminPassword))
                {
                    var customerService = EngineContext.Current.Resolve<ICustomerService>();

                    var customer = customerService.GetCustomerByEmail(adminEmail);
                    var currentPassword = customerService.GetCurrentPassword(customer.Id);

                    passwordObj.Password = currentPassword.Password;
                    passwordObj.PasswordFormatId = currentPassword.PasswordFormatId;
                    passwordObj.PasswordSalt = currentPassword.PasswordSalt;
                }
                else
                {
                    passwordObj.Password = adminPassword;
                }

                // Set store details
                var store = dbContext.Set<Store>().FirstOrDefault();
                store.SslEnabled = true;
                store.Url = string.Format("http://{0}.{1}", storeName, MultisiteHelper.Domain);
                store.Hosts = string.Format("{0}.{1}", storeName, MultisiteHelper.Domain);

                /* Sets store settings. */
                dbContext.Set<Setting>().Single(s => s.Name == "seosettings.defaulttitle").Value = storeName;
                dbContext.Set<Setting>().Single(s => s.Name == "storeinformationsettings.storename").Value = storeName;
                dbContext.Set<Setting>().Single(s => s.Name == "storeinformationsettings.storeurl").Value = string.Format("{0}.{1}", storeName, MultisiteHelper.Domain);

                // Set security settings
                dbContext.Set<Setting>().Single(s => s.Name == "securitysettings.forcesslforallpages").Value = "True";

                if (string.IsNullOrEmpty(dbContext.Set<Setting>().Single(s => s.Name == "storeinformationsettings.defaultstoretheme").Value))
                {
                    dbContext.Set<Setting>().Single(s => s.Name == "storeinformationsettings.defaultstoretheme").Value = theme;
                }                
                /* Sets store logo picture */
                Picture storeLogoPicture;
                if (logo == null || logo.ContentLength == 0)
                {
                    var logoData =
                        File.ReadAllBytes(HttpContext.Current.Server.MapPath(string.Format(@"~/Content/Images/multiSite/default-logo.jpg")));

                    storeLogoPicture = new Picture
                    {
                        PictureBinary = logoData,
                        MimeType = "image/jpeg"
                    };
                    dbContext.Set<Picture>().Add(storeLogoPicture);
                }
                else
                {
                    var logoData = new byte[logo.ContentLength];
                    logo.InputStream.Read(logoData, 0, logo.ContentLength);
                    storeLogoPicture = new Picture
                    {
                        PictureBinary = logoData,
                        MimeType = logo.ContentType
                    };
                    dbContext.Set<Picture>().Add(storeLogoPicture);
                }

                dbContext.SaveChanges();
                logoPictureId = storeLogoPicture.Id;
            }

            using (var dbContext = new MultisiteObjectContext(connectionString, true))
            {
                // websitelogosettings.logopictureid is comming from "Shopfast.Plugin.Misc.WebsiteLogo" Plugin which is already set the Logo
                var logoSetting = dbContext.Set<Setting>().SingleOrDefault(s => s.Name == "websitelogosettings.logopictureid")
                    ?? dbContext.Set<Setting>().Add(new Setting { Name = "websitelogosettings.logopictureid" });
                logoSetting.Value = logoPictureId.ToString();
                dbContext.SaveChanges();
            }

            // For print Logo
            //using (var dbContext = new MultisiteObjectContext(connectionString, true))
            //{
            //    var logoSetting = dbContext.Set<Setting>().SingleOrDefault(s => s.Name == "storeinformationsettings.logopictureidforprinting")
            //        ?? dbContext.Set<Setting>().Add(new Setting { Name = "storeinformationsettings.logopictureidforprinting" });
            //    logoSetting.Value = logopictureidforprinting.ToString();
            //    dbContext.SaveChanges();
            //}
            //------------------------
        }

        static string CreatePasswordHash(string password, string saltkey, string passwordFormat = "SHA1")
        {
            if (String.IsNullOrEmpty(passwordFormat))
                passwordFormat = "SHA1";
            string saltAndPassword = String.Concat(password, saltkey);
            string hashedPassword =
                FormsAuthentication.HashPasswordForStoringInConfigFile(
                    saltAndPassword, passwordFormat);
            return hashedPassword;
        }

        public static int GetLeftDaysOfTrial()
        {
#if(DEBUG)
            return 1;
#else
            if (MultisiteHelper.IsAdminSite)
                return int.MaxValue;

            using (var dbContext = new Sites4Entities())
            {
                var storeSite = dbContext.Sites.SingleOrDefault(site => site.StoreName.ToLower() == MultisiteHelper.SubDomain.ToLower());
                if (storeSite.IsOrder.Value)
                    return int.MaxValue;

                var totalDays = DateTime.UtcNow.Subtract(storeSite.CreationDate).TotalDays;
                return (int)Math.Ceiling(MultisiteHelper.TrialDayCount - totalDays);
            }
#endif
        }

        public static Picture GetLogo(string storeConnectionString)
        {
            using (var dbContext = new MultisiteObjectContext(storeConnectionString, true))
            {
                // websitelogosettings.logopictureid is comming from "Shopfast.Plugin.Misc.WebsiteLogo" Plugin which is already set the Logo
                var pictureId = dbContext.Set<Setting>().Where(setting => setting.Name == "websitelogosettings.logopictureid")
                                             .Select(setting => setting.Value).DefaultIfEmpty("0").First();
                if (pictureId == "0")
                {
                    return new Picture
                    {
                        PictureBinary = File.ReadAllBytes(HttpContext.Current.Server.MapPath(@"~/Content\Images\multisite/Logo.png")),
                        MimeType = "image/png"
                    };
                }
                else
                {
                    var logoPictureId = int.Parse(pictureId);
                    var imgLogo = dbContext.Set<Picture>().Single(picture => picture.Id == logoPictureId);
                   
                    return imgLogo;
                }
            }
        }

        // For print Logo
        public static Picture GetPrintLogo(string storeConnectionString)
        {
            using (var dbContext = new MultisiteObjectContext(storeConnectionString, true))
            {
                var pictureId = dbContext.Set<Setting>().Where(setting => setting.Name == "storeinformationsettings.logopictureidforprinting")
                                             .Select(setting => setting.Value).DefaultIfEmpty("0").First();
                if (pictureId == "0")
                {
                    return new Picture
                    {
                        PictureBinary = File.ReadAllBytes(HttpContext.Current.Server.MapPath(@"~/Content\Images\multisite/Logo_Print.jpg")),
                        MimeType = "image/png"
                    };
                }
                else
                {
                    var logoPictureId = int.Parse(pictureId);
                    var imgLogo = dbContext.Set<Picture>().Single(picture => picture.Id == logoPictureId);
                    return imgLogo;
                }
            }
        }
        //------------------------

        public static int GetSiteProductCount()
        {
            if (!MultisiteHelper.IsAdminSite)
                return 0;

            using (var dbContext = new MultisiteObjectContext(MultisiteHelper.AdminConnectionString, true))
            {
                return dbContext.Set<Product>().Count(product => product.Published);
            }
        }

        public static bool IsLogoExists(string storeConnectionString)
        {
            using (var dbContext = new MultisiteObjectContext(storeConnectionString, true))
            {
                // websitelogosettings.logopictureid is comming from "Shopfast.Plugin.Misc.WebsiteLogo" Plugin which is already set the Logo
                var logoPictureId = dbContext.Set<Setting>().Where(setting => setting.Name == "websitelogosettings.logopictureid")
                                             .Select(setting => setting.Value).DefaultIfEmpty("0").First();
                if (logoPictureId == "0" || logoPictureId == "88")
                    return false;
                else
                    return true;
            }
        }

        // For print Logo
        public static bool IsPrintLogoExists(string storeConnectionString)
        {
            using (var dbContext = new MultisiteObjectContext(storeConnectionString, true))
            {
                var logoPictureId = dbContext.Set<Setting>().Where(setting => setting.Name == "storeinformationsettings.logopictureidforprinting")
                                             .Select(setting => setting.Value).DefaultIfEmpty("0").First();
                if (logoPictureId == "0" || logoPictureId == "88")
                    return false;
                else
                    return true;
            }
        }
        //---------------------------------------
        public static bool IsTrial()
        {
#if(DEBUG)
            return true;
#else
            if (MultisiteHelper.IsAdminSite)
                return false;

            using (var dbContext = new Sites4Entities())
            {
                var storeSite = dbContext.Sites.SingleOrDefault(site => site.StoreName.ToLower() == MultisiteHelper.SubDomain.ToLower());
                if (storeSite.IsOrder != null && storeSite.IsOrder.HasValue)
                    return !storeSite.IsOrder.Value;
                else
                    return true;
            }
#endif
        }

        public static void LogToAdminDatabase(string message)
        {
            using (var dbContext = new MultisiteObjectContext(MultisiteHelper.AdminConnectionString, true))
            {
                dbContext.Set<Log>().Add(new Log
                {
                    ShortMessage = message,
                    CreatedOnUtc = DateTime.UtcNow,
                    LogLevel = LogLevel.Debug
                });
                dbContext.SaveChanges();
            }
        }

        public static void RenameSite(int siteId, string storeName)
        {
            using (var dbContext = new Sites4Entities())
            {
                var storeSite = dbContext.Sites.SingleOrDefault(site => site.Id == siteId);
                if (storeSite == null)
                    throw new Exception("No site found with Id " + siteId.ToString());

                if (dbContext.Sites.Any(site => site.Id != siteId && site.StoreName == storeName))
                    throw new Exception("This name already used: " + storeName);

                var oldStoreSettingsFilename = Path.Combine(App_data,
                    string.Format("{0}{1}", storeSite.StoreName, settingsFilename));
                
                var newStoreSettingsFilename = Path.Combine(App_data,
                    string.Format("{0}{1}", storeName, settingsFilename));

                File.Move(oldStoreSettingsFilename, newStoreSettingsFilename);
                storeSite.StoreName = storeName;

                dbContext.SaveChanges();
            }
        }

        #endregion
    }
}
