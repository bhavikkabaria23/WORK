﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;

namespace MultiSite.Data
{
    [Table("SitesPlugins")]
    public class SitesPlugins
    {
        public DateTime CreationDate
        {
            get;
            set;
        }

        public int Id
        {
            get;
            set;
        }

        public bool IsDefault
        {
            get;
            set;
        }

        public string StoreName
        {
            get;
            set;
        }

        public string SystemName
        {
            get;
            set;
        }

        public SitesPlugins()
        {
        }
    }
}