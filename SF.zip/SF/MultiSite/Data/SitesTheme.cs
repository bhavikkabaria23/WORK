﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace MultiSite.Data
{
    [Table("SitesTheme")]
    public class SitesTheme
    {
        public int Id { get; set; }

        public string StoreName { get; set; }
        
        public string TemplateName { get; set; }

        public string ThemeName { get; set; }        

        public bool IsMobileTheme { get; set; }

        public DateTime CreationDate { get; set; }

    }
}
