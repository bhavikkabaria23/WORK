﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace MultiSite.Data
{
    [Table("Sites")]
    public class Site
    {
        public int Id { get; set; }
        public int? ParentId { get; set; }
        
        public string StoreName { get; set; }
        
        public DateTime CreationDate { get; set; }
        
        public bool? IsOrder { get; set; }
        
        public bool deleted { get; set; }

        public int PackageProductId { get; set; }

        [ForeignKey("Owner")]
        public int Owner_Id { get; set; }

        public string DbName { get; set; }

        public Owner Owner { get; set; }

        // When transaction declined any any reason from Store Recuring process. store will be suspend and no one can see home page
        public bool IsSuspend { get; set; }
    }

    // For All Sites Order Totals
    public class SiteOrderDetails
    {
        public int siteid { get; set; }
        public string dbname { get; set; }
        public decimal todayTotal { get; set; }
        public decimal weekTotal { get; set; }
        public decimal monthTotal { get; set; }
        public decimal yearTotal { get; set; }
        public decimal allTotal { get; set; }
        public decimal avgOrder { get; set; }
        public int orderCount { get; set; }
    }
}
