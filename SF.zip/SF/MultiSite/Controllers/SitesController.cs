﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Nop.Core.Data;
using System.Web.Hosting;
using System.Data.SqlClient;
using System.Web.Configuration;
using Nop.Core.Infrastructure;
using Nop.Services.Authentication;
using Nop.Services.Customers;
using Nop.Data;
using System.Text.RegularExpressions;
using System.Data.Common;
using MultiSite.Models;
using MultiSite.Data;
using MultiSite.Files;
using Nop.Core.Domain.Customers;
//using Nop.Web.Framework.Themes;
using MultiSite.Models.SiteTheme;
using System.Data;
using MultiSite.Kendoui;

namespace Nop.Admin.Controllers
{
    public class SitesController : Controller
    {
        #region Properties

        public int DaysLeft
        {
            get
            {
                if (Session["DaysLeft"] == null)
                {
                    Session["DaysLeft"] = MultiSiteDataProvider.GetLeftDaysOfTrial();
                }
                return (int)Session["DaysLeft"];
            }
        }

        public bool IsTrial
        {
            get
            {
                if (Session["IsTrial"] == null)
                {
                    Session["IsTrial"] = MultiSiteDataProvider.IsTrial();
                }
                return (bool)Session["IsTrial"];
            }
        }

        public DateTime PopupShownLast
        {
            get
            {
                if (Session["PopupShownLast"] == null)
                {
                    Session["PopupShownLast"] = DateTime.MinValue;
                }
                return (DateTime)Session["PopupShownLast"];
            }
            set
            {
                Session["PopupShownLast"] = value;
            }
        }

        #endregion

        #region Action Methods

        public ActionResult Index()
        {
            return RedirectToAction("List");
        }

        public ActionResult List()
        {
            if (!IsAdminUser())
            {
                return AccessDeniedView();
            }

            if (!MultisiteHelper.IsAdminSite)
                return HttpNotFound();

            var model = new SiteListModel();
            // For All Sites Order Totals        
            List<SiteOrderDetails> lstSitesOrder = SiteListModel.GetSiteOrderDetails();
            model.todayTotalAllSites = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                      FormatPrice(Math.Round(lstSitesOrder.Sum(so => so.todayTotal), 2));
            model.weekTotalAllSites = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                FormatPrice(Math.Round(lstSitesOrder.Sum(so => so.weekTotal), 2));
            model.monthTotalAllSites = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                FormatPrice(Math.Round(lstSitesOrder.Sum(so => so.monthTotal), 2));
            model.yearTotalAllSites = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                FormatPrice(Math.Round(lstSitesOrder.Sum(so => so.yearTotal), 2));
            model.allTotalAllSites = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                FormatPrice(Math.Round(lstSitesOrder.Sum(so => so.allTotal), 2));
            model.totalSites = SiteListModel.Total("", null, null);
            model.avgTotalAllSites = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                FormatPrice(Math.Round((lstSitesOrder.Sum(so => so.avgOrder / model.totalSites)), 2));
            model.avgTotal = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                FormatPrice(Math.Round((lstSitesOrder.Sum(so => so.avgOrder)), 2));
            //-------------------------------------

            return View(model);
        }

        public ActionResult SiteList(DataSourceRequest command, SiteListModel model)
        {
            if (!IsAdminUser())
            {
                return AccessDeniedView();
            }
            if (!MultisiteHelper.IsAdminSite)
                return HttpNotFound();
            // For All Sites Order Totals        
            List<SiteOrderDetails> lstSitesOrder = SiteListModel.GetSiteOrderDetails();
            var sites = SiteListModel.SearchSites(model.CustomerEmail, command.Page - 1, command.PageSize,
                model.StartDate, model.EndDate, lstSitesOrder);
            //-----------------------------
            var gridModel = new DataSourceResult
            {
                Data = sites,
                Total = SiteListModel.Total(model.CustomerEmail, model.StartDate, model.EndDate)
            };
            return Json(gridModel);
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult DeleteSite(DataSourceRequest command, SiteListModel model, int id)
        {
            if (!IsAdminUser())
                return null;

            try
            {
                string App_data = HostingEnvironment.MapPath("~/App_Data/");
                using (var dbContext = new Sites4Entities())    
                {
                    var store = dbContext.Sites.Include("Owner").SingleOrDefault(s => s.Id == id);
                    if (store != null)
                    {
                        MultisiteHelper.RemoveConnectionString(store.StoreName);
                        dbContext.Owners.Remove(store.Owner);
                        dbContext.SaveChanges();
                        MultisiteHelper.ResetSites();

                        var creatorConnStr = WebConfigurationManager.ConnectionStrings["MasterCatalog"].ConnectionString;
                        var settings = new MultisiteDataSettingsManager().LoadSettings(store.StoreName);
                        DbConnectionStringBuilder builder = new DbConnectionStringBuilder();
                        builder.ConnectionString = settings.DataConnectionString;
                        var dbName = builder["initial catalog"] as string;
                        using (var dbConnection = new SqlConnection(creatorConnStr))
                        {
                            dbConnection.Open();

                            var dbCommand = new SqlCommand(string.Format(@"EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N'{0}'", dbName), dbConnection);
                            dbCommand.ExecuteNonQuery();

                            dbCommand = new SqlCommand(string.Format(@"ALTER DATABASE [{0}] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE", dbName), dbConnection);
                            dbCommand.ExecuteNonQuery();

                            dbCommand = new SqlCommand(string.Format(@"DROP DATABASE [{0}]", dbName), dbConnection);
                            dbCommand.ExecuteNonQuery();

                            dbConnection.Close();
                        }

                        System.IO.File.Delete(string.Format(@"{0}\{1}Settings.txt", App_data, store.StoreName));
                    }
                }
            }
            catch (Exception ex)
            {
                MultiSiteDataProvider.LogToAdminDatabase("Delete site: " + ex.Message);
                throw;
            }
            // For All Sites Order Totals        
            List<SiteOrderDetails> lstSitesOrder = SiteListModel.GetSiteOrderDetails();
            var sites = SiteListModel.SearchSites(model.CustomerEmail, 0, 0, model.StartDate, model.EndDate, lstSitesOrder);
            //-----------------------------            
            var gridModel = new DataSourceResult
            {
                Data = sites,
                Total = SiteListModel.Total(model.CustomerEmail, model.StartDate, model.EndDate)
            };

            return View(gridModel);
        }

        [HttpPost]
        public ActionResult Rename(int Id, string storeName)
        {
            if (storeName.StartsWith("http://", StringComparison.InvariantCultureIgnoreCase))
            {
                storeName = storeName.Substring(7);
            }
            if (storeName.EndsWith("/"))
            {
                storeName = storeName.TrimEnd('/');
            }
            if (!Regex.IsMatch(storeName, @"^\w{2,15}$") && !Regex.IsMatch(storeName, @"^([\w-]+\.)+[\w-]+$"))
            {
                return Json(new { error = true, msg = "Store name is incorrect" });
            }
            else
            {
                try
                {
                    MultiSiteDataProvider.RenameSite(Id, storeName);
                    MultisiteHelper.ResetSites();
                }
                catch (Exception ex)
                {
                    return Json(new { error = true, msg = ex.Message });
                }
                return Json(new { error = false, msg = "OK" });
            }
        }
                
        #endregion

        #region Methods

        bool IsAdminUser()
        {
#if (DEBUG)
            return true;
#else
            var _authenticationService = EngineContext.Current.Resolve<IAuthenticationService>();
            var customer = _authenticationService.GetAuthenticatedCustomer();
            return (customer != null && customer.IsAdmin());
#endif
        }

        #endregion



        protected ActionResult AccessDeniedView()
        {
            //return new HttpUnauthorizedResult();
            //return RedirectToAction("AccessDenied", "Security", new { pageUrl = this.Request.RawUrl });
            return RedirectToAction("Login", "Customer", new { Area = "", ReturnUrl = this.Request.RawUrl });
        }

        public ActionResult SiteDetails(int id)
        {
            if (!IsAdminUser())
            {
                return AccessDeniedView();
            }

            return View(SiteListModel.GetById(id));
        }

        public ActionResult Expired()
        {
            if (IsTrial && DaysLeft <= MultisiteHelper.TrialLeftDaysStartShowPopup
                && PopupShownLast < DateTime.Now.Subtract(MultisiteHelper.ShowPopupInterval))
            {
                PopupShownLast = DateTime.Now;
                ViewData["days"] = DaysLeft;
                ViewData["StoreName"] = string.Format(@"{0}.{1}", MultisiteHelper.SubDomain, MultisiteHelper.Domain);
                return PartialView("Expired");

            }

            return Content("");
            //return Content(string.Format("popupShownLast: {0}; diff: {1}; sub: {2}; ShowPopupInterval: {3}",
            //    popupShownLast, DateTime.Now.Subtract(popupShownLast), DateTime.Now.Subtract(MultisiteHelper.ShowPopupInterval), MultisiteHelper.ShowPopupInterval));
        }


        //Admin menu based on super admin and user - add "adminType" parameter
        public ActionResult GoSiteAdmin(int Id,string adminType)
            //-----------------------
        {
            if (!IsAdminUser())
            {
                return AccessDeniedView();
            }
            if (!MultisiteHelper.IsAdminSite)
                return HttpNotFound();

            var site = SiteListModel.GetById(Id);
            if (site == null)
            {
                return HttpNotFound();
            }
            var storeUrl = site.storeName.Contains('.') ? site.storeName
                                : string.Format(@"{0}.{1}", site.storeName, MultisiteHelper.Domain);
            var guid = Guid.NewGuid();
            MultisiteHelper.TempLoginGuids.Add(guid, new MultisiteHelper.LoginInfo { StoreName = site.storeName });

            //Admin menu based on super admin and user - add "adminType" parameter
            if (!string.IsNullOrEmpty(adminType))
            {
                return Redirect(string.Format("http://{0}/Merchant/TmpAdmin?guid={1}&adminType={2}", storeUrl, guid, adminType));

            }
            else
            {
                return Redirect(string.Format("http://{0}/Merchant/TmpAdmin?guid={1}", storeUrl, guid));
            }
            //Admin menu based on super admin and user - add "adminType" parameter

        }
    }
}
