﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nop.Core.Domain.Orders;
using Nop.Core.Events;
using Nop.Core.Data;
using Nop.Web.Models.SiteRegistration;
using MultiSite.Models;
using Nop.Services.Events;
using MultiSite.Data;

namespace MultiSite
{
    public class SiteProcessing : IConsumer<OrderPaidEvent>
    {
        public void HandleEvent(OrderPaidEvent orderPaidEvent)
        {
            if (MultisiteHelper.IsAdminSite)
            {
                // not in used
            }
        }
    }
}
