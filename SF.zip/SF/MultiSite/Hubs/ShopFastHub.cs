﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNet.SignalR;

namespace MultiSite.Hubs
{
    public class ShopFastHub : Hub
    {
        #region Fields

        private static IHubContext _hubContext = GlobalHost.ConnectionManager.GetHubContext<ShopFastHub>();
        private readonly static ConnectionMapping<string> _connections =
            new ConnectionMapping<string>();

        #endregion

        #region Properties

        public static ConnectionMapping<string> Connections
        {
            get { return _connections; }
        }

        #endregion

        #region Methods

        public override Task OnConnected()
        {
            var userName = Context.User.Identity.Name;
            _connections.Add(userName, Context.ConnectionId);

            return base.OnConnected();
        }

        public override Task OnDisconnected(bool stopCalled)
        {
            var clientId = Context.ConnectionId;
            _connections.Remove(clientId, Context.ConnectionId);

            return base.OnDisconnected(stopCalled);
        }

        public override Task OnReconnected()
        {
            var clientId = Context.ConnectionId;
            if (!_connections.GetConnections(clientId).Contains(Context.ConnectionId))
            {
                _connections.Add(clientId, Context.ConnectionId);
            }

            return base.OnReconnected();
        }

        public static void CreateStoreProcess(string emailId, string message)
        {
            _hubContext.Clients.All.CreateStoreProcess(emailId, message);
        }

        #endregion
    }
}
