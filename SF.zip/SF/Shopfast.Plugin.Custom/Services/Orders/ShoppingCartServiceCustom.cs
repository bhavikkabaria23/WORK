﻿using Nop.Core.Data;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Orders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Services.Orders
{    
    
    public class ShoppingCartServiceCustom : IShoppingCartServiceCustom
    {
        #region Fields
        private readonly IRepository<ShoppingCartItem> _sciRepository;
        #endregion

        #region Ctor
        public ShoppingCartServiceCustom(IRepository<ShoppingCartItem> sciRepository)
        {
            this._sciRepository = sciRepository;
        }
        #endregion
        public virtual void DeleteShoppingCartItemForCustomer(Customer customer)
        {
            var query = from sci in _sciRepository.Table
                        where sci.CustomerId == customer.Id
                        select sci;

            if (query != null && query.Any())
            {
                var cartItems = query.ToList();
                foreach (var cartItem in cartItems)
                    _sciRepository.Delete(cartItem);
            }
        }
    }
}