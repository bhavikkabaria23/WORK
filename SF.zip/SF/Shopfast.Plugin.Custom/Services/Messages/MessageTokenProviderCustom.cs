﻿using Nop.Core.Domain.Customers;
using Nop.Services.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Nop.Services.Customers;
using Nop.Core.Domain.Tax;
using Nop.Services.Common;
using Nop.Services.Stores;
using Nop.Services.Events;
using Nop.Core;
using MultiSite.Data;

namespace Shopfast.Plugin.Custom.Services.Messages
{
    public class MessageTokenProviderCustom : IMessageTokenProviderCustom
    {

         #region Fields
        private readonly IStoreService _storeService;
        private readonly IStoreContext _storeContext;
        private readonly IEventPublisher _eventPublisher;

        #endregion

        #region Ctor

        public MessageTokenProviderCustom(     
            IStoreService storeService,
            IStoreContext storeContext,
            IEventPublisher eventPublisher)
        {           
            this._storeService = storeService;       
            this._eventPublisher = eventPublisher;
            this._storeContext = storeContext;
        }

        #endregion

        #region Utilities
        /// <summary>
        /// Get store URL
        /// </summary>
        /// <param name="storeId">Store identifier; Pass 0 to load URL of the current store</param>
        /// <param name="useSsl">Use SSL</param>
        /// <returns></returns>
        protected virtual string GetStoreUrl(int storeId = 0, bool useSsl = false)
        {
            var store = _storeService.GetStoreById(storeId) ?? _storeContext.CurrentStore;

            if (store == null)
                throw new Exception("No store could be loaded");

            return useSsl ? store.SecureUrl : store.Url;
        }
        #endregion

        #region Methods
        public virtual void AddCustomerTokens(IList<Token> tokens, Customer customer ,bool showDemoSite = false)
        {
            tokens.Add(new Token("Customer.Email", customer.Email));
            tokens.Add(new Token("Customer.Username", customer.Username));
            tokens.Add(new Token("Customer.FullName", customer.GetFullName()));
            tokens.Add(new Token("Customer.FirstName", customer.GetAttribute<string>(SystemCustomerAttributeNames.FirstName)));
            tokens.Add(new Token("Customer.LastName", customer.GetAttribute<string>(SystemCustomerAttributeNames.LastName)));
            tokens.Add(new Token("Customer.VatNumber", customer.GetAttribute<string>(SystemCustomerAttributeNames.VatNumber)));
            tokens.Add(new Token("Customer.VatNumberStatus", ((VatNumberStatus)customer.GetAttribute<int>(SystemCustomerAttributeNames.VatNumberStatusId)).ToString()));



            //note: we do not use SEO friendly URLS because we can get errors caused by having .(dot) in the URL (from the email address)
            //TODO add a method for getting URL (use routing because it handles all SEO friendly URLs)
            string passwordRecoveryUrl = string.Format("{0}passwordrecovery/confirm?token={1}&email={2}", GetStoreUrl(), customer.GetAttribute<string>(SystemCustomerAttributeNames.PasswordRecoveryToken), HttpUtility.UrlEncode(customer.Email));
            string accountActivationUrl = string.Empty;
            //Sign up form  - Demo site
            if (showDemoSite)
            {
                accountActivationUrl = string.Format("{0}customer/activation?token={1}&email={2}&showDemoSite={3}",GetStoreUrl(), customer.GetAttribute<string>(SystemCustomerAttributeNames.AccountActivationToken), HttpUtility.UrlEncode(customer.Email), showDemoSite);
            }
            else
            {
                accountActivationUrl = string.Format("{0}customer/activation?token={1}&email={2}", GetStoreUrl(), customer.GetAttribute<string>(SystemCustomerAttributeNames.AccountActivationToken), HttpUtility.UrlEncode(customer.Email));
            }
            var wishlistUrl = string.Format("{0}wishlist/{1}", GetStoreUrl(), customer.CustomerGuid);
            tokens.Add(new Token("Customer.PasswordRecoveryURL", passwordRecoveryUrl, true));
            tokens.Add(new Token("Customer.AccountActivationURL", accountActivationUrl, true));
            tokens.Add(new Token("Wishlist.URLForCustomer", wishlistUrl, true));

            //event notification
            _eventPublisher.EntityTokensAdded(customer, tokens);
        }

        public virtual void AddErrorMessageTokens(IList<Token> tokens, string url)
        {
            tokens.Add(new Token("ErrorPage.URL", url));
        }

        public virtual void AddStoreOwnerOrderTokens(IList<Token> tokens, SiteOrders siteOrder,string planPrice)
        {
            tokens.Add(new Token("StoreOwner.StoreName", siteOrder.StoreName));
            tokens.Add(new Token("StoreOwner.OwnerEmail", siteOrder.OwnerEmail));
            tokens.Add(new Token("StoreOwner.PackageName", siteOrder.PackageName));
            tokens.Add(new Token("StoreOwner.PackagePrice", planPrice));
            tokens.Add(new Token("StoreOwner.PlanExpirationDate", siteOrder.PlanExpirationDate));
            tokens.Add(new Token("StoreOwner.CreationDate", siteOrder.CreationDate));            
        }
        #endregion
    }
}