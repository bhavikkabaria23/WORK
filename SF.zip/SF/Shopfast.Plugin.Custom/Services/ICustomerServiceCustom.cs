﻿using Nop.Core.Domain.Customers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Services
{
    public interface ICustomerServiceCustom
    {
        Customer GetAdminCustomer();

        /// <summary>
        /// Delete a customer permanently
        /// </summary>
        /// <param name="customer">Customer</param>
        void DeleteCustomerPermanent(Customer customer);
    }
}