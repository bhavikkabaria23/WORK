﻿using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Services.Logging;
using Nop.Services.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Services
{
    public class TestTaskDemo : ITask
    {
        private readonly ILogger _logger;

        public TestTaskDemo(ILogger logger)
        {
            this._logger = logger;
        }

        /// <summary>
        /// Executes a task
        /// </summary>
        public virtual void Execute()
        {
            try
            {
                var dbContext = EngineContext.Current.Resolve<IDbContext>();
                dbContext.ExecuteSqlCommand("insert into TestTask (LastRunDate) values(@p0)", false, null,
                  DateTime.Now);
                _logger.Information("Test Task Run successfully at "+ DateTime.Now.ToString());
            }

            catch (Exception exc)
            {
                _logger.Error(string.Format("Error when running Test Task Demo. {0}", exc.Message), exc);
            }
        }
    }
}