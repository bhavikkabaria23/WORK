﻿using Nop.Core;
using Nop.Core.Data;
using Nop.Core.Domain.Customers;
using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Services.Customers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Services
{
    public class CustomerServiceCustom : ICustomerServiceCustom
    {
        public virtual Customer GetAdminCustomer()
        {
            IDbContext dbContext = EngineContext.Current.Resolve<IDbContext>();
            Customer customer = dbContext.SqlQuery<Customer>("sp_GetAdminCustomer").FirstOrDefault();
            return customer;
        }

        /// <summary>
        /// Delete a customer permanently
        /// </summary>
        /// <param name="customer">Customer</param>
        public virtual void DeleteCustomerPermanent(Customer customer)
        {
            if (customer == null)
                throw new ArgumentNullException("customer");

            if (customer.IsSystemAccount)
                throw new NopException(string.Format("System customer account ({0}) could not be deleted", customer.SystemName));

            //foreach (var role in customer.CustomerRoles)
            //{
            //    EngineContext.Current.Resolve<ICustomerService>().DeleteCustomerRole(role);
            //}
            EngineContext.Current.Resolve<IRepository<Customer>>().Delete(customer);
        }
    }
}