﻿using MultiSite.Data;
using Nop.Core.Domain.Orders;
using Shopfast.Plugin.Custom.Models.NopAdmin.Catalog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Services.SchedueTaskCustom
{
    public interface IRecuringPlansService
    {
        void ReOrderChecoutMultiple(List<Order> orders, AppProductListModel product, int months, List<SiteOrders> siteOrders, List<Owner> owners);

        bool ReOrderChecoutSingle(AppProductListModel product, int months, SiteOrders currentSiteOrder, Owner owner);
    }
}