﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using Nop.Web.Framework.Mvc.Routes;

namespace Shopfast.Plugin.Custom.Infrastructure
{
    public class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(RouteCollection routes)
        {
            ViewEngines.Engines.Insert(0, new PluginViewEngine());
            //routes.MapRoute("barcodeview",
            //   "admin/product/barcodeview/{productId}",
            //   new { controller = "ProductCustomAdmin", action = "BarcodeView" },
            //   new[] { "Shopfast.Plugin.Custom.Controllers" }
            //   ).DataTokens.Add("area", "admin");

            //routes.MapRoute("showonpointofsaleview",
            // "admin/product/showonpointofsaleview/{productId}",
            // new { controller = "ProductCustomAdmin", action = "ShowOnPointOfSaleView" },
            // new[] { "Shopfast.Plugin.Custom.Controllers" }
            // ).DataTokens.Add("area", "admin");
            #region Admin

            #region Product Custom Admin Controller
            var route = routes.MapRoute("GetBarcodePath",
               "admin/product/GetBarcodePath/{number}/{barcodeSymbology}",
               new { controller = "ProductCustomAdmin", action = "GetBarcodePath" },
               new[] { "Shopfast.Plugin.Custom.Controllers" });
            route.DataTokens.Add("area", "");
            routes.Remove(route);
            routes.Insert(0, route);

            route = routes.MapRoute("showonpointofsaleview",
             "admin/product/showonpointofsaleview/{productId}",
             new { controller = "ProductCustomAdmin", action = "ShowOnPointOfSaleView" },
             new[] { "Shopfast.Plugin.Custom.Controllers" }
             );
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);

            route = routes.MapRoute("barcodeview",
               "admin/product/barcodeview/{productId}",
               new { controller = "ProductCustomAdmin", action = "BarcodeView" },
               new[] { "Shopfast.Plugin.Custom.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);

            route = routes.MapRoute("barcodeview",
             "admin/product/ProductList",
             new { controller = "ProductCustomAdmin", action = "ProductList" },
             new[] { "Shopfast.Plugin.Custom.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);

            route = routes.MapRoute("ProductGtinView",
              "admin/product/ProductGtinView",
              new { controller = "ProductCustomAdmin", action = "ProductGtinView" },
              new[] { "Shopfast.Plugin.Custom.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);         

            #region AdminThemeSelectionView
            route = routes.MapRoute("AdminThemeSelectionView",
             "admin/setting/AdminThemeSelectionView",
             new { controller = "SettingAdminCustom", action = "AdminThemeSelectionView" },
             new[] { "Shopfast.Plugin.Custom.Controllers" }
             );
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);
            #endregion         

            #endregion

            #region Order Custom Admin Controller
            route = routes.MapRoute("OrderTempIdView",
               "admin/order/OrderTempIdView/{orderId}",
               new { controller = "OrderCustomAdmin", action = "OrderTempIdView" },
               new[] { "Shopfast.Plugin.Custom.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);

            route = routes.MapRoute("SignatureView",
              "admin/order/SignatureView/{orderId}",
              new { controller = "OrderCustomAdmin", action = "SignatureView" },
              new[] { "Shopfast.Plugin.Custom.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);
            #endregion

            #region PaymentAdminCustomController
            route = routes.MapRoute("paymentmethods",
           "admin/payment/paymetnmethods",
           new { controller = "PaymentAdminCustom", action = "Methods" },
           new[] { "Shopfast.Plugin.Custom.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);

            route = routes.MapRoute("paymentMethodUpdate",
        "admin/payment/paymentMethodUpdate",
        new { controller = "PaymentAdminCustom", action = "MethodUpdate" },
        new[] { "Shopfast.Plugin.Custom.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);

            route = routes.MapRoute("paymentMethodMarkPrimary",
      "admin/payment/paymentMethodMarkPrimary",
      new { controller = "PaymentAdminCustom", action = "MethodMarkPrimary" },
      new[] { "Shopfast.Plugin.Custom.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);
            #endregion

            #region Merchant Admin Controller
            route = routes.MapRoute("StorePlans",
     "Admin/store-plan",
     new { controller = "MerchantAdmin", action = "StorePlans" },
     new[] { "Shopfast.Plugin.Custom.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);

            route = routes.MapRoute("StoreCheckout",
      "Admin/store-checkout/{productId}/{planType}",
      new { controller = "MerchantAdmin", action = "StoreCheckout", productId = UrlParameter.Optional, planType = UrlParameter.Optional },
      new[] { "Shopfast.Plugin.Custom.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);

            route = routes.MapRoute("ApplyDiscountCoupon",
     "Admin/store-apply-coupon",
     new { controller = "MerchantAdmin", action = "ApplyDiscountCoupon" },
     new[] { "Shopfast.Plugin.Custom.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);         

            route = routes.MapRoute("StoreTheme",
     "Admin/store-theme",
     new { controller = "MerchantAdmin", action = "StoreTheme" },
     new[] { "Shopfast.Plugin.Custom.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);

            route = routes.MapRoute("StoreDomains",
     "Admin/store-domain",
     new { controller = "MerchantAdmin", action = "StoreDomains" },
     new[] { "Shopfast.Plugin.Custom.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);

            route = routes.MapRoute("StoreBuyDomain",
     "Admin/store-buydomain",
     new { controller = "MerchantAdmin", action = "StoreBuyDomain" },
     new[] { "Shopfast.Plugin.Custom.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);

            route = routes.MapRoute("StoreConnectDomain",
  "Admin/store-connectdomain",
  new { controller = "MerchantAdmin", action = "StoreConnectDomain" },
  new[] { "Shopfast.Plugin.Custom.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);

            route = routes.MapRoute("StoreTransferDomain",
  "Admin/store-transferdomain",
  new { controller = "MerchantAdmin", action = "StoreTransferDomain" },
  new[] { "Shopfast.Plugin.Custom.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);

            route = routes.MapRoute("StoreStartMyStore",
"Admin/start-my-store",
new { controller = "MerchantAdmin", action = "StoreStartMyStore" },
new[] { "Shopfast.Plugin.Custom.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);

            route = routes.MapRoute("StoreHireExpert",
   "Admin/store-hireexpert",
   new { controller = "MerchantAdmin", action = "StoreHireExpert" },
   new[] { "Shopfast.Plugin.Custom.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);

            route = routes.MapRoute("StoreHireExpert",
 "Admin/store-hireexpert-form/{group}/{steps}",
 new { controller = "MerchantAdmin", action = "StoreHireExpertForm", group = UrlParameter.Optional, steps = UrlParameter.Optional },
 new[] { "Shopfast.Plugin.Custom.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);

            route = routes.MapRoute("AvailableThemes",
"Admin/AvailableThemes",
new { controller = "MerchantAdmin", action = "AvailableThemes" },
new[] { "Shopfast.Plugin.Custom.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);

            route = routes.MapRoute("AvailableThemes",
"Admin/AddStoreTheme",
new { controller = "MerchantAdmin", action = "AddStoreTheme" },
new[] { "Shopfast.Plugin.Custom.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);

            route = routes.MapRoute("AvailableStoreThemes",
"Admin/AvailableStoreThemes",
new { controller = "MerchantAdmin", action = "AvailableStoreThemes" },
new[] { "Shopfast.Plugin.Custom.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);

            route = routes.MapRoute("AvailableStoreThemes",
"Admin/AvailableStoreThemes",
new { controller = "MerchantAdmin", action = "AvailableStoreThemes" },
new[] { "Shopfast.Plugin.Custom.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);

            route = routes.MapRoute("StoreThemeAction",
"Admin/StoreThemeAction",
new { controller = "MerchantAdmin", action = "StoreThemeAction" },
new[] { "Shopfast.Plugin.Custom.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);

            route = routes.MapRoute("RemoveStoreTheme",
"Admin/RemoveStoreTheme",
new { controller = "MerchantAdmin", action = "RemoveStoreTheme" },
new[] { "Shopfast.Plugin.Custom.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);

            routes.MapRoute("PackageOrders", "MyAccount/PackageOrders",
                    new { controller = "Plans", action = "PackageOrders" },
                    new[] { "Shopfast.Plugin.Custom.Controllers" });
            routes.MapRoute("PackageOrderDetail", "MyAccount/PackageOrderDetail/{orderId}",
                new { controller = "Plans", action = "PackageOrderDetail", orderId = UrlParameter.Optional },
                new[] { "Shopfast.Plugin.Custom.Controllers" });

            routes.MapRoute("MerchantCards", "MyAccount/MerchantCards",
                 new { controller = "Plans", action = "MerchantCards" },
                 new[] { "Shopfast.Plugin.Custom.Controllers" });
            routes.MapRoute("SuspendStore", "Plan/SuspendStore",
               new { controller = "Plans", action = "SuspendStore" },
               new[] { "Shopfast.Plugin.Custom.Controllers" });
            #endregion

            #region Home Admin Custom
            route = routes.MapRoute("DashboardStats",
   "Admin/Dashboard-Stats",
   new { controller = "HomeAdminCustom", action = "DashboardStats" },
   new[] { "Shopfast.Plugin.Custom.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);
            #endregion

            #region RecuringOrderTaskConfig Controller
            route = routes.MapRoute("RecuringOrderTaskConfig",
   "Admin/RecuringOrderTaskConfig",
   new { controller = "RecuringOrderTaskConfig", action = "Configure" },
   new[] { "Shopfast.Plugin.Custom.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);
            #endregion

            #endregion

            #region Web

            #region Order Custom Web Controller
            // Print Order Details For SMS
            route = routes.MapRoute("SmsReceiptPrint",
                            "smsreceipt/{orderId}",
                            new { controller = "OrderCustomWeb", action = "PrintOrderDetailsForSMS" },
                            new[] { "Shopfast.Plugin.Custom.Controllers" });
            routes.Remove(route);
            routes.Insert(0, route);
            route = routes.MapRoute("PrintOrderDetailsForSMS",
                            "order-details-print/{orderId}",
                            new { controller = "OrderCustomWeb", action = "PrintOrderDetailsForSMS" },
                            new[] { "Shopfast.Plugin.Custom.Controllers" });
            routes.Remove(route);
            routes.Insert(0, route);
            //---------------------------
            #endregion

            #region ShoppingCartCustomWeb Controller
            // FormatPrice
            routes.MapRoute("formatprice",
                         "formatprice/{productId}",
                         new { controller = "ShoppingCartCustomWeb", action = "FormatPrice", productId = UrlParameter.Optional },
                         new[] { "Shopfast.Plugin.Custom.Controllers" });
            routes.Remove(route);
            routes.Insert(0, route);
            // DeleteProductFromCart for SMS page
            routes.MapRoute("removeitem",
                           "removeitem/{productId}",
                           new { controller = "ShoppingCartCustomWeb", action = "DeleteProductFromCart" },
                           new[] { "Shopfast.Plugin.Custom.Controllers" });
            routes.Remove(route);
            routes.Insert(0, route);

            // Clear Cart By Customer email
            routes.MapRoute("ClearCartByCustomeremail",
                          "clearcart/",
                          new { controller = "ShoppingCartCustomWeb", action = "ClearCartByCustomeremail" },
                          new[] { "Shopfast.Plugin.Custom.Controllers" });
            routes.Remove(route);
            routes.Insert(0, route);

            routes.MapRoute("OrderSummaryLeft",
                       "OrderSummaryLeft",
                       new { controller = "ShoppingCartCustomWeb", action = "OrderSummaryLeft" },
                       new[] { "Shopfast.Plugin.Custom.Controllers" });
            routes.Remove(route);
            routes.Insert(0, route);

            routes.MapRoute("OrderTotalsLeft",
                       "OrderTotalsLeft",
                       new { controller = "ShoppingCartCustomWeb", action = "OrderTotalsLeft" },
                       new[] { "Shopfast.Plugin.Custom.Controllers" });
            routes.Remove(route);
            routes.Insert(0, route);
            #endregion

            #region Merchant Controller
            // This is Common free trial
            routes.MapRoute("FreeTrial",
                           "freetrial",
                           new { controller = "Merchant", action = "FreeTrialCommonSetup1" },
                           new[] { "Nop.Web.Controllers" });
            routes.Remove(route);
            routes.Insert(0, route);

            routes.MapRoute("setupfinishTest",
                              "setupfinishtest",
                              new { controller = "Merchant", action = "setupfinishTest" },
                              new[] { "Nop.Web.Controllers" });
            routes.Remove(route);
            routes.Insert(0, route);

            routes.MapRoute("store-registration",
                              "store-registration",
                              new { controller = "Merchant", action = "StoreRegistration" },
                              new[] { "Nop.Web.Controllers" });
            routes.Remove(route);
            routes.Insert(0, route);

            routes.MapRoute("CreateStore",
                         "CreateStore",
                         new { controller = "Merchant", action = "CreateStore" },
                         new[] { "Nop.Web.Controllers" });
            routes.Remove(route);
            routes.Insert(0, route);

            routes.MapRoute("MobileCreateStore",
                     "mobile-createstore",
                     new { controller = "Merchant", action = "CreateStoreMobile" },
                     new[] { "Nop.Web.Controllers" });
            routes.Remove(route);
            routes.Insert(0, route);
            //-----------------
            #endregion

            #region CustomerCustomWeb Controller
            routes.MapRoute("MobileLogin",
              "MobileLogin/",
              new { controller = "CustomerCustomWeb", action = "MobileLogin" },
              new[] { "Shopfast.Plugin.Custom.Controllers" });
            routes.Remove(route);
            routes.Insert(0, route);

            routes.MapRoute("applogin",
                "app_login/",
                new { controller = "CustomerCustomWeb", action = "app_login" },
                new[] { "Shopfast.Plugin.Custom.Controllers" });
            routes.Remove(route);
            routes.Insert(0, route);

            routes.MapRoute("StoreCustomerLogin",
                "StoreCustomerLogin/",
                new { controller = "CustomerCustomWeb", action = "StoreCustomerLogin" },
                new[] { "Shopfast.Plugin.Custom.Controllers" });
            routes.Remove(route);
            routes.Insert(0, route);

            routes.MapRoute("MerchantAdminAutoLogin",
               "MerchantAdminAutoLogin/",
               new { controller = "CustomerCustomWeb", action = "MerchantAdminAutoLogin" },
               new[] { "Shopfast.Plugin.Custom.Controllers" });
            routes.Remove(route);
            routes.Insert(0, route);

            routes.MapRoute("DemoSiteSignUp",
             "Demositesignup/",
             new { controller = "CustomerCustomWeb", action = "DemoSiteSignUp" },
             new[] { "Shopfast.Plugin.Custom.Controllers" });
            routes.Remove(route);
            routes.Insert(0, route);

            routes.MapRoute("resellersignup",
          "resellersignup/",
          new { controller = "CustomerCustomWeb", action = "ResellerSignUp" },
          new[] { "Shopfast.Plugin.Custom.Controllers" });
            routes.Remove(route);
            routes.Insert(0, route);

            #endregion

            #region CustomWeb Controller
            routes.MapRoute("CustomPolls",
            "polls-page/",
            new { controller = "CustomWeb", action = "CustomPolls" },
            new[] { "Shopfast.Plugin.Custom.Controllers" });
            routes.Remove(route);
            routes.Insert(0, route);

            routes.MapRoute("testAPI",
            "testAPI",
            new { controller = "CustomWeb", action = "testAPI" },
            new[] { "Shopfast.Plugin.Custom.Controllers" });
            routes.Remove(route);
            routes.Insert(0, route);

            routes.MapRoute("SaveCustomizedTheme",
            "savecustomizedtheme/",
            new { controller = "CustomWeb", action = "SaveCustomizedTheme" },
            new[] { "Shopfast.Plugin.Custom.Controllers" });
            routes.Remove(route);
            routes.Insert(0, route);
            #endregion

            #region Plans Controller
            routes.MapRoute("Main_StorePlans",
   "store-pricing",
   new { controller = "Plans", action = "StorePlans" },
   new[] { "Shopfast.Plugin.Custom.Controllers" });
            routes.Remove(route);
            routes.Insert(0, route);

            routes.MapRoute("Main_StoreCheckout",
      "store-checkout/{productId}/{planType}",
      new { controller = "Plans", action = "StoreCheckout", productId = UrlParameter.Optional, planType = UrlParameter.Optional },
      new[] { "Shopfast.Plugin.Custom.Controllers" });
            routes.Remove(route);
            routes.Insert(0, route);

            routes.MapRoute("Main_ApplyDiscountCoupon",
       "store-apply-coupon",
       new { controller = "Plans", action = "ApplyDiscountCoupon" },
       new[] { "Shopfast.Plugin.Custom.Controllers" });            
            routes.Remove(route);
            routes.Insert(0, route);

            routes.MapRoute("Main_RemoveDiscountCoupon",
      "store-remove-coupon",
      new { controller = "Plans", action = "RemoveDiscountCoupon" },
      new[] { "Shopfast.Plugin.Custom.Controllers" });
            routes.Remove(route);
            routes.Insert(0, route);          
            #endregion

            routes.MapRoute("WebsiteLogo",
           "merchant/logo/",
           new { controller = "CustomWeb", action = "Logo" },
            new[] { "Shopfast.Plugin.Custom.Controllers" });
            routes.Remove(route);
            routes.Insert(0, route);
            #endregion
        }

        public int Priority
        {
            get { return -100; }
        }
    }
}