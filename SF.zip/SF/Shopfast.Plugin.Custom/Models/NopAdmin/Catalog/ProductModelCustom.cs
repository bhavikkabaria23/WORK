﻿using Nop.Web.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Shopfast.Plugin.Custom.Models.NopAdmin.Catalog
{
    public class ProductModelCustom
    {
        public ProductModelCustom()
        {
            AvailableBarcodeCategories = new List<SelectListItem>();
        }
        public int ProductId { get; set; }

        public string Gtin { get; set; }

        [NopResourceDisplayName("Admin.Catalog.Products.Fields.BarcodeId")]
        public int BarcodeId { get; set; }

        [NopResourceDisplayName("Admin.Catalog.Products.Fields.ShowOnPointOfSale")]
        public bool ShowOnPointOfSale { get; set; }

        public IList<SelectListItem> AvailableBarcodeCategories { get; set; }
    }
}