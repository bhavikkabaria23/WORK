﻿using AutoMapper;
using Nop.Services.Payments;
using Shopfast.Plugin.Custom.Infrastructure.Mapper;
using Shopfast.Plugin.Custom.Models.NopAdmin.Payments;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Extensions.NopAdmin
{
    public static class MappingExtensionsCustom
    {
        public static TDestination MapTo<TSource, TDestination>(this TSource source)
        {
            return AutoMapperConfiguration.Mapper.Map<TSource, TDestination>(source);
        }

        public static TDestination MapTo<TSource, TDestination>(this TSource source, TDestination destination)
        {
            return AutoMapperConfiguration.Mapper.Map(source, destination);
        }

        #region Payment methods additional

        public static PaymentMethodModelCustom ToModelCustom(this IPaymentMethod entity)
        {
            return entity.MapTo<IPaymentMethod, PaymentMethodModelCustom>();
        }
        #endregion
    }
}