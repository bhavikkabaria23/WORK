﻿using Microsoft.Crm.Sdk.Samples.HelperCode;
using MultiSite.Models;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace Shopfast.Plugin.Custom.CRMHelper
{
    public partial class CrmApi
    {
        //Start with base version and update with actual version later.
        private static Version webAPIVersion = new Version(9, 0);

        private static string getVersionedWebAPIPath()
        {
            return string.Format("v{0}/", webAPIVersion.ToString(2));
        }

        public static async Task<bool> ShopfastSignUpPricingCRMPost(FormCollection fc)
        {

            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            var httpClient = new HttpClient(auth.ClientHandler, true);
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");

            // Generate json object from model
            var merchantForm = new JObject();
            merchantForm.Add("new_FirstName", fc["new_FirstName"]);
            merchantForm.Add("new_LastName", fc["new_LastName"]);
            merchantForm.Add("new_email", fc["new_email"]);
            merchantForm.Add("new_phonenumber", fc["new_phonenumber"]);
            merchantForm.Add("new_businessname", fc["new_businessname"]);
            merchantForm.Add("new_BusinessType", fc["new_BusinessType_index"]);
            merchantForm.Add("new_industrytype", fc["new_industrytype_index"]);

            HttpRequestMessage createRequest =
            new HttpRequestMessage(HttpMethod.Post, getVersionedWebAPIPath() + "new_storepricingsignupstarts");
            createRequest.Content = new StringContent(merchantForm.ToString(),
                Encoding.UTF8, "application/json");

            HttpResponseMessage createResponse =
                await httpClient.SendAsync(createRequest);
            if (createResponse.StatusCode == HttpStatusCode.NoContent) //204
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}