﻿using Nop.Admin.Controllers;
using Nop.Core.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Nop.Admin.Extensions;
using Shopfast.Plugin.Custom.Services;
using Nop.Core;
using MultiSite.Data;
using Nop.Web.Framework.Controllers;
using System.Net.Http;
using Nop.Core.Domain.Catalog;
using System.Web.Script.Serialization;
using Shopfast.Plugin.Custom.Models.NopAdmin.Catalog;
using MultiSite.Models;
using Nop.Services.Directory;
using Nop.Services.Customers;
using Nop.Core.Domain.Customers;
using System.Text;
using Newtonsoft.Json;
using Nop.Services.Localization;
using System.Net.Http.Headers;
using Newtonsoft.Json.Linq;
using Shopfast.Plugin.Custom.Models.NopAdmin.MerchantAdmin;
using System.Net;
using System.Collections.Specialized;
using System.Security.Cryptography;
using Nop.Core.Infrastructure;
using Nop.Web.Framework.Themes;
using Nop.Services.Stores;
using Nop.Core.Domain;
using Nop.Services.Configuration;
using Nop.Web.Models.Order;
using Shopfast.Plugin.Custom.Models.NopAdmin.Orders;
using MultiSite.Hubs;
using Nop.Web.Models.SiteRegistration;
using Nop.Data;
using MultiSite.Services;
using Nop.Services.Logging;
using Nop.Services.Security;
using Nop.Web.Framework.Security;
using Shopfast.Plugin.Custom.Helper;
using Shopfast.Plugin.Custom.Services.SchedueTaskCustom;
using System.Threading.Tasks;
using Nop.Services.Payments;
using Nop.Services.Orders;
using Nop.Services.Catalog;
using Nop.Core.Domain.Orders;
using Nop.Services.Discounts;
using Nop.Web.Factories;
using Shopfast.Plugin.Custom.Services.Orders;
using Shopfast.Plugin.Custom.Extensions.NopWeb;

namespace Shopfast.Plugin.Custom.Controllers
{
    public class PlansController : BaseController
    {
        #region Fields
        private readonly IStoreContext _storeContext;
        private readonly IWorkContext _workContext;
        private readonly ICountryService _countryService;
        private readonly IStateProvinceService _stateProvinceService;
        private readonly ICustomerRegistrationService _customerRegistrationService;
        private readonly CustomerSettings _customerSettings;
        private readonly ILocalizationService _localizationService;
        private readonly IStoreService _storeService;
        private readonly ISettingService _settingService;
        private readonly HttpContextBase _httpContext;
        private readonly ILogger _logger;
        private readonly IEncryptionService _encryptionService;
        private readonly IRecuringPlansService _recuringPlansService;
        private readonly IOrderProcessingService _orderProcessingService;
        private readonly IShoppingCartService _shoppingCartService;
        private readonly IProductService _productService;
        private readonly IDiscountService _discountService;
        private readonly IShoppingCartModelFactory _shoppingCartModelFactory;
        private readonly IOrderTotalCalculationService _orderTotalCalculationService;
        private readonly IShoppingCartServiceCustom _shoppingCartServiceCustom;

        private static string ShopfastAPIBaseUrl = System.Configuration.ConfigurationManager.AppSettings["ShopfastAPIBaseUrl"];
        #endregion

        #region Ctor

        public PlansController(IStoreContext storeContext,
            IWorkContext workContext,
            ICountryService countryService,
            IStateProvinceService stateProvinceService,
            ICustomerRegistrationService customerRegistrationService,
            CustomerSettings customerSettings,
            ILocalizationService localizationService,
            IStoreService storeService,
            ISettingService settingService,
            HttpContextBase httpContext,
            ILogger logger, IEncryptionService encryptionService,
            IRecuringPlansService recuringPlansService,
            IOrderProcessingService orderProcessingService,
            IShoppingCartService shoppingCartService,
            IProductService productService,
            IDiscountService discountService,
            IShoppingCartModelFactory shoppingCartModelFactory,
            IOrderTotalCalculationService orderTotalCalculationService,
            IShoppingCartServiceCustom shoppingCartServiceCustom
            )
        {
            this._settingService = settingService;
            this._storeContext = storeContext;
            this._workContext = workContext;
            this._countryService = countryService;
            this._stateProvinceService = stateProvinceService;
            this._customerRegistrationService = customerRegistrationService;
            this._customerSettings = customerSettings;
            this._localizationService = localizationService;
            this._storeService = storeService;
            this._httpContext = httpContext;
            this._logger = logger;
            this._encryptionService = encryptionService;
            this._recuringPlansService = recuringPlansService;
            this._orderProcessingService = orderProcessingService;
            this._shoppingCartService = shoppingCartService;
            this._productService = productService;
            this._discountService = discountService;
            this._shoppingCartModelFactory = shoppingCartModelFactory;
            this._orderTotalCalculationService = orderTotalCalculationService;
            _shoppingCartServiceCustom = shoppingCartServiceCustom;
        }
        #endregion

        #region Private Methods
        private bool UpdateSiteOwnerSiteOrder(StoreCheckoutModel model, int orderId)
        {
            #region Update Site, Owner and SiteOrder tables
            bool checkoutResult = false;
            using (var dbContext = new Sites4Entities())
            {
                var site = dbContext.Sites.FirstOrDefault(s => s.Id == model.ownerModel.siteId);
                var siteupdate = site;
                if (site != null)
                {
                    var owner = dbContext.Owners.FirstOrDefault(o => o.Id == site.Owner_Id);
                    //site.CreationDate = DateTime.UtcNow.AddDays(days); // no need to update creation date for purchased store
                    site.IsOrder = true;
                    site.Owner = owner;
                    dbContext.Entry(site).CurrentValues.SetValues(siteupdate);

                    //Add this order to SiteOrders and make other orders IsActive to false for this store.
                    var existingSiteOrders = dbContext.SiteOrders.Where(so => so.StoreName.ToLower() == site.StoreName.ToLower());
                    if (existingSiteOrders != null && existingSiteOrders.Any())
                    {
                        foreach (var order in existingSiteOrders)
                        {
                            var orderUpdate = order;
                            order.IsActive = false;
                            dbContext.Entry(order).CurrentValues.SetValues(orderUpdate);
                        }
                    }
                    SiteOrders siteOrder = new SiteOrders()
                    {
                        StoreName = site.StoreName,
                        SiteId = site.Id,
                        OwnerId = site.Owner_Id,
                        OwnerEmail = owner.email,
                        PackageId = model.product.Id,
                        PackageName = model.product.Name,
                        //OrderId = checkoutResponse.CheckoutTransactionResult.OrderId,
                        OrderId = orderId,
                        IsActive = true,
                        CreationDate = DateTime.UtcNow,
                        PlanExpirationDate = (model.PlanType == "monthly") ? DateTime.UtcNow.AddMonths(1) : DateTime.UtcNow.AddYears(1) // this for yearly
                    };
                    dbContext.SiteOrders.Add(siteOrder);
                    dbContext.SaveChanges();
                    checkoutResult = true;
                    _logger.Information("checkout success");
                }
            }
            return checkoutResult;
            #endregion
        }
        #endregion

        /// <summary>
        /// Generate passwords
        /// </summary>
        /// <param name="passwordLength"></param>
        /// <param name="strongPassword"> </param>
        /// <returns></returns>
        private string PasswordGenerator(int passwordLength, bool strongPassword)
        {
            Random Random = new Random();
            int seed = Random.Next(1, int.MaxValue);
            const string allowedChars = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ0123456789";
            const string specialCharacters = @"!#$%()*/^~?@_";

            var chars = new char[passwordLength];
            var rd = new Random(seed);

            for (var i = 0; i < passwordLength; i++)
            {
                // If we are to use special characters
                if (strongPassword && i % Random.Next(3, passwordLength) == 0)
                {
                    chars[i] = specialCharacters[rd.Next(0, specialCharacters.Length)];
                }
                else
                {
                    chars[i] = allowedChars[rd.Next(0, allowedChars.Length)];
                }
            }

            return new string(chars);
        }

        public ActionResult StorePlans()
        {
            //        #region testing
            //        var product2= _productService.GetProductById(114);
            //        product2.Price = 0;
            //        // Create order and get order id
            //        _shoppingCartService.AddToCart(_workContext.CurrentCustomer,
            //product2, ShoppingCartType.ShoppingCart, _storeContext.CurrentStore.Id,
            //null, decimal.Zero,
            //null, null, 1, true);

            //        var processPaymentRequest = new ProcessPaymentRequest();
            //        processPaymentRequest.StoreId = _storeContext.CurrentStore.Id;
            //        processPaymentRequest.CustomerId = _workContext.CurrentCustomer.Id;
            //        processPaymentRequest.PaymentMethodSystemName = null;
            //        var placeOrderResult = _orderProcessingService.PlaceOrder(processPaymentRequest);
            //        _logger.Information("StoreCheckout - $0 amount - order id : " + placeOrderResult.PlacedOrder.Id + " - " + DateTime.Now.ToString());
            //        if (placeOrderResult.Success)
            //        {
            //            _logger.Information("StoreCheckout - success");
            //        }
            //        #endregion





            _logger.Information("Store plans page 2 - " + DateTime.Now.ToString());
            ProductRespose productRespose = new ProductRespose();
            var client = new HttpClient();
            HttpResponseMessage response = client.GetAsync(ShopfastAPIBaseUrl + "/api/v1/catalog/products/app-products").Result;
            if (response.IsSuccessStatusCode)
            {
                var productsString = response.Content.ReadAsStringAsync().Result;
                JavaScriptSerializer js = new JavaScriptSerializer();
                var products = js.Deserialize<List<AppProductListModel>>(productsString);

                if (products != null && products.Any())
                {
                    products = products.Where(p => p.ProductSpecificationAttributes != null
                        && p.ProductSpecificationAttributes.Any(ps => ps.AttributeName.ToLower() == "ispackage" && ps.ValueRaw.ToLower() == "yes")
                        ).ToList();
                    foreach (var product in products)
                    {
                        if (product.ProductSpecificationAttributes.Any(ps => ps.AttributeName.ToLower() == "pricing" && ps.ValueRaw.ToLower() == "monthly"))
                        {
                            if (product.ProductSpecificationAttributes.Any(ps => ps.AttributeName.ToLower() == "most_popular" && ps.ValueRaw.ToLower() == "yes"))
                            {
                                product.IsMostPopular = true;
                            }
                            productRespose.MonthlyPackageList.Add(product);
                        }
                        else if (product.ProductSpecificationAttributes.Any(ps => ps.AttributeName.ToLower() == "pricing" && ps.ValueRaw.ToLower() == "yearly"))
                        {
                            if (product.ProductSpecificationAttributes.Any(ps => ps.AttributeName.ToLower() == "most_popular" && ps.ValueRaw.ToLower() == "yes"))
                            {
                                product.IsMostPopular = true;
                            }
                            productRespose.YearlyPackageList.Add(product);
                        }
                    }
                }
            }
            return View(string.Format("/Themes/{0}/Views/Plans/Pricing.cshtml", EngineContext.Current.Resolve<IThemeContext>().WorkingThemeName), productRespose);
        }

        public ActionResult StoreCheckout(int productId, string planType = "monthly")
        {
            // Delete cart of existing customer
            _shoppingCartServiceCustom.DeleteShoppingCartItemForCustomer(_workContext.CurrentCustomer);
            // Remove all coupon codes of customer
            _workContext.CurrentCustomer.RemoveDiscountAllCouponCode();

            StoreCheckoutModel checkoutModel = new StoreCheckoutModel();
            if (productId > 0)
            {
                checkoutModel.PlanType = planType;
                var client = new HttpClient();
                // Here Need to call GetProductById API, Need from Sanjay
                HttpResponseMessage response = client.GetAsync(ShopfastAPIBaseUrl + "/api/v1/catalog/products/app-products").Result;
                if (response.IsSuccessStatusCode)
                {
                    var productsString = response.Content.ReadAsStringAsync().Result;
                    JavaScriptSerializer js = new JavaScriptSerializer();
                    var products = js.Deserialize<List<AppProductListModel>>(productsString);

                    if (products != null && products.Any())
                    {
                        checkoutModel.product = products.SingleOrDefault(p => p.Id == productId);
                        if (checkoutModel.product != null && checkoutModel.product.ProductAttributes != null
                            && checkoutModel.product.ProductAttributes.Any(pa => pa.Name.ToLower() == "subscription" && pa.AttributeControlType.ToLower() == "radiolist" && pa.Values != null && pa.Values.Any()))
                        {
                            checkoutModel.ProductAttributes = checkoutModel.product.ProductAttributes.ToList();
                        }
                    }
                    var _oRegisterStoreModel = _httpContext.Session["RegisterStoreModel"] as SiteRegistrationModel;
                    var subdomain = MultisiteHelper.SubDomain;
                    if (_oRegisterStoreModel != null)
                    {
                        checkoutModel.ownerModel = _oRegisterStoreModel;
                    }
                }
            }
            return View(string.Format("/Themes/{0}/Views/Plans/StoreCheckout.cshtml", EngineContext.Current.Resolve<IThemeContext>().WorkingThemeName), checkoutModel);
        }

        [HttpPost]
        public ActionResult StoreCheckout(StoreCheckoutModel model, string subscriptionRadio)
        {
            try
            {
                var _oRegisterStoreModel = _httpContext.Session["RegisterStoreModel"] as SiteRegistrationModel;
                if (_oRegisterStoreModel != null)
                {
                    _logger.Information("_oRegisterStoreModel is not null");
                    if (model.product.Id > 0 && !string.IsNullOrEmpty(model.PlanType))
                    {
                        _logger.Information("product id found - " + model.product.Id);
                        bool IsStoreToCreate = false;
                        CheckoutTransaction request = new CheckoutTransaction();
                        // POST API
                        string month = "";
                        string year = "";
                        if (model.product.Price == decimal.Zero)
                        {
                            // We have added product to cart when applying discount coupon and price is zero

                            var processPaymentRequest = new ProcessPaymentRequest();
                            processPaymentRequest.StoreId = _storeContext.CurrentStore.Id;
                            processPaymentRequest.CustomerId = _workContext.CurrentCustomer.Id;
                            processPaymentRequest.PaymentMethodSystemName = null;
                            var placeOrderResult = _orderProcessingService.PlaceOrder(processPaymentRequest);
                            _logger.Information("StoreCheckout - $0 amount - order id : " + placeOrderResult.PlacedOrder.Id + " - " + DateTime.Now.ToString());
                            if (placeOrderResult.Success)
                            {
                                IsStoreToCreate = UpdateSiteOwnerSiteOrder(model, placeOrderResult.PlacedOrder.Id);
                                _logger.Information("StoreCheckout - UpdateSiteOwnerSiteOrder is called -  $0 amount - order id : " + placeOrderResult.PlacedOrder.Id + " - " + DateTime.Now.ToString());
                            }
                        }
                        else
                        {
                            // Delete cart of existing customer
                            _shoppingCartServiceCustom.DeleteShoppingCartItemForCustomer(_workContext.CurrentCustomer);

                            #region Checkout Transaction by API       
                            _logger.Information("StoreCheckout - > $0 amount  - " + DateTime.Now.ToString());
                            if (!string.IsNullOrEmpty(model.Expires))
                            {
                                string[] expires = model.Expires.Split('/');
                                if (expires != null && expires.Any())
                                    month = expires[0].Trim();
                                if (expires.Count() > 1)
                                    year = expires[1].Trim();
                            }
                            if (!string.IsNullOrEmpty(model.cardNumber))
                            {
                                model.cardNumber = model.cardNumber.Replace(" ", "");
                            }

                            double subscriptionPrice = 0;
                            string subscriptionId = string.Empty;

                            if (!string.IsNullOrEmpty(subscriptionRadio))
                            {
                                string[] subscription = subscriptionRadio.Split('~');
                                if (subscription != null && subscription.Any())
                                {
                                    subscriptionId = subscription[0];
                                    if (subscription.Count() > 1)
                                    {
                                        subscriptionPrice = Convert.ToDouble(subscription[1]);
                                    }
                                }

                            }
                            request.Products = model.product.Id.ToString();
                            request.Quantities = "1";
                            request.TotalAmount = Convert.ToDouble(model.product.Price) + subscriptionPrice;
                            request.Email = model.ownerModel.email;
                            request.CardType = "Visa";
                            request.CardName = "test";
                            request.CardNumber = model.cardNumber;
                            request.ExpiryMonth = month;
                            request.ExpiryYear = "20" + year;
                            request.VerifyCode = model.CVV;
                            request.TransactionType = "card";
                            request.UseRewardPoints = false;
                            request.Attributes = (!string.IsNullOrEmpty(subscriptionId)) ? subscriptionId : null;
                            request.IsWebOrder = true;

                            var jsonString = JsonConvert.SerializeObject(request);
                            _logger.Information("checkout API request - " + jsonString);

                            var element = new JObject();
                            element["Data"] = jsonString;
                            byte[] byteData = Encoding.UTF8.GetBytes("{body}");
                            byteData = Encoding.UTF8.GetBytes(element.ToString());

                            using (var contentPayment = new ByteArrayContent(byteData))
                            {
                                contentPayment.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                                var client = new HttpClient();
                                var responsePayment = client.PostAsync(ShopfastAPIBaseUrl + "/sf_API/Service.svc/Json/CheckoutTransaction", contentPayment).Result;
                                if (responsePayment.IsSuccessStatusCode)
                                {
                                    _logger.Information("checkout IsSuccessStatusCode true");

                                    var checkoutResponse = responsePayment.Content.ReadAsAsync<CheckoutResponse>().Result;
                                    _logger.Information("checkout response - " + JsonConvert.SerializeObject(checkoutResponse.CheckoutTransactionResult));
                                    if (checkoutResponse.CheckoutTransactionResult.Status)
                                    {
                                        _logger.Information("checkoutResponse.CheckoutTransactionResult.Status - true");
                                        // If success then change store creted date based on selected package
                                        // Make store "Purchased" from "Trial" based on "IsOrder" field            
                                        IsStoreToCreate = UpdateSiteOwnerSiteOrder(model, checkoutResponse.CheckoutTransactionResult.OrderId);
                                    }
                                }
                            }
                            #endregion                           
                        }
                        if (IsStoreToCreate)
                        {
                            _logger.Information("StoreCheckout - Store creation starting - IsStoreToCreate : " + IsStoreToCreate + " - " + DateTime.Now.ToString());
                            #region Create Store and DB based on RegisterStore model
                            ShopFastHub.CreateStoreProcess(_oRegisterStoreModel.email, "step1");
                            _logger.Information("step1 success");
                            string storeName;
                            _oRegisterStoreModel.storeName = _oRegisterStoreModel.storeName.SanitazeStoreName();

                            // Copy database and settings
                            SiteHelper.AddToSqlServer(_oRegisterStoreModel.storeName, _oRegisterStoreModel.industryType, out storeName);
                            ShopFastHub.CreateStoreProcess(_oRegisterStoreModel.email, "step2");
                            _logger.Information("step2 success");

                            var customer = _workContext.CurrentCustomer;

                            // Setup store admin credentials and basic settings into database.
                            var storeDatabase = SiteHelper.GetStoreConnectionString(storeName);
                            MultiSiteDataProvider.ConfigureStoreDatabase(_oRegisterStoreModel.storeName, storeDatabase, _oRegisterStoreModel.email, string.Empty, MultisiteHelper.DefaultTheme, null);
                            _logger.Information("configure database");
                            _oRegisterStoreModel.isOrder = true;

                            using (var dbContext = new Sites4Entities())
                            {
                                var owner = dbContext.Owners.Where(o => o.Id == _oRegisterStoreModel.OwnerId).FirstOrDefault();
                                if (owner != null)
                                {
                                    owner.Selling = _oRegisterStoreModel.Selling;
                                    owner.SomethingToSell = _oRegisterStoreModel.SomethingToSell;
                                    owner.HelpBusinessLogo = _oRegisterStoreModel.HelpBusinessLogo;
                                    owner.HelpBusinessBrainStorm = _oRegisterStoreModel.HelpBusinessBrainStorm;
                                    owner.HelpBusinessWebinar = _oRegisterStoreModel.HelpBusinessWebinar;
                                    owner.HelpBusinessProduct = _oRegisterStoreModel.HelpBusinessProduct;
                                    owner.SystemName = _oRegisterStoreModel.SystemName;
                                    owner.LaunchStore = _oRegisterStoreModel.LaunchStore;
                                    owner.WhatToSell = _oRegisterStoreModel.WhatToSell;
                                    owner.SellAtMarket = _oRegisterStoreModel.SellAtMarket;
                                    owner.SellAtRetailStore = _oRegisterStoreModel.SellAtRetailStore;
                                    owner.CurrentRevenue = _oRegisterStoreModel.CurrentRevenue;
                                    owner.StoreForCLient = _oRegisterStoreModel.StoreForCLient;

                                    owner.description = _oRegisterStoreModel.Description;
                                    owner.firstName = _oRegisterStoreModel.firstName;
                                    owner.LastName = _oRegisterStoreModel.lastName;
                                    owner.phone = _oRegisterStoreModel.phone;
                                    owner.starting = _oRegisterStoreModel.Starting;
                                    owner.Country = _oRegisterStoreModel.Country;
                                    owner.Website = _oRegisterStoreModel.Website;
                                    owner.StreetAddress = _oRegisterStoreModel.StreetAddress;
                                    owner.StreetAddress2 = _oRegisterStoreModel.StreetAddress2;
                                    owner.City = _oRegisterStoreModel.City;
                                    owner.ZipPostalCode = _oRegisterStoreModel.ZipPostalCode;
                                    owner.State = _oRegisterStoreModel.State;

                                    owner.AvgSaleAmout = _oRegisterStoreModel.AvgSaleAmout;
                                    owner.ProcessorName = _oRegisterStoreModel.ProcessorName;
                                    owner.ProcessorEmail = _oRegisterStoreModel.ProcessorEmail;
                                    owner.ProcessorPhoneNumber = _oRegisterStoreModel.ProcessorPhoneNumber;
                                    owner.SiteCategory = _oRegisterStoreModel.SiteCategory;
                                    owner.TeamPeople = _oRegisterStoreModel.TeamPeople;
                                    owner.Reason = _oRegisterStoreModel.Reason;
                                    owner.IsRegistered = true;

                                    // Need to encrypt this card info
                                    owner.CardType = _encryptionService.EncryptText(request.CardType);
                                    owner.CardName = _encryptionService.EncryptText(request.CardName);
                                    owner.CardNumber = _encryptionService.EncryptText(model.cardNumber);
                                    owner.VerifyCode = _encryptionService.EncryptText(model.CVV);
                                    owner.ExpiryMonth = _encryptionService.EncryptText(month);
                                    if (!string.IsNullOrEmpty(year))
                                        owner.ExpiryYear = _encryptionService.EncryptText("20" + year);

                                    dbContext.Entry(owner).CurrentValues.SetValues(owner);
                                    dbContext.SaveChanges();

                                    // CRM Shopfast Store entry to "new _shopfaststore"

                                    // Add host in plesk.
                                    _oRegisterStoreModel.password = PasswordGenerator(12, true);
                                    ShopFastHub.CreateStoreProcess(_oRegisterStoreModel.email, "step3");
                                    _logger.Information("step 3 success");
                                    var hostResult = SiteHelper.AddPleskHost(_oRegisterStoreModel);
                                    _logger.Information("step 3 success");
                                    if (hostResult)
                                    {
                                        // Upload file in FTP server.
                                        var ftpUserName = _oRegisterStoreModel.email.Split('@')[0].ToString().Length > 15 ? _oRegisterStoreModel.email.Split('@')[0].Substring(0, 15) : _oRegisterStoreModel.email.Split('@')[0];

                                        SiteHelper.UploadFtpFile(_oRegisterStoreModel.storeName, ftpUserName, _oRegisterStoreModel.password);
                                        _logger.Information("UploadFtpFile");

                                        var _workflowMessageService = new MultisiteWorkflowMessageService();
                                        _workflowMessageService.SendTrialStoreCreatedCustomerNotification(_oRegisterStoreModel);
                                        _workflowMessageService.SendTrialStoreCreatedAdminNotification(_oRegisterStoreModel);

                                        ShopFastHub.CreateStoreProcess(_oRegisterStoreModel.email, "step4");
                                        _logger.Information("CreateStoreProcess");

                                        return Json(new { storeUrl = string.Format(@"http://{0}.{1}/MerchantAdminAutoLogin?email={2}&owner_id={3}", _oRegisterStoreModel.storeName, MultisiteHelper.Domain, customer.Email, _oRegisterStoreModel.OwnerId) });
                                    }
                                }
                            }

                            #endregion
                        }


                        // if checkout API failed and trasaction not done
                        //{
                        // Rollback store which is created
                        // 1) delete registered customer from DB physically
                        // delete site and owner of that customer
                        // delete store and sub domain from PLESK
                        // delete DB of that store
                        //}            
                    }
                    else
                    {
                        return Json(new { error = "Error : Plan is not selected. Please select a plan" });
                    }

                }
                _logger.Error("Store or Merchant is not registered. Please try again.");
                return Json(new { error = "Store or Merchant is not registered. Please try again." });
            }
            catch (Exception ex)
            {
                _logger.Error("Error from catch of StoreCheckout- HttpPost - " + ex.Message);
                return Json(new { error = "Error occurred while creating a store. Please try again." });
            }
        }

        // This method is ONLY used for LOCAL Env for testing purpose
        [HttpPost]
        public ActionResult StoreCheckoutLocal(StoreCheckoutModel model, string subscriptionRadio)
        {
            //bool checkoutResult = false;
            //var _oRegisterStoreModel = _httpContext.Session["RegisterStoreModel"] as SiteRegistrationModel;
            //if (_oRegisterStoreModel != null)
            //{
            //    if (model.product.Id > 0 && !string.IsNullOrEmpty(model.PlanType))
            //    {
            //        #region Checkout Transaction by API
            //        CheckoutTransaction request = new CheckoutTransaction();
            //        // POST API
            //        string month = "";
            //        string year = "";
            //        if (!string.IsNullOrEmpty(model.Expires))
            //        {
            //            string[] expires = model.Expires.Split('/');
            //            if (expires != null && expires.Any())
            //                month = expires[0].Trim();
            //            if (expires.Count() > 1)
            //                year = expires[1].Trim();
            //        }
            //        if (!string.IsNullOrEmpty(model.cardNumber))
            //        {
            //            model.cardNumber = model.cardNumber.Replace(" ", "");
            //        }

            //        double subscriptionPrice = 0;
            //        string subscriptionId = string.Empty;

            //        if (!string.IsNullOrEmpty(subscriptionRadio))
            //        {
            //            string[] subscription = subscriptionRadio.Split('~');
            //            if (subscription != null && subscription.Any())
            //            {
            //                subscriptionId = subscription[0];
            //                if (subscription.Count() > 1)
            //                {
            //                    subscriptionPrice = Convert.ToDouble(subscription[1]);
            //                }
            //            }

            //        }
            //        request.Products = model.product.Id.ToString();
            //        request.Quantities = "1";
            //        request.TotalAmount = Convert.ToDouble(model.product.Price) + subscriptionPrice;
            //        request.Email = model.ownerModel.email;
            //        request.CardType = "Visa";
            //        request.CardName = "test";
            //        request.CardNumber = model.cardNumber;
            //        request.ExpiryMonth = month;
            //        request.ExpiryYear = "20" + year;
            //        request.VerifyCode = model.CVV;
            //        request.TransactionType = "card";
            //        request.UseRewardPoints = false;
            //        request.Attributes = (!string.IsNullOrEmpty(subscriptionId)) ? subscriptionId : null;
            //        request.IsWebOrder = true;

            //        var jsonString = JsonConvert.SerializeObject(request);
            //        var element = new JObject();
            //        element["Data"] = jsonString;
            //        byte[] byteData = Encoding.UTF8.GetBytes("{body}");
            //        byteData = Encoding.UTF8.GetBytes(element.ToString());

            //        using (var contentPayment = new ByteArrayContent(byteData))
            //        {
            //            contentPayment.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            //            var client = new HttpClient();
            //            var responsePayment = client.PostAsync(ShopfastAPIBaseUrl + "/sf_API/Service.svc/Json/CheckoutTransaction", contentPayment).Result;
            //            if (responsePayment.IsSuccessStatusCode)
            //            {
            //                var checkoutResponse = responsePayment.Content.ReadAsAsync<CheckoutResponse>().Result;
            //                if (checkoutResponse.CheckoutTransactionResult.Status)
            //                {
            //                    // If success then change store creted date based on selected package
            //                    // Make store "Purchased" from "Trial" based on "IsOrder" field                        
            //                    using (var dbContext = new Sites4Entities())
            //                    {
            //                        var site = dbContext.Sites.FirstOrDefault(s => s.Id == model.ownerModel.siteId);
            //                        var siteupdate = site;
            //                        if (site != null)
            //                        {
            //                            var owner = dbContext.Owners.FirstOrDefault(o => o.Id == site.Owner_Id);
            //                            //site.CreationDate = DateTime.UtcNow.AddDays(days); // no need to update creation date for purchased store
            //                            site.IsOrder = true;
            //                            site.Owner = owner;
            //                            dbContext.Entry(site).CurrentValues.SetValues(siteupdate);

            //                            //Add this order to SiteOrders and make other orders IsActive to false for this store.
            //                            var existingSiteOrders = dbContext.SiteOrders.Where(so => so.StoreName.ToLower() == site.StoreName.ToLower());
            //                            if (existingSiteOrders != null && existingSiteOrders.Any())
            //                            {
            //                                foreach (var order in existingSiteOrders)
            //                                {
            //                                    var orderUpdate = order;
            //                                    order.IsActive = false;
            //                                    dbContext.Entry(order).CurrentValues.SetValues(orderUpdate);
            //                                }
            //                            }
            //                            SiteOrders siteOrder = new SiteOrders()
            //                            {
            //                                StoreName = site.StoreName,
            //                                SiteId = site.Id,
            //                                OwnerId = site.Owner_Id,
            //                                OwnerEmail = owner.email,
            //                                PackageId = model.product.Id,
            //                                PackageName = model.product.Name,
            //                                OrderId = checkoutResponse.CheckoutTransactionResult.OrderId,
            //                                IsActive = true,
            //                                CreationDate = DateTime.UtcNow,
            //                                PlanExpirationDate = (model.PlanType == "monthly") ? DateTime.UtcNow.AddMonths(1) : DateTime.UtcNow.AddYears(1) // this for yearly
            //                            };
            //                            dbContext.SiteOrders.Add(siteOrder);
            //                            dbContext.SaveChanges();
            //                            checkoutResult = true;
            //                        }
            //                    }
            //                }
            //            }
            //        }
            //        #endregion
            //        if (checkoutResult)
            //        {
            //            #region Create Store and DB based on RegisterStore model
            //            //ShopFastHub.CreateStoreProcess(_oRegisterStoreModel.email, "step1");
            //            string storeName;
            //            _oRegisterStoreModel.storeName = _oRegisterStoreModel.storeName.SanitazeStoreName();

            //            // Copy database and settings
            //            SiteHelper.AddToSqlServer(_oRegisterStoreModel.storeName, _oRegisterStoreModel.industryType, out storeName);
            //            //ShopFastHub.CreateStoreProcess(_oRegisterStoreModel.email, "step2");

            //            var customer = _workContext.CurrentCustomer;

            //            // Setup store admin credentials and basic settings into database.
            //            var storeDatabase = SiteHelper.GetStoreConnectionString(storeName);
            //            MultiSiteDataProvider.ConfigureStoreDatabase(_oRegisterStoreModel.storeName, storeDatabase, _oRegisterStoreModel.email, string.Empty, MultisiteHelper.DefaultTheme, null);

            //            _oRegisterStoreModel.isOrder = true;

            //            using (var dbContext = new Sites4Entities())
            //            {
            //                var owner = dbContext.Owners.Where(o => o.Id == _oRegisterStoreModel.OwnerId).FirstOrDefault();
            //                if (owner != null)
            //                {
            //                    owner.Selling = _oRegisterStoreModel.Selling;
            //                    owner.SomethingToSell = _oRegisterStoreModel.SomethingToSell;
            //                    owner.HelpBusinessLogo = _oRegisterStoreModel.HelpBusinessLogo;
            //                    owner.HelpBusinessBrainStorm = _oRegisterStoreModel.HelpBusinessBrainStorm;
            //                    owner.HelpBusinessWebinar = _oRegisterStoreModel.HelpBusinessWebinar;
            //                    owner.HelpBusinessProduct = _oRegisterStoreModel.HelpBusinessProduct;
            //                    owner.SystemName = _oRegisterStoreModel.SystemName;
            //                    owner.LaunchStore = _oRegisterStoreModel.LaunchStore;
            //                    owner.WhatToSell = _oRegisterStoreModel.WhatToSell;
            //                    owner.SellAtMarket = _oRegisterStoreModel.SellAtMarket;
            //                    owner.SellAtRetailStore = _oRegisterStoreModel.SellAtRetailStore;
            //                    owner.CurrentRevenue = _oRegisterStoreModel.CurrentRevenue;
            //                    owner.StoreForCLient = _oRegisterStoreModel.StoreForCLient;

            //                    owner.description = _oRegisterStoreModel.Description;
            //                    owner.firstName = _oRegisterStoreModel.firstName;
            //                    owner.LastName = _oRegisterStoreModel.lastName;
            //                    owner.phone = _oRegisterStoreModel.phone;
            //                    owner.starting = _oRegisterStoreModel.Starting;
            //                    owner.Country = _oRegisterStoreModel.Country;
            //                    owner.Website = _oRegisterStoreModel.Website;
            //                    owner.StreetAddress = _oRegisterStoreModel.StreetAddress;
            //                    owner.StreetAddress2 = _oRegisterStoreModel.StreetAddress2;
            //                    owner.City = _oRegisterStoreModel.City;
            //                    owner.ZipPostalCode = _oRegisterStoreModel.ZipPostalCode;
            //                    owner.State = _oRegisterStoreModel.State;

            //                    owner.AvgSaleAmout = _oRegisterStoreModel.AvgSaleAmout;
            //                    owner.ProcessorName = _oRegisterStoreModel.ProcessorName;
            //                    owner.ProcessorEmail = _oRegisterStoreModel.ProcessorEmail;
            //                    owner.ProcessorPhoneNumber = _oRegisterStoreModel.ProcessorPhoneNumber;
            //                    owner.SiteCategory = _oRegisterStoreModel.SiteCategory;
            //                    owner.TeamPeople = _oRegisterStoreModel.TeamPeople;
            //                    owner.Reason = _oRegisterStoreModel.Reason;
            //                    owner.IsRegistered = true;

            //                    // Need to encrypt this card info
            //                    owner.CardType = "Visa";
            //                    owner.CardName = "test";
            //                    owner.CardNumber = _encryptionService.EncryptText(model.cardNumber);
            //                    owner.VerifyCode = _encryptionService.EncryptText(model.CVV);
            //                    owner.ExpiryMonth = _encryptionService.EncryptText(month);
            //                    owner.ExpiryYear = _encryptionService.EncryptText("20" + year);

            //                    dbContext.Entry(owner).CurrentValues.SetValues(owner);
            //                    dbContext.SaveChanges();

            //                    // Add host in plesk.
            //                    _oRegisterStoreModel.password = PasswordGenerator(12, true);
            //                    //ShopFastHub.CreateStoreProcess(_oRegisterStoreModel.email, "step3");
            //                    //var hostResult = SiteHelper.AddPleskHost(_oRegisterStoreModel);
            //                    var hostResult = true;
            //                    if (hostResult)
            //                    {
            //                        // Upload file in FTP server.
            //                        //var ftpUserName = _oRegisterStoreModel.email.Split('@')[0].ToString().Length > 15 ? _oRegisterStoreModel.email.Split('@')[0].Substring(0, 15) : _oRegisterStoreModel.email.Split('@')[0];

            //                        //SiteHelper.UploadFtpFile(_oRegisterStoreModel.storeName, ftpUserName, _oRegisterStoreModel.password);

            //                        var _workflowMessageService = new MultisiteWorkflowMessageService();
            //                        _workflowMessageService.SendTrialStoreCreatedCustomerNotification(_oRegisterStoreModel);
            //                        _workflowMessageService.SendTrialStoreCreatedAdminNotification(_oRegisterStoreModel);

            //                        //ShopFastHub.CreateStoreProcess(_oRegisterStoreModel.email, "step4");

            //                        return Json(new { storeUrl = string.Format(@"http://{0}.{1}/MerchantAdminAutoLogin?email={2}&owner_id={3}", _oRegisterStoreModel.storeName, MultisiteHelper.Domain, customer.Email, _oRegisterStoreModel.OwnerId) });
            //                    }
            //                }
            //            }

            //            #endregion
            //        }
            //        // if checkout API failed and trasaction not done
            //        //{
            //        // Rollback store which is created
            //        // 1) delete registered customer from DB physically
            //        // delete site and owner of that customer
            //        // delete store and sub domain from PLESK
            //        // delete DB of that store
            //        //}            
            //    }
            //    else
            //    {
            //        return Json(new { error = "Error : Plan is not selected. Please select a plan" });
            //    }

            //}
            return Json(new { error = "Error while creating a store. Please try again." });
        }

        public ActionResult ApplyDiscountCouponOLD(string _pPrice, string _pCouponCode)
        {
            decimal checkoutPrice = 0;
            decimal.TryParse(_pPrice, out checkoutPrice);
            decimal finalPrice = checkoutPrice;
            // get all discount coupons from API            
            var client = new HttpClient();
            HttpResponseMessage response = client.GetAsync(ShopfastAPIBaseUrl + "/sf_api/service.svc/json/getdiscounts").Result;
            if (response.IsSuccessStatusCode)
            {
                var discountsString = response.Content.ReadAsStringAsync().Result;
                JavaScriptSerializer js = new JavaScriptSerializer();
                var discounts = js.Deserialize<DiscountsResponse>(discountsString);
                if (discounts != null && discounts.GetDiscountsResult != null && discounts.GetDiscountsResult.Any())
                {
                    var discount = discounts.GetDiscountsResult.FirstOrDefault(d => d.Name.Equals(_pCouponCode, StringComparison.InvariantCultureIgnoreCase));
                    if (discount != null)
                    {
                        //check date range
                        DateTime now = DateTime.UtcNow;
                        if (discount.StartDateUtc.HasValue)
                        {
                            DateTime startDate = DateTime.SpecifyKind(discount.StartDateUtc.Value, DateTimeKind.Utc);
                            if (startDate.CompareTo(now) > 0)
                            {
                                return Json(new
                                {
                                    success = false,
                                    message = _localizationService.GetResource("ShoppingCart.Discount.NotStartedYet")
                                });
                            }
                        }
                        if (discount.EndDateUtc.HasValue)
                        {
                            DateTime endDate = DateTime.SpecifyKind(discount.EndDateUtc.Value, DateTimeKind.Utc);
                            if (endDate.CompareTo(now) < 0)
                            {
                                return Json(new
                                {
                                    success = false,
                                    message = _localizationService.GetResource("ShoppingCart.Discount.Expired")
                                });
                            }
                        }
                        if (discount.UsePercentag)
                        {
                            var discountPrice = (checkoutPrice * discount.DiscountPercentage) / 100;
                            finalPrice = checkoutPrice - discountPrice;
                        }
                        else
                        {
                            finalPrice = checkoutPrice - discount.DiscountAmount;
                        }
                        return Json(new
                        {
                            success = true,
                            finalprice = finalPrice,
                            finalpricestring = finalPrice.ToString("G29"),
                            message = _localizationService.GetResource("ShoppingCart.DiscountCouponCode.Applied")
                        });
                    }
                }
            }
            return Json(new
            {
                success = false,
                message = _localizationService.GetResource("ShoppingCart.DiscountCouponCode.WrongDiscount")
            });
        }

        public ActionResult ApplyDiscountCoupon(string _pPrice, string _pCouponCode, int _pProductId = 0)
        {
            if (_pProductId == 0)
            {
                return Json(new
                {
                    success = false,
                    message = "Package is not available"
                });
            }
            var jsonResult = new JsonResult();
            //trim
            if (_pCouponCode != null)
                _pCouponCode = _pCouponCode.Trim();
            // Delete cart of existing customer
            _shoppingCartServiceCustom.DeleteShoppingCartItemForCustomer(_workContext.CurrentCustomer);

            // Add to cart
            var product = _productService.GetProductById(_pProductId);
            _shoppingCartService.AddToCart(_workContext.CurrentCustomer,
    product, ShoppingCartType.ShoppingCart, _storeContext.CurrentStore.Id,
    null, decimal.Zero,
    null, null, 1, true);

            //cart
            var cart = _workContext.CurrentCustomer.ShoppingCartItems
                .Where(sci => sci.ShoppingCartType == ShoppingCartType.ShoppingCart)
                .LimitPerStore(_storeContext.CurrentStore.Id)
                .ToList();

            //parse and save checkout attributes
            //ParseAndSaveCheckoutAttributes(cart, form);

            List<string> Messages = new List<string>();
            if (!String.IsNullOrWhiteSpace(_pCouponCode))
            {
                //we find even hidden records here. this way we can display a user-friendly message if it's expired
                var discounts = _discountService.GetAllDiscountsForCaching(couponCode: _pCouponCode, showHidden: true)
                    .Where(d => d.RequiresCouponCode)
                    .ToList();
                if (discounts.Any())
                {
                    var userErrors = new List<string>();
                    var anyValidDiscount = discounts.Any(discount =>
                    {
                        var validationResult = _discountService.ValidateDiscount(discount, _workContext.CurrentCustomer, new[] { _pCouponCode });
                        userErrors.AddRange(validationResult.Errors);
                        return validationResult.IsValid;
                    });

                    if (anyValidDiscount)
                    {
                        //valid
                        _workContext.CurrentCustomer.ApplyDiscountCouponCode(_pCouponCode);
                        Messages.Add(_localizationService.GetResource("ShoppingCart.DiscountCouponCode.Applied"));
                        List<AppliedGiftCard> appliedGiftCards;
                        List<DiscountForCaching> orderAppliedDiscounts;
                        decimal orderDiscountAmount;
                        int redeemedRewardPoints;
                        decimal redeemedRewardPointsAmount;
                        var orderTotal = _orderTotalCalculationService.GetShoppingCartTotal(cart, out orderDiscountAmount,
                out orderAppliedDiscounts, out appliedGiftCards, out redeemedRewardPoints, out redeemedRewardPointsAmount);
                        if (!orderTotal.HasValue)
                        {
                            Messages.Add("Order total couldn't be calculated");
                            jsonResult = Json(new
                            {
                                success = false,
                                message = String.Join("</br>", Messages)
                            });
                        }
                        else
                        {
                            jsonResult = Json(new
                            {
                                success = true,
                                finalprice = orderTotal,
                                finalpricestring = Convert.ToDecimal(orderTotal).ToString("G29"),
                                message = String.Join("</br>", Messages)
                            });
                            return jsonResult;
                        }
                    }
                    else
                    {
                        if (userErrors.Any())
                            //some user errors
                            Messages = userErrors;
                        else
                            //general error text
                            Messages.Add(_localizationService.GetResource("ShoppingCart.DiscountCouponCode.WrongDiscount"));
                    }
                }
                else
                    //discount cannot be found
                    Messages.Add(_localizationService.GetResource("ShoppingCart.DiscountCouponCode.WrongDiscount"));
            }
            else
                //empty coupon code
                Messages.Add(_localizationService.GetResource("ShoppingCart.DiscountCouponCode.WrongDiscount"));
            jsonResult = Json(new
            {
                success = false,
                message = String.Join("</br>", Messages)
            });
            return jsonResult;
        }

        public ActionResult RemoveDiscountCoupon(string _pCouponCode)
        {
            var discount = _discountService.GetAllDiscountsForCaching(couponCode: _pCouponCode)
                    .FirstOrDefault(d => d.RequiresCouponCode && _discountService.ValidateDiscount(d, _workContext.CurrentCustomer).IsValid);
            if (discount != null)
            {
                _workContext.CurrentCustomer.RemoveDiscountCouponCode(discount.CouponCode);
            }
            var cart = _workContext.CurrentCustomer.ShoppingCartItems
              .Where(sci => sci.ShoppingCartType == ShoppingCartType.ShoppingCart)
              .LimitPerStore(_storeContext.CurrentStore.Id)
              .ToList();

            List<AppliedGiftCard> appliedGiftCards;
            List<DiscountForCaching> orderAppliedDiscounts;
            decimal orderDiscountAmount;
            int redeemedRewardPoints;
            decimal redeemedRewardPointsAmount;
            var orderTotal = _orderTotalCalculationService.GetShoppingCartTotal(cart, out orderDiscountAmount,
                out orderAppliedDiscounts, out appliedGiftCards, out redeemedRewardPoints, out redeemedRewardPointsAmount);
            return Json(new
            {
                finalprice = orderTotal,
                finalpricestring = Convert.ToDecimal(orderTotal).ToString("G29"),
                success = true
            });
        }

        public ActionResult SuspendStore()
        {
            return View(string.Format("/Themes/{0}/Views/Plans/SuspendStore.cshtml", EngineContext.Current.Resolve<IThemeContext>().WorkingThemeName));
        }

        #region My Account - Package Order        
        public ActionResult PackageOrders()
        {
            if (!_workContext.CurrentCustomer.IsRegistered())
                return new HttpUnauthorizedResult();
            CustomerOrderListModelCustom model = new CustomerOrderListModelCustom();
            var email = _workContext.CurrentCustomer.Email;
            if (!string.IsNullOrEmpty(email))
            {
                using (var dbContext = new Sites4Entities())
                {
                    var owner = dbContext.Owners.FirstOrDefault(s => s.email.ToLower() == email.ToLower());
                    if (owner != null)
                    {
                        var site = dbContext.Sites.FirstOrDefault(s => s.Owner_Id == owner.Id);
                        if (site != null)
                        {
                            var siteOrder = dbContext.SiteOrders.Where(s => s.StoreName.ToLower() == site.StoreName.ToLower());
                            if (siteOrder != null)
                            {
                                var client = new HttpClient();
                                HttpResponseMessage response = client.GetAsync(ShopfastAPIBaseUrl + "/api/v1/sales/online-orders/").Result;
                                if (response.IsSuccessStatusCode)
                                {
                                    var orderString = response.Content.ReadAsStringAsync().Result;
                                    JavaScriptSerializer js = new JavaScriptSerializer();
                                    var order = js.Deserialize<List<CustomerOrderListModelCustom.OrderDetailsModel>>(orderString);
                                    order = order.Where(o => siteOrder.Any(so => so.OrderId == o.Id)).OrderByDescending(o => o.CreatedOn).ToList();
                                    order.ForEach(o =>
                                    {
                                        o.IsActive = siteOrder.FirstOrDefault(so => so.OrderId == o.Id).IsActive;
                                    });
                                    model.Orders = order;
                                }
                            }
                        }
                    }
                    else
                    {
                        model.Message = _localizationService.GetResource("Account.PackageOrders.Message");
                    }
                }
            }
            return View(string.Format("/Themes/{0}/Views/Plans/PackageOrders.cshtml", EngineContext.Current.Resolve<IThemeContext>().WorkingThemeName), model);
        }

        public ActionResult PackageOrderDetail(int orderId)
        {
            OrderDetailsModel model = new OrderDetailsModel();
            //var subdomain = MultisiteHelper.SubDomain;
            //if (!string.IsNullOrEmpty(subdomain))
            //{
            using (var dbContext = new Sites4Entities())
            {
                //var siteOrder = dbContext.SiteOrders.FirstOrDefault(s => s.StoreName.ToLower() == subdomain.ToLower() && s.IsActive == true);
                //if (siteOrder != null)
                //{
                var client = new HttpClient();
                HttpResponseMessage response = client.GetAsync(ShopfastAPIBaseUrl + "/api/v1/sales/online-orders/" + orderId).Result;
                if (response.IsSuccessStatusCode)
                {
                    var orderString = response.Content.ReadAsStringAsync().Result;
                    JavaScriptSerializer js = new JavaScriptSerializer();
                    model = js.Deserialize<OrderDetailsModel>(orderString);
                }
                //}
            }
            //}
            return View(string.Format("/Themes/{0}/Views/Plans/PackageOrderDetail.cshtml", EngineContext.Current.Resolve<IThemeContext>().WorkingThemeName), model);
        }
        #endregion

        #region My Account - Merchant Card
        public ActionResult MerchantCards()
        {
            if (!_workContext.CurrentCustomer.IsRegistered())
                return new HttpUnauthorizedResult();
            MerchantCardInfo model = new MerchantCardInfo();
            var email = _workContext.CurrentCustomer.Email;
            if (!string.IsNullOrEmpty(email))
            {
                using (var dbContext = new Sites4Entities())
                {
                    var owner = dbContext.Owners.FirstOrDefault(s => s.email.ToLower() == email.ToLower());
                    if (owner != null)
                    {
                        string ExpiryMonth = "";
                        string ExpiryYear = "";
                        if (!string.IsNullOrEmpty(owner.CardNumber))
                        {
                            model.CardNumber = _encryptionService.DecryptText(owner.CardNumber.Trim());
                            model.CardNumber = CommonHelperCustom.ReplaceAll(model.CardNumber, 'X', 4);
                            _logger.Information("Card number : " + model.CardNumber);
                        }
                        if (!string.IsNullOrEmpty(owner.ExpiryMonth))
                            ExpiryMonth = _encryptionService.DecryptText(owner.ExpiryMonth.Trim());
                        if (!string.IsNullOrEmpty(owner.ExpiryYear))
                            ExpiryYear = _encryptionService.DecryptText(owner.ExpiryYear.Trim());
                        if (!string.IsNullOrEmpty(owner.VerifyCode))
                            model.CVV = _encryptionService.DecryptText(owner.VerifyCode.Trim());
                        if (!string.IsNullOrEmpty(owner.CardName))
                            model.CardName = _encryptionService.DecryptText(owner.CardName.Trim());
                        if (!string.IsNullOrEmpty(owner.ZipCode))
                            model.ZipCode = _encryptionService.DecryptText(owner.ZipCode.Trim());
                        model.Expires = ExpiryMonth + ExpiryYear.Substring(ExpiryYear.Length - 2);
                        model.OwnerEmail = email;
                    }
                    else
                    {
                        model.Message = _localizationService.GetResource("Account.MerchantCards.Message");
                    }
                }
            }
            return View(string.Format("/Themes/{0}/Views/Plans/MerchantCards.cshtml", EngineContext.Current.Resolve<IThemeContext>().WorkingThemeName), model);
        }

        [HttpPost]
        [PublicAntiForgery]
        public ActionResult MerchantCards(MerchantCardInfo model)
        {
            if (!_workContext.CurrentCustomer.IsRegistered())
                return new HttpUnauthorizedResult();
            string month = "";
            string year = "";
            if (!string.IsNullOrEmpty(model.Expires))
            {
                string[] expires = model.Expires.Split('/');
                if (expires != null && expires.Any())
                    month = expires[0].Trim();
                if (expires.Count() > 1)
                    year = expires[1].Trim();
            }
            using (var dbContext = new Sites4Entities())
            {
                var owner = dbContext.Owners.FirstOrDefault(s => s.email.ToLower() == model.OwnerEmail.ToLower());
                if (owner != null)
                {
                    int count = 0;
                    if (!string.IsNullOrEmpty(model.CardNumber))
                    {
                        owner.CardNumber = _encryptionService.EncryptText(model.CardNumber);
                        count = 1;
                    }

                    if (!string.IsNullOrEmpty(month))
                    {
                        owner.ExpiryMonth = _encryptionService.EncryptText(month);
                        count = 1;
                    }

                    if (!string.IsNullOrEmpty(year))
                    {
                        owner.ExpiryYear = _encryptionService.EncryptText(year);
                        count = 1;
                    }

                    if (!string.IsNullOrEmpty(model.CVV))
                    {
                        owner.VerifyCode = _encryptionService.EncryptText(model.CVV);
                        count = 1;
                    }

                    if (!string.IsNullOrEmpty(model.CardName))
                    {
                        owner.CardName = _encryptionService.EncryptText(model.CardName);
                        count = 1;
                    }

                    if (!string.IsNullOrEmpty(model.ZipCode))
                    {
                        owner.ZipCode = _encryptionService.EncryptText(model.ZipCode);
                        count = 1;
                    }
                    if (count == 1)
                    {
                        dbContext.Entry(owner).CurrentValues.SetValues(owner);
                        dbContext.SaveChanges();

                        CheckForRecuringOrders(owner);
                        // Run backgroud task to create recuring order for this store if remaining in past months/year
                        // 1) Get first IsActive=true record from SiteOrder table of this store owner by email
                        // If plan and order found from SiteOrder of this store then only do below process                        
                        // get product detail from API by id and check for "ispackage"=yes and "pricing"=monthly/yearly
                        // based on monthly or yearly, check recuring period not done for how many months/year based on current date
                        // if required to recuring plan then only get order details based on order id of SiteOrder table
                        // then based on that period do the "ReOrderChecout" same as done in RecuringPlansTask.cs
                    }
                }
            }
            return RedirectToRoute("MerchantCards");
        }

        private void CheckForRecuringOrders(Owner owner)
        {
            _logger.Information("1. CheckForRecuringOrders Start");
            using (var dbContext = new Sites4Entities())
            {
                // Get site order
                var siteOrder = dbContext.SiteOrders.FirstOrDefault(s => s.OwnerEmail == owner.email && s.IsActive == true);
                if (siteOrder != null)
                {
                    // get plan from API
                    ProductRespose productRespose = new ProductRespose();
                    var client = new HttpClient();
                    HttpResponseMessage response = client.GetAsync(ShopfastAPIBaseUrl + "/api/v1/catalog/products/app-products").Result;
                    if (response.IsSuccessStatusCode)
                    {
                        var productsString = response.Content.ReadAsStringAsync().Result;
                        JavaScriptSerializer js = new JavaScriptSerializer();
                        var products = js.Deserialize<List<AppProductListModel>>(productsString);
                        _logger.Information("2. Get prodicts from API");
                        if (products != null && products.Any())
                        {
                            var product = products.FirstOrDefault(p => p.Id == siteOrder.PackageId && p.ProductSpecificationAttributes != null
                          && p.ProductSpecificationAttributes.Any(ps => ps.AttributeName.ToLower() == "ispackage" && ps.ValueRaw.ToLower() == "yes")
                          );
                            if (product != null)
                            {
                                var siteOrderDate = siteOrder.CreationDate;
                                var currentDate = DateTime.UtcNow.Date;
                                bool _bResult = false;
                                if (product.ProductSpecificationAttributes.Any(ps => ps.AttributeName.ToLower() == "pricing" && ps.ValueRaw.ToLower() == "monthly"))
                                {
                                    var months = (currentDate.Month - siteOrderDate.Month) + 12 * (currentDate.Year - siteOrderDate.Year);
                                    for (int j = 1; j <= months; j++)
                                    {
                                        var recusringOrderDate = siteOrderDate.AddMonths(j);
                                        if (recusringOrderDate <= currentDate)
                                        {
                                            _bResult = _recuringPlansService.ReOrderChecoutSingle(product, 1, siteOrder, owner);
                                            _logger.Information("2. CheckForRecuringOrders - Monthly , Product = " + product.Id + "," + product.Name + " , Cycle = " + j + " , recusringOrderDate = " + recusringOrderDate.ToString() + " , _bResult" + _bResult);
                                            if (!_bResult) // if _bResult false then no need to check for other months/years, so break the for loop
                                            {
                                                _logger.Information("3. CheckForRecuringOrders - BREAK Monthly , Product = " + product.Id + "," + product.Name + " , Cycle = " + j + " , recusringOrderDate = " + recusringOrderDate.ToString() + " , _bResult" + _bResult);
                                                break;
                                            }
                                        }
                                    }
                                }
                                else if (product.ProductSpecificationAttributes.Any(ps => ps.AttributeName.ToLower() == "pricing" && ps.ValueRaw.ToLower() == "yearly"))
                                {
                                    var years = currentDate.Year - siteOrderDate.Year;
                                    for (int j = 1; j <= years; j++)
                                    {
                                        var recusringOrderDate = siteOrderDate.AddYears(j);
                                        if (recusringOrderDate <= currentDate)
                                        {
                                            _bResult = _recuringPlansService.ReOrderChecoutSingle(product, 12, siteOrder, owner);
                                            _logger.Information("2. CheckForRecuringOrders - Yearly , Product = " + product.Id + "," + product.Name + " , Cycle = " + j + " , recusringOrderDate = " + recusringOrderDate.ToString() + " , _bResult" + _bResult);
                                            if (!_bResult) // if _bResult false then no need to check for other months/years, so break the for loop
                                            {
                                                _logger.Information("3. CheckForRecuringOrders - BREAK Yearly , Product = " + product.Id + "," + product.Name + " , Cycle = " + j + " , recusringOrderDate = " + recusringOrderDate.ToString() + " , _bResult" + _bResult);
                                                break;
                                            }
                                        }
                                    }
                                }
                                if (_bResult == true)
                                {
                                    // Renew the store from suspend
                                    var existingSite = dbContext.Sites.FirstOrDefault(so => so.Id == siteOrder.SiteId);
                                    var siteUpdate = existingSite;
                                    existingSite.IsSuspend = false;
                                    dbContext.Entry(existingSite).CurrentValues.SetValues(siteUpdate);
                                    _logger.Information("4. CheckForRecuringOrders - Store renew from suspend for the Store = " + existingSite.Id + "," + existingSite.StoreName + "  , Product = " + product.Id + "," + product.Name + " , _bResult" + _bResult);
                                }
                            }
                        }
                    }
                }
            }
        }
        #endregion

        #region Pricing Sign Up
        public ActionResult PricingSignUp()
        {
            return View(string.Format("/Themes/{0}/Views/Plans/PricingSignUp.cshtml", EngineContext.Current.Resolve<IThemeContext>().WorkingThemeName));
        }

        [HttpPost]
        public ActionResult PricingSignUp(FormCollection fc)
        {
            bool result = false;
            Task.WaitAll(Task.Run(async () => { result = await CRMHelper.CrmApi.ShopfastSignUpPricingCRMPost(fc); }));
            return Json(new { success = true, message = _localizationService.GetResource("Pricing.Signup.Successmessage") });
        }
        #endregion

    }
}