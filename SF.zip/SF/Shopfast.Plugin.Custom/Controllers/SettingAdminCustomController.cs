﻿using Nop.Admin.Controllers;
using Nop.Admin.Models.Settings;
using Nop.Core.Infrastructure;
using Nop.Web.Framework.Themes;
using Shopfast.Plugin.Custom.Models.NopAdmin.Settings;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Shopfast.Plugin.Custom.Controllers
{
    public class SettingAdminCustomController : BaseAdminController
    {
        #region Fields
        private readonly IThemeProvider _themeProvider;
        #endregion

        #region Constructors
        public SettingAdminCustomController(IThemeProvider themeProvider)
        {
            this._themeProvider = themeProvider;
        }
        #endregion
        // GET: SettingAdminCustom
        public ActionResult AdminThemeSelectionView()
        {
            GeneralCommonSettingsModelCustom model = new GeneralCommonSettingsModelCustom();
            string DefaultStoreThemeForAdmin = EngineContext.Current.Resolve<Nop.Services.Configuration.ISettingService>().GetSettingByKey<string>("storeinformationsettings.defaultstorethemeforadmin");
            model.DefaultStoreThemeForAdmin = DefaultStoreThemeForAdmin;
            model.AvailableStoreThemesForAdmin = _themeProvider
                .GetAdminThemeConfigurations()
                .Select(x =>
                {
                    return new SelectListItem()
                    {
                        Text = x.ThemeTitle,
                        Value = x.ThemeName,
                        Selected = x.ThemeName.Equals(DefaultStoreThemeForAdmin, StringComparison.InvariantCultureIgnoreCase)
                    };
                })
                .ToList();
            //select default from web.config admin theme if none selected
            if (!model.AvailableStoreThemesForAdmin.Any(t => t.Selected))
            {
                model.DefaultStoreThemeForAdmin = System.Configuration.ConfigurationManager.AppSettings["defaultstorethemeforadmin"]; ;
            }
            return View(model);
        }
    }
}