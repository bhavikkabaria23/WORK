﻿using Nop.Admin.Controllers;
using Nop.Core;
using Nop.Core.Configuration;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Stores;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Mvc;
using Shopfast.Plugin.Custom.Models.NopAdmin.RecuringOrderTaskConfig;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Shopfast.Plugin.Custom.Controllers
{
    public class RecuringOrderTaskConfigController : BaseAdminController
    {
        private readonly IWorkContext _workContext;
        private readonly IStoreService _storeService;
        private readonly ISettingService _settingService;
        private readonly ILocalizationService _localizationService;

        public RecuringOrderTaskConfigController(IWorkContext workContext,
            IStoreService storeService,
            ISettingService settingService,
            ILocalizationService localizationService)
        {
            this._workContext = workContext;
            this._storeService = storeService;
            this._settingService = settingService;
            this._localizationService = localizationService;
        }

        [AdminAuthorize]        
        public ActionResult Configure()
        {
            //load settings for a chosen store scope
            var storeScope = this.GetActiveStoreScopeConfiguration(_storeService, _workContext);
            var recuringOrderTaskSettings = _settingService.LoadSetting<RecuringOrderTaskSettings>(storeScope);

            var model = new ConfigurationModel();
            model.StartTime = Convert.ToDateTime(recuringOrderTaskSettings.StartTime);
            model.EndTime = Convert.ToDateTime(recuringOrderTaskSettings.EndTime);            

            model.ActiveStoreScopeConfiguration = storeScope;
            if (storeScope > 0)
            {
                model.StartTime_OverrideForStore = _settingService.SettingExists(recuringOrderTaskSettings, x => x.StartTime, storeScope);
                model.EndTime_OverrideForStore = _settingService.SettingExists(recuringOrderTaskSettings, x => x.EndTime, storeScope);                
            }

            return View("~/Plugins//Shopfast.Plugin.Custom/Views/RecuringOrderTaskConfig/Configure.cshtml", model);
        }

        [HttpPost]
        [AdminAuthorize]        
        public ActionResult Configure(ConfigurationModel model)
        {
            if (!ModelState.IsValid)
                return Configure();

            //load settings for a chosen store scope
            var storeScope = this.GetActiveStoreScopeConfiguration(_storeService, _workContext);
            var recuringOrderTaskSettings = _settingService.LoadSetting<RecuringOrderTaskSettings>(storeScope);

            //save settings
            recuringOrderTaskSettings.StartTime = model.StartTime;
            recuringOrderTaskSettings.EndTime = model.EndTime;            

            /* We do not clear cache after each setting update.
             * This behavior can increase performance because cached settings will not be cleared 
             * and loaded from database after each update */

            _settingService.SaveSettingOverridablePerStore(recuringOrderTaskSettings, x => x.StartTime, model.StartTime_OverrideForStore, storeScope, false);
            _settingService.SaveSettingOverridablePerStore(recuringOrderTaskSettings, x => x.EndTime, model.EndTime_OverrideForStore, storeScope, false);            

            //now clear settings cache
            _settingService.ClearCache();

            SuccessNotification(_localizationService.GetResource("Admin.Plugins.Saved"));

            return Configure();
        }
    }

    public class RecuringOrderTaskSettings : ISettings
    {
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
    }    
}