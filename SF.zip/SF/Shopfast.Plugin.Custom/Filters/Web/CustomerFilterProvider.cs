﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Nop.Web.Controllers;

namespace Shopfast.Plugin.Custom.Filters.Web
{
    public class CustomerFilterProvider : IFilterProvider
    {
        public IEnumerable<Filter> GetFilters(ControllerContext controllerContext, ActionDescriptor actionDescriptor)
        {
            if ((actionDescriptor.ControllerDescriptor.ControllerType == typeof(CustomerController)) &&
                (actionDescriptor.ActionName.ToLower().Equals("login")) ||
                (actionDescriptor.ActionName.ToLower().Equals("resellersignup") && controllerContext.HttpContext.Request.HttpMethod == "POST")
                )
                //(actionDescriptor.ActionName.Equals("OpcConfirmOrder") || actionDescriptor.ActionName.Equals("ConfirmOrder")))
            {
                return new[]
                    {
                        new Filter(new CustomerFilterAttribute(), FilterScope.Action, null)
                    };
            }

            return new Filter[] { };
        }
    }
}