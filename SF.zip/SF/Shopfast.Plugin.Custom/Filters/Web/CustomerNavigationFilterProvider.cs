﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Nop.Web.Controllers;
using Shopfast.Plugin.Custom.Filters.Web;

namespace Shopfast.Plugin.Custom.Filters.Web
{
    public class CustomerNavigationFilterProvider : IFilterProvider
    {
        public IEnumerable<Filter> GetFilters(ControllerContext controllerContext, ActionDescriptor actionDescriptor)
        {
            if ((actionDescriptor.ControllerDescriptor.ControllerType == typeof(CustomerController)) &&
                (actionDescriptor.ActionName.Equals("CustomerNavigation")))
            {
                return new[]
                    {
                        new Filter(new CustomerNavigationFilterAttribute(), FilterScope.Action, null)
                    };
            }

            return new Filter[] { };
        }
    }
}