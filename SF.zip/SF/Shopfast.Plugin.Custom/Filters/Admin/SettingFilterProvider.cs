﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Nop.Admin.Controllers;

namespace Shopfast.Plugin.Custom.Filters.Admin
{
    public class SettingFilterProvider : IFilterProvider
    {
        public IEnumerable<Filter> GetFilters(ControllerContext controllerContext, ActionDescriptor actionDescriptor)
        {
            if ((actionDescriptor.ControllerDescriptor.ControllerType == typeof(SettingController)) &&
                (actionDescriptor.ActionName.Equals("GeneralCommon")))
            {
                return new[]
                    {
                        new Filter(new SettingFilterAttribute(), FilterScope.Action, null)
                    };
            }

            return new Filter[] { };
        }
    }
}