﻿using Nop.Admin.Controllers;
using Nop.Admin.Models.Settings;
using Nop.Core;
using Nop.Core.Data;
using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Services.Configuration;
using Nop.Services.Stores;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Themes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Shopfast.Plugin.Custom.Filters.Admin
{
    public class SettingFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {

        }
        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            if (filterContext.Controller.ControllerContext.HttpContext.Request.HttpMethod == "POST")
            {
                // Save / Update Admin Theme. Now we do not need this
                //var form = filterContext.HttpContext.Request.Unvalidated.Form;
                //if (form != null)
                //{
                //    var DefaultStoreThemeForAdmin = form["DefaultStoreThemeForAdmin"];
                //    var dbContext = EngineContext.Current.Resolve<IDbContext>();
                //    int cnt = dbContext.SqlQuery<int>("select count(*) from Setting where Name =@p0", "storeinformationsettings.defaultstorethemeforadmin").FirstOrDefault();
                //    if (cnt > 0)
                //    {
                //        dbContext.ExecuteSqlCommand("update Setting SET Value=@p0 WHERE Name=@p1", false, null,
                //        DefaultStoreThemeForAdmin, "storeinformationsettings.defaultstorethemeforadmin");
                //    }
                //    else
                //    {
                //        dbContext.ExecuteSqlCommand("insert into Setting (Name,Value,StoreId) VALUES (@p0,@p1,@p2)", false, null,
                //        "storeinformationsettings.defaultstorethemeforadmin", DefaultStoreThemeForAdmin, 0);
                //    }

                //}
            }
            else
            {
                if (!MultisiteHelper.IsAdminSite)
                {
                    var generalCommonSettingsModel = filterContext.Controller.ViewData.Model as GeneralCommonSettingsModel;
                    var availableThemes = EngineContext.Current.Resolve<IThemeProvider>().GetThemeConfigurations();

                    //------Show only those themes which have the rights for particular Store-------
                    availableThemes = availableThemes
                        .Where(t => MultisiteHelper.GetAllSiteThemes(MultisiteHelper.SubDomain, false).Any(x => x.ThemeName == t.ThemeName))
                        .Where(x => x.Stores == "" || x.Stores.Split(',').Select(s => s.Trim().ToLower()).Contains(MultisiteHelper.CurrentUrl.ToLower()))
                        .DefaultIfEmpty(availableThemes.SingleOrDefault(x => x.ThemeName == MultisiteHelper.DefaultTheme))
                        .ToList();

                    var dbContext = EngineContext.Current.Resolve<IDbContext>();
                    var DefaultStoreTheme = Convert.ToString(dbContext.SqlQuery<string>("select Value from Setting where Name =@p0", "storeinformationsettings.defaultstoretheme").FirstOrDefault());

                    generalCommonSettingsModel.StoreInformationSettings.AvailableStoreThemes = availableThemes
                     .Select(x => new GeneralCommonSettingsModel.StoreInformationSettingsModel.ThemeConfigurationModel
                     {
                         ThemeTitle = x.ThemeTitle,
                         ThemeName = x.ThemeName,
                         PreviewImageUrl = x.PreviewImageUrl,
                         PreviewText = x.PreviewText,
                         SupportRtl = x.SupportRtl,
                         Selected = x.ThemeName.Equals(DefaultStoreTheme, StringComparison.InvariantCultureIgnoreCase)
                     })
                     .ToList();
                }
            }
        }
    }
}