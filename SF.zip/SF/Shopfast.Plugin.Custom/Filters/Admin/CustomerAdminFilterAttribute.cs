﻿using MultiSite.Models;
using Nop.Admin.Models.Customers;
using Nop.Core.Data;
using Nop.Core.Domain.Customers;
using Nop.Core.Infrastructure;
using Nop.Services.Customers;
using Shopfast.Plugin.Custom.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Shopfast.Plugin.Custom.Filters.Admin
{
    public class CustomerAdminFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {

        }
        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            if (filterContext.HttpContext.Request["changepassword"] != null)
            {
                if (filterContext.HttpContext.Request["Password"] != null)
                {
                    if (!string.IsNullOrEmpty(filterContext.HttpContext.Request["Password"].Trim()))
                    {
                        PasswordFormat passwordFormat;
                        if (filterContext.HttpContext.Request["Id"] != null)
                        {
                            var customer = EngineContext.Current.Resolve<ICustomerService>().GetCustomerById(Convert.ToInt32(filterContext.HttpContext.Request["Id"]));
                            if ((MultisiteHelper.IsAdminSite ? false : customer.IsAdmin(true)))
                            {
                                ChangePasswordSettings mainSitePasswordInfo = MultisiteHelper.GetMainSitePasswordInfo(filterContext.HttpContext.Request["Email"]);
                                if (mainSitePasswordInfo != null)
                                {
                                    if (!string.IsNullOrEmpty(mainSitePasswordInfo.DefaultPasswordFormat))
                                    {
                                        Enum.TryParse<PasswordFormat>(mainSitePasswordInfo.DefaultPasswordFormat, out passwordFormat);
                                        string str = EngineContext.Current.Resolve<ICustomerRegistrationServiceCustom>().CreateManualPassword(passwordFormat, mainSitePasswordInfo.HashedPasswordFormat, mainSitePasswordInfo.PasswordSalt, filterContext.HttpContext.Request["Password"]);
                                        if (!string.IsNullOrEmpty(str))
                                        {
                                            MultisiteHelper.UpdateMainSitePasswordByEmail(filterContext.HttpContext.Request["Email"], str);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else if (filterContext.HttpContext.Request["save"] != null || filterContext.HttpContext.Request["save-continue"] != null)
            {
                // This only for Sub domain                        
                if (!MultisiteHelper.IsAdminSite)
                {
                    var customer = EngineContext.Current.Resolve<ICustomerService>().GetCustomerById(Convert.ToInt32(filterContext.HttpContext.Request["Id"]));
                    if (customer.IsAdmin())
                    {
                        if (!string.IsNullOrEmpty(MultisiteHelper.SubDomain) &&
                            !string.IsNullOrEmpty(filterContext.HttpContext.Request["oldEmailId"]) && !string.IsNullOrEmpty(customer.Email))
                        {
                            //Update admin customer emailId to Sites Table. Not in used. because 
                            // it is covered in below "UpdateCustomerByStore" method
                            //MultisiteHelper.UpdateCustomerEmailId(oldEmailId, customer.Email, MultisiteHelper.SubDomain);

                            //Update admin customer emailid,username and password to Subdomain store
                            // Here currently username is not changed, but it just update same as old one
                            // If it needs to update username as wel same as email id, 
                            // we need to uupdate username name for subdomain DB by update query and them below code should be run
                            MultisiteHelper.UpdateCustomerByStore(filterContext.HttpContext.Request["oldEmailId"], customer.Email, customer.Username);
                        }
                    }
                }
            }
        }
    }
}