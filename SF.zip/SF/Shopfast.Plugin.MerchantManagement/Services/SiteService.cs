﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using MultiSite.Data;
using MultiSite.Models;
using Nop.Core.Data;
using Shopfast.Plugin.MerchantManagement.Models;
using System.Data.Entity;
using Nop.Core;

namespace Shopfast.Plugin.MerchantManagement.Services
{
    public class SiteService
    {
        public Site GetSiteById(int siteId)
        {

            using (var dbContext = new Sites4Entities())
            {
                return dbContext.Sites.FirstOrDefault(x => x.Id == siteId);
            }
        }

        public Site GetSiteByStoreName(string storeName)
        {

            using (var dbContext = new Sites4Entities())
            {
                return dbContext.Sites.FirstOrDefault(x => x.StoreName.ToLower() == storeName.ToLower());
            }
        }

        public Owner GetOwnerBySiteId(int siteId)
        {

            using (var dbContext = new Sites4Entities())
            {
                return dbContext.Owners.FirstOrDefault(z => z.Id == (dbContext.Sites.FirstOrDefault(x => x.Id == siteId)).Owner_Id);
            }
        }

        public Owner GetOwnerById(int id)
        {

            using (var dbContext = new Sites4Entities())
            {
                return dbContext.Owners.FirstOrDefault(z => z.Id == id);
            }
        }

        public void UpdateOwner(Owner owner)
        {

            using (var dbContext = new Sites4Entities())
            {
                var ownerToUpdate = dbContext.Owners.FirstOrDefault(x => x.Id == owner.Id);
                dbContext.Entry(ownerToUpdate).CurrentValues.SetValues(owner);
                dbContext.SaveChanges();
            }
        }

        // For All Sites Order Totals
        public List<SiteOrderDetailsModel> GetSiteOrderDetails(int? parentId)
        {
            using (var dbContext = new Sites4Entities())
            {
                var siteOrderDetails = dbContext.Database.SqlQuery<SiteOrderDetailsModel>("sp_GetOrderDetailsOfAllSites @ParentSiteId", parentId.HasValue ? new SqlParameter("ParentSiteId", parentId) : new SqlParameter("ParentSiteId", DBNull.Value)).ToList();
                return siteOrderDetails;
            }
        }

        // OLD method
        public IEnumerable<SiteModel> SearchSites(string email, int page, int pageSize, DateTime? startDate, DateTime? endDate, int? parentId)
        {

            // For All Sites Order Totals
            using (var dbContext = new Sites4Entities())
            {
                IEnumerable<SiteModel> sites = dbContext.Database.SqlQuery<SiteModel>("EXEC GetAssociatedSites @SiteId", parentId.HasValue ? new SqlParameter("SiteId", parentId) : new SqlParameter("SiteId", DBNull.Value));
                //if (sites != null && sites.Any() && !string.IsNullOrEmpty(email))
                //    sites = sites.Where(s => s.customerEmail.Contains(email));

                //if (sites != null && sites.Any() && startDate.HasValue)
                //    sites = sites.Where(s => s.CreationDate >= startDate.Value);

                //if (sites != null && sites.Any() && endDate.HasValue)
                //    sites = sites.Where(s => s.CreationDate <= endDate.Value);

                if (!string.IsNullOrEmpty(email))
                    sites = sites.Where(s => s.customerEmail != null && s.customerEmail.ToLower().Contains(email.ToLower()));

                if (startDate.HasValue)
                    sites = sites.Where(s => s.CreationDate >= startDate.Value);

                if (endDate.HasValue)
                    sites = sites.Where(s => s.CreationDate <= endDate.Value);

                if (pageSize > 0)
                {
                    sites = sites.Skip(pageSize * page).Take(pageSize);
                }

                var list = sites.ToList();
                return list;
            }
        }

        //public IEnumerable<SiteModel> SearchSites(string email, int pageIndex, int pageSize, DateTime? startDate, DateTime? endDate, int? parentId, out int totalSites, bool IsChild)
        //{

        //    // For All Sites Order Totals
        //    using (var dbContext = new Sites4Entities())
        //    {                
        //        var sites = dbContext.Database.SqlQuery<SiteModel>("EXEC GetAssociatedSites @SiteId", parentId.HasValue ? new SqlParameter("SiteId", parentId) : new SqlParameter("SiteId", DBNull.Value)).AsQueryable();
        //        if (IsChild)
        //        {
        //            sites = sites.Where(s => s.ParentId != null);
        //        }
        //        else
        //        {
        //            if (parentId == null)
        //            {
        //                sites = sites.Where(s => s.ParentId == null);
        //            }
        //        }
        //        if (!string.IsNullOrEmpty(email))
        //            sites = sites.Where(s => s.customerEmail == email);

        //        if (startDate.HasValue)
        //            sites = sites.Where(s => s.CreationDate >= startDate.Value);

        //        if (endDate.HasValue)
        //            sites = sites.Where(s => s.CreationDate <= endDate.Value);                
        //        //totalSites = sites.Count();              
        //        //var list=sites.ToList();
        //        //var list = new PagedList<SiteModel>(sites, pageIndex, pageSize);
        //        totalSites = 0;
        //        if (pageSize > 0)
        //        {
        //            sites = sites.Skip(pageSize * pageIndex).Take(pageSize);
        //        }
        //        return sites;
        //    }
        //}

        public int SaveStorePlugins(string storeName, List<string> selectedPlugins)
        {
            int num;
            try
            {
                Sites4Entities dbContext = new Sites4Entities();
                try
                {
                    List<SitesPlugins> AvailablePlugins = (
                        from st in dbContext.SitesPlugins
                        where !st.IsDefault && (st.StoreName == storeName)
                        select st).ToList<SitesPlugins>();
                    foreach (SitesPlugins item in AvailablePlugins)
                    {
                        if (item != null)
                        {
                            if (!selectedPlugins.Contains(item.SystemName))
                            {
                                dbContext.Entry<SitesPlugins>(item).State = EntityState.Deleted;
                                dbContext.SaveChanges();
                            }
                        }
                    }
                    foreach (string selectedPlugin in selectedPlugins)
                    {
                        if (!AvailablePlugins.Exists((SitesPlugins t) => t.SystemName == selectedPlugin))
                        {
                            SitesPlugins sitesPlugin = new SitesPlugins()
                            {
                                SystemName = selectedPlugin,
                                StoreName = storeName,
                                IsDefault = false,
                                CreationDate = DateTime.UtcNow
                            };
                            dbContext.SitesPlugins.Add(sitesPlugin);
                            dbContext.SaveChanges();
                        }
                    }
                }
                finally
                {
                    if (dbContext != null)
                    {
                        ((IDisposable)dbContext).Dispose();
                    }
                }
                num = 1;
            }
            catch
            {
                num = 0;
            }
            return num;
        }

        public IEnumerable<SitesPlugins> GetPluginsByStoreName(string storeName)
        {
            IEnumerable<SitesPlugins> list;
            Sites4Entities dbContext = new Sites4Entities();
            try
            {
                list = (
                    from x in dbContext.SitesPlugins
                    where !x.IsDefault && (x.StoreName.ToLower() == storeName.ToLower())
                    select x).ToList<SitesPlugins>();
            }
            finally
            {
                if (dbContext != null)
                {
                    ((IDisposable)dbContext).Dispose();
                }
            }
            return list;
        }

    }
}
