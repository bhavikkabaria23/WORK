﻿
using Nop.Core.Plugins;
using System;
using System.Web;
using MultiSite.Data;
using Nop.Services.Localization;
using System.IO;
using System.Web.Mvc;
using System.Web.Routing;
using Nop.Web.Framework.Menu;
using System.Linq;
using SiteMapNode = Nop.Web.Framework.Menu.SiteMapNode;
using Nop.Core.Infrastructure;

namespace Shopfast.Plugin.MerchantManagement
{
    public class MerchantManagementProvider : BasePlugin, IAdminMenuPlugin
    {

        /// <summary>
        /// Install plugin
        /// </summary>
        public override void Install()
        {
            /*var settings = new PluginSettings { DefaultTheme = "Default clean", ApplicationName = "shopfast.com" };
            _settingService.SaveSetting(settings);*/
            AddOrUpdateLocaleResource();            //locales
            using (var dbContext = new Sites4Entities())
            {
                var script = File.ReadAllText(HttpContext.Current.Server.MapPath("~/Plugins/Shopfast.Plugin.MerchantManagement/Sql/install.sql"));
                //split the script on "GO" commands
                string[] splitter = { "\r\nGO\r\n" };
                string[] commandTexts = script.Split(splitter,
                    StringSplitOptions.RemoveEmptyEntries);
                foreach (string commandText in commandTexts)
                {
                    //execute commandText
                    dbContext.Database.ExecuteSqlCommand(commandText);
                }
            }

            base.Install();
        }

        public void AddOrUpdateLocaleResource()
        {
            this.AddOrUpdatePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.Customer", "Customer");
            this.AddOrUpdatePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.Customer.Hint", "Select customer by typing part of his info");
            this.AddOrUpdatePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.Description", "Description");
            this.AddOrUpdatePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.Description.Hint", "Description");
            this.AddOrUpdatePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.Starting", "Starting");
            this.AddOrUpdatePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.Starting.Hint", "Starting");
            this.AddOrUpdatePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.StoreName", "Store Name");
            this.AddOrUpdatePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.StoreName.Hint", "Store Name");
            this.AddOrUpdatePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.IndustryType", "Industry Type");
            this.AddOrUpdatePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.IndustryType.Hint", "Industry Type");
            this.AddOrUpdatePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.AvgSaleAmout", "AvgSaleAmout");
            this.AddOrUpdatePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.AvgSaleAmout.Hint", "AvgSaleAmout");
            this.AddOrUpdatePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.ProcessorName", "Processor Name");
            this.AddOrUpdatePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.ProcessorName.Hint", "Processor Name");
            this.AddOrUpdatePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.ProcessorEmail", "Processor Email");
            this.AddOrUpdatePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.ProcessorEmail.Hint", "Processor Email");
            this.AddOrUpdatePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.ProcessorPhoneNumber", "Processor Phone Number");
            this.AddOrUpdatePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.ProcessorPhoneNumber.Hint", "Processor Phone Number");
            this.AddOrUpdatePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.ActivationCode", "Activation Code");
            this.AddOrUpdatePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.ActivationCode.Hint", "Activation Code");
            this.AddOrUpdatePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.Site.Created", "The item has been created successfully.");
            this.AddOrUpdatePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.Site.Updated", "The item has been updated successfully.");
            this.AddOrUpdatePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.UserName", "UserName.");
            this.AddOrUpdatePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.NoUserRegistred", "There is no user registered with that email address.");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.MerchantManagement.Fields.Group", "Group.");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.MerchantManagement.Fields.SystemName", "SystemName.");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.MerchantManagement.Fields.Version", "Version.");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.MerchantManagement.Fields.Author", "Author.");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.MerchantManagement.Fields.IsEnabled", "IsEnabled.");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.MerchantManagement.Fields.Logo", "Logo.");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.MerchantManagement.Fields.Logo", "Logo.");
            this.AddOrUpdatePluginLocaleResource("Admin.Merchant.Management", "Merchant Management");

        }

        /// <summary>
        /// Uninstall plugin
        /// </summary>
        public override void Uninstall()
        {

            //locales
            this.DeletePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.Description");
            this.DeletePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.Description.Hint");
            this.DeletePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.Starting");
            this.DeletePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.Starting.Hint");
            this.DeletePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.StoreName");
            this.DeletePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.StoreName.Hint");
            this.DeletePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.IndustryType");
            this.DeletePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.IndustryType.Hint");
            this.DeletePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.AvgSaleAmout");
            this.DeletePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.AvgSaleAmout.Hint");
            this.DeletePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.ProcessorName");
            this.DeletePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.ProcessorName.Hint");
            this.DeletePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.ProcessorEmail");
            this.DeletePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.ProcessorEmail.Hint");
            this.DeletePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.ProcessorPhoneNumber");
            this.DeletePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.ProcessorPhoneNumber.Hint");
            this.DeletePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.ActivationCode");
            this.DeletePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.ActivationCode.Hint");
            this.DeletePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.Site.Created");
            this.DeletePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.Site.Updated");
            this.DeletePluginLocaleResource("ShopFast.Plugin.Misc.SitesManagement.UserName");
            this.DeletePluginLocaleResource("Shopfast.Plugin.MerchantManagement.Fields.Group");
            this.DeletePluginLocaleResource("Shopfast.Plugin.MerchantManagement.Fields.SystemName");
            this.DeletePluginLocaleResource("Shopfast.Plugin.MerchantManagement.Fields.Version");
            this.DeletePluginLocaleResource("Shopfast.Plugin.MerchantManagement.Fields.Author");
            this.DeletePluginLocaleResource("Shopfast.Plugin.MerchantManagement.Fields.IsEnabled");
            this.DeletePluginLocaleResource("Admin.Merchant.Management");

            base.Uninstall();
        }


        public void GetConfigurationRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "List";
            controllerName = "MerchantManagement";
            routeValues = new RouteValueDictionary { { "Namespaces", "Shopfast.Plugin.MerchantManagement.Controllers" }, { "area", null } };
        }

        public void ManageSiteMap(SiteMapNode rootNode)
        {
            var helper = new UrlHelper(System.Web.HttpContext.Current.Request.RequestContext);
            var localizationService = EngineContext.Current.Resolve<ILocalizationService>();
            if (Nop.Core.Data.MultisiteHelper.IsAdminSite)
            {
                var menuItem = new SiteMapNode()
                {
                    SystemName = "MerchantManagement",
                    Title = localizationService.GetResource("Admin.Merchant.Management"),
                    Url = helper.RouteUrl("Plugin.MerchantList.SiteList"),
                    Visible = true,
                    IconClass = "fa fa-share-square-o"
                };
                //var pluginNode = rootNode.ChildNodes.FirstOrDefault(x => x.SystemName == "Configuration");
                //if (pluginNode != null)
                //{
                //    pluginNode.ChildNodes.Insert(2,menuItem);                
                //}
                //else
                rootNode.ChildNodes.Add(menuItem);
            }

            if (!Nop.Core.Data.MultisiteHelper.IsAdminSite)
            {
                var menuItem = new SiteMapNode()
                {
                    SystemName = "MerchantDetail",
                    Title = localizationService.GetResource("Admin.Merchant.Detail"),
                    Url = helper.RouteUrl("Plugin.MerchantList.MySiteDetails"),
                    Visible = true,
                    IconClass = "fa fa-share-square-o"
                };
                //var pluginNode = rootNode.ChildNodes.FirstOrDefault(x => x.SystemName == "Configuration");
                //if (pluginNode != null)
                //{
                //    pluginNode.ChildNodes.Insert(2,menuItem);                
                //}
                //else
                rootNode.ChildNodes.Add(menuItem);
            }
        }
    }
}
