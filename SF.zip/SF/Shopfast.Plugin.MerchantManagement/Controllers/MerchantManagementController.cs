﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Nop.Core.Data;
using System.Web.Hosting;
using System.Data.SqlClient;
using System.Web.Configuration;
using Nop.Core.Infrastructure;
using Nop.Services.Authentication;
using Nop.Services.Customers;
using Nop.Data;
using System.Text.RegularExpressions;
using System.Data.Common;
using MultiSite.Data;
using MultiSite.Files;
using Nop.Core.Domain.Customers;
using System.Data;
using System.Text;
using MultiSite.Models;
using Nop.Core;
using Nop.Services.Catalog;
using Nop.Services.Directory;
using Nop.Services.Localization;
using Nop.Services.Security;
using Nop.Web.Framework.Controllers;
using Shopfast.Plugin.MerchantManagement.Models.Kendoui;
using Shopfast.Plugin.MerchantManagement.Models;
using Nop.Web.Framework.Themes;
using Nop.Web.Models.SiteRegistration;
using Shopfast.Plugin.MerchantManagement.Services;
using SiteListModel = Shopfast.Plugin.MerchantManagement.Models.SiteListModel;
using MultiSite.Services;
using Nop.Admin.Controllers;
using Nop.Core.Domain.Logging;
using Nop.Services.Common;
using Nop.Services.Logging;
using PostedThemes = Shopfast.Plugin.MerchantManagement.Models.PostedThemes;

namespace Shopfast.Plugin.MerchantManagement.Controllers
{
    public class MerchantManagementController : BasePluginController
    {
        #region Fields
        private readonly SiteService _siteService;
        private readonly IPermissionService _permissionService;
        private readonly ILocalizationService _localizationService;
        private readonly ICustomerService _customerService;

        #endregion
        public MerchantManagementController(SiteService siteService, IPermissionService permissionService, ILocalizationService localizationService, ICustomerService customerService)
        {
            _siteService = siteService;
            _permissionService = permissionService;
            _localizationService = localizationService;
            _customerService = customerService;
        }
        #region Action Methods

        // OLD method for grid treeview
        //[HttpPost]
        //[AdminAuthorize]
        //public ActionResult SiteSelect(DataSourceRequest command, SiteListModel model)
        //{
        //    //filter by parrent id
        //    var parentId = GetCurrentSiteId();
        //    /*var siteList = _siteService.SearchSites(model.CustomerEmail, command.Page - 1, command.PageSize,
        //        model.StartDate, model.EndDate, parentId);*/
        //    var siteList = _siteService.SearchSites(model.CustomerEmail, 0, Int16.MaxValue,
        //        model.StartDate, model.EndDate, parentId);
        //    var priceFormatter = EngineContext.Current.Resolve<IPriceFormatter>();

        //    var lstSitesOrder = _siteService.GetSiteOrderDetails(parentId);
        //    var siteModelList = siteList.Select(site =>
        //    {
        //        var siteModel = new SiteModel
        //        {
        //            Id = site.Id,
        //            storeName = site.storeName,
        //            ParentId = site.ParentId == parentId ? null : site.ParentId,
        //            ParentId = site.ParentId == parentId ? null : site.ParentId,
        //            customerEmail = site.customerEmail,
        //            CreationDate = site.CreationDate,
        //            status = site.IsOrder ?? false ? "purchased" : "trial"
        //        };
        //        var siteOrderDetails = lstSitesOrder.FirstOrDefault(so => so.siteid == site.Id);
        //        siteModel.todayTotal = priceFormatter.FormatPrice(siteOrderDetails != null ? siteOrderDetails.todayTotal : 0);
        //        siteModel.weekTotal = priceFormatter.FormatPrice(siteOrderDetails != null ? siteOrderDetails.weekTotal : 0);
        //        siteModel.monthTotal = priceFormatter.FormatPrice(siteOrderDetails != null ? siteOrderDetails.monthTotal : 0);
        //        siteModel.yearTotal = priceFormatter.FormatPrice(siteOrderDetails != null ? siteOrderDetails.yearTotal : 0);
        //        siteModel.allTotal = priceFormatter.FormatPrice(siteOrderDetails != null ? siteOrderDetails.allTotal : 0);
        //        siteModel.avgOrder = priceFormatter.FormatPrice(siteOrderDetails != null ? siteOrderDetails.allTotal / siteOrderDetails.orderCount : 0);
        //        return siteModel;
        //    }).ToList();
        //    return Json(siteModelList.ToArray());
        //}

        [HttpPost]
        [AdminAuthorize]
        public ActionResult SiteSelect(DataSourceRequest command, SiteListModel model)
        {
            //filter by parrent id
            var parentId = GetCurrentSiteId();
            /*var siteList = _siteService.SearchSites(model.CustomerEmail, command.Page - 1, command.PageSize,
                model.StartDate, model.EndDate, parentId);*/
            int totalSites;
            var siteList = _siteService.SearchSites(model.CustomerEmail, command.Page - 1, command.PageSize,
                model.StartDate, model.EndDate, parentId);
            if (parentId == null)
            {
                siteList = siteList.Where(s => s.ParentId == null);
            }

            var priceFormatter = EngineContext.Current.Resolve<IPriceFormatter>();

            var lstSitesOrder = _siteService.GetSiteOrderDetails(parentId);
            var siteModelList = siteList.Select(site =>
            {
                var siteModel = new SiteModel
                {
                    Id = site.Id,
                    storeName = site.storeName,
                    ParentId = site.ParentId == parentId ? null : site.ParentId,
                    customerEmail = site.customerEmail,
                    CreationDate = site.CreationDate,
                    status = site.IsOrder ?? false ? "purchased" : "trial"
                };
                var siteOrderDetails = lstSitesOrder.FirstOrDefault(so => so.siteid == site.Id);
                siteModel.todayTotal = priceFormatter.FormatPrice(siteOrderDetails != null ? siteOrderDetails.todayTotal : 0);
                siteModel.weekTotal = priceFormatter.FormatPrice(siteOrderDetails != null ? siteOrderDetails.weekTotal : 0);
                siteModel.monthTotal = priceFormatter.FormatPrice(siteOrderDetails != null ? siteOrderDetails.monthTotal : 0);
                siteModel.yearTotal = priceFormatter.FormatPrice(siteOrderDetails != null ? siteOrderDetails.yearTotal : 0);
                siteModel.allTotal = priceFormatter.FormatPrice(siteOrderDetails != null ? siteOrderDetails.allTotal : 0);
                siteModel.avgOrder = priceFormatter.FormatPrice(siteOrderDetails != null ? siteOrderDetails.allTotal / siteOrderDetails.orderCount : 0);
                return siteModel;
            }).ToList();
            var gridModel = new DataSourceResult
            {
                Data = siteModelList,
                Total = SiteListModel.Total(model.CustomerEmail, model.StartDate, model.EndDate, null).gridTotal
            };
            return Json(gridModel);
            //return Json(siteModelList.ToArray());
        }

        [HttpPost]
        [AdminAuthorize]
        public ActionResult SiteSelectChild(DataSourceRequest command, SiteListModel model)
        {
            //filter by parrent id
            var parentId = GetCurrentSiteId();
            /*var siteList = _siteService.SearchSites(model.CustomerEmail, command.Page - 1, command.PageSize,
                model.StartDate, model.EndDate, parentId);*/
            int totalSites;
            var siteList = _siteService.SearchSites(model.CustomerEmail, command.Page - 1, command.PageSize,
                model.StartDate, model.EndDate, parentId);
            if (parentId == null)
            {
                siteList = siteList.Where(s => s.ParentId != null);
            }

            var priceFormatter = EngineContext.Current.Resolve<IPriceFormatter>();

            var lstSitesOrder = _siteService.GetSiteOrderDetails(parentId);
            var siteModelList = siteList.Select(site =>
            {
                var siteModel = new SiteModel
                {
                    Id = site.Id,
                    storeName = site.storeName,
                    ParentId = site.ParentId == parentId ? null : site.ParentId,
                    customerEmail = site.customerEmail,
                    CreationDate = site.CreationDate,
                    status = site.IsOrder ?? false ? "purchased" : "trial"
                };
                var siteOrderDetails = lstSitesOrder.FirstOrDefault(so => so.siteid == site.Id);
                siteModel.todayTotal = priceFormatter.FormatPrice(siteOrderDetails != null ? siteOrderDetails.todayTotal : 0);
                siteModel.weekTotal = priceFormatter.FormatPrice(siteOrderDetails != null ? siteOrderDetails.weekTotal : 0);
                siteModel.monthTotal = priceFormatter.FormatPrice(siteOrderDetails != null ? siteOrderDetails.monthTotal : 0);
                siteModel.yearTotal = priceFormatter.FormatPrice(siteOrderDetails != null ? siteOrderDetails.yearTotal : 0);
                siteModel.allTotal = priceFormatter.FormatPrice(siteOrderDetails != null ? siteOrderDetails.allTotal : 0);
                siteModel.avgOrder = priceFormatter.FormatPrice(siteOrderDetails != null ? siteOrderDetails.allTotal / siteOrderDetails.orderCount : 0);
                return siteModel;
            }).ToList();
            var gridModel = new DataSourceResult
            {
                Data = siteModelList,
                Total = SiteListModel.Total(model.CustomerEmail, model.StartDate, model.EndDate, parentId).gridTotal
            };
            return Json(gridModel);
            //return Json(siteModelList.ToArray());
        }

        private int? GetCurrentSiteId()
        {
            var logger = EngineContext.Current.Resolve<ILogger>();

            string storeName = MultisiteHelper.SubDomain;
            int? parentId = null;
            if (storeName != "")
            {
                var site = _siteService.GetSiteByStoreName(storeName);
                if (site != null)
                {
                    parentId = site.Id;
                }
            }
            logger.Information("storeName = " + storeName + " parentID = " + parentId);
            return parentId;
        }

        public ActionResult AjaxLoadCustomers(string filter)
        {
            var customers = new List<Customer>();
            if (String.IsNullOrEmpty(filter))
            {
                customers.AddRange(_customerService.GetAllCustomers(
                    customerRoleIds: new int[] { _customerService.GetCustomerRoleBySystemName("Registered").Id }
                    ).ToList());
            }
            else
            {
                customers.AddRange(_customerService.GetAllCustomers(
                    email: filter,
                    customerRoleIds: new int[] { _customerService.GetCustomerRoleBySystemName("Registered").Id }
                    ).ToList());
                customers.AddRange(_customerService.GetAllCustomers(
                    firstName: filter,
                    customerRoleIds: new int[] { _customerService.GetCustomerRoleBySystemName("Registered").Id }
                    ).ToList());
                customers.AddRange(_customerService.GetAllCustomers(
                    lastName: filter,
                    customerRoleIds: new int[] { _customerService.GetCustomerRoleBySystemName("Registered").Id }
                    ).ToList());
                customers.AddRange(_customerService.GetAllCustomers(
                    company: filter,
                    customerRoleIds: new int[] { _customerService.GetCustomerRoleBySystemName("Registered").Id }
                    ).ToList());
                customers.AddRange(_customerService.GetAllCustomers(
                    phone: filter,
                    customerRoleIds: new int[] { _customerService.GetCustomerRoleBySystemName("Registered").Id }
                    ).ToList());
            }
            customers = customers.Distinct().ToList();
            customers.RemoveAll(c => String.IsNullOrEmpty(c.Email));

            //return Json(customers, JsonRequestBehavior.AllowGet)r;
            return Json(customers.Select(customer => customer.Email), JsonRequestBehavior.AllowGet);
        }


        [AdminAuthorize]
        public ActionResult SiteCreate(int? id = null)
        {
            // id is null. Try to find current store id by store name
            if (id == null)
                id = GetCurrentSiteId();
            var model = new SiteModel { ParentId = id, IsDetails = false };
            return View("~/Plugins/Shopfast.Plugin.MerchantManagement/Views/MerchantManagement/SiteCreate.cshtml", model);
        }

        [AdminAuthorize]
        [HttpPost]
        public ActionResult SiteCreate(SiteModel model)
        {
            try
            {

                string storeName;
                /* Copy database and settings */
                model.storeName = model.storeName.SanitazeStoreName();

                SiteHelper.AddToSqlServer(model.storeName, model.industryType, out storeName);
                var customer = _customerService.GetCustomerByEmail(model.customerEmail);

                /* Setup store admin credentials and basic settings into database. */
                var storeDatabase = SiteHelper.GetStoreConnectionString(storeName);
                if (customer == null)
                {

                    ErrorNotification(_localizationService.GetResource("ShopFast.Plugin.Misc.SitesManagement.NoUserRegistred"), false);
                    return View("~/Plugins/Shopfast.Plugin.MerchantManagement/Views/MerchantManagement/SiteCreate.cshtml", model);
                }
                MultiSiteDataProvider.ConfigureStoreDatabase(model.storeName, storeDatabase, model.customerEmail, model.password, MultisiteHelper.DefaultTheme, null);
                using (var dbContext = new Sites4Entities())
                {
                    if (model.customerEmail != "(not changed)" && customer != null)
                    {
                        Site storeSite = new Site
                        {
                            StoreName = model.storeName,
                            CreationDate = DateTime.UtcNow,
                            IsOrder = false,
                            deleted = false,
                            DbName = MultisiteHelper.GetDbName(storeName),
                            ParentId = model.ParentId,
                            // For package details         
                            PackageProductId = 0,
                            //----------------------------------------
                            Owner = new Owner
                            {
                                email = customer.Email,
                                description = model.description,
                                firstName = model.firstName = customer.GetAttribute<string>(SystemCustomerAttributeNames.FirstName) ?? "",
                                industryType = model.industryType,
                                LastName = model.lastName = customer.GetAttribute<string>(SystemCustomerAttributeNames.LastName) ?? "",
                                phone = model.phone ?? "",
                                starting = model.starting,
                                Country = model.Country ?? "",
                                Website = model.Website ?? "",
                                //Multisite_NewField_change
                                StreetAddress = model.StreetAddress ?? "",
                                City = model.City ?? "",
                                ZipPostalCode = model.ZipPostalCode ?? "",
                                State = model.State,
                                // Free trial integration in new page
                                AvgSaleAmout = model.AvgSaleAmout,
                                ProcessorName = model.ProcessorName,
                                ProcessorEmail = model.ProcessorEmail,
                                ProcessorPhoneNumber = model.ProcessorPhoneNumber
                                //-----------------------
                                //--------------------------
                            }
                        };
                        dbContext.Sites.Add(storeSite);
                    }
                    dbContext.SaveChanges();
                    MultisiteHelper.ResetSites();
                }
                var _workflowMessageService = new MultisiteWorkflowMessageService();
                //isTrial)
                var result = _workflowMessageService.SendTrialStoreCreatedCustomerNotification(model, true);

                _workflowMessageService.SendTrialStoreCreatedAdminNotification(model, true);

            }
            catch (Exception ex)
            {
                LogException(ex);
            }
            SuccessNotification(_localizationService.GetResource("ShopFast.Plugin.Misc.SitesManagement.Site.Created"));
            return RedirectToRoute("Plugin.MerchantList.SiteList");
        }


        [AdminAuthorize]
        public ActionResult SiteDetails(int id)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageSettings))
                return AccessDeniedView();
            Owner owner = _siteService.GetOwnerBySiteId(id);
            var model = owner.ToModel();
            model.customerEmail = owner.email;
            model.IsDetails = true;
            model.Id = id;
            return View("~/Plugins/Shopfast.Plugin.MerchantManagement/Views/MerchantManagement/SiteDetails.cshtml", model);
        }

        [AdminAuthorize]
        [HttpPost]
        public ActionResult SiteDetails(SiteModel model)
        {
            // Need to ask to Ronny about all these detail fetched from current customer and update from there
            // Do we need these details to update?
            var customer = _customerService.GetCustomerByEmail(model.customerEmail);
            var address = customer.Addresses.FirstOrDefault();
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageSettings))
                return AccessDeniedView();
            Owner owner = _siteService.GetOwnerBySiteId(model.Id);
            model.Id = owner.Id;
            owner = model.ToOwnerEntity();
            owner.email = customer.Email;
            owner.firstName = customer.GetAttribute<string>(SystemCustomerAttributeNames.FirstName) ?? "";
            owner.LastName = customer.GetAttribute<string>(SystemCustomerAttributeNames.LastName) ?? "";
            owner.phone = address != null ? address.PhoneNumber : "";
            owner.Country = address != null ? address.Country.Name : "";
            owner.StreetAddress = address != null ? address.Address1 : "";
            owner.City = address != null ? address.City : "";
            owner.ZipPostalCode = address != null ? address.ZipPostalCode : "";
            owner.State = address != null ? address.StateProvince.Name : "";

            _siteService.UpdateOwner(owner);
            SuccessNotification(_localizationService.GetResource("ShopFast.Plugin.Misc.SitesManagement.Site.Updated"));
            return RedirectToRoute("Plugin.MerchantList.SiteList");
        }

        [AdminAuthorize]
        public ActionResult MySiteDetails()
        {
            int? siteid = 0;
            siteid = GetCurrentSiteId();
            return RedirectToRoute("Plugin.MerchantList.SiteDetails", new { id = siteid });
        }

        #endregion

        #region Action Methods



        public ActionResult Index()
        {
            return RedirectToAction("List");
        }

        public ActionResult List()
        {
            if (!IsAdminUser())
            {
                return AccessDeniedView();
            }

            var model = new SiteListModel();
            // For All Sites Order Totals  
            var parentId = GetCurrentSiteId();
            var lstSitesOrder = _siteService.GetSiteOrderDetails(parentId);
            model.todayTotalAllSites = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                      FormatPrice(Math.Round(lstSitesOrder.Sum(so => so.todayTotal), 2));
            model.weekTotalAllSites = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                FormatPrice(Math.Round(lstSitesOrder.Sum(so => so.weekTotal), 2));
            model.monthTotalAllSites = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                FormatPrice(Math.Round(lstSitesOrder.Sum(so => so.monthTotal), 2));
            model.yearTotalAllSites = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                FormatPrice(Math.Round(lstSitesOrder.Sum(so => so.yearTotal), 2));
            model.allTotalAllSites = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                FormatPrice(Math.Round(lstSitesOrder.Sum(so => so.allTotal), 2));
            model.totalSites = SiteListModel.Total("", null, null).total;
            model.avgTotalAllSites = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                FormatPrice(Math.Round((model.totalSites > 0 ? lstSitesOrder.Sum(so => so.avgOrder / model.totalSites) : 0), 2));
            model.avgTotal = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                FormatPrice(Math.Round((lstSitesOrder.Sum(so => so.avgOrder)), 2));
            //-------------------------------------

            return View("~/Plugins/Shopfast.Plugin.MerchantManagement/Views/MerchantManagement/List.cshtml", model);
        }

        [HttpPost]
        public ActionResult SiteList(DataSourceRequest command, SiteListModel model)
        {
            if (!IsAdminUser())
            {
                return AccessDeniedView();
            }

            // For All Sites Order Totals        
            var parentId = GetCurrentSiteId();
            var lstSitesOrder = _siteService.GetSiteOrderDetails(parentId);
            var sites = SiteListModel.SearchSites(model.CustomerEmail, command.Page - 1, command.PageSize,
                model.StartDate, model.EndDate, lstSitesOrder);
            //-----------------------------
            var gridModel = new DataSourceResult
            {
                Data = sites,
                Total = SiteListModel.Total(model.CustomerEmail, model.StartDate, model.EndDate).total
            };
            return Json(gridModel);
        }

        /// <summary>
        /// NOTE : we are not using GetChildSites because we dont need child store functionality as of now
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult DeleteSite(int id)
        {
            if (!IsAdminUser())
                return null;
            //var children = GetChildSites(id);
            RemoveSite(id);
            //foreach (var child in children)
            //{
            //    RemoveSite(child.Id);
            //}
            return RedirectToRoute("Plugin.MerchantList.SiteList.SuperAdmin");
        }

        public static List<Site> GetChildSites(int id)
        {
            using (var dbContext = new Sites4Entities())
            {
                var siteList = dbContext.Database.SqlQuery<Site>("GetAssociatedSites @SiteId", new SqlParameter("@SiteId", id)).ToList();
                return siteList;
            }
        }

        /// <summary>        
        /// 2) Delete plesk subscription and customer (customer, domain, subscription)
        /// 1) Backup dataabase from SP "C:\shopfast.com\Database\Backup"
        /// 3) Delete DB. for that use the SP
        /// 4) Delete existing customer from SF_Master
        /// 5) Delete Setting file of the store
        /// 3) Delete owner, site, siteorder, sitetheme,siteplugin
        /// </summary>
        /// <param name="id"></param>
        private static void RemoveSite(int id)
        {
            try
            {
                string App_data = HostingEnvironment.MapPath("~/App_Data/");
                using (var dbContext = new Sites4Entities())
                {
                    var store = dbContext.Sites.Include("Owner").SingleOrDefault(s => s.Id == id);
                    if (store != null)
                    {
                        //Delete plesk subscription and customer (customer, domain, subscription)
                        EngineContext.Current.Resolve<ILogger>().Information("Shopfast.Plugin.MerchantManagement.Controllers - RemoveSite - DeletePleskSubscription Started - Store  - " + store.StoreName + " - "+DateTime.Now.ToString());
                        string pleskReturnId = SiteHelper.DeletePleskSubscription(store.StoreName);
                        if (!string.IsNullOrEmpty(pleskReturnId))
                        {
                            EngineContext.Current.Resolve<ILogger>().Information("Shopfast.Plugin.MerchantManagement.Controllers - RemoveSite - DeletePleskCustomer Started - Store  - " + store.StoreName +" - " + DateTime.Now.ToString());
                            SiteHelper.DeletePleskCustomer(store.Owner.email);                          
                        }

                        int DBDeletedRes;
                        //Backup dataabase to "C:\shopfast.com\Database\Backup" and then delete by SP
                        EngineContext.Current.Resolve<ILogger>().Information("Shopfast.Plugin.MerchantManagement.Controllers - RemoveSite - BackupDeleteStoreDBByStore Started - Store  - " + store.StoreName + " - " + DateTime.Now.ToString());
                        DBDeletedRes = SiteHelper.BackupDeleteStoreDBByStore(store);
                        if (DBDeletedRes > 0)
                        {
                            MultisiteHelper.RemoveConnectionString(store.StoreName);
                            MultisiteHelper.ResetSites();

                            // Delete Setting file of the store
                            System.IO.File.Delete(string.Format(@"{0}\{1}Settings.txt", App_data, store.StoreName));
                        }

                        #region Delete DB of sub domain based on connection string OLD Approach
                        //var creatorConnStr = WebConfigurationManager.ConnectionStrings["MasterCatalog"].ConnectionString;
                        //var settings = new MultisiteDataSettingsManager().LoadSettings(store.StoreName);
                        //DbConnectionStringBuilder builder = new DbConnectionStringBuilder();
                        //builder.ConnectionString = settings.DataConnectionString;
                        //var dbName = builder["initial catalog"] as string;
                        //using (var dbConnection = new SqlConnection(creatorConnStr))
                        //{
                        //    dbConnection.Open();

                        //    #region Backup store DB
                        //    int result = SiteListModel.BackupStoreDB(dbConnection, store.StoreName);
                        //    #endregion

                        //    var dbCommand =
                        //        new SqlCommand(
                        //            string.Format(@"EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N'{0}'",
                        //                dbName), dbConnection);
                        //    dbCommand.ExecuteNonQuery();

                        //    dbCommand =
                        //        new SqlCommand(
                        //            string.Format(@"ALTER DATABASE [{0}] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE", dbName),
                        //            dbConnection);
                        //    dbCommand.ExecuteNonQuery();

                        //    dbCommand = new SqlCommand(string.Format(@"DROP DATABASE [{0}]", dbName), dbConnection);
                        //    dbCommand.ExecuteNonQuery();
                        //    dbConnection.Close();
                        //    // Remove sub domain from cloud flare using API
                        //    SiteHelper.DeleteCloudFareDNS(store.StoreName);
                        //}
                        #endregion
                    }
                }
            }

            catch (Exception ex)
            {
                EngineContext.Current.Resolve<ILogger>().Error("Shopfast.Plugin.MerchantManagement.Controllers - RemoveSite - Site id - "+id+" - " + ex.Message);                
            }
        }

        [HttpPost]
        public ActionResult Rename(int Id, string storeName)
        {
            if (storeName.StartsWith("http://", StringComparison.InvariantCultureIgnoreCase))
            {
                storeName = storeName.Substring(7);
            }
            if (storeName.EndsWith("/"))
            {
                storeName = storeName.TrimEnd('/');
            }
            if (!Regex.IsMatch(storeName, @"^\w{2,15}$") && !Regex.IsMatch(storeName, @"^([\w-]+\.)+[\w-]+$"))
            {
                return Json(new { error = true, msg = "Store name is incorrect" });
            }
            else
            {
                try
                {
                    MultiSiteDataProvider.RenameSite(Id, storeName);
                    MultisiteHelper.ResetSites();
                }
                catch (Exception ex)
                {
                    return Json(new { error = true, msg = ex.Message });
                }
                return Json(new { error = false, msg = "OK" });
            }
        }

        //Store Template Theme
        #region Store Template Theme
        public ActionResult SiteTheme(int Id = 0)
        {
            return View("~/Plugins/Shopfast.Plugin.MerchantManagement/Views/MerchantManagement/SiteTheme.cshtml", GetThemesInitialModel(Id));
        }

        [HttpPost]
        public ActionResult SiteTheme(SiteThemeModel model, List<string> chkThemes, int Id = 0)
        {
            SaveSiteThemes(model, chkThemes, Id);
            return RedirectToRoute("Plugin.MerchantList.SiteTheme");
        }

        #endregion

        #endregion

        #region Methods

        bool IsAdminUser()
        {
#if (DEBUG)
            return true;
#else
            var _authenticationService = EngineContext.Current.Resolve<IAuthenticationService>();
            var customer = _authenticationService.GetAuthenticatedCustomer();
            return (customer != null && customer.IsAdmin());
#endif
        }

        private List<SitesTheme> GetAllSiteThemes(string storeName, bool IsMobileTheme)
        {
            using (var dbContext = new Sites4Entities())
            {
                return dbContext.SitesThemes.Where(s => s.StoreName == storeName
                    && s.IsMobileTheme == IsMobileTheme).ToList();
            }
        }

        private void SaveSiteThemes(SiteThemeModel model, List<string> chkThemes, int Id = 0)
        {
            using (var dbContext = new Sites4Entities())
            {
                #region Save Desktop theme
                if (chkThemes == null) chkThemes = new List<string>();

                var AvailableStoreDesktopTheme = dbContext.SitesThemes
                        .Where(st => st.StoreName == model.storeName && st.IsMobileTheme == false).ToList();
                foreach (var item in AvailableStoreDesktopTheme)
                {
                    if (item != null)
                    {
                        if (!chkThemes.Contains(item.ThemeName))
                        {
                            dbContext.Entry(item).State = System.Data.Entity.EntityState.Deleted;
                            dbContext.SaveChanges();
                        }
                    }
                }
                for (int i = 0; i < chkThemes.Count(); i++)
                {
                    if (!AvailableStoreDesktopTheme.Exists(t => t.ThemeName == chkThemes[i]))
                    {
                        SitesTheme sitetheme = new SitesTheme
                        {
                            StoreName = model.storeName,
                            TemplateName = model.industryType,
                            ThemeName = chkThemes[i],
                            IsMobileTheme = false,
                            CreationDate = DateTime.Now
                        };
                        dbContext.SitesThemes.Add(sitetheme);
                        dbContext.SaveChanges();
                    }
                }
                #endregion

                //#region Save Mopbile theme
                //List<string> postedMobileThemeValues = new List<string>();
                //if (model.PostedMobileThemes == null) model.PostedMobileThemes = new PostedThemes();

                //// if a view model array of posted Themes values exists
                //// and is not empty,save selected ids
                //if (model.PostedMobileThemes.ThemesValues != null && model.PostedMobileThemes.ThemesValues.Any())
                //{
                //    postedMobileThemeValues = model.PostedMobileThemes.ThemesValues.ToList();
                //}
                //var AvailableStoreMobileTheme = dbContext.SitesThemes
                //        .Where(st => st.StoreName == model.storeName && st.IsMobileTheme == true).ToList();
                //foreach (var item in AvailableStoreMobileTheme)
                //{
                //    if (item != null)
                //    {
                //        if (!postedMobileThemeValues.Contains(item.ThemeName))
                //        {
                //            dbContext.Entry(item).State = System.Data.Entity.EntityState.Deleted;
                //            dbContext.SaveChanges();
                //        }
                //    }
                //}
                //for (int i = 0; i < postedMobileThemeValues.Count(); i++)
                //{
                //    if (!AvailableStoreMobileTheme.Exists(t => t.ThemeName == postedMobileThemeValues[i]))
                //    {
                //        SitesTheme sitetheme = new SitesTheme
                //        {
                //            StoreName = model.storeName,
                //            TemplateName = model.industryType,
                //            ThemeName = postedMobileThemeValues[i],
                //            IsMobileTheme = true,
                //            CreationDate = DateTime.Now
                //        };
                //        dbContext.SitesThemes.Add(sitetheme);
                //        dbContext.SaveChanges();
                //    }
                //}
                //#endregion
            }
        }

        //this was used when CheckboxListFor is used
        //private void SaveSiteThemes(SiteModel model,int Id = 0)
        //{
        //    using (var dbContext = new Sites4Entities())
        //    {
        //        #region Save Desktop theme
        //        List<string> postedDesktopThemeValues = new List<string>();
        //        if (model.PostedDesktopThemes == null) model.PostedDesktopThemes = new MultiSite.Models.SiteTheme.PostedThemes();

        //        // if a view model array of posted Themes values exists
        //        // and is not empty,save selected ids

        //        if (model.PostedDesktopThemes.ThemesValues != null && model.PostedDesktopThemes.ThemesValues.Any())
        //        {
        //            postedDesktopThemeValues = model.PostedDesktopThemes.ThemesValues.ToList();
        //        }


        //        var AvailableStoreDesktopTheme = dbContext.SitesThemes
        //                .Where(st => st.StoreName == model.storeName && st.IsMobileTheme == false).ToList();
        //        foreach (var item in AvailableStoreDesktopTheme)
        //        {
        //            if (item != null)
        //            {
        //                if (!postedDesktopThemeValues.Contains(item.ThemeName))
        //                {
        //                    dbContext.Entry(item).State = System.Data.Entity.EntityState.Deleted;
        //                    dbContext.SaveChanges();
        //                }
        //            }
        //        }
        //        for (int i = 0; i < postedDesktopThemeValues.Count(); i++)
        //        {
        //            if (!AvailableStoreDesktopTheme.Exists(t => t.ThemeName == postedDesktopThemeValues[i]))
        //            {
        //                SitesTheme sitetheme = new SitesTheme
        //                {
        //                    StoreName = model.storeName,
        //                    TemplateName = model.industryType,
        //                    ThemeName = postedDesktopThemeValues[i],
        //                    IsMobileTheme = false,
        //                    CreationDate = DateTime.Now
        //                };
        //                dbContext.SitesThemes.Add(sitetheme);
        //                dbContext.SaveChanges();
        //            }
        //        }
        //        #endregion

        //        #region Save Mopbile theme
        //        List<string> postedMobileThemeValues = new List<string>();
        //        if (model.PostedMobileThemes == null) model.PostedMobileThemes = new PostedThemes();

        //        // if a view model array of posted Themes values exists
        //        // and is not empty,save selected ids
        //        if (model.PostedMobileThemes.ThemesValues != null && model.PostedMobileThemes.ThemesValues.Any())
        //        {
        //            postedMobileThemeValues = model.PostedMobileThemes.ThemesValues.ToList();
        //        }
        //        var AvailableStoreMobileTheme = dbContext.SitesThemes
        //                .Where(st => st.StoreName == model.storeName && st.IsMobileTheme == true).ToList();
        //        foreach (var item in AvailableStoreMobileTheme)
        //        {
        //            if (item != null)
        //            {
        //                if (!postedMobileThemeValues.Contains(item.ThemeName))
        //                {
        //                    dbContext.Entry(item).State = System.Data.Entity.EntityState.Deleted;
        //                    dbContext.SaveChanges();
        //                }
        //            }
        //        }
        //        for (int i = 0; i < postedMobileThemeValues.Count(); i++)
        //        {
        //            if (!AvailableStoreMobileTheme.Exists(t => t.ThemeName == postedMobileThemeValues[i]))
        //            {
        //                SitesTheme sitetheme = new SitesTheme
        //                {
        //                    StoreName = model.storeName,
        //                    TemplateName = model.industryType,
        //                    ThemeName = postedMobileThemeValues[i],
        //                    IsMobileTheme = true,
        //                    CreationDate = DateTime.Now
        //                };
        //                dbContext.SitesThemes.Add(sitetheme);
        //                dbContext.SaveChanges();
        //            }
        //        }
        //        #endregion
        //    }
        //}

        /// <summary>
        /// for setup initial view model for all Themes
        /// </summary>
        private SiteThemeModel GetThemesInitialModel(int Id)
        {
            //setup properties
            var model = new SiteThemeModel();

            model = SiteListModel.GetByIdForTheme(Id);

            IEnumerable<Theme> selectedThemes = new List<Theme>();

            #region Destop Theme
            // Get all Desktop Themes
            //var AvailableStoreThemesForDesktops = EngineContext.Current.Resolve<IThemeProvider>()
            //                .GetThemeConfigurations()
            //                .Where(x => x.Stores == "" || Nop.Core.Data.MultisiteHelper.IsAdminSite || x.Stores.Split(',').Select(s => s.Trim().ToLower()).Contains(MultisiteHelper.CurrentUrl.ToLower()));
            var AvailableStoreThemesForDesktops = EngineContext.Current.Resolve<IThemeProvider>()
                            .GetThemeConfigurations();
            //setup a view model

            //List<Theme> AvailableThemes = new List<Theme>();
            if (AvailableStoreThemesForDesktops.Count() > 0)
            {
                var sitesTheme = MultisiteHelper.GetAllSiteThemes(model.storeName, false);
                var AvailableThemeList = AvailableStoreThemesForDesktops.Select(t => new Theme
                {
                    Name = t.ThemeTitle,
                    Value = t.ThemeName,
                    PreviewImageUrl = t.PreviewImageUrl,
                    PreviewText = t.PreviewText,
                    IsSelected = sitesTheme.Any(st => st.ThemeName == t.ThemeName)
                });

                model.AvailableDesktopThemes = AvailableThemeList.ToList();
                model.SelectedDesktopThemes = selectedThemes;
            }
            #endregion

            return model;
        }
        //------------------------------

        #endregion



        protected ActionResult AccessDeniedView()
        {
            return RedirectToAction("Login", "Customer", new { Area = "", ReturnUrl = this.Request.RawUrl });
        }

        //Admin menu based on super admin and user - add "adminType" parameter
        public ActionResult GoSiteAdmin(int Id, string adminType)
        //-----------------------
        {
            if (!IsAdminUser())
            {
                return AccessDeniedView();
            }

            var site = SiteListModel.GetById(Id);
            if (site == null)
            {
                return HttpNotFound();
            }
            var storeUrl = site.storeName.Contains('.') ? site.storeName
                                : string.Format(@"{0}.{1}", site.storeName, MultisiteHelper.Domain);
            var guid = Guid.NewGuid();
            MultisiteHelper.TempLoginGuids.Add(guid, new MultisiteHelper.LoginInfo { StoreName = site.storeName });

            //Admin menu based on super admin and user - add "adminType" parameter
            if (!string.IsNullOrEmpty(adminType))
            {

                return Redirect(string.Format("http://{0}{1}?guid={2}&adminType={3}", storeUrl, Url.RouteUrl("Plugin.MerchantList.TmpAdmin"), guid, adminType));

            }
            else
            {
                return Redirect(string.Format("http://{0}{1}?guid={2}", storeUrl, Url.RouteUrl("Plugin.MerchantList.TmpAdmin"), guid));
            }
            //Admin menu based on super admin and user - add "adminType" parameter

        }


        //Admin menu based on super admin and user - add "adminType" parameter
        public ActionResult TmpAdmin(Guid guid, string adminType = "")
        //-----------------------
        {
            StringBuilder log = new StringBuilder();
            try
            {
                //anti-forgery
                if (MultisiteHelper.TempLoginGuids.ContainsKey(guid) && MultisiteHelper.TempLoginGuids[guid].StoreName == MultisiteHelper.SubDomain)
                {
                    MultisiteHelper.TempLoginGuids.Remove(guid);
                    var _customerService = new MultisiteCustomerService();
                    var _authenticationService = EngineContext.Current.Resolve<IAuthenticationService>();
                    var _storeContext = EngineContext.Current.Resolve<IStoreContext>();
                    var adminCustomer = _customerService.GetFirstAdminCustomer();
                    if (adminCustomer == null)
                    {
                        //find superadmin user
                        var username = string.Format("{0}@{1}", "superadmin", MultisiteHelper.Domain);
                        var sadmin = _customerService.GetCustomerByUsername(username);
                        //not found
                        if (sadmin == null)
                        {
                            //register
                            var _customerRegistrationService = EngineContext.Current.Resolve<ICustomerRegistrationService>();
                            sadmin = _customerService.InsertAdminCustomer(username);
                            var registrationRequest = new CustomerRegistrationRequest(sadmin, username,
                                username, Guid.NewGuid().ToString(), PasswordFormat.Hashed, _storeContext.CurrentStore.Id, true);
                            var registrationResult = _customerRegistrationService.RegisterCustomer(registrationRequest);
                            log.AppendFormat("User {0} registered at {1} with status {2}", username, MultisiteHelper.SubDomain, registrationResult.Success);
                        }
                        //var _logger = EngineContext.Current.Resolve<ILogger>();
                        try
                        {
                            using (var dc = new MultisiteObjectContext(MultisiteHelper.CurrentConnectionString, true))
                            {

                                var affectedRows = dc.Database.ExecuteSqlCommand(string.Format(
                                    "insert into dbo.Customer_CustomerRole_Mapping(CustomerRole_Id, Customer_Id) select 1, Id from dbo.Customer where Email = '{0}'",
                                    username));
                                if (affectedRows == 1)
                                {
                                    log.AppendFormat("User {0} got admin rights OK. ", username);
                                }
                                else
                                {
                                    log.AppendFormat("Unexpected number of rows: {0}", affectedRows);
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            log.AppendFormat("User {0} at {1} registration exception: {2}", username, MultisiteHelper.SubDomain, ex.Message, ex.InnerException != null ? ex.InnerException.Message : "");

                        }
                        _authenticationService.SignIn(sadmin, true);
                    }
                    else
                    {
                        _authenticationService.SignIn(adminCustomer, true);
                    }
                    if (!string.IsNullOrWhiteSpace(log.ToString()))
                    {
                        MultiSiteDataProvider.LogToAdminDatabase(log.ToString());
                    }

                    //Admin menu based on super admin and user
                    if (!string.IsNullOrEmpty(adminType))
                    {
                        return Redirect("/admin?type=" + adminType);
                    }
                    else
                    {
                        return Redirect("/admin");
                    }

                }
                else
                {
                    log.AppendLine("TmpAdmin: Guid not found");
                    MultiSiteDataProvider.LogToAdminDatabase(log.ToString());
                }
            }
            catch (Exception ex)
            {
                log.AppendFormat("TmpAdmin: {0} {1}", ex.Message, ex.InnerException != null ? ex.InnerException.Message : "");
                MultiSiteDataProvider.LogToAdminDatabase(log.ToString());
            }

            return HttpNotFound();
        }
    }

}
// thursday_change