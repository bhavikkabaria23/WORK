﻿using MultiSite.Data;
using Nop.Core;
using Nop.Core.Plugins;
using Nop.Services.Localization;
using Nop.Web.Framework.Controllers;
using Shopfast.Plugin.MerchantManagement;
using Shopfast.Plugin.MerchantManagement.Models;
using Shopfast.Plugin.MerchantManagement.Models.Kendoui;
using Shopfast.Plugin.MerchantManagement.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Web.Mvc;

namespace Shopfast.Plugin.MerchantManagement.Controllers
{
    public class PluginFilterController : BasePluginController
    {
        private readonly IPluginFinder _pluginFinder;

        private readonly ILocalizationService _localizationService;

        private readonly IWebHelper _webHelper;

        private readonly SiteService _siteService;

        public PluginFilterController(IPluginFinder pluginFinder, ILocalizationService localizationService, IWebHelper webHelper, SiteService siteService)
        {
            this._pluginFinder = pluginFinder;
            this._localizationService = localizationService;
            this._webHelper = webHelper;
            this._siteService = siteService;
        }

        [AdminAuthorize]
        [HttpPost]
        public ActionResult FilterSelected(string storeName, List<string> selectedPlugins)
        {
            if (selectedPlugins == null)
            {
                selectedPlugins = new List<string>();
            }
            base.TempData["selectedIds"] = selectedPlugins;
            if (this._siteService.SaveStorePlugins(storeName, selectedPlugins) <= 0)
            {
                this.ErrorNotification("Something wrong to save plugins. Please try to save again.", false);
            }
            else
            {
                this.SuccessNotification("Plugins saved successfully.", true);
            }
            return Json(new { Result = true });
        }

        [AdminAuthorize]
        public ActionResult PluginList(int? id)
        {
            PluginListModel model = new PluginListModel();
            IList<SelectListItem> availableGroups = model.AvailableGroups;
            SelectListItem selectListItem = new SelectListItem()
            {
                Text = this._localizationService.GetResource("Admin.Common.All"),
                Value = ""
            };
            availableGroups.Add(selectListItem);
            foreach (string g in this._pluginFinder.GetPluginGroups())
            {
                IList<SelectListItem> selectListItems = model.AvailableGroups;
                SelectListItem selectListItem1 = new SelectListItem()
                {
                    Text = g,
                    Value = g
                };
                selectListItems.Add(selectListItem1);
            }
            model.storeName = this._siteService.GetSiteById(Convert.ToInt32(id)).StoreName;
            return View("~/Plugins/Shopfast.Plugin.MerchantManagement/Views/PluginFilter/PluginList.cshtml", model);
        }

        [AdminAuthorize]
        [HttpPost]
        public ActionResult PluginListSelect(DataSourceRequest command, PluginListModel model)
        {
            List<PluginDescriptor> pluginDescriptors = this._pluginFinder.GetPluginDescriptors(LoadPluginsMode.All,null, 0, model.SearchGroup).ToList<PluginDescriptor>();
            DataSourceResult dataSourceResult = new DataSourceResult()
            {
                Data = (
                    from x in pluginDescriptors
                    select this.PreparePluginModel(x, model.storeName, false, false) into x
                    orderby x.Group
                    select x).ToList<PluginModel>(),
                Total = pluginDescriptors.Count<PluginDescriptor>()
            };
            return Json(dataSourceResult);
        }

        [NonAction]
        protected virtual PluginModel PreparePluginModel(PluginDescriptor pluginDescriptor, string StoreName, bool prepareLocales = true, bool prepareStores = true)
        {
            PluginModel model = pluginDescriptor.ToModel();
            model.LogoUrl = pluginDescriptor.GetLogoUrl(this._webHelper);
            IEnumerable<SitesPlugins> storeplugin = this._siteService.GetPluginsByStoreName(StoreName);
            if (storeplugin.Count<SitesPlugins>() > 0)
            {
                if (!storeplugin.Any<SitesPlugins>((SitesPlugins p) => p.SystemName == model.SystemName))
                {
                    model.IsFilter = "";
                }
                else
                {
                    model.IsFilter = "checked=checked";
                }
            }
            return model;
        }
    }
}