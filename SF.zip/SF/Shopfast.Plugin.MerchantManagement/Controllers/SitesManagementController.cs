﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using Nop.Core.Data;
using Nop.Core.Infrastructure;
using Nop.Services.Catalog;
using Nop.Web.Controllers;
using Nop.Web.Framework.Controllers;
using Shopfast.Plugin.MerchantManagement.Models;
using Shopfast.Plugin.MerchantManagement.Models.Kendoui;

namespace Shopfast.Plugin.MerchantManagement.Controllers
{
    public class SitesManagementController : BasePublicController
    {
        #region Action Methods

        #endregion
        [AdminAuthorize]
        private ActionResult SiteList()
        {
            var model = new TreeDataSourceResult();
            // For All Sites Order Totals        
            model.Data = SiteListModel.GetSiteOrderDetails();
            /*model.todayTotalAllSites = EngineContext.Current.Resolve<IPriceFormatter>().
                FormatPrice(Math.Round(lstSitesOrder.Sum(so => so.TodayTotal), 2));
            model.weekTotalAllSites = EngineContext.Current.Resolve<IPriceFormatter>().
                FormatPrice(Math.Round(lstSitesOrder.Sum(so => so.WeekTotal), 2));
            model.monthTotalAllSites = EngineContext.Current.Resolve<IPriceFormatter>().
                FormatPrice(Math.Round(lstSitesOrder.Sum(so => so.MonthTotal), 2));
            model.yearTotalAllSites = EngineContext.Current.Resolve<IPriceFormatter>().
                FormatPrice(Math.Round(lstSitesOrder.Sum(so => so.YearTotal), 2));
            model.allTotalAllSites = EngineContext.Current.Resolve<IPriceFormatter>().
                FormatPrice(Math.Round(lstSitesOrder.Sum(so => so.AllTotal), 2));
            model.totalSites = SiteListModel.Total("", null, null);
            model.avgTotalAllSites = EngineContext.Current.Resolve<IPriceFormatter>().
                FormatPrice(Math.Round((lstSitesOrder.Sum(so => so.AvgOrder/model.totalSites)), 2));
            model.avgTotal = EngineContext.Current.Resolve<IPriceFormatter>().
                FormatPrice(Math.Round((lstSitesOrder.Sum(so => so.AvgOrder)), 2));*/
            //-------------------------------------

            return View("~/Plugins/Shopfast.Plugin.MerchantManagement/Views/MerchantManagement/List.cshtml", model);
        }
    }
}
