﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Shopfast.Plugin.MerchantManagement.Models
{
    public class SiteOrderDetailsModel
    {
        public int siteid { get; set; }
        public string dbname { get; set; }
        public decimal todayTotal { get; set; }
        public decimal weekTotal { get; set; }
        public decimal monthTotal { get; set; }
        public decimal yearTotal { get; set; }
        public decimal allTotal { get; set; }
        public decimal avgOrder { get; set; }
        public int orderCount { get; set; }
    }
}