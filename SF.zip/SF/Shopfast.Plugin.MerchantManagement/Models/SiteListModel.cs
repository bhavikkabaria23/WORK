﻿using System.Web.Mvc;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Configuration;
using System.Linq;
using MultiSite.Data;
using Nop.Core.Data;
using System.Data.SqlClient;
using System.IO;
using Nop.Core.Infrastructure;
using MultiSite.Models;

namespace Shopfast.Plugin.MerchantManagement.Models
{
    public class SiteListModel
    {
        [UIHint("DateNullable")]
        [DisplayName("Start Date")]
        public DateTime? StartDate { get; set; }
        
        [UIHint("DateNullable")]
        [DisplayName("End Date")]
        public DateTime? EndDate { get; set; }

        [DisplayName("Customer Email")]
        public string CustomerEmail { get; set; }

        // For All Sites Order Totals        
        public string todayTotalAllSites { get; set; }
        public string weekTotalAllSites { get; set; }
        public string monthTotalAllSites { get; set; }
        public string yearTotalAllSites { get; set; }
        public string allTotalAllSites { get; set; }
        public string avgTotalAllSites { get; set; }
        public string avgTotal { get; set; }

        public List<SiteOrderDetailsModel> lstSitesOrder { get; set; }
        //--------------------------------------

        public static IEnumerable<SiteModel> SearchSites(string email, int page, int pageSize, DateTime? startDate, DateTime? endDate, List<SiteOrderDetailsModel> lstSitesOrder)
        {
            if (!MultisiteHelper.IsAdminSite)
            {
                return null;
            }
            // For All Sites Order Totals
            using (var dbContext = new Sites4Entities())
            {
                //string todayTotalAllSites = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                //        FormatPrice(0);
                //string weekTotalAllSites = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                //        FormatPrice(0);
                //string monthTotalAllSites = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                //        FormatPrice(0);
                //string yearTotalAllSites = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                //        FormatPrice(0);
                //string allTotalAllSites = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                //        FormatPrice(0);
                //             var siteOrderDetails = dbContext.Database.SqlQuery<SiteOrderDetailsModel>(
                // "sp_GetOrderDetailsOfAllSites @dbPrefix",
                // new SqlParameter("@dbPrefix", MultisiteHelper.ApplicationName)
                //).ToList();
                //if (lstSitesOrder.Count() > 0)
                //{
                //    SiteListModel siteList = new SiteListModel();
                //    siteList.todayTotalAllSites = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                //        FormatPrice(Math.Round(siteOrderDetails.Sum(so => so.todayTotal), 2));
                //    siteList.weekTotalAllSites = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                //        FormatPrice(Math.Round(siteOrderDetails.Sum(so => so.weekTotal), 2));
                //    siteList.monthTotalAllSites = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                //        FormatPrice(Math.Round(siteOrderDetails.Sum(so => so.monthTotal), 2));
                //    siteList.yearTotalAllSites = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                //        FormatPrice(Math.Round(siteOrderDetails.Sum(so => so.yearTotal), 2));
                //    siteList.allTotalAllSites = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                //        FormatPrice(Math.Round(siteOrderDetails.Sum(so => so.allTotal), 2));                    
                //}
                //-------------------------------------
                var sites = dbContext.Sites.Include("Owner").OrderBy(s => s.Id).AsEnumerable();

                if (!string.IsNullOrEmpty(email))
                    sites = sites.Where(s => s.Owner.email == email);

                if (startDate.HasValue)
                    sites = sites.Where(s => s.CreationDate >= startDate.Value);

                if (endDate.HasValue)
                    sites = sites.Where(s => s.CreationDate <= endDate.Value);

                if (pageSize > 0)
                {
                    sites = sites.Skip(pageSize * page).Take(pageSize);
                }

                return sites.Select(site =>
                    new SiteModel
                    {
                        Id = site.Id,
                        storeName = site.StoreName,
                        customerEmail = site.Owner.email,
                        CreationDate = site.CreationDate,
                        status = site.IsOrder ?? false ? "purchased" : "trial",
                        // For All Sites Order Totals
                        todayTotal = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                        FormatPrice(lstSitesOrder.Where(so => so.siteid == site.Id).Select(so => so.todayTotal).FirstOrDefault()),
                        weekTotal = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                        FormatPrice(lstSitesOrder.Where(so => so.siteid == site.Id).Select(so => so.weekTotal).FirstOrDefault()),
                        monthTotal = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                        FormatPrice(lstSitesOrder.Where(so => so.siteid == site.Id).Select(so => so.monthTotal).FirstOrDefault()),
                        yearTotal = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                        FormatPrice(lstSitesOrder.Where(so => so.siteid == site.Id).Select(so => so.yearTotal).FirstOrDefault()),
                        allTotal = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                        FormatPrice(lstSitesOrder.Where(so => so.siteid == site.Id).Select(so => so.allTotal).FirstOrDefault()),
                        avgOrder = EngineContext.Current.Resolve<Nop.Services.Catalog.IPriceFormatter>().
                        FormatPrice(lstSitesOrder.Where(so => so.siteid == site.Id).Select(so => (so.allTotal) / so.orderCount).FirstOrDefault())
                        //--------------------------------------
                    }).ToList();
            }
        }

        public static SiteCount Total(string email, DateTime? startDate, DateTime? endDate, int? parentId = 0)
        {
            SiteCount siteCount = new SiteCount();
            if (!MultisiteHelper.IsAdminSite)
            {
                return siteCount;
            }

            using (var dbContext = new Sites4Entities())
            {                
                var sites = dbContext.Sites.AsEnumerable();              

                if (!string.IsNullOrEmpty(email))
                    sites = sites.Where(s => s.Owner.email == email);

                if (startDate.HasValue)
                    sites = sites.Where(s => s.CreationDate >= startDate.Value);

                if (endDate.HasValue)
                    sites = sites.Where(s => s.CreationDate <= endDate.Value);
                if (parentId != 0)
                {
                    siteCount.gridTotal = sites.Count(s => s.ParentId == parentId);
                }
                siteCount.total = sites.Count();                
                return siteCount;
            }
        }

        public int totalSites { get; set; }

        public static SiteModel GetById(int id)
        {
            using (var dbContext = new Sites4Entities())
            {
                var site = dbContext.Sites.Include("Owner").SingleOrDefault(s => s.Id == id);
                if (site == null)
                {
                    return null;
                }

                return new SiteModel
                {
                    CreationDate = site.CreationDate,
                    customerEmail = site.Owner.email,
                    Id = site.Id,
                    status = site.IsOrder ?? false ? "Purchased" : "Trial",
                    storeName = site.StoreName,
                    description = site.Owner.description,
                    firstName = site.Owner.firstName,
                    industryType = site.Owner.industryType,
                    lastName = site.Owner.LastName,
                    phone = site.Owner.phone,
                    starting = site.Owner.starting,
                    Country = site.Owner.Country,
                    Website = site.Owner.Website,
                    //Multisite_NewField_change
                    StreetAddress = site.Owner.StreetAddress,
                    City = site.Owner.City,
                    ZipPostalCode = site.Owner.ZipPostalCode,
                    State = site.Owner.State,

                    // Free trial integration in new page
                    AvgSaleAmout = site.Owner.AvgSaleAmout,
                    ProcessorName = site.Owner.ProcessorName,
                    ProcessorEmail = site.Owner.ProcessorEmail,
                    ProcessorPhoneNumber = site.Owner.ProcessorPhoneNumber
                    //-----------------------

                    //--------------------------
                };
            }
        }

        public static SiteThemeModel GetByIdForTheme(int id)
        {
            using (var dbContext = new Sites4Entities())
            {
                var site = dbContext.Sites.Include("Owner").SingleOrDefault(s => s.Id == id);
                if (site == null)
                {
                    return null;
                }

                return new SiteThemeModel
                {                    
                    Id = site.Id,
                    status = site.IsOrder ?? false ? "Purchased" : "Trial",
                    storeName = site.StoreName,
                    description = site.Owner.description,
                    firstName = site.Owner.firstName,
                    industryType = site.Owner.industryType,
                    lastName = site.Owner.LastName,
                    phone = site.Owner.phone,
                    starting = site.Owner.starting,
                    Country = site.Owner.Country,
                    Website = site.Owner.Website,
                    //Multisite_NewField_change
                    StreetAddress = site.Owner.StreetAddress,
                    City = site.Owner.City,
                    ZipPostalCode = site.Owner.ZipPostalCode,
                    State = site.Owner.State,

                    // Free trial integration in new page
                    AvgSaleAmout = site.Owner.AvgSaleAmout,
                    ProcessorName = site.Owner.ProcessorName,
                    ProcessorEmail = site.Owner.ProcessorEmail,
                    ProcessorPhoneNumber = site.Owner.ProcessorPhoneNumber
                    //-----------------------

                    //--------------------------
                };
            }
        }
        
        //------------------

        public static int DeleteCustomerByStore(string email)
        {
            using (var dbContext = new Sites4Entities())
            {
                dbContext.Database.ExecuteSqlCommand(
       "sp_DeleteCustomerByStore @dbPrefix, @email",
       new SqlParameter("@dbPrefix", MultisiteHelper.ApplicationName),
               new SqlParameter("@email", email));
                return 1;
            }
        }

        public static int BackupStoreDB(SqlConnection dbConnection, string StoreName)
        {
            string backupPath = ConfigurationManager.AppSettings["BackupStoreDBPath"];
            if (Directory.Exists(backupPath))
            {
                string dbName = MultisiteHelper.ApplicationName + "_" + StoreName;
                string filePath = backupPath + dbName + "_" + DateTime.Now.ToString("yyyy_MM_dd_hh_mm_ss") + ".BAK";
                var dbCommand = new SqlCommand(string.Format(@"BACKUP DATABASE [{0}] TO DISK = '{1}'",
                   dbName, filePath), dbConnection);
                dbCommand.ExecuteNonQuery();
                return 1;
            }
            else
            {
                return 0;
            }
        }

    }

    public class SiteCount
    {
        public int total { get; set; }
        public int gridTotal { get; set; }
    }
}
