﻿using Nop.Web.Framework;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Web.Mvc;

namespace Shopfast.Plugin.MerchantManagement.Models
{
    public class PluginListModel
    {
        [NopResourceDisplayName("Shopfast.Plugin.MerchantManagement.Fields.Group")]
        public IList<SelectListItem> AvailableGroups
        {
            get;
            set;
        }

        [NopResourceDisplayName("Shopfast.Plugin.MerchantManagement.Fields.Group")]
        public string SearchGroup
        {
            get;
            set;
        }

        public string storeName
        {
            get;
            set;
        }

        public PluginListModel()
        {
            this.AvailableGroups = new List<SelectListItem>();
        }
    }
}