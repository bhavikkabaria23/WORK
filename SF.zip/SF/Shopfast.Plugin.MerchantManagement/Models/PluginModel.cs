﻿using Nop.Web.Framework;
using System;
using System.Runtime.CompilerServices;

namespace Shopfast.Plugin.MerchantManagement.Models
{
    public class PluginModel
    {
        [NopResourceDisplayName("Shopfast.Plugin.MerchantManagement.Fields.Author")]
        public string Author
        {
            get;
            set;
        }

        public bool CanChangeEnabled
        {
            get;
            set;
        }

        [NopResourceDisplayName("Shopfast.Plugin.MerchantManagement.Fields.Configure")]
        public string ConfigurationUrl
        {
            get;
            set;
        }

        [NopResourceDisplayName("Shopfast.Plugin.MerchantManagement.Fields.DisplayOrder")]
        public int DisplayOrder
        {
            get;
            set;
        }

        [NopResourceDisplayName("Shopfast.Plugin.MerchantManagement.Fields.FriendlyName")]
        public string FriendlyName
        {
            get;
            set;
        }

        [NopResourceDisplayName("Shopfast.Plugin.MerchantManagement.Fields.Group")]
        public string Group
        {
            get;
            set;
        }

        [NopResourceDisplayName("Shopfast.Plugin.MerchantManagement.Fields.Installed")]
        public bool Installed
        {
            get;
            set;
        }

        [NopResourceDisplayName("Shopfast.Plugin.MerchantManagement.Fields.IsEnabled")]
        public bool IsEnabled
        {
            get;
            set;
        }

        public virtual string IsFilter
        {
            get;
            set;
        }

        [NopResourceDisplayName("Shopfast.Plugin.MerchantManagement.Fields.Logo")]
        public string LogoUrl
        {
            get;
            set;
        }

        [NopResourceDisplayName("Shopfast.Plugin.MerchantManagement.Fields.SystemName")]
        public string SystemName
        {
            get;
            set;
        }

        [NopResourceDisplayName("Shopfast.Plugin.MerchantManagement.Fields.Version")]
        public string Version
        {
            get;
            set;
        }

        public PluginModel()
        {
        }
    }
}