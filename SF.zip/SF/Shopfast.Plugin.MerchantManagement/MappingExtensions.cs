﻿using AutoMapper;
using MultiSite.Data;
using MultiSite.Models;
using Nop.Core.Infrastructure;
using Nop.Core.Plugins;
using Shopfast.Plugin.MerchantManagement.Models;

namespace Shopfast.Plugin.MerchantManagement
{
    public static class MappingExtensions
    {
        public static TDestination MapTo<TSource, TDestination>(this TSource source)
        {
            return AutoMapperConfiguration.Mapper.Map<TSource, TDestination>(source);
        }

        public static TDestination MapTo<TSource, TDestination>(this TSource source, TDestination destination)
        {
            return AutoMapperConfiguration.Mapper.Map(source, destination);
        }

        #region Reason
        public static SiteModel ToModel(this Site entity)
        {
            return entity.MapTo<Site, SiteModel>();            
        }
        public static Site ToEntity(this SiteModel model)
        {
            return model.MapTo<SiteModel, Site>();            
        }
        public static SiteModel ToModel(this Owner entity)
        {            
            return entity.MapTo<Owner, SiteModel>();            
        }
        public static Owner ToOwnerEntity(this SiteModel model)
        {
            return model.MapTo<SiteModel, Owner>();            
        }

        public static PluginModel ToModel(this PluginDescriptor entity)
        {            
            return entity.MapTo<PluginDescriptor, PluginModel>();            
        }
        #endregion

    }

    public static class AutoMapperConfiguration
    {
        private static MapperConfiguration _mapperConfiguration;
        private static IMapper _mapper;

        public static void Init()
        {
            _mapperConfiguration = new MapperConfiguration(cfg =>
          {
              cfg.CreateMap<Site, SiteModel>();
              cfg.CreateMap<Owner, SiteModel>();
              cfg.CreateMap<SiteModel, Site>();
              cfg.CreateMap<SiteModel, Owner>();
              cfg.CreateMap<PluginDescriptor, PluginModel>().ReverseMap();
          });
            _mapper = _mapperConfiguration.CreateMapper();
        }

        /// <summary>
        /// Mapper
        /// </summary>
        public static IMapper Mapper
        {
            get
            {
                return _mapper;
            }
        }
        /// <summary>
        /// Mapper configuration
        /// </summary>
        public static MapperConfiguration MapperConfiguration
        {
            get
            {
                return _mapperConfiguration;
            }
        }
    }

    public class AutoMapperStartupTask : IStartupTask
    {
        public void Execute()
        {
            AutoMapperConfiguration.Init();
        }

        public int Order
        {
            get { return 0; }
        }
    }
}
