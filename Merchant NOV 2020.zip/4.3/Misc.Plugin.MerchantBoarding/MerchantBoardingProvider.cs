﻿using System.Collections.Generic;
using Nop.Core;
using Nop.Core.Domain.Customers;
using Nop.Core.Infrastructure;
using Nop.Services.Cms;
using Nop.Services.Configuration;
using Nop.Services.Customers;
using Nop.Services.Localization;
using Nop.Services.Media;
using Nop.Services.Plugins;
using Nop.Web.Framework.Infrastructure;
using Nop.Web.Framework.Menu;

namespace Nop.Plugin.Widgets.NivoSlider
{
    /// <summary>
    /// PLugin
    /// </summary>
    public class MerchantBoardingProvider : BasePlugin, IAdminMenuPlugin
    {
        private readonly ILocalizationService _localizationService;
        private readonly IPictureService _pictureService;
        private readonly ISettingService _settingService;
        private readonly IWebHelper _webHelper;
        private readonly INopFileProvider _fileProvider;

        public MerchantBoardingProvider(ILocalizationService localizationService,
            IWebHelper webHelper)
        {
            _localizationService = localizationService;
            _webHelper = webHelper;
        }

        /// <summary>
        /// Gets widget zones where this widget should be rendered
        /// </summary>
        /// <returns>Widget zones</returns>
        public IList<string> GetWidgetZones()
        {
            return new List<string> { PublicWidgetZones.HomepageTop };
        }

        /// <summary>
        /// Gets a configuration page URL
        /// </summary>
        public override string GetConfigurationPageUrl()
        {
            return _webHelper.GetStoreLocation() + "Admin/MerchantBoarding/Configure";
        }

        /// <summary>
        /// Install plugin
        /// </summary>
        public override void Install()
        {
            // Add "Merchant", "Partner" role if not exist
            if (EngineContext.Current.Resolve<ICustomerService>().GetCustomerRoleBySystemName("Merchant") == null)
            {
                CustomerRole role = new CustomerRole();
                role.Name = "Merchant";
                role.SystemName = "Merchant";
                role.Active = true;
                EngineContext.Current.Resolve<ICustomerService>().InsertCustomerRole(role);
            }
            if (EngineContext.Current.Resolve<ICustomerService>().GetCustomerRoleBySystemName("Partner") == null)
            {
                CustomerRole role = new CustomerRole();
                role.Name = "Partner";
                role.SystemName = "Partner";
                role.Active = true;
                EngineContext.Current.Resolve<ICustomerService>().InsertCustomerRole(role);
            }
            //--------------------------------

            //locales
            _localizationService.AddPluginLocaleResource(new Dictionary<string, string>
            {
                //locales
                // Common
                ["Plugin.MerchantBoarding.PleaseAccept"] = "Please accept the terms and condition",

                // Configuartion
                ["Plugin.MerchantBoarding.Fields.EnableTINCheck"] = "Enable TINCheck",
                ["Plugin.MerchantBoarding.Fields.TINCheckModeId"] = "TINCheck ModeI",
                ["Plugin.MerchantBoarding.Fields.TINCheckTestUsername"] = "TINCheck Test Username",
                ["Plugin.MerchantBoarding.Fields.TINCheckTestPassword"] = "TINCheck Test Password",
                ["Plugin.MerchantBoarding.Fields.TINCheckLiveUsername"] = "TINCheck Live Username",
                ["Plugin.MerchantBoarding.Fields.TINCheckLivePassword"] = "TINCheck Live Password",
                ["Plugin.MerchantBoarding.Fields.EnableBlockScore"] = "Enable BlockScore",


                // My Account
                ["Plugin.MerchantBoarding.MerchantFees"] = "Merchant Fees",
                ["Plugin.MerchantBoarding.PartnerFees"] = "Partner Fees",
                // Merchant boarding Register
                ["Plugin.MerchantBoarding.MerchantBoarding"] = "Merchant Boarding",
                ["Plugin.MerchantBoarding.CorporationName"] = "Corporation Name",
                ["Plugin.MerchantBoarding.ContactName"] = "Contact Name",
                ["Plugin.MerchantBoarding.EmailAddress"] = "Email Address",
                ["Plugin.MerchantBoarding.TelephoneNumber"] = "Telephone Number",
                ["Plugin.MerchantBoarding.Password"] = "Password",
                ["Plugin.MerchantBoarding.MerchantRegisterConfirm"] = "By checking this box I am consenting to providing eVance and the subsidiaries of the OLB group all required information for the online application.",

                // Merchant Information
                ["Plugin.MerchantBoarding.MerchantInformation"] = "Merchant Information",
                ["Plugin.MerchantBoarding.FaxNumber"] = "Fax Number",
                ["Plugin.MerchantBoarding.Cell"] = "Cell #",
                ["Plugin.MerchantBoarding.MerchantName"] = "Merchant Name(DBA or Trade Name)",
                ["Plugin.MerchantBoarding.LocationAddress"] = "Location Address",
                ["Plugin.MerchantBoarding.City"] = "City",
                ["Plugin.MerchantBoarding.State"] = "State",
                ["Plugin.MerchantBoarding.ZipCode"] = "Zip Code",
                ["Plugin.MerchantBoarding.LocationAddress2"] = "Location Address (2)",

                // Legal Information
                ["Plugin.MerchantBoarding.LegalInformation"] = "Legal Information",
                ["Plugin.MerchantBoarding.LegalName"] = "Corporation/Legal Name (if different)",
                ["Plugin.MerchantBoarding.CorporateAddress"] = "Corporate Address (if diffrent)",
                ["Plugin.MerchantBoarding.Federal"] = "FEDERAL TAX ID OR SSN DETAILS",
                ["Plugin.MerchantBoarding.TaxId"] = "Federal Tax Id",
                ["Plugin.MerchantBoarding.SSN"] = "SSN",
                ["Plugin.MerchantBoarding.MCCCODE"] = "MCC CODE",
                ["Plugin.MerchantBoarding.IsMailingAddress"] = "Is Your mailing address same as Location Address?",
                ["Plugin.MerchantBoarding.MailingAddress"] = "Mailing Address",

                // Business Information
                ["Plugin.MerchantBoarding.BusinessInformation"] = "Business Information",
                ["Plugin.MerchantBoarding.IsPaymentCard"] = "Do you currently Accept Payment Cards?",
                ["Plugin.MerchantBoarding.IsTerminated"] = "Has the merchant Been terminated from Accepting Cards?",
                ["Plugin.MerchantBoarding.IsSecurityBranch"] = "Have you had a Security Breach?",
                ["Plugin.MerchantBoarding.IfSoExplain?"] = "If so explain?",
                ["Plugin.MerchantBoarding.WhoWith"] = "Who is it with",
                ["Plugin.MerchantBoarding.PCIDDSCompliance"] = "Include latest proof of PCI DDS compliance",
                ["Plugin.MerchantBoarding.UploadDocument"] = "(Upload Document)",
                ["Plugin.MerchantBoarding.TypeOfBusiness"] = "Type of Business",
                ["Plugin.MerchantBoarding.TypeOfBusiness.Option1"] = "Individual/Sole Proprietor",
                ["Plugin.MerchantBoarding.TypeOfBusiness.Option2"] = "Partnership",
                ["Plugin.MerchantBoarding.TypeOfBusiness.Option3"] = "Corporation ",
                ["Plugin.MerchantBoarding.TypeOfBusiness.Option4"] = "Private",
                ["Plugin.MerchantBoarding.TypeOfBusiness.Option5"] = "LLC: state",
                ["Plugin.MerchantBoarding.TypeOfBusiness.Option6"] = "Goverment",
                ["Plugin.MerchantBoarding.TypeOfBusiness.Option7"] = "Publicly Traded",
                ["Plugin.MerchantBoarding.TypeOfBusiness.Option8"] = "Non Profit",
                ["Plugin.MerchantBoarding.EvidenceOf501(c)(3)Sstatus"] = "(provide evidence of 501(c)(3) status)",
                ["Plugin.MerchantBoarding.LengthBusinessYears"] = "LENGTH OF TIME IN BUSINESS (YEARS)",
                ["Plugin.MerchantBoarding.LengthBusinessMonths"] = "LENGTH OF TIME IN BUSINESS (MONTHS)",
                ["Plugin.MerchantBoarding.Year"] = "YEARS",
                ["Plugin.MerchantBoarding.Month"] = "MONTHS",
                ["Plugin.MerchantBoarding.WebsiteAddress"] = "WEBSITE ADDRESS",
                ["Plugin.MerchantBoarding.NoOfLocations"] = "NUMBER OF LOCATIONS",
                ["Plugin.MerchantBoarding.CustomerServiceNo"] = "CUSTOMER SERVICE PHONE #",
                ["Plugin.MerchantBoarding.MerchantSignature"] = "Merchant Signature",
            });

            base.Install();
        }

        /// <summary>
        /// Uninstall plugin
        /// </summary>
        public override void Uninstall()
        {

            base.Uninstall();
        }

        public void ManageSiteMap(SiteMapNode rootNode)
        {
            //var menuItem1 = new SiteMapNode()
            //{
            //    SystemName = "ResidualReports",
            //    Title = EngineContext.Current.Resolve<ILocalizationService>().GetResource("Admin.ResidualReport.Title"),
            //    Url = "/Admin/ResidualReports",
            //    Visible = true,
            //    IconClass = "fa-dot-circle-o"
            //};
            //var menuItem2 = new SiteMapNode()
            //{
            //    SystemName = "TotalPayoutsReports",
            //    Title = EngineContext.Current.Resolve<ILocalizationService>().GetResource("Admin.PayoutsReport.Title"),
            //    Url = "/Admin/Payouts",
            //    Visible = true,
            //    IconClass = "fa-dot-circle-o"
            //};
            //var firstNode = new SiteMapNode()
            //{
            //    SystemName = "Reports",
            //    Title = EngineContext.Current.Resolve<ILocalizationService>().GetResource("Admin.Report.Title"),
            //    Visible = true,
            //    IconClass = "fa-dot-circle-o"
            //};
            //if (firstNode != null)
            //{
            //    firstNode.ChildNodes.Add(menuItem1);
            //    firstNode.ChildNodes.Add(menuItem2);
            //    rootNode.ChildNodes.Add(firstNode);
            //}
            //else
            //{
            //    rootNode.ChildNodes.Add(menuItem1);
            //    rootNode.ChildNodes.Add(menuItem2);
            //}
        }

        /// <summary>
        /// Gets a value indicating whether to hide this plugin on the widget list page in the admin area
        /// </summary>
        public bool HideInWidgetList => false;
    }
}