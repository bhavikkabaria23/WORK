﻿using Microsoft.AspNetCore.Mvc;
using Misc.Plugin.MerchantBoarding.Models;
using Nop.Core.Infrastructure;
using Nop.Web.Factories;
using Nop.Web.Framework.Components;
using Nop.Web.Framework.Themes;
using System.Threading.Tasks;

namespace Misc.Plugin.MerchantBoarding.Components
{
    public class MerchantApplicationsViewComponent : NopViewComponent
    {
        private readonly ICommonModelFactory _commonModelFactory;

        public MerchantApplicationsViewComponent(ICommonModelFactory commonModelFactory)
        {
            _commonModelFactory = commonModelFactory;
        }

        public IViewComponentResult Invoke()
        {
            MerchantApplicationModel model = new MerchantApplicationModel();
            Task.WaitAll(Task.Run(async () => { model = await MerchantApplicationsCRMGet(); }));

            return View("/Themes/Main/Views/MerchantBoarding/_MerchantApplications.cshtml", model);
        }
    }
}
