﻿using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Core.Infrastructure;
using Nop.Services.Customers;
using Nop.Web.Factories;
using Nop.Web.Framework.Components;
using Nop.Web.Framework.Themes;
using System.Linq;

namespace Misc.Plugin.MerchantBoarding.Components
{
    public class LoadRegisterPageViewComponent : NopViewComponent
    {
        private readonly ICommonModelFactory _commonModelFactory;

        public LoadRegisterPageViewComponent(ICommonModelFactory commonModelFactory)
        {
            _commonModelFactory = commonModelFactory;
        }

        public IViewComponentResult Invoke()
        {
            var currentCustomer = EngineContext.Current.Resolve<IWorkContext>().CurrentCustomer;
            var customerRoles = EngineContext.Current.Resolve<ICustomerService>().GetCustomerRoles(currentCustomer);
            if (customerRoles != null && customerRoles.Any())
            {

                var merchantRole = customerRoles.FirstOrDefault(r => r.SystemName.ToLower() == "merchant");
                var partnerRole = customerRoles.FirstOrDefault(r => r.SystemName.ToLower() == "partner");
                if (merchantRole != null)
                {
                    return View("/Themes/Main/Views/MerchantBoarding/Index.cshtml");
                }
                else if (partnerRole != null)
                {
                    return View("/Themes/Main/Views/PartnerRegistration/Index.cshtml");
                }
            }
            return Content("Registerd customer is not a Merchant or Partner. Please define the role of Merchant or Partner");
        }
    }
}
