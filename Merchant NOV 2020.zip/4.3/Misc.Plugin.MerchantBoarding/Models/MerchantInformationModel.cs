﻿using FluentValidation.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Misc.Plugin.MerchantBoarding.Models
{
    public class BaseInformationModel
    {
        public BaseInformationModel()
        {
            #region State and MCCCOde List
            StateList = new List<StateModel>();
            MCCCodeList = new List<StateModel>();
            StateList.Add(new StateModel { StateIndex = -1, StateName = "" });
            StateList.Add(new StateModel { StateIndex = 0, StateName = "Alabama" });
            StateList.Add(new StateModel { StateIndex = 1, StateName = "Alaska" });
            StateList.Add(new StateModel { StateIndex = 2, StateName = "Arizona" });
            StateList.Add(new StateModel { StateIndex = 3, StateName = "Arkansas" });
            StateList.Add(new StateModel { StateIndex = 4, StateName = "California" });
            StateList.Add(new StateModel { StateIndex = 5, StateName = "Colorado" });
            StateList.Add(new StateModel { StateIndex = 6, StateName = "Connecticut" });
            StateList.Add(new StateModel { StateIndex = 7, StateName = "Delaware" });
            StateList.Add(new StateModel { StateIndex = 8, StateName = "District Of Columbia" });
            StateList.Add(new StateModel { StateIndex = 9, StateName = "Florida" });
            StateList.Add(new StateModel { StateIndex = 10, StateName = "Georgia" });
            StateList.Add(new StateModel { StateIndex = 11, StateName = "Hawaii" });
            StateList.Add(new StateModel { StateIndex = 12, StateName = "Idaho" });
            StateList.Add(new StateModel { StateIndex = 13, StateName = "Illinois" });
            StateList.Add(new StateModel { StateIndex = 14, StateName = "Indiana" });
            StateList.Add(new StateModel { StateIndex = 15, StateName = "Iowa" });
            StateList.Add(new StateModel { StateIndex = 16, StateName = "Kansas" });
            StateList.Add(new StateModel { StateIndex = 17, StateName = "Kentucky" });
            StateList.Add(new StateModel { StateIndex = 18, StateName = "Louisiana" });
            StateList.Add(new StateModel { StateIndex = 19, StateName = "Maine" });
            StateList.Add(new StateModel { StateIndex = 20, StateName = "Maryland" });
            StateList.Add(new StateModel { StateIndex = 21, StateName = "Massachusetts" });
            StateList.Add(new StateModel { StateIndex = 22, StateName = "Michigan" });
            StateList.Add(new StateModel { StateIndex = 23, StateName = "Minnesota" });
            StateList.Add(new StateModel { StateIndex = 24, StateName = "Mississippi" });
            StateList.Add(new StateModel { StateIndex = 25, StateName = "Missouri" });
            StateList.Add(new StateModel { StateIndex = 26, StateName = "Montana" });
            StateList.Add(new StateModel { StateIndex = 27, StateName = "Nebraska" });
            StateList.Add(new StateModel { StateIndex = 28, StateName = "Nevada" });
            StateList.Add(new StateModel { StateIndex = 29, StateName = "New Hampshire" });
            StateList.Add(new StateModel { StateIndex = 30, StateName = "New Jersey" });
            StateList.Add(new StateModel { StateIndex = 31, StateName = "New Mexico" });
            StateList.Add(new StateModel { StateIndex = 32, StateName = "New York" });
            StateList.Add(new StateModel { StateIndex = 33, StateName = "North Carolina" });
            StateList.Add(new StateModel { StateIndex = 34, StateName = "North Dakota" });
            StateList.Add(new StateModel { StateIndex = 35, StateName = "Ohio" });
            StateList.Add(new StateModel { StateIndex = 36, StateName = "Oklahoma" });
            StateList.Add(new StateModel { StateIndex = 37, StateName = "Oregon" });
            StateList.Add(new StateModel { StateIndex = 38, StateName = "Pennsylvania" });
            StateList.Add(new StateModel { StateIndex = 39, StateName = "Rhode Island" });
            StateList.Add(new StateModel { StateIndex = 40, StateName = "South Carolina" });
            StateList.Add(new StateModel { StateIndex = 41, StateName = "South Dakota" });
            StateList.Add(new StateModel { StateIndex = 42, StateName = "Tennessee" });
            StateList.Add(new StateModel { StateIndex = 43, StateName = "Texas" });
            StateList.Add(new StateModel { StateIndex = 44, StateName = "Utah" });
            StateList.Add(new StateModel { StateIndex = 45, StateName = "Vermont" });
            StateList.Add(new StateModel { StateIndex = 46, StateName = "Virginia" });
            StateList.Add(new StateModel { StateIndex = 47, StateName = "Washington" });
            StateList.Add(new StateModel { StateIndex = 48, StateName = "West Virginia" });
            StateList.Add(new StateModel { StateIndex = 49, StateName = "Wisconsin" });
            StateList.Add(new StateModel { StateIndex = 50, StateName = "Wyoming" });

            MCCCodeList.Add(new StateModel { StateIndex = -1, StateName = "" });
            MCCCodeList.Add(new StateModel { StateIndex = 0, StateName = "5812 - Eating Places, Restaurants" });
            MCCCodeList.Add(new StateModel { StateIndex = 1, StateName = "5813 - Bars, Cocktail Lounges, (Alcoholic Beverages)" });
            MCCCodeList.Add(new StateModel { StateIndex = 2, StateName = "5814 - Fast Food Restaurants" });
            MCCCodeList.Add(new StateModel { StateIndex = 3, StateName = "5499 - Miscellaneous Food Stores, Specialty Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 4, StateName = "5921 - Package Stores, Beer, Wine, and Liquor" });
            MCCCodeList.Add(new StateModel { StateIndex = 5, StateName = "5941 - Sporting Goods Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 6, StateName = "5947 - Card, Gift, Novelty, and Souvenir Shops" });
            MCCCodeList.Add(new StateModel { StateIndex = 7, StateName = "5993 - Cigar Stores and Stands" });
            MCCCodeList.Add(new StateModel { StateIndex = 8, StateName = "5999 - Miscellaneous and Specialty Retail Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 9, StateName = "7230 - Barber and Beauty Shops" });
            MCCCodeList.Add(new StateModel { StateIndex = 10, StateName = "7299 - Other Services not elsewhere classified" });
            MCCCodeList.Add(new StateModel { StateIndex = 11, StateName = "7538 - Automotive Service Shops" });
            MCCCodeList.Add(new StateModel { StateIndex = 12, StateName = "8099 - Health Practitioners, Medical Services not elsewhere classified" });
            MCCCodeList.Add(new StateModel { StateIndex = 13, StateName = "4121 - Limousines and Taxicabs" });
            MCCCodeList.Add(new StateModel { StateIndex = 14, StateName = "5511 - Automobile and Truck Dealers-Sales, Service, Repairs, Parts, and Leasing" });
            MCCCodeList.Add(new StateModel { StateIndex = 15, StateName = "5532 - Automotive Tire Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 16, StateName = "7399 - Business Services not elsewhere classified" });
            MCCCodeList.Add(new StateModel { StateIndex = 17, StateName = "7531 - Automotive Body Repair Shops" });
            MCCCodeList.Add(new StateModel { StateIndex = 18, StateName = "7999 - Recreation Services not elsewhere classified" });
            MCCCodeList.Add(new StateModel { StateIndex = 19, StateName = "8111 - Attorneys, Legal Services" });
            MCCCodeList.Add(new StateModel { StateIndex = 20, StateName = "8299 - Schools and Educational Services not elsewhere classified" });
            MCCCodeList.Add(new StateModel { StateIndex = 21, StateName = "0742 - Veterinary Services" });
            MCCCodeList.Add(new StateModel { StateIndex = 22, StateName = "0763 - Agricultural Cooperatives" });
            MCCCodeList.Add(new StateModel { StateIndex = 23, StateName = "0780 - Horticultural and Landscaping Services" });
            MCCCodeList.Add(new StateModel { StateIndex = 24, StateName = "1520 - General Contractors-Residential and Commercial" });
            MCCCodeList.Add(new StateModel { StateIndex = 25, StateName = "1711 - AC, Heating, and Plumbing Contractors" });
            MCCCodeList.Add(new StateModel { StateIndex = 26, StateName = "1731 - Electrical Contractors" });
            MCCCodeList.Add(new StateModel { StateIndex = 27, StateName = "1740 - insulation, Masonry Setting Contractors" });
            MCCCodeList.Add(new StateModel { StateIndex = 28, StateName = "1750 - Carpentry Contractors" });
            MCCCodeList.Add(new StateModel { StateIndex = 29, StateName = "1761 - Roofing and Siding, Sheet Metal Work Contractors" });
            MCCCodeList.Add(new StateModel { StateIndex = 30, StateName = "1771 - Concrete Work Contractors" });
            MCCCodeList.Add(new StateModel { StateIndex = 31, StateName = "1799 - Contractors, Special Trade-not elsewhere classified" });
            MCCCodeList.Add(new StateModel { StateIndex = 32, StateName = "2741 - Miscellaneous Publishing and Printing" });
            MCCCodeList.Add(new StateModel { StateIndex = 33, StateName = "2791 - Typesetting, Plate Making, and Related Services" });
            MCCCodeList.Add(new StateModel { StateIndex = 34, StateName = "2842 - Sanitation and Specialty Cleaning Preparations" });
            MCCCodeList.Add(new StateModel { StateIndex = 35, StateName = "3000 through 3299 - Airlines, Air Carriers" });
            MCCCodeList.Add(new StateModel { StateIndex = 36, StateName = "3351 through 3441 - Car Rental Agencies" });
            MCCCodeList.Add(new StateModel { StateIndex = 37, StateName = "3501 through 3999 - Lodging-Hotels, Motels, Resorts" });
            MCCCodeList.Add(new StateModel { StateIndex = 38, StateName = "4011 - Railroads-Freight." });
            MCCCodeList.Add(new StateModel { StateIndex = 39, StateName = "4111 - Transportation-Commuter Passenger, including ferries" });
            MCCCodeList.Add(new StateModel { StateIndex = 40, StateName = "4112 - Passenger Railways" });
            MCCCodeList.Add(new StateModel { StateIndex = 41, StateName = "4119 - Ambulance Services" });
            MCCCodeList.Add(new StateModel { StateIndex = 42, StateName = "4131 - Bus Lines" });
            MCCCodeList.Add(new StateModel { StateIndex = 43, StateName = "4214 - Motor Freight Carriers, Trucking, Moving and Storage Companies, Local Delivery" });
            MCCCodeList.Add(new StateModel { StateIndex = 44, StateName = "4215 - Courier Services Air and Ground, Freight Forwarders" });
            MCCCodeList.Add(new StateModel { StateIndex = 45, StateName = "4225 - Public Warehousing Farm Products, Refrigerated and Household Goods Storage" });
            MCCCodeList.Add(new StateModel { StateIndex = 46, StateName = "4411 - Cruise Lines" });
            MCCCodeList.Add(new StateModel { StateIndex = 47, StateName = "4457 - Boat Leases and Boat Rentals" });
            MCCCodeList.Add(new StateModel { StateIndex = 48, StateName = "4468 - Marinas, Marine Service/Supplies" });
            MCCCodeList.Add(new StateModel { StateIndex = 49, StateName = "4511 - Air Carriers, Airlines Not Elsewhere Classified" });
            MCCCodeList.Add(new StateModel { StateIndex = 50, StateName = "4582 - Airports, Airport Terminals, Flying Fields" });
            MCCCodeList.Add(new StateModel { StateIndex = 51, StateName = "4722 - Travel Agencies and Tour Operators" });
            MCCCodeList.Add(new StateModel { StateIndex = 52, StateName = "4784 - Bridge and Road Fees, Tolls" });
            MCCCodeList.Add(new StateModel { StateIndex = 53, StateName = "4789 - Transportation Services not elsewhere classified" });
            MCCCodeList.Add(new StateModel { StateIndex = 54, StateName = "4812 - Telecommunication Equipment Including Telephone Sales" });
            MCCCodeList.Add(new StateModel { StateIndex = 55, StateName = "4813 - Key-entry Telecom Merchant providing single local and long-distance phone calls" });
            MCCCodeList.Add(new StateModel { StateIndex = 56, StateName = "4814 - Telecommunication Services including prepaid phone services and recurring phone services" });
            MCCCodeList.Add(new StateModel { StateIndex = 57, StateName = "4816 - Computer Network/Information Services" });
            MCCCodeList.Add(new StateModel { StateIndex = 58, StateName = "4821 - Telegraph Services" });
            MCCCodeList.Add(new StateModel { StateIndex = 59, StateName = "4829 - Money Transfer" });
            MCCCodeList.Add(new StateModel { StateIndex = 60, StateName = "4899 - Cable, Satellite, and Other Pay Television and Radio Services" });
            MCCCodeList.Add(new StateModel { StateIndex = 61, StateName = "4900 - Utilities-Electric, Gas, Heating Oil, Sanitary, Water" });
            MCCCodeList.Add(new StateModel { StateIndex = 62, StateName = "5013 - Motor Vehicle Supplies and New Parts" });
            MCCCodeList.Add(new StateModel { StateIndex = 63, StateName = "5021 - Office and Commercial Furniture" });
            MCCCodeList.Add(new StateModel { StateIndex = 64, StateName = "5039 - Construction Materials not elsewhere classified" });
            MCCCodeList.Add(new StateModel { StateIndex = 65, StateName = "5044 - Office, Photographic, Photocopy, and Microfilm Equipment" });
            MCCCodeList.Add(new StateModel { StateIndex = 66, StateName = "5045 - Computers, Computer Peripheral Equipment, Software" });
            MCCCodeList.Add(new StateModel { StateIndex = 67, StateName = "5046 - Commercial Equipment not elsewhere classified" });
            MCCCodeList.Add(new StateModel { StateIndex = 68, StateName = "5047 - Dental/Laboratory/Medical/Ophthalmic Hospital Equipment and Supplies" });
            MCCCodeList.Add(new StateModel { StateIndex = 69, StateName = "5051 - Metal Service Centers and Offices" });
            MCCCodeList.Add(new StateModel { StateIndex = 70, StateName = "5065 - Electrical Parts and Equipment" });
            MCCCodeList.Add(new StateModel { StateIndex = 71, StateName = "5072 - Hardware Equipment and Supplies" });
            MCCCodeList.Add(new StateModel { StateIndex = 72, StateName = "5074 - Plumbing and Heating Equipment" });
            MCCCodeList.Add(new StateModel { StateIndex = 73, StateName = "5085 - lndustrial Supplies not elsewhere classified" });
            MCCCodeList.Add(new StateModel { StateIndex = 74, StateName = "5094 - Precious Stones and Metals, Watches and Jewelry" });
            MCCCodeList.Add(new StateModel { StateIndex = 75, StateName = "5099 - Durable Goods not elsewhere classified" });
            MCCCodeList.Add(new StateModel { StateIndex = 76, StateName = "5111 - Stationery, Office Supplies, Printing and Writing Paper" });
            MCCCodeList.Add(new StateModel { StateIndex = 77, StateName = "5122 - Drugs, Drug Proprietors, and Druggists Sundries" });
            MCCCodeList.Add(new StateModel { StateIndex = 78, StateName = "5131 - Piece Goods, Notions, and Other Dry Goods" });
            MCCCodeList.Add(new StateModel { StateIndex = 79, StateName = "5137 - Men's, Women's, and Children's Uniforms and Commercial Clothing" });
            MCCCodeList.Add(new StateModel { StateIndex = 80, StateName = "5139 - Commercial Footwear" });
            MCCCodeList.Add(new StateModel { StateIndex = 81, StateName = "5169 - Chemicals and Allied Products not elsewhere classified" });
            MCCCodeList.Add(new StateModel { StateIndex = 82, StateName = "5172 - Petroleum and Petroleum Products" });
            MCCCodeList.Add(new StateModel { StateIndex = 83, StateName = "5192 - Books, Periodicals, and Newspapers" });
            MCCCodeList.Add(new StateModel { StateIndex = 84, StateName = "5193 - Florists Supplies, Nursery Stock, and Flowers" });
            MCCCodeList.Add(new StateModel { StateIndex = 85, StateName = "5198 - Paints, Varnishes, and Supplies" });
            MCCCodeList.Add(new StateModel { StateIndex = 86, StateName = "5199 - Nondurable Goods not elsewhere classified" });
            MCCCodeList.Add(new StateModel { StateIndex = 87, StateName = "5200 - Home Supply Warehouse Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 88, StateName = "5211 - Building Materials, Lumber Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 89, StateName = "5231 - Glass, Paint, Wallpaper Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 90, StateName = "5251 - Hardware Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 91, StateName = "5261 - Lawn and Garden Supply Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 92, StateName = "5271 - Mobile Home Dealers" });
            MCCCodeList.Add(new StateModel { StateIndex = 93, StateName = "5300 - Wholesale Clubs" });
            MCCCodeList.Add(new StateModel { StateIndex = 94, StateName = "5309 - Duty Free Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 95, StateName = "5310 - Discount Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 96, StateName = "5311 - Department Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 97, StateName = "5331 - Variety Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 98, StateName = "5399 - Miscellaneous General Merchandise Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 99, StateName = "5411 - Grocery Stores, Supermarkets" });
            MCCCodeList.Add(new StateModel { StateIndex = 100, StateName = "5422 - Freezer, Locker Meat Provisioners" });
            MCCCodeList.Add(new StateModel { StateIndex = 101, StateName = "5441 - Candy, Nut, Confectionery Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 102, StateName = "5451 - Dairy Products Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 103, StateName = "5462 - Bakeries" });
            MCCCodeList.Add(new StateModel { StateIndex = 104, StateName = "5521 - Automobile and Truck Dealers-(Used Only)-Sales" });
            MCCCodeList.Add(new StateModel { StateIndex = 105, StateName = "5531 - Auto Store, Home Supply Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 106, StateName = "5533 - Automotive Parts, Accessories Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 107, StateName = "5541 - Service Stations (with or without Ancillary Services)" });
            MCCCodeList.Add(new StateModel { StateIndex = 108, StateName = "5542 - Fuel Dispenser, Automated" });
            MCCCodeList.Add(new StateModel { StateIndex = 109, StateName = "5551 - Boat Dealers" });
            MCCCodeList.Add(new StateModel { StateIndex = 110, StateName = "5561 - Camper Dealers, Recreational and Utility Trailers" });
            MCCCodeList.Add(new StateModel { StateIndex = 111, StateName = "5571 - Motorcycle Shops and Dealers" });
            MCCCodeList.Add(new StateModel { StateIndex = 112, StateName = "5592 - Motor Home Dealers" });
            MCCCodeList.Add(new StateModel { StateIndex = 113, StateName = "5598 - Snowmobile Dealers" });
            MCCCodeList.Add(new StateModel { StateIndex = 114, StateName = "5599 - Miscellaneous Automotive, Aircraft, and Farm Equipment Dealers not elsewhere classified" });
            MCCCodeList.Add(new StateModel { StateIndex = 115, StateName = "5611 - Men's and Boys' Clothing and Accessories Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 116, StateName = "5621 - Women's Ready to Wear Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 117, StateName = "5631 - Women's Accessory and Specialty Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 118, StateName = "5641 - Children's and Infants' Wear Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 119, StateName = "5651 - Family Clothing Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 120, StateName = "5655 - Sports Apparel, Riding Apparel Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 121, StateName = "5661 - Shoe Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 122, StateName = "5681 - Furriers and Fur Shops" });
            MCCCodeList.Add(new StateModel { StateIndex = 123, StateName = "5691 - Men's and Women's Clothing Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 124, StateName = "5697 - Alterations, Mending, Seamstresses, Tailors" });
            MCCCodeList.Add(new StateModel { StateIndex = 125, StateName = "5698 - Wig and Toupee Shops" });
            MCCCodeList.Add(new StateModel { StateIndex = 126, StateName = "5699 - Accessory and Apparel Stores-Miscellaneous" });
            MCCCodeList.Add(new StateModel { StateIndex = 127, StateName = "5712 - Equipment, Furniture, and Home Furnishings Stores (except Appliances)" });
            MCCCodeList.Add(new StateModel { StateIndex = 128, StateName = "5713 - Floor Covering Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 129, StateName = "5714 - Drapery, Upholstery, and Window Coverings Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 130, StateName = "5718 - Fireplace, Fireplace Screens and Accessories Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 131, StateName = "5719 - Miscellaneous House Furnishing Specialty Shops" });
            MCCCodeList.Add(new StateModel { StateIndex = 132, StateName = "5722 - Household Appliance Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 133, StateName = "5732 - Electronic Sales" });
            MCCCodeList.Add(new StateModel { StateIndex = 134, StateName = "5733 - Music Stores-Musical Instruments, Pianos, Sheet Music." });
            MCCCodeList.Add(new StateModel { StateIndex = 135, StateName = "5734 - Computer Software Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 136, StateName = "5735 - Record Shops" });
            MCCCodeList.Add(new StateModel { StateIndex = 137, StateName = "5811 - Caterers" });
            MCCCodeList.Add(new StateModel { StateIndex = 138, StateName = "5815 - Digital Goods-Audiovisual Media Including Books, Movies, and Music." });
            MCCCodeList.Add(new StateModel { StateIndex = 139, StateName = "5816 - Digital Goods-Games" });
            MCCCodeList.Add(new StateModel { StateIndex = 140, StateName = "5817 - Digital Goods-Software Applications (Excluding Games)" });
            MCCCodeList.Add(new StateModel { StateIndex = 141, StateName = "5818 - Digital Goods-Multi-Category" });
            MCCCodeList.Add(new StateModel { StateIndex = 142, StateName = "5912 - Drug Stores, Pharmacies" });
            MCCCodeList.Add(new StateModel { StateIndex = 143, StateName = "5931 - Second Hand Stores, Used Merchandise Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 144, StateName = "5932 - Antique Shops-Sales, Repairs, and Restoration Services" });
            MCCCodeList.Add(new StateModel { StateIndex = 145, StateName = "5933 - Pawn Shops" });
            MCCCodeList.Add(new StateModel { StateIndex = 146, StateName = "5935 - Salvage and Wrecking Yards" });
            MCCCodeList.Add(new StateModel { StateIndex = 147, StateName = "5937 - Antique Reproduction Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 148, StateName = "5940 - Bicycle Shops-Sales and Service" });
            MCCCodeList.Add(new StateModel { StateIndex = 149, StateName = "5942 - Book Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 150, StateName = "5943 - Office, School Supply, and Stationery Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 151, StateName = "5944 - Clock, Jewelry, Watch, and Silverware Store" });
            MCCCodeList.Add(new StateModel { StateIndex = 152, StateName = "5945 - Game, Toy, and Hobby Shops" });
            MCCCodeList.Add(new StateModel { StateIndex = 153, StateName = "5946 - Camera and Photographic Supply Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 154, StateName = "5948 - Leather Goods and Luggage Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 155, StateName = "5949 - Fabric, Needlework, Piece Goods, and Sewing Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 156, StateName = "5950 - Crystal and Glassware Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 157, StateName = "5960 - Direct Marketing-Insurance Services" });
            MCCCodeList.Add(new StateModel { StateIndex = 158, StateName = "5962 - Direct Marketing-Travel-Related Arrangement Services" });
            MCCCodeList.Add(new StateModel { StateIndex = 159, StateName = "5963 - Door-to-Door Sales" });
            MCCCodeList.Add(new StateModel { StateIndex = 160, StateName = "5964 - Direct Marketing-Catalog Merchants" });
            MCCCodeList.Add(new StateModel { StateIndex = 161, StateName = "5965 - Direct Marketing-Combination Catalog and Retail Merchants" });
            MCCCodeList.Add(new StateModel { StateIndex = 162, StateName = "5966 - Direct Marketing-Outbound Telemarketing Merchants" });
            MCCCodeList.Add(new StateModel { StateIndex = 163, StateName = "5967 - Direct Marketing-Inbound Telemarketing Merchants" });
            MCCCodeList.Add(new StateModel { StateIndex = 164, StateName = "5968 - Direct Marketing-Continuity/Subscription Merchants" });
            MCCCodeList.Add(new StateModel { StateIndex = 165, StateName = "5969 - Direct Marketing-Other Direct Marketers-not elsewhere classified" });
            MCCCodeList.Add(new StateModel { StateIndex = 166, StateName = "5970 - Artist Supply Stores, Craft Shops" });
            MCCCodeList.Add(new StateModel { StateIndex = 167, StateName = "5971 - Art Dealers and Galleries" });
            MCCCodeList.Add(new StateModel { StateIndex = 168, StateName = "5972 - Stamp and Coin Stores-Philatelic and Numismatic Supplies" });
            MCCCodeList.Add(new StateModel { StateIndex = 169, StateName = "5973 - Religious Goods Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 170, StateName = "5975 - Hearing Aids-Sales, Service, Supply Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 171, StateName = "5976 - Orthopedic Goods-Artificial Limb Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 172, StateName = "5977 - Cosmetic Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 173, StateName = "5978 - Typewriter Stores-Rentals, Sales, Service" });
            MCCCodeList.Add(new StateModel { StateIndex = 174, StateName = "5983 - Fuel Dealers-Coal, Fuel Oil, Liquefied Petroleum, Wood" });
            MCCCodeList.Add(new StateModel { StateIndex = 175, StateName = "5992 - Florists" });
            MCCCodeList.Add(new StateModel { StateIndex = 176, StateName = "5994 - News Dealers and Newsstands" });
            MCCCodeList.Add(new StateModel { StateIndex = 177, StateName = "5995 - Pet Shops-Pet Food and Supplies" });
            MCCCodeList.Add(new StateModel { StateIndex = 178, StateName = "5996 - Swimming Pools-Sales and Supplies" });
            MCCCodeList.Add(new StateModel { StateIndex = 179, StateName = "5997 - Electric Razor Stores-Sales and Service" });
            MCCCodeList.Add(new StateModel { StateIndex = 180, StateName = "5998 - Tent and Awning Shops" });
            MCCCodeList.Add(new StateModel { StateIndex = 181, StateName = "6010 - Manual Cash Disbursements-Customer Financial lnstitution" });
            MCCCodeList.Add(new StateModel { StateIndex = 182, StateName = "6011 - Automated Cash Disbursements-Customer Financial Institution" });
            MCCCodeList.Add(new StateModel { StateIndex = 183, StateName = "6012 - Merchandise and Services-Customer Financial Institution" });
            MCCCodeList.Add(new StateModel { StateIndex = 184, StateName = "6050 - Quasi Cash-Customer Financial Institution" });
            MCCCodeList.Add(new StateModel { StateIndex = 185, StateName = "6051 - Quasi Cash-Merchant" });
            MCCCodeList.Add(new StateModel { StateIndex = 186, StateName = "6211 - Securities-Brokers/Dealers" });
            MCCCodeList.Add(new StateModel { StateIndex = 187, StateName = "6300 - lnsurance Sales, Underwriting, and Premiums" });
            MCCCodeList.Add(new StateModel { StateIndex = 188, StateName = "6513 - Real Estate Agents and Managers-Rentals" });
            MCCCodeList.Add(new StateModel { StateIndex = 189, StateName = "6532 - Payment Transaction-Customer Financial Institution" });
            MCCCodeList.Add(new StateModel { StateIndex = 190, StateName = "6533 - Payment Transaction-Merchant" });
            MCCCodeList.Add(new StateModel { StateIndex = 191, StateName = "6536 - MoneySend lntracountry" });
            MCCCodeList.Add(new StateModel { StateIndex = 192, StateName = "6537 - MoneySend lntercountry" });
            MCCCodeList.Add(new StateModel { StateIndex = 193, StateName = "6538 - MoneySend Funding" });
            MCCCodeList.Add(new StateModel { StateIndex = 194, StateName = "6540 - POI Funding Transactions (Excluding MoneySend)" });
            MCCCodeList.Add(new StateModel { StateIndex = 195, StateName = "7011 - Lodging-Hotels, Motels, Resorts-not elsewhere classified" });
            MCCCodeList.Add(new StateModel { StateIndex = 196, StateName = "7012 - Timeshares" });
            MCCCodeList.Add(new StateModel { StateIndex = 197, StateName = "7032 - Recreational and Sporting Camps" });
            MCCCodeList.Add(new StateModel { StateIndex = 198, StateName = "7033 - Campgrounds and Trailer Parks" });
            MCCCodeList.Add(new StateModel { StateIndex = 199, StateName = "7210 - Cleaning, Garment, and Laundry Services" });
            MCCCodeList.Add(new StateModel { StateIndex = 200, StateName = "7211 - Laundry Services-Family and Commercial" });
            MCCCodeList.Add(new StateModel { StateIndex = 201, StateName = "7216 - Dry Cleaners" });
            MCCCodeList.Add(new StateModel { StateIndex = 202, StateName = "7217 - Carpet and Upholstery Cleaning" });
            MCCCodeList.Add(new StateModel { StateIndex = 203, StateName = "7221 - Photographic Studios" });
            MCCCodeList.Add(new StateModel { StateIndex = 204, StateName = "7251 - Hat Cleaning Shops, Shoe Repair Shops, Shoe Shine Parlors" });
            MCCCodeList.Add(new StateModel { StateIndex = 205, StateName = "7261 - Funeral Service and Crematories" });
            MCCCodeList.Add(new StateModel { StateIndex = 206, StateName = "7273 - Dating Services" });
            MCCCodeList.Add(new StateModel { StateIndex = 207, StateName = "7276 - Tax Preparation Service" });
            MCCCodeList.Add(new StateModel { StateIndex = 208, StateName = "7277 - Debt, Marriage, Personal-Counseling Service" });
            MCCCodeList.Add(new StateModel { StateIndex = 209, StateName = "7278 - Buying/Shopping Clubs, Services" });
            MCCCodeList.Add(new StateModel { StateIndex = 210, StateName = "7296 - Clothing Rental-Costumes, Uniforms, and Formal Wear" });
            MCCCodeList.Add(new StateModel { StateIndex = 211, StateName = "7297 - Massage Parlors" });
            MCCCodeList.Add(new StateModel { StateIndex = 212, StateName = "7298 - Health and Beauty Spas" });
            MCCCodeList.Add(new StateModel { StateIndex = 213, StateName = "7311 - Advertising Services" });
            MCCCodeList.Add(new StateModel { StateIndex = 214, StateName = "7321 - Consumer Credit Reporting Agencies" });
            MCCCodeList.Add(new StateModel { StateIndex = 215, StateName = "7333 - Commercial Art, Graphics, Photography" });
            MCCCodeList.Add(new StateModel { StateIndex = 216, StateName = "7338 - Quick Copy, Reproduction, and Blueprinting Services" });
            MCCCodeList.Add(new StateModel { StateIndex = 217, StateName = "7339 - Stenographic and Secretarial Support Services" });
            MCCCodeList.Add(new StateModel { StateIndex = 218, StateName = "7342 - Exterminating and Disinfecting Services" });
            MCCCodeList.Add(new StateModel { StateIndex = 219, StateName = "7349 - Cleaning and Maintenance, Janitorial Services" });
            MCCCodeList.Add(new StateModel { StateIndex = 220, StateName = "7361 - Employment Agencies, Temporary Help Services" });
            MCCCodeList.Add(new StateModel { StateIndex = 221, StateName = "7372 - Computer Programming, Data Processing, and Integrated Systems Design Services" });
            MCCCodeList.Add(new StateModel { StateIndex = 222, StateName = "7375 - lnformation Retrieval Services" });
            MCCCodeList.Add(new StateModel { StateIndex = 223, StateName = "7379 - Computer Maintenance, Repair, and Services not elsewhere classified" });
            MCCCodeList.Add(new StateModel { StateIndex = 224, StateName = "7392 - Consulting, Management, and Public Relations Services" });
            MCCCodeList.Add(new StateModel { StateIndex = 225, StateName = "7393 - Detective Agencies, Security Services including Armored Cars, Guard Dogs" });
            MCCCodeList.Add(new StateModel { StateIndex = 226, StateName = "7394 - Equipment Rental and Leasing Services, Furniture Rental, Tool Rental" });
            MCCCodeList.Add(new StateModel { StateIndex = 227, StateName = "7395 - Photo Developing, Photofinishing Laboratories" });
            MCCCodeList.Add(new StateModel { StateIndex = 228, StateName = "7512 - Automobile Rental Agency not elsewhere classified" });
            MCCCodeList.Add(new StateModel { StateIndex = 229, StateName = "7513 - Truck Rental." });
            MCCCodeList.Add(new StateModel { StateIndex = 230, StateName = "7519 - Motor Home and Recreational Vehicle Rental" });
            MCCCodeList.Add(new StateModel { StateIndex = 231, StateName = "7523 - Automobile Parking Lots and Garages" });
            MCCCodeList.Add(new StateModel { StateIndex = 232, StateName = "7534 - Tire Retreading and Repair Shops" });
            MCCCodeList.Add(new StateModel { StateIndex = 233, StateName = "7535 - Automotive Paint Shops" });
            MCCCodeList.Add(new StateModel { StateIndex = 234, StateName = "7542 - Car Washes" });
            MCCCodeList.Add(new StateModel { StateIndex = 235, StateName = "7549 - Towing Services" });
            MCCCodeList.Add(new StateModel { StateIndex = 236, StateName = "7622 - Electronic Repair Shops" });
            MCCCodeList.Add(new StateModel { StateIndex = 237, StateName = "7623 - Air Conditioning and Refrigeration Repair Shops" });
            MCCCodeList.Add(new StateModel { StateIndex = 238, StateName = "7629 - Appliance Repair Shops, Electrical and Small" });
            MCCCodeList.Add(new StateModel { StateIndex = 239, StateName = "7631 - Clock, Jewelry, and Watch Repair Shops" });
            MCCCodeList.Add(new StateModel { StateIndex = 240, StateName = "7641 - Furniture-Reupholstery and Repair, Refinishing" });
            MCCCodeList.Add(new StateModel { StateIndex = 241, StateName = "7692 - Welding Repair" });
            MCCCodeList.Add(new StateModel { StateIndex = 242, StateName = "7699 - Miscellaneous Repair Shops and Related Services" });
            MCCCodeList.Add(new StateModel { StateIndex = 243, StateName = "7800 - Government Owned Lottery (U.S. Region Only)" });
            MCCCodeList.Add(new StateModel { StateIndex = 244, StateName = "7801 - lnternet Gambling (U.S. Region Only)" });
            MCCCodeList.Add(new StateModel { StateIndex = 245, StateName = "7802 - Government Licensed Horse/Dog Racing (U.S. Region Only)" });
            MCCCodeList.Add(new StateModel { StateIndex = 246, StateName = "7829 - Motion Picture and Video Tape Production and Distribution" });
            MCCCodeList.Add(new StateModel { StateIndex = 247, StateName = "7832 - Motion Picture Theaters" });
            MCCCodeList.Add(new StateModel { StateIndex = 248, StateName = "7841 - Video Entertainment Rental Stores" });
            MCCCodeList.Add(new StateModel { StateIndex = 249, StateName = "7911 - Dance Halls, Schools, and Studios" });
            MCCCodeList.Add(new StateModel { StateIndex = 250, StateName = "7922 - Theatrical Producers (except Motion Pictures), Ticket Agencies" });
            MCCCodeList.Add(new StateModel { StateIndex = 251, StateName = "7929 - Bands, Orchestras, and Miscellaneous Entertainers not elsewhere classified" });
            MCCCodeList.Add(new StateModel { StateIndex = 252, StateName = "7932 - Pool and Billiard Establishments" });
            MCCCodeList.Add(new StateModel { StateIndex = 253, StateName = "7933 - Bowling Alleys" });
            MCCCodeList.Add(new StateModel { StateIndex = 254, StateName = "7941 - Athletic Fields, Commercial Sports, Professional Sports Clubs, Sports Promoters" });
            MCCCodeList.Add(new StateModel { StateIndex = 255, StateName = "7991 - Tourist Attractions and Exhibits" });
            MCCCodeList.Add(new StateModel { StateIndex = 256, StateName = "7992 - Golf Courses, Public." });
            MCCCodeList.Add(new StateModel { StateIndex = 257, StateName = "7993 - Video Amusement Game Supplies" });
            MCCCodeList.Add(new StateModel { StateIndex = 258, StateName = "7994 - Video Game Arcades/Establishments" });
            MCCCodeList.Add(new StateModel { StateIndex = 259, StateName = "7995 - Gambling Transactions" });
            MCCCodeList.Add(new StateModel { StateIndex = 260, StateName = "7996 - Amusement Parks, Carnivals, Circuses, Fortune Tellers" });
            MCCCodeList.Add(new StateModel { StateIndex = 261, StateName = "7997 - Clubs-Country Clubs, Membership (Athletic, Recreation, Sports), Private Golf Courses" });
            MCCCodeList.Add(new StateModel { StateIndex = 262, StateName = "7998 - Aquariums, Dolphinariums, Zoos, and Seaquariums" });
            MCCCodeList.Add(new StateModel { StateIndex = 263, StateName = "8011 - Doctors not elsewhere classified" });
            MCCCodeList.Add(new StateModel { StateIndex = 264, StateName = "8021 - Dentists, Orthodontists" });
            MCCCodeList.Add(new StateModel { StateIndex = 265, StateName = "8031 - Osteopathic Physicians" });
            MCCCodeList.Add(new StateModel { StateIndex = 266, StateName = "8041 - Chiropractors" });
            MCCCodeList.Add(new StateModel { StateIndex = 267, StateName = "8042 - Optometrists, Ophthalmologists" });
            MCCCodeList.Add(new StateModel { StateIndex = 268, StateName = "8043 - Opticians, Optical Goods, and Eyeglasses" });
            MCCCodeList.Add(new StateModel { StateIndex = 269, StateName = "8049 - Chiropodists, Podiatrists" });
            MCCCodeList.Add(new StateModel { StateIndex = 270, StateName = "8050 - Nursing and Personal Care Facilities" });
            MCCCodeList.Add(new StateModel { StateIndex = 271, StateName = "8062 - Hospitals" });
            MCCCodeList.Add(new StateModel { StateIndex = 272, StateName = "8071 - Dental and Medical Laboratories" });
            MCCCodeList.Add(new StateModel { StateIndex = 273, StateName = "8211 - Schools, Elementary and Secondary" });
            MCCCodeList.Add(new StateModel { StateIndex = 274, StateName = "8220 - Colleges, Universities, Professional Schools, and Junior Colleges" });
            MCCCodeList.Add(new StateModel { StateIndex = 275, StateName = "8241 - Schools, Correspondence" });
            MCCCodeList.Add(new StateModel { StateIndex = 276, StateName = "8244 - Schools, Business and Secretarial" });
            MCCCodeList.Add(new StateModel { StateIndex = 277, StateName = "8249 - Schools, Trade and Vocational" });
            MCCCodeList.Add(new StateModel { StateIndex = 278, StateName = "8351 - Child Care Services" });
            MCCCodeList.Add(new StateModel { StateIndex = 279, StateName = "8398 - Organizations, Charitable and Social Service" });
            MCCCodeList.Add(new StateModel { StateIndex = 280, StateName = "8641 - Associations-Civic, Social, and Fraternal" });
            MCCCodeList.Add(new StateModel { StateIndex = 281, StateName = "8651 - Organizations, Political" });
            MCCCodeList.Add(new StateModel { StateIndex = 282, StateName = "8661 - Organizations, Religious" });
            MCCCodeList.Add(new StateModel { StateIndex = 283, StateName = "8675 - Automobile Associations" });
            MCCCodeList.Add(new StateModel { StateIndex = 284, StateName = "8699 - Organizations, Membership not elsewhere classified" });
            MCCCodeList.Add(new StateModel { StateIndex = 285, StateName = "8734 - Testing Laboratories (Non-Medical)" });
            MCCCodeList.Add(new StateModel { StateIndex = 286, StateName = "8911 - Architectural, Engineering, and Surveying Services" });
            MCCCodeList.Add(new StateModel { StateIndex = 287, StateName = "8931 - Accounting, Auditing, and Bookkeeping Services" });
            MCCCodeList.Add(new StateModel { StateIndex = 288, StateName = "8999 - Professional Services not elsewhere classified" });
            MCCCodeList.Add(new StateModel { StateIndex = 289, StateName = "9211 - Court Costs including Alimony and Child Support." });
            MCCCodeList.Add(new StateModel { StateIndex = 290, StateName = "9222 - Fines" });
            MCCCodeList.Add(new StateModel { StateIndex = 291, StateName = "9223 - Bail and Bond Payments" });
            MCCCodeList.Add(new StateModel { StateIndex = 292, StateName = "9311 - Tax Payments" });
            MCCCodeList.Add(new StateModel { StateIndex = 293, StateName = "9399 - Government Services not elsewhere classified" });
            MCCCodeList.Add(new StateModel { StateIndex = 294, StateName = "9402 - Postal Services-Government Only" });
            MCCCodeList.Add(new StateModel { StateIndex = 295, StateName = "9405 - lntra-Government Purchases-Government Only" });
            MCCCodeList.Add(new StateModel { StateIndex = 296, StateName = "9406 - Government-owned Lottery (Specific Countries)" });


            #endregion
        }
        public string CustomerEmail { get; set; }
        public string ContactName { get; set; }
        public string TelePhoneNumber { get; set; }
        public string MerchantId { get; set; }
        public string MerchantUri { get; set; }
        public string BankUri { get; set; }
        public string BankName { get; set; }
        public string LocationAddress { get; set; }
        public string City { get; set; }
        public string Zip { get; set; }
        public string LocationAddress2 { get; set; }
        public string City2 { get; set; }
        public string Zip2 { get; set; }
        public int SelectedState1 { get; set; }
        public int SelectedState2 { get; set; }
        public int SelectedState3 { get; set; }
        public int SelectedState4 { get; set; }

        public int SelectedState5 { get; set; }
        public int MCCCode { get; set; }
        public string FileName { get; set; }
        public string FileBase64 { get; set; }
        public string FileName2 { get; set; }
        public string FileBase642 { get; set; }
        public string FileName3 { get; set; }
        public string FileBase643 { get; set; }
        public string FileName4 { get; set; }
        public string FileBase644 { get; set; }
        public string FileName5 { get; set; }
        public string FileBase645 { get; set; }
        public string FileName6 { get; set; }
        public string FileBase646 { get; set; }
        public string FileName7 { get; set; }
        public string FileBase647 { get; set; }
        public string FileName8 { get; set; }
        public string FileBase648 { get; set; }
        public string FileName9 { get; set; }
        public string FileBase649 { get; set; }

        public List<StateModel> StateList { get; set; }
        public List<StateModel> MCCCodeList { get; set; }

        public string DocusignUrl { get; set; }
    }

    public class StateModel
    {
        public string StateName { get; set; }
        public int StateIndex { get; set; }
    }

    public class FormSteps
    {
        public string FormsCompleted { get; set; }
        public string CurrentForm { get; set; }
        public string MerchantDocusignSigned { get; set; }
    }

    public class NoteEntityModel
    {
        public string notetext { get; set; }
        public string subject { get; set; }
        public string filename { get; set; }
        public string mimetype { get; set; }
        public string documentbody { get; set; }
        public string documentbodybase64 { get; set; }
        public string LookupEntity { get; set; }
        public string entityId { get; set; }
    }

    #region Merchant Information
    public class MerchantInformationModel : BaseInformationModel
    {
        public string FaxNumber { get; set; }
        public string MerchantName { get; set; }
        public bool IsMoreLocation { get; set; }
        public string CellPhone { get; set; }
    }

    public class LegalInformationModel : BaseInformationModel
    {
        public string LegalName { get; set; }
        [Required(ErrorMessage = "Required")]
        public bool IsTaxId { get; set; } // if true then "Tax Id" else "SSN"
        public string TaxOrSsn { get; set; }
        [Required(ErrorMessage = "Required")]
        public bool IsMailingAddressSame { get; set; }
        public string MailLocationAddress { get; set; }
        public string MailCity { get; set; }
        public string MailZip { get; set; }
    }

    public class BusinessInformationModel : BaseInformationModel
    {
        [Required(ErrorMessage = "Required")]
        public bool IsPaymentCard { get; set; }
        public string PaymentCard { get; set; }
        [Required(ErrorMessage = "Required")]
        public bool IsTerminated { get; set; }
        public string AcceptCardExplanation { get; set; }
        [Required(ErrorMessage = "Required")]
        public bool IsSecurityBranch { get; set; }
        public string SecurityBranchExplanation { get; set; }
        public string LatestProofOfPCIDDSComplianceFile { get; set; }

        [Required(ErrorMessage = "Required")]
        public int TypeOfBusiness { get; set; } // Use Enum for type of business later on
        public string LLCCity { get; set; }
        public string NonProfitFile { get; set; }

        public int BusinessYears { get; set; }
        public int BusinessMonths { get; set; }

        public int new_numberoflocations { get; set; }
        public string new_customerserviceno { get; set; }

    }

    public class BusinessInformation2Model : BaseInformationModel
    {
        public BusinessInformation2Model()
        {
            VolumeMonths = new List<bool>();
            for (int i = 1; i <= 12; i++)
            {
                VolumeMonths.Add(false);
            }
            MerchantUse = new List<bool>();
            for (int i = 1; i <= 2; i++)
            {
                MerchantUse.Add(false);
            }
            MethodOfAcceptance = new List<bool>();
            for (int i = 1; i <= 4; i++)
            {
                MethodOfAcceptance.Add(false);
            }
        }
        [Required(ErrorMessage = "Required")]
        public int NatureOfBusiness { get; set; } //new_natureofbusinesscsv -> 1 - 14
        public string Other { get; set; }
        public string InternetUrl { get; set; } // show if NatureOfBusiness = 3, Internet
        [Required(ErrorMessage = "Required")]
        public bool IsSeasonalSales { get; set; }
        public List<bool> VolumeMonths { get; set; }// new_pleaseselecthighvolumemonthscsv -> Month wise
        public string ProductsOrServices { get; set; }
        public List<bool> MerchantUse { get; set; } // if 2 then "Software", 1 "Terminal"
        public string TerminalType { get; set; } // if "Terminal"
        public string PaymentApplicationName { get; set; } // if "Software"
        public string PaymentApplicationVersion { get; set; } // if "Software"
        [Required(ErrorMessage = "Required")]
        public bool MerchantNameAppear { get; set; } // if false then "DBA Name" else "Legal Name"
        public List<bool> MethodOfAcceptance { get; set; } // new_methodofacceptancetotalstoequal100csv -> 1 - Card Swipe,2 - MO/TO %, 3 - Key Entered %, 4 - Internet %
        public string CardSwipevalue { get; set; }
        public string KeyEntervalue { get; set; }
        public string Motovalue { get; set; }
        public string Internetvalue { get; set; }
        public string new_cardsnotaccept { get; set; }

        public string new_websiteaddress { get; set; }

    }

    public class QuestionnaireModel : BaseInformationModel
    {
        public QuestionnaireModel()
        {
            DoYouSell1 = new List<bool>();
            for (int i = 1; i <= 2; i++)
            {
                DoYouSell1.Add(false);
            }
            PercentageOfSale = new List<bool>();
            for (int i = 1; i <= 4; i++)
            {
                PercentageOfSale.Add(false);
            }
            DoYouSell2 = new List<bool>();
            for (int i = 1; i <= 2; i++)
            {
                DoYouSell2.Add(false);
            }
            Advertise = new List<bool>();
            for (int i = 1; i <= 5; i++)
            {
                Advertise.Add(false);
            }
        }
        public string BusinessPercentage { get; set; } // decimal for %, need to make decimal in CRM
        public string PublicPercentage { get; set; } // decimal for %, need to make decimal in CRM
        [Required(ErrorMessage = "Required")]
        public bool IsRetailLocation { get; set; }
        public List<bool> DoYouSell1 { get; set; }// new_doyousellaserviceorproductscsv -> S,P
        public string DecribeProduct { get; set; }
        public List<bool> PercentageOfSale { get; set; } // new_whatpercentageofsaleswillbefromcsv -> M,T,I,C
        public string MailValue { get; set; }
        public string InternetValue { get; set; }
        public string TelephoneValue { get; set; }
        public string CardPresentValue { get; set; }

        public string PhysicalAddress { get; set; }
        public string PhysicalCity { get; set; }
        public string PhysicalZip { get; set; }
        [Required(ErrorMessage = "Required")]
        public bool IsProductAddress { get; set; }
        public string ProductAddress { get; set; }
        public string ProductCity { get; set; }
        public string ProductZip { get; set; }
        [Required(ErrorMessage = "Required")]
        public bool IsOwnProduct { get; set; }
        public List<bool> DoYouSell2 { get; set; }// new_doyousellcheckallthatapplycsv -> L,N
        public string CardBrandProcessor { get; set; }
        public int ChargeBacks { get; set; }
        public string ChargeBackAmount { get; set; } // price in dollar $ amount
        [Required(ErrorMessage = "Required")]
        public int WhenCharged { get; set; } // if 0 then "Time of Order", if 1 then "Upon Shipment"...................
        [Required(ErrorMessage = "Required")]
        public int DeliverDays { get; set; } // 0 -> "1-7 days", 1 -> "8-14 Days" and 2 -> 14+ Days
        [Required(ErrorMessage = "Required")]
        public bool IsOtherCompany { get; set; }
        public string CompanyName { get; set; }
        public string CompanyTelephone { get; set; }
        public string CompanyAddress { get; set; }
        public List<bool> Advertise { get; set; }// new_howdoyouadvertisecsv -> C,M,T,I,O
        public string RefundPolicy { get; set; }
        public bool IsAllowForm { get; set; }

        public string new_thirdpartycardholderdata { get; set; }
    }

    public class Questionnaire2Model : BaseInformationModel
    {
        public Questionnaire2Model()
        {
            MethodOfMarketing = new List<bool>();
            for (int i = 1; i <= 6; i++)
            {
                MethodOfMarketing.Add(false);
            }
            PercentageOfProducts = new List<bool>();
            for (int i = 1; i <= 4; i++)
            {
                PercentageOfProducts.Add(false);
            }
            WhoProcessOrder = new List<bool>();
            for (int i = 1; i <= 3; i++)
            {
                WhoProcessOrder.Add(false);
            }
            WhoEnterCreditCard = new List<bool>();
            for (int i = 1; i <= 4; i++)
            {
                WhoEnterCreditCard.Add(false);
            }
        }
        public string BusinessPercentage { get; set; }
        public string IndividualPercentage { get; set; }
        public List<bool> MethodOfMarketing { get; set; }// new_methodofmarketingcsv -> n,t,i,d,o,other
        public string MethodOfMarketingOther { get; set; }
        public List<bool> PercentageOfProducts { get; set; }// new_percentageofproductssoldviacsv -> m,t,i,o
        public string MailFaxValue { get; set; }
        public string TelephoneOrderValue { get; set; }
        public string InternetOrderValue { get; set; }
        public string OtherValue { get; set; }
        public List<bool> WhoProcessOrder { get; set; }// new_whoprocessestheordercsv -> m,f,o
        public string WhoProcessOrderOther { get; set; }
        public List<bool> WhoEnterCreditCard { get; set; }// new_whoenterscreditcardinformationintothecsv -> m,f,c,o
        public string WhoEnterCreditCardOther { get; set; }
        [Required(ErrorMessage = "Required")]
        public bool IsCreditCardPayment { get; set; }
        public string MerchantCertiNumber { get; set; }
        public string Issuer { get; set; }
        public string ExpDate { get; set; }
        [Required(ErrorMessage = "Required")]
        public bool IsProduct { get; set; }
        [Required(ErrorMessage = "Required")]
        public bool IsProductLocationSame { get; set; }
        public string ProductLocation { get; set; }
        public int ProductShipDays { get; set; }
        [Required(ErrorMessage = "Required")]
        public int WhoShipProduct { get; set; } // 0 - Merchant, 1- Fullfillment Center
        [Required(ErrorMessage = "Required")]
        public int ProductShippedBy { get; set; } // 0 - U.S. Mail , 1 - Other
        public string OtherShippedBy { get; set; }
        [Required(ErrorMessage = "Required")]
        public bool IsDeliveryReceipt { get; set; }
        public bool IsAllowForm { get; set; }
    }

    public class ProcessingDetailsModel : BaseInformationModel
    {
        public ProcessingDetailsModel()
        {
            new_havemerchantbankruptcycsv = new List<bool>();
            for (int i = 1; i <= 3; i++)
            {
                new_havemerchantbankruptcycsv.Add(false);
            }
        }
        // For Visa/MasterCard/DIscover
        public string PaymentCardMonthly { get; set; } // $ amount        
        public string AvgTicket { get; set; }// $ amount
        public string HighestTicket { get; set; }// $ amount

        // For Amex
        public string AmericanExpressMonthly { get; set; } // $ amount        
        public string new_avgticketae { get; set; }// $ amount
        public string new_maxticketae { get; set; }// $ amount

        [Required(ErrorMessage = "Required")]
        public bool IsServicer { get; set; }
        public string ServicerName { get; set; }
        public string ServicerContactNumber { get; set; }
        [Required(ErrorMessage = "Required")]
        public bool IsFulfillmentHouse { get; set; }
        public string HouseName { get; set; }
        public string HouseContactNumber { get; set; }
        [Required(ErrorMessage = "Required")]
        public bool IsBankruptcy { get; set; }
        public string BankruptcyExplain { get; set; }
        [Required(ErrorMessage = "Required")]
        public bool IsSeasonalMerchant { get; set; }
        public int MonthsSeason { get; set; }
        public List<bool> new_havemerchantbankruptcycsv { get; set; }
    }

    public class BaseOwnershipInformation : BaseInformationModel
    {
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Title { get; set; }
        public string SSN { get; set; }
        public string OwnershipPercent { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string DateOfBirthString { get; set; }
        public string HomePhone { get; set; }
        public string EmailAddress { get; set; }
        public int DLState { get; set; }
        [Required(ErrorMessage = "Required")]
        public bool ControllingInterest { get; set; }
        public string DrivingLicenseNumber { get; set; }
        public DateTime DrivingLicenseExpDate { get; set; }
        public string DrivingLicenseExpDateString { get; set; }

    }
    public class OwnershipInformation : BaseInformationModel
    {
        public OwnershipInformation()
        {
            Owner1 = new BaseOwnershipInformation();
            Owner2 = new BaseOwnershipInformation();
            Owner3 = new BaseOwnershipInformation();
            Owner4 = new BaseOwnershipInformation();
            ControllingOwner = new BaseOwnershipInformation();
        }
        public BaseOwnershipInformation Owner1 { get; set; }
        public BaseOwnershipInformation Owner2 { get; set; }
        public BaseOwnershipInformation Owner3 { get; set; }
        public BaseOwnershipInformation Owner4 { get; set; }
        public BaseOwnershipInformation ControllingOwner { get; set; }
        public bool IsOwner2 { get; set; }
        public bool IsOwner3 { get; set; }
        public bool IsOwner4 { get; set; }
        public string Owner1BirthDate { get; set; }
    }

    public class SiteInspectionModel : BaseInformationModel
    {
        public bool OperateBusiness { get; set; } // new_baseduponisosreviewdoesmerchanthavetheap
        public string Comment { get; set; } // new_comment
        public string InspectorName { get; set; }// new_inspectorname
        public DateTime InspectorDate { get; set; } // new_inspectiondate
        public string InspectorDateString { get; set; }
    }

    public class EquipmentInformationModel : BaseInformationModel
    {
        public EquipmentInformationModel()
        {
            new_primarycommunicationtypecsv = new List<bool>();
            for (int i = 1; i <= 4; i++)
            {
                new_primarycommunicationtypecsv.Add(false);
            }
            new_merchantprogramtypecsv = new List<bool>();
            for (int i = 1; i <= 8; i++)
            {
                new_merchantprogramtypecsv.Add(false);
            }
        }


        //PRIMARY COMMUNICATION TYPE
        //new_primarycommunicationtypecsv - checkbox
        public List<bool> new_primarycommunicationtypecsv { get; set; }

        //GATEWAY
        //new_gateway - radio ->  0 -> SecurePay
        [Required(ErrorMessage = "Required")]
        public bool new_gateway { get; set; }
        //GATEWAY NAME
        //new_gatewayname1
        public string new_gatewayname1 { get; set; }
        //GATEWAY VERSION
        //new_gatewayversion
        public string new_gatewayversion { get; set; }

        //MERCHANT PROGRAM TYPE - checkbox -> ret - 1, i - 2, tip, res, MO, Tip, Lod, Other
        //new_merchantprogramtypecsv
        public List<bool> new_merchantprogramtypecsv { get; set; }
        //OTHER(EBT,ETC)
        //new_otherebtetc
        public string new_otherebtetc { get; set; }

        //PC SOFTWARE NAME
        //new_pcsoftwarename
        public string new_pcsoftwarename { get; set; }
        //VERSION
        //new_softwareversion
        public string new_softwareversion { get; set; }
        //QIR CERTIFIER FIRST & LAST NAME
        //new_qircertifierfirstlastname
        public string new_qircertifierfirstlastname { get; set; }

        //BATCH OPTIONS - radio -> 0- Auto Batch Time
        //new_batchoptions
        [Required(ErrorMessage = "Required")]
        public bool new_batchoptions { get; set; }
        //Auto Batch Time
        //new_autobatchtime
        public string new_autobatchtime { get; set; }
        //Manual Batch Time
        //new_manualbatchtime
        public string new_manualbatchtime { get; set; }

    }
    #endregion

    #region Bank Information
    public class BankDisclosureModel : BaseInformationModel
    {
        public string Description { get; set; }
    }
    public class BankingInformationModel : BaseInformationModel
    {
        public string AccountBankName { get; set; } // update to Merchant Info -> new_bankname
        public string Transit { get; set; }// update to Merchant Info -> new_transitabarouting
        public string Account { get; set; } // update to Merchant Info -> new_accountdda
        public string AccountContact { get; set; } // update to Merchant Info -> new_contact
        public string AccountPhone { get; set; } // update to Merchant Info -> new_phone
        public string GuarantorDescription { get; set; } // get from bank template -> HTML -> new_continuingpersonalguarantyprovision
        public string Owner1Name { get; set; } // get from Merchant Info -> OwnershipInformation - Owner 1 title,Firstname,Middle name,Lastname
        public string Owner2Name { get; set; } // get from Merchant Info ->  OwnershipInformation - Owner 2 title,Firstname,Middle name,Lastname
    }
    public class ImportantInformationModel : BaseInformationModel
    {
        public string NewAccountDescription { get; set; } // get from bank template -> HTML -> new_merchantapplicationandagreementacceptance
        public string CertificationDescription { get; set; } // get from bank template -> HTML -> new_certificationofbeneficialowners
        public string Owner1Name { get; set; }
        public string Owner2Name { get; set; }
        public bool new_importantinformationcheck { get; set; }

        #region Merchant Fees fields
        public string new_visamcdistiered1 { get; set; }
        public string new_visamcdispassthru1 { get; set; }
        public string new_visamcdistiered2 { get; set; }
        public string new_visamcdispassthru2 { get; set; }
        public string new_authfee { get; set; }
        public string new_monthlymanagfee { get; set; }
        public string new_onlineservicefee { get; set; }
        public string MonthlyMinimum { get; set; }
        public string AnualFee { get; set; }
        public string PinDebitFee { get; set; }
        public string BatchFee { get; set; }
        public string ChargebackPer { get; set; }
        public string PerAchRejectFee { get; set; }
        public string ChargebackRetrieval { get; set; }
        public string VoicePerAuthFee { get; set; }
        public string new_passthrufee { get; set; }
        public string new_opvoiceperauthfee { get; set; }
        public string new_transfee { get; set; }
        public string AvsFee { get; set; }
        public string EarlyTerminationFee { get; set; }
        public string new_ebttransfee { get; set; }
        public string new_ebtstatementfee { get; set; }
        public string new_otherfee { get; set; }
        public string new_visamcdisaxpmidqual { get; set; }
        public string new_visamcdisaxpnonqual { get; set; }
        public string NonEmvCompliance { get; set; }
        public string new_tinmismatchfee { get; set; }
        public string MonthlyPciFee { get; set; }
        public string NonPciComplianceFee { get; set; }
        public string new_axppassthruicplus { get; set; }

        public string new_achservicefees { get; set; }
        public string new_achsetupfees { get; set; }
        public string new_achmonthlyfees { get; set; }
        public string new_achdiscountrate { get; set; }
        public string new_achperitem { get; set; }
        public string new_achreturnfee { get; set; }
        public string new_achstoppaymentcustomercancelationfee { get; set; }

        #endregion
    }
    public class RatesFeesModel : BaseInformationModel
    {
        public string MonthlyMinimum { get; set; }// new_monthlyminimum
        public string MonthlyPciFee { get; set; }// new_monthlypcifee
        public string TransactionFee { get; set; }// new_visamcdiscovertransactionfee
        public string MonthlyCustomerSvsFee { get; set; }// new_monthlycustomersvsfee
        public string NonPciComplianceFee { get; set; } // new_nonpcicompliancefee
        public string AmexFee { get; set; }// new_amextransactionfee
        public string RegulatoryFee { get; set; }// new_irsregulatoryfee
        public string PinDebitFee { get; set; }// new_pindebittransactionfee
        public string AnualFee { get; set; }// new_annualfee
        public string NonEmvCompliance { get; set; }// new_nonemvcompliance
        public string VoicePerAuthFee { get; set; }// new_voiceperauthfee
        public string MerchantReporting { get; set; }// new_merchantonlineportalreporting
        public string EarlyTerminationFee { get; set; }// new_earlyterminationfee
        public string EmvTransaction { get; set; }//new_emvtransactionperdevice
        public string G2Monitoring { get; set; }//new_g2monitoring
        public string ApplicationFee { get; set; }//new_applicationfee
        public string BatchFee { get; set; }//new_batchsettlementfee
        public string ExcessiveHelpDeskCall { get; set; }//new_excessivehelpdeskcalls
        public string AvsFee { get; set; }// new_avsfeeaddressverificationservice
        public string EmvRecidencyFee { get; set; }// new_emvresidencyfee
        public string MerlinkChargeBack { get; set; }//new_merlinkchargeback             
        public bool IsMerlinkChargeBack { get; set; }//new_merlinkchargebackbool             
    }
    public class RecurringFeesModel : BaseInformationModel
    {
        public RecurringFeesModel()
        {
            ListOptionalProductsServices = new List<OptionalProductsServices>();
        }
        public string MonthlyMinimum { get; set; }// new_monthlyminimum
        public string MonthlyPciFee { get; set; }// new_monthlypcifee
        public string TransactionFee { get; set; }// new_visamcdiscovertransactionfee
        public string MonthlyCustomerSvsFee { get; set; }// new_monthlycustomersvsfee
        public string NonPciComplianceFee { get; set; } // new_nonpcicompliancefee
        public string AmexFee { get; set; }// new_amextransactionfee
        public string RegulatoryFee { get; set; }// new_irsregulatoryfee
        public string PinDebitFee { get; set; }// new_pindebittransactionfee
        public string AnualFee { get; set; }// new_annualfee
        public string NonEmvCompliance { get; set; }// new_nonemvcompliance
        public string VoicePerAuthFee { get; set; }// new_voiceperauthfee
        public string MerchantReporting { get; set; }// new_merchantonlineportalreporting
        public string EarlyTerminationFee { get; set; }// new_earlyterminationfee
        public string EmvTransaction { get; set; }//new_emvtransactionperdevice
        public string G2Monitoring { get; set; }//new_g2monitoring
        public string ApplicationFee { get; set; }//new_applicationfee
        public string BatchFee { get; set; }//new_batchsettlementfee
        public string ExcessiveHelpDeskCall { get; set; }//new_excessivehelpdeskcalls
        public string AvsFee { get; set; }// new_avsfeeaddressverificationservice
        public string EmvRecidencyFee { get; set; }// new_emvresidencyfee
        public string MerlinkChargeBack { get; set; }//new_merlinkchargeback             
        public bool IsMerlinkChargeBack { get; set; }//new_merlinkchargebackbool       

        public string MultipassSetupFee { get; set; }//new_multipasssetupfee
        public string MultipassGatewayFee { get; set; }//new_multipassgatewaymonthlyfee        
        public string MultipassPerTransFee { get; set; }//new_multipasspertransfee
        public string EnsureBillSetupFee { get; set; }//new_ensurebillsetupfee
        public string EnsureBillMonthlyFee { get; set; }//new_ensurebillmonthlyfee
        public string EnsureBillItemFee { get; set; }//new_ensurebillupdateperitemfee
        public string MobileSetupFee { get; set; }//new_wirelessmobilesetupfee
        public string MonthlyMobileFee { get; set; }// new_monthlywirelessmobilefee
        public string MobilePerTransFee { get; set; }//new_wirelessmobilepertransfee
        public string GatewaySetupFee { get; set; }//new_gatewaysetupfee
        public string GatewayMonthlyFee { get; set; }//new_gatewaymonthlyfee
        public string GatewayPerTransFee { get; set; }//new_gatewaypertransfee

        // Other fees
        public string ChargebackPer { get; set; }//new_chargebackperchargeback
        public string ChargebackReversals { get; set; }//new_chargebackreversalsperreversal
        public string ChargebackRetrieval { get; set; }//new_chargebackretrievalperretrieval
        public string ChargebackPreArbitration { get; set; }//new_chargebackprearbitrationprearbitration
        public string PerAchRejectFee { get; set; }//new_perachrejectfee
        public string FANF { get; set; }//new_visafixedacquirernetworkfeefanf

        //Optional Products or Services
        public List<OptionalProductsServices> ListOptionalProductsServices { get; set; }

        public string PersonalGuaranteeDesc { get; set; }

    }

    public class PersonalGuaranteeModel : BaseInformationModel
    {
        public string PersonalGuaranteeDesc { get; set; }
    }

    public class DocuSignFormModel : BaseInformationModel
    {

    }
    public class MerchantThankYouModel : BaseInformationModel
    {
    }
    #endregion

    #region Optional Products or Services
    public class OptionalProductsServices
    {
        public string new_name { get; set; }
        public string new_setupfee { get; set; }
        public string new_monthly { get; set; }
        public string new_peritempertransfee { get; set; }
    }
    #endregion

    #region Partner (ISO/Bank) Information
    public class CompanyInformationModel : BaseInformationModel
    {
        public string DBAName { get; set; }
        //new_dbaname
        //Contact Name -> get ContactName from BaseInformationModel
        //new_contactname
        //Address ->  get LocationAddress, City, Zip, SelectedState1 from BaseInformationModel
        //new_address,new_city, new_zipcode, new_state
        public string TaxId { get; set; }
        // new_federaltaxid
        [Required(ErrorMessage = "Required")]
        public int CorporationType { get; set; }
        //new_corporationtype

        //For LLC:State drop down Use SelectedState2 from BaseInformationModel
        //new_state1

        //File upload for Non Profit
        //new_nonprofitevidence
    }

    public class PrincipleInformationModel : BaseInformationModel
    {
        public string FullName { get; set; }
        //new_fullname
        public string Title { get; set; }
        //new_title
        // HOME ADDRESS ->  get LocationAddress, City, Zip, SelectedState1 from BaseInformationModel
        //new_homeaddress, new_city1, new_zipcode1, new_state2
        //HOME PHONE  -> get TelePhoneNumber from BaseInformationModel
        //new_homephone
        public string MobilePhone { get; set; }
        //new_mobilephone
        public string SSN { get; set; } // Social Security #
        //new_socialsecurity
        public DateTime BirthDate { get; set; }
        public string BirthDateString { get; set; }
        //new_dateofbirth
    }

    public class AuthorizationModel : BaseInformationModel
    {
        public string AuthorizationDescription { get; set; } // only get from CRM
        //new_authorizationtemplate
        public string SSN { get; set; } // only get from PrincipleInformationModel
        //new_socialsecurity
        public string BirthDate { get; set; }// only get from PrincipleInformationModel
                                             //new_dateofbirth
                                             //Residence Street Address: ->  use LocationAddress, City, Zip, SelectedState1 from BaseInformationModel, // only get from PrincipleInformationModel
                                             ////new_address,new_city, new_zipcode, new_state

        // new_authorization_signature
    }

    public class AgreementModel : BaseInformationModel
    {
        //new_signatureprincipal
        public string AgreementDescription { get; set; }
        //new_agreementtemplate
    }

    public class AppendixAModel : BaseInformationModel
    {
        public AppendixAModel()
        {
            ListMerchantFees = new List<MerchantFees>();
        }
        public List<MerchantFees> ListMerchantFees { get; set; }
        // All Fee proprties -> only get from CRM
        //Revenue Share----------------
        //REVENUE PERCENTAGE PAID ON ABOVE ALL COSTS
        public string new_revenuepercentagepaidonaboveallcosts { get; set; }

        //Transaction Fees------------------
        //VISA/MC/DISCOVER TRANSACTION FEE        
        public string new_visamcdiscovertransactionfee { get; set; }

        //NON-BANKCARD TRANSACTION FEE
        //new_nonbankcardtransactionfee
        public string new_nonbankcardtransactionfee { get; set; }

        //DEBIT TRANSACTION FEE (PLUS NETWORK FEES)
        //new_debittransactionfeeplusnetworkfees
        public string new_debittransactionfeeplusnetworkfees { get; set; }

        //EBT TRANSACTIONS
        //new_ebttransactions
        public string new_ebttransactions { get; set; }

        //ADDRESS VERIFICATION SYSTEM (AVS) ELECTRONIC
        //new_addressverificationsystemavselectronic
        public string new_addressverificationsystemavselectronic { get; set; }

        //MICROS PER TRANSACTION
        //new_microspertransactionz
        public string new_microspertransactionz { get; set; }


        //Setup, Maintenance and Membership Fees------------------------
        //BATCH HEADER - ACH FEE
        //new_batchheaderachfee
        public string new_batchheaderachfee { get; set; }

        //CHARGEBACK - INITIAL CASE
        //new_chargebackinitialcase
        public string new_chargebackinitialcase { get; set; }

        //CHARGEBACK - REVERSALS
        //new_chargebackreversals
        public string new_chargebackreversals { get; set; }

        //MERCHANT STATEMENT/SERVICE (PER LOCATION)
        //new_merchantstatementserviceperlocation
        public string new_merchantstatementserviceperlocation { get; set; }

        //MERCHANT ACCOUNT ON FILE FEE
        //new_merchantaccountonfilefee
        public string new_merchantaccountonfilefee { get; set; }

        //ANNUAL FEE
        //new_annualfee
        public string new_annualfee { get; set; }

        //CANCELLATION FEE
        //new_cancellationfee
        public string new_cancellationfee { get; set; }

        //PCI COMPLIANCE MONTHLY FEE
        //new_pcicompliancemonthlyfee
        public string new_pcicompliancemonthlyfee { get; set; }

        //PCI NON-COMPLIANCE FEE
        //new_pcinoncompliancefee
        public string new_pcinoncompliancefee { get; set; }

        //TIN MISMATCH FEE
        //new_tinmismatchfee
        public string new_tinmismatchfee { get; set; }

        //GOVT. COMPLIANCE FEE
        //new_govtcompliancefee
        public string new_govtcompliancefee { get; set; }

        //INTERACTIVE VOICE RESPONSE AUTH (ARU OR IVR)
        //new_interactivevoiceresponseautharuorivr
        public string new_interactivevoiceresponseautharuorivr { get; set; }

        //ACH REJECT FEES
        //new_achrejectfees
        public string new_achrejectfees { get; set; }

        //RETRIEVALS
        //new_retrievals
        public string new_retrievals { get; set; }

        //WELCOME KITS
        //new_welcomekits
        public string new_welcomekits { get; set; }

        //MERCHANT ONLINE REPORTING
        //new_merchantonlinereporting
        public string new_merchantonlinereporting { get; set; }

        //Association Rates...................
        //VISA/MC/DISC INTERCHANGE, DUES AND ASSESSMENTS
        //new_visamcdiscinterchangeduesandassessments
        public string new_visamcdiscinterchangeduesandassessments { get; set; }

        //DEBIT NETWORK INTERCHANGE
        //new_debitnetworkinterchange
        public string new_debitnetworkinterchange { get; set; }

        //BIN/BANK SPONSORSHIP EXPENSE
        //new_binbanksponsorshipexpense
        public string new_binbanksponsorshipexpense { get; set; }

        //AMERICAN EXPRESS BLUE NETWORK/INTERCHANGE
        //new_americanexpressbluenetworkinterchange
        public string new_americanexpressbluenetworkinterchange { get; set; }

        //AMERICAN EXPRESS SPONSORSHIP FEE
        //new_americanexpresssponsorshipfee
        public string new_americanexpresssponsorshipfee { get; set; }

        //ASSOCIATION BRANDING FEES
        //new_associationbrandingfees
        public string new_associationbrandingfees { get; set; }

        //Additional Service Fees-----------------------
        //HELP DESK(PER CALL) AFTER HOURS TSYS
        //new_helpdeskpercallafterhourstsys
        public string new_helpdeskpercallafterhourstsys { get; set; }

        //CUSTOMER SERVICE PER MID MONTHLY
        //new_customerservicepermidmonthly
        public string new_customerservicepermidmonthly { get; set; }

        //Wireless Service-------------------
        //WIRELESS TRANSACTION FEE(GPRS/CDMA)
        //new_wirelesstransactionfeegprscdma
        public string new_wirelesstransactionfeegprscdma { get; set; }

        //WIRELESS INITIAL SETUP PER UNIT
        //new_wirelessinitialsetupperunit
        public string new_wirelessinitialsetupperunit { get; set; }

        //WIRELESS MONTHLY IP ADDRESS FEE/LABEL>
        //new_wirelessmonthlyipaddressfeelabel
        public string new_wirelessmonthlyipaddressfeelabel { get; set; }

        //WIRELESS GSM SIM CARD (TSYS POS) PER DEVICE
        //new_wirelessgsmsimcardtsysposperdevice
        public string new_wirelessgsmsimcardtsysposperdevice { get; set; }

        //WIRELESS GSM SIM CARD (NON-TSYS POS) PER DEVICE
        //new_wirelessgsmsimcardnontsysposperdevice            
        public string new_wirelessgsmsimcardnontsysposperdevice { get; set; }

        //Virtual Terminal Fees-------------------        
        //SECUREPAY MONTHLY
        //new_securepaymonthly
        public string new_securepaymonthly { get; set; }

        //SECUREPAY TRANSACTION
        //new_securepaytransaction
        public string new_securepaytransaction { get; set; }

        //NMI MONTHLY - FULL ACCESS UNLIMITED MOBILE DEVICES
        //new_nmimonthlyfullaccessunlimitedmobiledevice
        public string new_nmimonthlyfullaccessunlimitedmobiledevice { get; set; }

        //MOBILE APP ONLY MONTHLY-PER DEVICE DOESNOT INCLUDE GATEWAY
        //new_mobileapponlymonthlyperdevicedoesnotinclu
        public string new_mobileapponlymonthlyperdevicedoesnotinclu { get; set; }

        //PER TRANSACTION
        //new_pertransaction
        public string new_pertransaction { get; set; }

        //PAYTRACE TRANSACTION
        //new_paytracetransaction
        public string new_paytracetransaction { get; set; }

        //PAYTRACE MONTHLY
        //new_paytracemonthly
        public string new_paytracemonthly { get; set; }

        //PAYTRACE SET UP FEE
        //new_paytracesetupfee
        public string new_paytracesetupfee { get; set; }

        //Equipment Setup Fees----------------------------
        //EQUIPMENT PROGRAMS/ENCRYPTION
        //new_equipmentprogramsencryption
        public string new_equipmentprogramsencryption { get; set; }

        // Suignature field
        //new_appendixa_signature                
    }

    public class MerchantFees
    {
        /* new_feescategory
         1 - Revenue Share 
        2 - Transaction Fees
        3 - Setup, Maintenance and Membership Fees
        4 - Association Rates
        5 - Additional Service Fees
        6 - Wireless Service
        7 - Virtual Terminal Fees
        8 - Equipment Setup Fees

            new_feevaluetype
            1 - Currency    
            2 - Percentage
         */
        public int? new_feescategory { get; set; }
        public string new_name { get; set; }
        public decimal? new_feevalueincurrency { get; set; }
        public decimal? new_feevalueinpercent { get; set; }
        public int? new_feevaluetype { get; set; }
    }

    public class AppendixBModel : BaseInformationModel
    {
        public string EthicsStatementDesciption { get; set; } // -> only get from CRM
        //new_appendixbtemplate
        public string SignImageBase64 { get; set; }
        //new_appendixb_signature
    }

    public class PaymentInformationModel : BaseInformationModel
    {
        public string ApplicantName { get; set; }
        //new_applicantsname
        public string DBACompanyName { get; set; }
        //new_dbacompanyname
        // Address -> use LocationAddress from BaseInformationModel
        //new_address1

        // Bank Name -> use BankName from BaseInformationModel
        //new_bankname

        // Bank Phone -> use TelePhoneNumber from BaseInformationModel
        //new_bankphone
        public string RoutingNumber { get; set; }
        //new_routingnumber
        public string AccountNumber { get; set; }
        //new_accountnumber

        //new_paymentinfo_signature

        // COPY OF DRIVER’S LICENSE -> use FileName, FileBase64 from BaseInformationModel
        //new_copyofdriverslicense

        // COPY OF PRE PRINTED VOIDED CHECK FOR DEPOSITS -> use FileName2, FileBase642 from BaseInformationModel
        // new_copyofpreprintedvoidedcheckfordeposits

        // COPY OF W9 FORM -> use FileName3, FileBase643 from BaseInformationModel
        //new_copyofw9form

        public int CorporationType { get; set; }
        public string CorporationTypeName { get; set; }
    }
    public class PartnerLogo : BaseInformationModel
    {
        public string PictureUrl { get; set; }
        public int AffiliateId { get; set; }
    }

    public class PartnerThankYouModel : BaseInformationModel
    {
    }

    public class AffiliateModelCustom
    {
        public int LogoId { get; set; }
        public string FriendlyUrlName { get; set; }
        public string PartnerId { get; set; }
    }
    #endregion

    #region Merchant Form Applications
    public class MerchantApplicationModel : BaseInformationModel
    {
        public MerchantApplicationModel()
        {
            MerchantApplicationList = new List<MerchantApplicationListModel>();
        }
        public List<MerchantApplicationListModel> MerchantApplicationList { get; set; }
    }
    public class MerchantApplicationListModel
    {
        public string new_merchantapplicationid { get; set; } // form CRM guid
        public string new_applicationid { get; set; } // Merchant Form ID - MID
        public DateTime createdon { get; set; }
        public string new_email { get; set; }
        public string new_name { get; set; }
        public string new_issigned { get; set; }
        public int new_status { get; set; }
        public string new_comment { get; set; }
    }
    #endregion

}

