﻿using System.Web.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;
using Nop.Web.Framework.Mvc.ModelBinding;

namespace Misc.Plugin.MerchantBoarding.Models
{
    public class ConfigurationModel
    {
        public int ActiveStoreScopeConfiguration { get; set; }

        [NopResourceDisplayName("Plugin.MerchantBoarding.Fields.EnableTINCheck")]
        public bool EnableTINCheck { get; set; }
        public bool EnableTINCheck_OverrideForStore { get; set; }                
        
        public int TINCheckModeId { get; set; }        
        [NopResourceDisplayName("Plugin.MerchantBoarding.Fields.TINCheckModeId")]
        public SelectList TINCheckModeValues { get; set; }
        public bool TINCheckModeId_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugin.MerchantBoarding.Fields.TINCheckTestUsername")]
        public string TINCheckTestUsername { get; set; }
        public bool TINCheckTestUsername_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugin.MerchantBoarding.Fields.TINCheckTestPassword")]
        public string TINCheckTestPassword { get; set; }
        public bool TINCheckTestPassword_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugin.MerchantBoarding.Fields.TINCheckLiveUsername")]
        public string TINCheckLiveUsername { get; set; }
        public bool TINCheckLiveUsername_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugin.MerchantBoarding.Fields.TINCheckLivePassword")]
        public string TINCheckLivePassword { get; set; }
        public bool TINCheckLivePassword_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugin.MerchantBoarding.Fields.EnableBlockScore")]
        public bool EnableBlockScore { get; set; }
        public bool EnableBlockScore_OverrideForStore { get; set; }
    }
}
