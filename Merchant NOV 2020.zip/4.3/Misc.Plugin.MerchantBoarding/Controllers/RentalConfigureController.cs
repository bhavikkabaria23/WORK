﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using DocuSign.eSign.Api;
using DocuSign.eSign.Client;
using DocuSign.eSign.Model;
using iTextSharp.text.pdf;
using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Core.Infrastructure;
using Nop.Services.Common;
using Nop.Services.Configuration;
using Nop.Services.Customers;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Media;
using Nop.Services.Messages;
using Nop.Services.Security;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;
using Misc.Plugin.MerchantBoarding.Models;

namespace Nop.Plugin.Widgets.NivoSlider.Controllers
{
    [Area(AreaNames.Admin)]
    [AutoValidateAntiforgeryToken]
    public class RentalConfigureController : BasePluginController
    {
        private readonly ILocalizationService _localizationService;
        private readonly INotificationService _notificationService;
        private readonly IPermissionService _permissionService;
        private readonly IPictureService _pictureService;
        private readonly ISettingService _settingService;
        private readonly IStoreContext _storeContext;
        private readonly ILogger _logger;
        private readonly IWorkContext _workContext;
        private readonly ICustomerService _customerService;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly IWebHelper _webHelper;




        #region DocuSign Variable
        private static string DocuSignBaseUrl = "https://demo.docusign.net/restapi";
        private static string DocuSignUsername = "jmartin@evanceprocessing.com";
        private static string DocuSignPassword = "Qw1declc3!";
        private static string DocuSignIntegratorKey = "0e22f21b-d194-4336-a1fa-8cc9b76eaf45";
        #endregion

        public RentalConfigureController(ILocalizationService localizationService,
            INotificationService notificationService,
            IPermissionService permissionService, 
            IPictureService pictureService,
            ISettingService settingService,
            IStoreContext storeContext,
            ILogger logger,
            IWorkContext workContext,
            ICustomerService customerService,
            IGenericAttributeService genericAttributeService,
            IWebHelper webHelper
            )
        {
            _localizationService = localizationService;
            _notificationService = notificationService;
            _permissionService = permissionService;
            _pictureService = pictureService;
            _settingService = settingService;
            _storeContext = storeContext;
            _logger = logger;
            _workContext = workContext;
            _customerService = customerService;
            _genericAttributeService = genericAttributeService;
            _webHelper = webHelper;
        }        

        public IActionResult Configure()
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageWidgets))
                return AccessDeniedView();
          

            return View("~/Plugins/Misc.Plugin.MerchantBoarding/Views/Configure.cshtml");
        }

        //[HttpPost]
        //public IActionResult Configure(ConfigurationModel model)
        //{
        //    if (!_permissionService.Authorize(StandardPermissionProvider.ManageWidgets))
        //        return AccessDeniedView();          

        //    _notificationService.SuccessNotification(_localizationService.GetResource("Admin.Plugins.Saved"));
        //    return Configure();
        //}
    }
}