﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using DocuSign.eSign.Api;
using DocuSign.eSign.Client;
using DocuSign.eSign.Model;
using iTextSharp.text.pdf;
using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Core.Domain.Customers;
using Nop.Core.Infrastructure;
using Nop.Services.Common;
using Nop.Services.Configuration;
using Nop.Services.Customers;
using Nop.Services.Directory;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Media;
using Nop.Services.Messages;
using Nop.Services.Security;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;
using Misc.Plugin.MerchantBoarding.Models;
using Nop.Web.Factories;
using Nop.Web.Models.ShoppingCart;
using Nop.Services.Orders;
using Nop.Core.Domain.Orders;

namespace Nop.Plugin.Widgets.NivoSlider.Controllers
{
    public class RentalController : BasePluginController
    {
        private readonly ILocalizationService _localizationService;
        private readonly INotificationService _notificationService;
        private readonly IPermissionService _permissionService;
        private readonly IPictureService _pictureService;
        private readonly ISettingService _settingService;
        private readonly IStoreContext _storeContext;
        private readonly ILogger _logger;
        private readonly IWorkContext _workContext;
        private readonly ICustomerService _customerService;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly IWebHelper _webHelper;
        private readonly ICustomerAttributeService _customerAttributeService;
        private readonly ICustomerAttributeParser _customerAttributeParser;
        private readonly IStateProvinceService _stateProvinceService;
        private readonly IShoppingCartService _shoppingCartService;
        private readonly IShoppingCartModelFactory _shoppingCartModelFactory;



        #region DocuSign Variable
        private static string DocuSignBaseUrl = "https://demo.docusign.net/restapi";
        private static string DocuSignUsername = "jmartin@evanceprocessing.com";
        private static string DocuSignPassword = "Qw1declc3!";
        private static string DocuSignIntegratorKey = "0e22f21b-d194-4336-a1fa-8cc9b76eaf45";
        #endregion

        public RentalController(ILocalizationService localizationService,
            INotificationService notificationService,
            IPermissionService permissionService,
            IPictureService pictureService,
            ISettingService settingService,
            IStoreContext storeContext,
            ILogger logger,
            IWorkContext workContext,
            ICustomerService customerService,
            IGenericAttributeService genericAttributeService,
            IWebHelper webHelper,
            ICustomerAttributeService customerAttributeService,
            ICustomerAttributeParser customerAttributeParser,
            IStateProvinceService stateProvinceService,
            IShoppingCartService shoppingCartService,
            IShoppingCartModelFactory shoppingCartModelFactory
            )
        {
            _localizationService = localizationService;
            _notificationService = notificationService;
            _permissionService = permissionService;
            _pictureService = pictureService;
            _settingService = settingService;
            _storeContext = storeContext;
            _logger = logger;
            _workContext = workContext;
            _customerService = customerService;
            _genericAttributeService = genericAttributeService;
            _webHelper = webHelper;
            _customerAttributeService = customerAttributeService;
            _customerAttributeParser = customerAttributeParser;
            _stateProvinceService = stateProvinceService;
            _shoppingCartService = shoppingCartService;
            _shoppingCartModelFactory = shoppingCartModelFactory;
        }

        //public string GeneratePDFDocusignTest()
        //{
        //    _logger.Information("GeneratePDFDocusign - Started today 222");
        //    string docusignUrl = string.Empty;
        //    try
        //    {
        //        var basePath = "~/Plugins/Misc.Plugin.MerchantBoarding/PDFs/";
        //        // Check if template is exist
        //        if (System.IO.File.Exists(EngineContext.Current.Resolve<INopFileProvider>().MapPath(basePath + "Templates/RentalPdf.pdf")))
        //        {
        //            #region PDF Generation code
        //            // create a new PDF reader based on the PDF template document
        //            string pdfTemplate = EngineContext.Current.Resolve<INopFileProvider>().MapPath(basePath + "Templates/RentalPdf.pdf");
        //            var pdfReader = new PdfReader(pdfTemplate);
        //            if (!Directory.Exists(EngineContext.Current.Resolve<INopFileProvider>().MapPath(basePath + "RentalPdf")))
        //            {
        //                Directory.CreateDirectory(EngineContext.Current.Resolve<INopFileProvider>().MapPath(basePath + "RentalPdf"));
        //            }

        //            // create a new PDF stamper to create investor PDF from template document                    
        //            string pdfFileName = string.Format("RentalPdf-{0}-{1}.pdf", _workContext.CurrentCustomer.Email, _workContext.CurrentCustomer.Id);
        //            var merchantPdfFile = EngineContext.Current.Resolve<INopFileProvider>().MapPath(basePath + "RentalPdf/" + pdfFileName);
        //            var pdfStamper = new PdfStamper(pdfReader, new FileStream(merchantPdfFile, FileMode.OpenOrCreate));

        //            //SetPDFCommonFields(pdfStamper);
        //            pdfStamper.FormFlattening = true;
        //            pdfStamper.Close();
        //            pdfReader.Close();
        //            #endregion

        //            #region Docusign
        //            // initialize client for desired environment (for production change to www)
        //            ApiClient apiClient = new ApiClient(DocuSignBaseUrl);
        //            var baseUrl = DocuSignBaseUrl;
        //            DocuSign.eSign.Client.Configuration.Default.ApiClient = apiClient;

        //            // configure 'X-DocuSign-Authentication' header
        //            string authHeader = string.Concat("{", string.Format("\"Username\":\"{0}\",\"Password\":\"{1}\",\"IntegratorKey\":\"{2}\"",
        //                DocuSignUsername, DocuSignPassword, DocuSignIntegratorKey), "}");
        //            if (!DocuSign.eSign.Client.Configuration.Default.DefaultHeader.Any())
        //                DocuSign.eSign.Client.Configuration.Default.AddDefaultHeader("X-DocuSign-Authentication", authHeader);

        //            /* ---------- Step 1: Login API ----------  */
        //            // login call is available in the authentication api 
        //            AuthenticationApi authApi = new AuthenticationApi();
        //            LoginInformation loginInfo = authApi.Login();

        //            // parse the first account ID that is returned (user might belong to multiple accounts)
        //            var accountId = loginInfo.LoginAccounts[0].AccountId;
        //            baseUrl = loginInfo.LoginAccounts[0].BaseUrl;

        //            // Update ApiClient with the new base url from login call
        //            apiClient = new ApiClient(baseUrl.Substring(0, baseUrl.IndexOf("v") - 1));
        //            DocuSign.eSign.Client.Configuration.Default.ApiClient = apiClient;

        //            /* ---------- Step 2: Create Envelope API ---------- */
        //            // create a new envelope which we will use to send the signature request            
        //            EnvelopeDefinition envDef = new EnvelopeDefinition();
        //            envDef.EmailSubject = pdfFileName;

        //            // Add a document to the envelope                  
        //            //_logger.Information("GeneratePDFDocusign - Static PDF check");

        //            byte[] investorPdfFileBytes = System.IO.File.ReadAllBytes(merchantPdfFile);
        //            var investorPdfDocument = new Document();
        //            investorPdfDocument.DocumentBase64 = System.Convert.ToBase64String(investorPdfFileBytes);
        //            investorPdfDocument.Name = pdfFileName;
        //            investorPdfDocument.DocumentId = "1";
        //            envDef.Documents = new List<Document>();
        //            envDef.Documents.Add(investorPdfDocument);

        //            #region Single Signer Code - Note in Use
        //            // // Add a recipient to sign the documeent
        //            // Signer signer = new Signer();
        //            // signer.Email = _workContext.CurrentCustomer.Email;
        //            // signer.Name = String.Format("{0} {1}", _workContext.CurrentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.FirstName), _workContext.CurrentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.LastName));
        //            // signer.RecipientId = "1";
        //            // signer.ClientUserId = _workContext.CurrentCustomer.Id.ToString();

        //            // // Create a |SignHere| tab somewhere on the document for the recipient to sign
        //            // signer.Tabs = new Tabs();
        //            // signer.Tabs.SignHereTabs = new List<SignHere>();
        //            // SignHere signHere = new SignHere();
        //            // signHere.DocumentId = "1";
        //            // signHere.PageNumber = "3";
        //            // signHere.RecipientId = "1";
        //            // signHere.XPosition = "150";
        //            // signHere.YPosition = "650";
        //            // signer.Tabs.SignHereTabs.Add(signHere);

        //            // //signer.Tabs = new Tabs();
        //            // //signer.Tabs.SignHereTabs = new List<SignHere>();
        //            // var signHere2 = new SignHere();
        //            // signHere2.DocumentId = "1";
        //            // signHere2.PageNumber = "3";
        //            // signHere2.RecipientId = "1";
        //            // signHere2.XPosition = "150";
        //            // signHere2.YPosition = "680";
        //            // signer.Tabs.SignHereTabs.Add(signHere2);

        //            // var signHere4 = new SignHere();
        //            // signHere4.DocumentId = "1";
        //            // signHere4.PageNumber = "4";
        //            // signHere4.RecipientId = "1";
        //            // signHere4.XPosition = "190";
        //            // signHere4.YPosition = "130";
        //            // signer.Tabs.SignHereTabs.Add(signHere4);

        //            // var signHere5 = new SignHere();
        //            // signHere5.DocumentId = "1";
        //            // signHere5.PageNumber = "4";
        //            // signHere5.RecipientId = "1";
        //            // signHere5.XPosition = "190";
        //            // signHere5.YPosition = "150";
        //            // signer.Tabs.SignHereTabs.Add(signHere5);

        //            // //signer.Tabs = new Tabs();
        //            // //signer.Tabs.SignHereTabs = new List<SignHere>();
        //            // var signHere3 = new SignHere();
        //            // signHere3.DocumentId = "1";
        //            // signHere3.PageNumber = "5";
        //            // signHere3.RecipientId = "1";
        //            // signHere3.XPosition = "170";
        //            // signHere3.YPosition = "340";
        //            //signer.Tabs.SignHereTabs.Add(signHere3);
        //            #endregion

        //            #region Multiple Signer Code
        //            // Add a recipient to sign the documeent
        //            Signer signer1 = new Signer();
        //            signer1.Email = _workContext.CurrentCustomer.Email;
        //            signer1.Name = _customerService.GetCustomerFullName(_workContext.CurrentCustomer);
        //            signer1.RecipientId = "1";
        //            signer1.RoutingOrder = "1";
        //            _logger.Information("GeneratePDFDocusign - signer1.RoutingOrder = " + signer1.RoutingOrder);
        //            signer1.ClientUserId = _workContext.CurrentCustomer.Id.ToString();
        //            // Create a |SignHere| tab somewhere on the document for the recipient to sign
        //            signer1.Tabs = new Tabs();
        //            signer1.Tabs.SignHereTabs = new List<SignHere>();
        //            SignHere signHere = new SignHere();
        //            signHere.DocumentId = "1";
        //            signHere.PageNumber = "1";
        //            signHere.RecipientId = "1";
        //            signHere.XPosition = "150";
        //            signHere.YPosition = "350";
        //            signer1.Tabs.SignHereTabs.Add(signHere);
        //            #endregion


        //            envDef.Recipients = new Recipients();
        //            envDef.Recipients.Signers = new List<Signer>();
        //            envDef.Recipients.Signers.Add(signer1);

        //            // set envelope status to "sent" to immediately send the signature request
        //            envDef.Status = "sent";
        //            // |EnvelopesApi| contains methods related to creating and sending Envelopes (aka signature requests)
        //            EnvelopesApi envelopesApi = new EnvelopesApi();
        //            EnvelopeSummary envelopeSummary = envelopesApi.CreateEnvelope(accountId, envDef);
        //            _genericAttributeService.SaveAttribute(_workContext.CurrentCustomer, "DocuSignEnvelopeId_" + _workContext.CurrentCustomer.Id + DateTime.Now.ToString("MMM_dd_yyyy_HH_mm_ss"), envelopeSummary.EnvelopeId);
        //            _logger.Information("GeneratePDFDocusign - envelope id = " + envelopeSummary.EnvelopeId);
        //            _logger.Information("GeneratePDFDocusign - return url = " + $"{_webHelper.GetStoreLocation()}Plugin/RentalDocusignCallback/");
        //            RecipientViewRequest viewOptions = new RecipientViewRequest()
        //            {

        //                ReturnUrl = $"{_webHelper.GetStoreLocation()}Plugin/RentalDocusignCallback/",
        //                ClientUserId = _workContext.CurrentCustomer.Id.ToString(),  // must match clientUserId set in step #2!
        //                AuthenticationMethod = "email",
        //                UserName = _customerService.GetCustomerFullName(_workContext.CurrentCustomer),
        //                Email = _workContext.CurrentCustomer.Email,
        //            };

        //            // create the recipient view(aka signing URL)
        //            //ViewUrl recipientView = envelopesApi.CreateRecipientView(accountId, envelopeSummary.EnvelopeId, viewOptions);
        //            ViewUrl recipientView = envelopesApi.CreateRecipientView(accountId, envelopeSummary.EnvelopeId, viewOptions);

        //            docusignUrl = recipientView.Url;
        //            _logger.Information("GeneratePDFDocusign - docusignUrl = " + docusignUrl);

        //        }
        //        #endregion
        //        return docusignUrl;
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.Error("GeneratePDFDocusign latest - url = " + docusignUrl + " - " + ex.Message + " - inner - " + ex.InnerException);
        //        return docusignUrl;
        //    }
        //}

        public string GeneratePDFDocusign()
        {
            _logger.Information("GeneratePDFDocusign - Started today 222");
            string docusignUrl = string.Empty;
            try
            {
                var basePath = "~/Plugins/Misc.Plugin.MerchantBoarding/PDFs/";
                // Check if template is exist
                if (System.IO.File.Exists(EngineContext.Current.Resolve<INopFileProvider>().MapPath(basePath + "Templates/RentalPdf.pdf")))
                {
                    #region PDF Generation code
                    //// create a new PDF reader based on the PDF template document
                    string pdfTemplate = EngineContext.Current.Resolve<INopFileProvider>().MapPath(basePath + "Templates/RentalPdf.pdf");
                    var pdfReader = new PdfReader(pdfTemplate);
                    if (!Directory.Exists(EngineContext.Current.Resolve<INopFileProvider>().MapPath(basePath + "RentalPdf")))
                    {
                        Directory.CreateDirectory(EngineContext.Current.Resolve<INopFileProvider>().MapPath(basePath + "RentalPdf"));
                    }

                    //// create a new PDF stamper to create investor PDF from template document                    
                    string pdfFileName = string.Format("RentalPdf-{0}-{1}.pdf", _workContext.CurrentCustomer.Email, _workContext.CurrentCustomer.Id);
                    var merchantPdfFile = EngineContext.Current.Resolve<INopFileProvider>().MapPath(basePath + "RentalPdf/" + pdfFileName);
                    using (var fs = new FileStream(merchantPdfFile, FileMode.OpenOrCreate))
                    {
                        var pdfStamper = new PdfStamper(pdfReader, fs);

                        SetPDFCommonFields(pdfStamper);
                        pdfStamper.FormFlattening = true;
                        pdfStamper.Close();
                        pdfReader.Close();
                    }
                    #endregion

                    #region Docusign
                    // initialize client for desired environment (for production change to www)
                    ApiClient apiClient = new ApiClient(DocuSignBaseUrl);
                    var baseUrl = DocuSignBaseUrl;
                    DocuSign.eSign.Client.Configuration.Default.ApiClient = apiClient;

                    // configure 'X-DocuSign-Authentication' header
                    string authHeader = string.Concat("{", string.Format("\"Username\":\"{0}\",\"Password\":\"{1}\",\"IntegratorKey\":\"{2}\"",
                        DocuSignUsername, DocuSignPassword, DocuSignIntegratorKey), "}");
                    if (!DocuSign.eSign.Client.Configuration.Default.DefaultHeader.Any())
                        DocuSign.eSign.Client.Configuration.Default.AddDefaultHeader("X-DocuSign-Authentication", authHeader);

                    /* ---------- Step 1: Login API ----------  */
                    // login call is available in the authentication api 
                    AuthenticationApi authApi = new AuthenticationApi();
                    LoginInformation loginInfo = authApi.Login();

                    // parse the first account ID that is returned (user might belong to multiple accounts)
                    var accountId = loginInfo.LoginAccounts[0].AccountId;
                    baseUrl = loginInfo.LoginAccounts[0].BaseUrl;

                    // Update ApiClient with the new base url from login call
                    apiClient = new ApiClient(baseUrl.Substring(0, baseUrl.IndexOf("v") - 1));
                    DocuSign.eSign.Client.Configuration.Default.ApiClient = apiClient;

                    /* ---------- Step 2: Create Envelope API ---------- */
                    // create a new envelope which we will use to send the signature request            
                    EnvelopeDefinition envDef = new EnvelopeDefinition();
                    envDef.EmailSubject = pdfFileName;

                    // Add a document to the envelope                  
                    //_logger.Information("GeneratePDFDocusign - Static PDF check");

                    byte[] investorPdfFileBytes = System.IO.File.ReadAllBytes(merchantPdfFile);
                    //byte[] investorPdfFileBytes = System.IO.File.ReadAllBytes(pdfTemplate);
                    // *****************
                    var investorPdfDocument = new Document();
                    investorPdfDocument.DocumentBase64 = System.Convert.ToBase64String(investorPdfFileBytes);
                    investorPdfDocument.Name = pdfFileName;
                    investorPdfDocument.DocumentId = "1";
                    envDef.Documents = new List<Document>();
                    envDef.Documents.Add(investorPdfDocument);

                    #region Multiple Signer Code
                    // Add a recipient to sign the documeent
                    Signer signer1 = new Signer();
                    signer1.Email = _workContext.CurrentCustomer.Email;
                    signer1.Name = _customerService.GetCustomerFullName(_workContext.CurrentCustomer);
                    signer1.RecipientId = "1";
                    signer1.RoutingOrder = "1";
                    _logger.Information("GeneratePDFDocusign - signer1.RoutingOrder = " + signer1.RoutingOrder);
                    signer1.ClientUserId = _workContext.CurrentCustomer.Id.ToString();
                    // Create a |SignHere| tab somewhere on the document for the recipient to sign
                    signer1.Tabs = new Tabs();
                    signer1.Tabs.SignHereTabs = new List<SignHere>();
                    SignHere signHere = new SignHere();
                    signHere.DocumentId = "1";
                    signHere.PageNumber = "1";
                    signHere.RecipientId = "1";
                    signHere.XPosition = "400";
                    signHere.YPosition = "530";
                    signer1.Tabs.SignHereTabs.Add(signHere);

                    var signHere2 = new SignHere();
                    signHere2.DocumentId = "1";
                    signHere2.PageNumber = "2";
                    signHere2.RecipientId = "1";
                    signHere2.XPosition = "350";
                    signHere2.YPosition = "690";
                    signer1.Tabs.SignHereTabs.Add(signHere2);
                    #endregion


                    envDef.Recipients = new Recipients();
                    envDef.Recipients.Signers = new List<Signer>();
                    envDef.Recipients.Signers.Add(signer1);

                    // set envelope status to "sent" to immediately send the signature request
                    envDef.Status = "sent";
                    // |EnvelopesApi| contains methods related to creating and sending Envelopes (aka signature requests)
                    EnvelopesApi envelopesApi = new EnvelopesApi();
                    EnvelopeSummary envelopeSummary = envelopesApi.CreateEnvelope(accountId, envDef);
                    _genericAttributeService.SaveAttribute(_workContext.CurrentCustomer, "DocuSignEnvelopeId_" + _workContext.CurrentCustomer.Id + DateTime.Now.ToString("MMM_dd_yyyy_HH_mm_ss"), envelopeSummary.EnvelopeId);
                    _logger.Information("GeneratePDFDocusign - envelope id = " + envelopeSummary.EnvelopeId);
                    _logger.Information("GeneratePDFDocusign - return url = " + $"{_webHelper.GetStoreLocation()}Plugin/RentalDocusignCallback/");
                    RecipientViewRequest viewOptions = new RecipientViewRequest()
                    {
                        ReturnUrl = $"{_webHelper.GetStoreLocation()}Plugin/RentalDocusignCallback/",
                        ClientUserId = _workContext.CurrentCustomer.Id.ToString(),  // must match clientUserId set in step #2!
                        AuthenticationMethod = "email",
                        UserName = _customerService.GetCustomerFullName(_workContext.CurrentCustomer),
                        Email = _workContext.CurrentCustomer.Email,
                    };

                    // create the recipient view(aka signing URL)
                    //ViewUrl recipientView = envelopesApi.CreateRecipientView(accountId, envelopeSummary.EnvelopeId, viewOptions);
                    ViewUrl recipientView = envelopesApi.CreateRecipientView(accountId, envelopeSummary.EnvelopeId, viewOptions);

                    docusignUrl = recipientView.Url;
                    _logger.Information("GeneratePDFDocusign - docusignUrl = " + docusignUrl);

                }
                #endregion
                return docusignUrl;
            }
            catch (Exception ex)
            {
                _logger.Error("GeneratePDFDocusign latest - url = " + docusignUrl + " - " + ex.Message + " - inner - " + ex.InnerException);
                return docusignUrl;
            }
        }

        public string GeneratePDFDocusignMultisign()
        {
            _logger.Information("GeneratePDFDocusign - Started today 222");
            string docusignUrl = string.Empty;
            try
            {
                var basePath = "~/Plugins/Misc.Plugin.MerchantBoarding/PDFs/";
                // Check if template is exist
                if (System.IO.File.Exists(EngineContext.Current.Resolve<INopFileProvider>().MapPath(basePath + "Templates/RentalPdf.pdf")))
                {
                    #region PDF Generation code
                    //// create a new PDF reader based on the PDF template document
                    string pdfTemplate = EngineContext.Current.Resolve<INopFileProvider>().MapPath(basePath + "Templates/RentalPdf.pdf");
                    var pdfReader = new PdfReader(pdfTemplate);
                    if (!Directory.Exists(EngineContext.Current.Resolve<INopFileProvider>().MapPath(basePath + "RentalPdf")))
                    {
                        Directory.CreateDirectory(EngineContext.Current.Resolve<INopFileProvider>().MapPath(basePath + "RentalPdf"));
                    }

                    //// create a new PDF stamper to create investor PDF from template document                    
                    string pdfFileName = string.Format("RentalPdf-{0}-{1}.pdf", _workContext.CurrentCustomer.Email, _workContext.CurrentCustomer.Id);
                    var merchantPdfFile = EngineContext.Current.Resolve<INopFileProvider>().MapPath(basePath + "RentalPdf/" + pdfFileName);
                    using (var fs = new FileStream(merchantPdfFile, FileMode.OpenOrCreate))
                    {
                        var pdfStamper = new PdfStamper(pdfReader, fs);

                        SetPDFCommonFields(pdfStamper);
                        pdfStamper.FormFlattening = true;
                        pdfStamper.Close();
                        pdfReader.Close();
                    }
                    #endregion

                    #region Docusign
                    // initialize client for desired environment (for production change to www)
                    ApiClient apiClient = new ApiClient(DocuSignBaseUrl);
                    var baseUrl = DocuSignBaseUrl;
                    DocuSign.eSign.Client.Configuration.Default.ApiClient = apiClient;

                    // configure 'X-DocuSign-Authentication' header
                    string authHeader = string.Concat("{", string.Format("\"Username\":\"{0}\",\"Password\":\"{1}\",\"IntegratorKey\":\"{2}\"",
                        DocuSignUsername, DocuSignPassword, DocuSignIntegratorKey), "}");
                    if (!DocuSign.eSign.Client.Configuration.Default.DefaultHeader.Any())
                        DocuSign.eSign.Client.Configuration.Default.AddDefaultHeader("X-DocuSign-Authentication", authHeader);

                    /* ---------- Step 1: Login API ----------  */
                    // login call is available in the authentication api 
                    AuthenticationApi authApi = new AuthenticationApi();
                    LoginInformation loginInfo = authApi.Login();

                    // parse the first account ID that is returned (user might belong to multiple accounts)
                    var accountId = loginInfo.LoginAccounts[0].AccountId;
                    baseUrl = loginInfo.LoginAccounts[0].BaseUrl;

                    // Update ApiClient with the new base url from login call
                    apiClient = new ApiClient(baseUrl.Substring(0, baseUrl.IndexOf("v") - 1));
                    DocuSign.eSign.Client.Configuration.Default.ApiClient = apiClient;

                    /* ---------- Step 2: Create Envelope API ---------- */
                    // create a new envelope which we will use to send the signature request            
                    EnvelopeDefinition envDef = new EnvelopeDefinition();
                    envDef.EmailSubject = pdfFileName;

                    // Add a document to the envelope                  
                    //_logger.Information("GeneratePDFDocusign - Static PDF check");

                    byte[] investorPdfFileBytes = System.IO.File.ReadAllBytes(merchantPdfFile);
                    //byte[] investorPdfFileBytes = System.IO.File.ReadAllBytes(pdfTemplate);
                    // *****************
                    var investorPdfDocument = new Document();
                    investorPdfDocument.DocumentBase64 = System.Convert.ToBase64String(investorPdfFileBytes);
                    investorPdfDocument.Name = pdfFileName;
                    investorPdfDocument.DocumentId = "1";
                    envDef.Documents = new List<Document>();
                    envDef.Documents.Add(investorPdfDocument);

                    #region Multiple Signer Code
                    // Add a recipient to sign the documeent
                    Signer signer1 = new Signer();
                    signer1.Email = _workContext.CurrentCustomer.Email;
                    signer1.Name = _customerService.GetCustomerFullName(_workContext.CurrentCustomer);
                    signer1.RecipientId = "1";
                    signer1.RoutingOrder = "1";
                    _logger.Information("GeneratePDFDocusign - signer1.RoutingOrder = " + signer1.RoutingOrder);
                    signer1.ClientUserId = _workContext.CurrentCustomer.Id.ToString();
                    // Create a |SignHere| tab somewhere on the document for the recipient to sign
                    signer1.Tabs = new Tabs();
                    signer1.Tabs.SignHereTabs = new List<SignHere>();
                    SignHere signHere = new SignHere();
                    signHere.DocumentId = "1";
                    signHere.PageNumber = "1";
                    signHere.RecipientId = "1";
                    signHere.XPosition = "400";
                    signHere.YPosition = "530";
                    signer1.Tabs.SignHereTabs.Add(signHere);

                    signer1.Tabs.InitialHereTabs = new List<InitialHere>();
                    var signHere2 = new InitialHere();
                    signHere2.DocumentId = "1";
                    signHere2.PageNumber = "2";
                    signHere2.RecipientId = "1";
                    signHere2.XPosition = "350";
                    signHere2.YPosition = "690";
                    signer1.Tabs.InitialHereTabs.Add(signHere2);                  
                    #endregion

                    //Signer signer2 = new Signer();

                    //signer2.Email = _workContext.CurrentCustomer.Email;
                    //signer2.Name = _customerService.GetCustomerFullName(_workContext.CurrentCustomer);
                    //signer2.RecipientId = "2";
                    ////signer2.ClientUserId = _workContext.CurrentCustomer.Id.ToString() + "_owner2";
                    //signer2.RoutingOrder = "2";
                    //_logger.Information("GeneratePDFDocusign - signer2.RoutingOrder = " + signer2.RoutingOrder);

                    //signer2.Tabs = new Tabs();
                    //signer2.Tabs.SignHereTabs = new List<SignHere>();
                    //var signHere3 = new SignHere();
                    //signHere3.DocumentId = "1";
                    //signHere3.PageNumber = "2";
                    //signHere3.RecipientId = "2";
                    //signHere2.XPosition = "350";
                    //signHere2.YPosition = "690";
                    //signer2.Tabs.SignHereTabs.Add(signHere3);


                    envDef.Recipients = new Recipients();
                    envDef.Recipients.Signers = new List<Signer>();
                    envDef.Recipients.Signers.Add(signer1);
                    //envDef.Recipients.Signers.Add(signer2);

                    // set envelope status to "sent" to immediately send the signature request
                    envDef.Status = "sent";
                    // |EnvelopesApi| contains methods related to creating and sending Envelopes (aka signature requests)
                    EnvelopesApi envelopesApi = new EnvelopesApi();
                    EnvelopeSummary envelopeSummary = envelopesApi.CreateEnvelope(accountId, envDef);
                    _genericAttributeService.SaveAttribute(_workContext.CurrentCustomer, "DocuSignEnvelopeId_" + _workContext.CurrentCustomer.Id + DateTime.Now.ToString("MMM_dd_yyyy_HH_mm_ss"), envelopeSummary.EnvelopeId);
                    _logger.Information("GeneratePDFDocusign - envelope id = " + envelopeSummary.EnvelopeId);
                    _logger.Information("GeneratePDFDocusign - return url = " + $"{_webHelper.GetStoreLocation()}Plugin/RentalDocusignCallback/");
                    RecipientViewRequest viewOptions = new RecipientViewRequest()
                    {
                        ReturnUrl = $"{_webHelper.GetStoreLocation()}Plugin/RentalDocusignCallback/",
                        ClientUserId = _workContext.CurrentCustomer.Id.ToString(),  // must match clientUserId set in step #2!
                        AuthenticationMethod = "email",
                        UserName = _customerService.GetCustomerFullName(_workContext.CurrentCustomer),
                        Email = _workContext.CurrentCustomer.Email,
                    };

                    // create the recipient view(aka signing URL)
                    //ViewUrl recipientView = envelopesApi.CreateRecipientView(accountId, envelopeSummary.EnvelopeId, viewOptions);
                    ViewUrl recipientView = envelopesApi.CreateRecipientView(accountId, envelopeSummary.EnvelopeId, viewOptions);

                    docusignUrl = recipientView.Url;
                    _logger.Information("GeneratePDFDocusign - docusignUrl = " + docusignUrl);

                }
                #endregion
                return docusignUrl;
            }
            catch (Exception ex)
            {
                _logger.Error("GeneratePDFDocusign latest - url = " + docusignUrl + " - " + ex.Message + " - inner - " + ex.InnerException);
                return docusignUrl;
            }
        }

        private AcroFields SetPDFCommonFields(PdfStamper pdfStamper)
        {
            var formFields = pdfStamper.AcroFields;
            try
            {
                var customer = _workContext.CurrentCustomer;
                var customerAttributes = _customerAttributeService.GetAllCustomerAttributes();
                var selectedCustomerAttributes = _genericAttributeService
                            .GetAttribute<string>(customer, NopCustomerDefaults.CustomCustomerAttributes);
                foreach (var attribute in customerAttributes)
                {
                    if (attribute.Name == "RENTAL MERCHANT #")
                    {
                        if (!string.IsNullOrEmpty(selectedCustomerAttributes))
                        {
                            var enteredText = _customerAttributeParser.ParseValues(selectedCustomerAttributes, attribute.Id);
                            if (enteredText.Any())
                                formFields.SetField("customer_merchantno", enteredText[0] ?? "");
                        }
                    }
                    if (attribute.Name == "REFERING PARTNER")
                    {
                        if (!string.IsNullOrEmpty(selectedCustomerAttributes))
                        {
                            var enteredText = _customerAttributeParser.ParseValues(selectedCustomerAttributes, attribute.Id);
                            if (enteredText.Any())
                                formFields.SetField("customer_partner", enteredText[0] ?? "");
                        }
                    }
                    if (attribute.Name == "RENTAL AGREEMENT #")
                    {
                        if (!string.IsNullOrEmpty(selectedCustomerAttributes))
                        {
                            var enteredText = _customerAttributeParser.ParseValues(selectedCustomerAttributes, attribute.Id);
                            if (enteredText.Any())
                                formFields.SetField("customer_agreementno", enteredText[0] ?? "");
                        }
                    }
                    if (attribute.Name == "DBA")
                    {
                        if (!string.IsNullOrEmpty(selectedCustomerAttributes))
                        {
                            var enteredText = _customerAttributeParser.ParseValues(selectedCustomerAttributes, attribute.Id);
                            if (enteredText.Any())
                                formFields.SetField("customer_dba", enteredText[0] ?? "");
                        }
                    }
                    if (attribute.Name == "SSN")
                    {
                        if (!string.IsNullOrEmpty(selectedCustomerAttributes))
                        {
                            var enteredText = _customerAttributeParser.ParseValues(selectedCustomerAttributes, attribute.Id);
                            if (enteredText.Any())
                            {
                                var ssn = enteredText[0];
                                var ssnArray = ssn.Split('-');
                                if (ssnArray != null && ssnArray.Any() && ssnArray.Length == 3)
                                {
                                    formFields.SetField("ssn1", SetSSN(ssnArray[0]) ?? "");
                                    formFields.SetField("ssn2", SetSSN(ssnArray[1]) ?? "");
                                    formFields.SetField("ssn3", SetSSN(ssnArray[2]) ?? "");
                                }
                            }
                        }
                    }
                }



                formFields.SetField("customer_name", _customerService.GetCustomerFullName(customer));
                formFields.SetField("customer_company", _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.CompanyAttribute) ?? "");
                formFields.SetField("customer_address", _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.StreetAddressAttribute) ?? "" + " " + _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.StreetAddress2Attribute) ?? "");
                formFields.SetField("customer_phone", _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.PhoneAttribute) ?? "");
                formFields.SetField("customer_city", _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.CityAttribute) ?? "");
                var stateid = _genericAttributeService.GetAttribute<int>(customer, NopCustomerDefaults.StateProvinceIdAttribute);
                if (stateid > 0)
                {
                    var state = _stateProvinceService.GetStateProvinceById(stateid);
                    formFields.SetField("customer_state", state.Abbreviation);
                }
                formFields.SetField("customer_zip", _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.ZipPostalCodeAttribute) ?? "");
                formFields.SetField("customer_fax", _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.FaxAttribute) ?? "");

                formFields.SetField("customer_date", DateTime.Now.ToString("MM-dd-yyyy"));

                // Cart
                var cart = _shoppingCartService.GetShoppingCart(_workContext.CurrentCustomer, ShoppingCartType.ShoppingCart, _storeContext.CurrentStore.Id);
                var model = new ShoppingCartModel();
                var modelCart = _shoppingCartModelFactory.PrepareShoppingCartModel(model, cart);
                var modelTotal = _shoppingCartModelFactory.PrepareOrderTotalsModel(cart, false);

                if (modelCart != null)
                {
                    if (modelCart.Items != null && modelCart.Items.Any())
                    {
                        int cnt = 0;
                        foreach (var item in modelCart.Items)
                        {
                            cnt++;
                            formFields.SetField("cart_p" + cnt, item.ProductName ?? "");
                            formFields.SetField("cart_qty" + cnt, item.Quantity.ToString() ?? "");
                            formFields.SetField("cart_p" + cnt + "_total", item.SubTotal ?? "");
                        }
                    }
                    if (modelTotal != null)
                    {
                        formFields.SetField("cart_subtotal", modelTotal.SubTotal ?? "");
                        formFields.SetField("cart_tax", modelTotal.Tax ?? "");
                        formFields.SetField("cart_total", modelTotal.OrderTotal ?? _localizationService.GetResource("ShoppingCart.Totals.CalculatedDuringCheckout"));
                    }
                }
                return formFields;
            }
            catch (Exception ex)
            {
                _logger.Error("Rental Plugin -  SetPDFCommonFields");
                return formFields;
            }
        }

        private string SetSSN(string ssnString)
        {
            string ssm = string.Empty;
            char[] characters = ssnString.ToCharArray();
            foreach (var item in characters)
            {
                ssm += item + "   ";
            }
            return ssm;
        }

        public IActionResult DocuSignForm()
        {
            DocuSignFormModel model = new DocuSignFormModel();
            model.CustomerEmail = _workContext.CurrentCustomer.Email;
            model.DocusignUrl = GeneratePDFDocusignMultisign();
            return PartialView("~/Plugins/Misc.Plugin.MerchantBoarding/Views/_DocuSign.cshtml", model);
        }

        public IActionResult RentalDocusignCallback()
        {
            return PartialView("~/Plugins/Misc.Plugin.MerchantBoarding/Views/_RentalDocusignCallback.cshtml");
        }

        
    }
}