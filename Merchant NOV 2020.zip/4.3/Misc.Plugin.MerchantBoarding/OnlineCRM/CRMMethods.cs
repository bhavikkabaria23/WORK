﻿using Microsoft.AspNetCore.Http;
using Misc.Plugin.MerchantBoarding.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Nop.Core;
using Nop.Core.Infrastructure;
using Nop.Services.Customers;
using Nop.Services.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Misc.Plugin.MerchantBoarding.OnlineCRM
{
    public class CRMMethods
    {
        #region Private Variable
        private readonly IWorkContext _workContext;
        private readonly ILogger _logger;
        private readonly ICustomerService _customerService;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private JObject registerForm = new JObject(), merchantForm = new JObject(),
       retrievedData;
        private HttpClient httpClient;
        #endregion

        public CRMMethods(
            IWorkContext workContext,
            ICustomerService customerService,
            ILogger logger,
            IHttpContextAccessor httpContextAccessor
            )
        {
            this._customerService = customerService;
            this._logger = logger;
            this._workContext = workContext;
            _httpContextAccessor = httpContextAccessor;
        }

        #region Private Methods
        public static string GetMIDCookie()
        {            
            var currentMID = EngineContext.Current.Resolve<IHttpContextAccessor>().HttpContext.Request.Cookies["CurrentMID"];
            //var currentMID = Request.Cookies["CurrentMID"].Value;
            if (!string.IsNullOrEmpty(currentMID))
            {
                return currentMID;
            }
            return "empty_mid_cookie";
        }
        private void CRMAPIResponse(HttpResponseMessage response)
        {
            _logger.Error("CRM API Error - " + " - Status Code - " + response.StatusCode + " - " + response.Content); //$$$$
        }
        #endregion

        #region All Forms CRM Methods - Merchant Boarding
        public async Task<MerchantApplicationModel> MerchantApplicationsCRMGet()
        {          
            MerchantApplicationModel model = new MerchantApplicationModel();

            string CustomerEmail = _workContext.CurrentCustomer.Email;
            if (!string.IsNullOrEmpty(CustomerEmail))
            {
                // Get merchant applications from customer email                
                string queryOptions = "?$filter=new_email eq '" + CustomerEmail + "'";
                //HttpResponseMessage merchantResponse = await httpClient.GetAsync("new_merchantapplications" + queryOptions);
                HttpResponseMessage merchantResponse = await OnlineCRMAPIHelper.CrmRequest(HttpMethod.Get, "new_merchantapplications" + queryOptions); //$$$$
                if (merchantResponse.StatusCode == HttpStatusCode.OK) //200
                {
                    retrievedData = JsonConvert.DeserializeObject<JObject>(
                        await merchantResponse.Content.ReadAsStringAsync());
                }
                else
                {
                    CRMAPIResponse(merchantResponse);
                }
                if (retrievedData != null)
                {
                    var jvalue = retrievedData.GetValue("value");
                    if (jvalue != null && jvalue.Count() > 0)
                    {
                        model.MerchantApplicationList = JsonConvert.DeserializeObject<List<MerchantApplicationListModel>>(jvalue.ToString());
                    }
                }
            }
            return model;
        }

        public async Task MerchantApplicationsCRMPost(IFormCollection form, string appid = "")
        {         
            registerForm = new JObject();
            if (string.IsNullOrEmpty(appid)) // for new registered customer
            {
                appid = GetCurrentRegisteredCustomerMID();
            }
            registerForm.Add("new_applicationid", appid);
            registerForm.Add("createdon", DateTime.UtcNow.ToString());
            registerForm.Add("new_email", _workContext.CurrentCustomer.Email);
            registerForm.Add("new_name", form["CorporateName"]);
            registerForm.Add("new_issigned", false);

            HttpRequestMessage createRequest1 =
           new HttpRequestMessage(HttpMethod.Post, "new_merchantapplications");
            createRequest1.Content = new StringContent(registerForm.ToString(),
                Encoding.UTF8, "application/json");
            HttpResponseMessage createResponse1 =
                await httpClient.SendAsync(createRequest1);
            if (createResponse1.StatusCode == HttpStatusCode.NoContent)  //204
            {
                // Merchant Application Added
            }
            else
            {
                CRMAPIResponse(createResponse1);
            }
        }
        public async Task<MerchantInformationModel> MerchantInformationCRMGet()
        {          
            MerchantInformationModel model = new MerchantInformationModel();

            string CustomerEmail = _workContext.CurrentCustomer.Email;
            if (!string.IsNullOrEmpty(CustomerEmail))
            {
                // Get merchant details from customer email
                //string queryOptions = "?$select=new_merchantboardingid&$filter=new_businessemailaddress eq '" + CustomerEmail + "'";
                // https://securepay.crm.dynamics.com/api/data/v9.0/new_merchantboardings?$filter=new_businessemailaddress%20eq%20%27bhavikkabaria23@gmail.com%27                
                //https://securepay.crm.dynamics.com/api/data/v9.0/new_merchantboardings?$filter=new_businessemailaddress%20eq%20%27bhavikkabaria23@gmail.com%27%20and%20new_telephone9%20eq%20%2798978977%27
                string queryOptions = "?$filter=new_businessemailaddress eq '" + CustomerEmail + "' and new_applicationid eq '" + GetMIDCookie() + "'";
                //HttpResponseMessage merchantResponse = await httpClient.GetAsync("new_merchantboardings" + queryOptions);
                HttpResponseMessage merchantResponse = await OnlineCRMAPIHelper.CrmRequest(HttpMethod.Get, "new_merchantboardings" + queryOptions); //$$$$
                if (merchantResponse.StatusCode == HttpStatusCode.OK) //200
                {
                    retrievedData = JsonConvert.DeserializeObject<JObject>(
                        await merchantResponse.Content.ReadAsStringAsync());
                }
                else
                {
                    CRMAPIResponse(merchantResponse);
                }
                if (retrievedData != null)
                {
                    var jvalue = retrievedData.GetValue("value");
                    if (jvalue != null && jvalue.Count() > 0)
                    {
                        string merchantId = Convert.ToString(jvalue[0].SelectToken("new_merchantboardingid"));
                        model.MerchantUri = "new_merchantboardings(" + merchantId + ")"; //$$$$
                        model.FaxNumber = Convert.ToString(jvalue[0].SelectToken("new_faxnumber"));
                        model.CellPhone = Convert.ToString(jvalue[0].SelectToken("new_cell"));
                        model.MerchantName = Convert.ToString(jvalue[0].SelectToken("new_merchantname"));
                        model.LocationAddress = Convert.ToString(jvalue[0].SelectToken("new_locationaddress1"));
                        model.City = Convert.ToString(jvalue[0].SelectToken("new_city1"));
                        model.Zip = Convert.ToString(jvalue[0].SelectToken("new_zipcode1"));
                        model.CustomerEmail = Convert.ToString(jvalue[0].SelectToken("new_businessemailaddress"));
                        model.ContactName = Convert.ToString(jvalue[0].SelectToken("new_name"));
                        model.TelePhoneNumber = Convert.ToString(jvalue[0].SelectToken("new_businessphonenumber"));
                        int SelectedState1 = model.SelectedState1 = -1;
                        if (!string.IsNullOrEmpty(Convert.ToString(jvalue[0].SelectToken("new_state1"))))
                        {
                            int.TryParse(Convert.ToString(jvalue[0].SelectToken("new_state1")), out SelectedState1);
                            model.SelectedState1 = SelectedState1;
                        }

                        model.LocationAddress2 = jvalue[0].SelectToken("new_locationaddress2").ToString();
                        model.City2 = jvalue[0].SelectToken("new_city2").ToString();
                        model.Zip2 = jvalue[0].SelectToken("new_zipcode2").ToString();
                        int SelectedState2 = model.SelectedState2 = -1;
                        if (!string.IsNullOrEmpty(Convert.ToString(jvalue[0].SelectToken("new_state2"))))
                        {
                            int.TryParse(Convert.ToString(jvalue[0].SelectToken("new_state2")), out SelectedState2);
                            model.SelectedState2 = SelectedState2;
                        }
                        if (!string.IsNullOrEmpty(model.LocationAddress2) || !string.IsNullOrEmpty(model.City2)
                            || !string.IsNullOrEmpty(model.Zip2) || SelectedState2 >= 0)
                        {
                            model.IsMoreLocation = true;
                        }
                    }
                }

                // if jason != null
                //{
                // set merchant Uri and store it in model
                // Bind MerchantInformation details to MerchantInformationModel
                //}
            }
            return model;
        }

        public async Task<bool> MerchantInformationCRMPost(FormCollection fc, MerchantInformationModel model)
        {           
            // Generate json object from model
            merchantForm.Add("new_faxnumber", model.FaxNumber);
            merchantForm.Add("new_cell", model.CellPhone);
            merchantForm.Add("new_merchantname", model.MerchantName);
            merchantForm.Add("new_locationaddress1", model.LocationAddress);
            merchantForm.Add("new_city1", model.City);
            merchantForm.Add("new_state1", model.SelectedState1);
            merchantForm.Add("new_zipcode1", model.Zip);
            if (model.IsMoreLocation)
            {
                merchantForm.Add("new_locationaddress2", model.LocationAddress2);
                merchantForm.Add("new_city2", model.City2);
                merchantForm.Add("new_state2", model.SelectedState2);
                merchantForm.Add("new_zipcode2", model.Zip2);
            }
            else
            {
                merchantForm.Add("new_locationaddress2", null);
                merchantForm.Add("new_city2", null);
                merchantForm.Add("new_state2", null);
                merchantForm.Add("new_zipcode2", null);
            }
            //Update Merchat
            if (!string.IsNullOrEmpty(model.MerchantUri))
            {
                HttpResponseMessage updateResponse = await OnlineCRMAPIHelper.CrmRequest(HttpMethod.Patch, model.MerchantUri, merchantForm.ToString()); //$$$$

               // HttpRequestMessage updateRequest = new HttpRequestMessage(
               //new HttpMethod("PATCH"), model.MerchantUri);
               // updateRequest.Content = new StringContent(merchantForm.ToString(),
               //     Encoding.UTF8, "application/json");
               // HttpResponseMessage updateResponse =
               //     await httpClient.SendAsync(updateRequest); //$$$$

                if (updateResponse.StatusCode == HttpStatusCode.NoContent) //204
                {
                    return true;
                }
                else
                {
                    CRMAPIResponse(updateResponse);
                    //throw new CrmHttpResponseException(updateResponse.Content);
                    return false;
                }
            }
            return false;
        }


        #endregion

    }
}
