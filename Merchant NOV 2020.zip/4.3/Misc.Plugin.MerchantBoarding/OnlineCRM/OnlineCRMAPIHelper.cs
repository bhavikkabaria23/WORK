﻿using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Misc.Plugin.MerchantBoarding.OnlineCRM
{
    public static class OnlineCRMAPIHelper
    {
        public static string clientId = "42198c04-29d6-4c7a-ae72-e8962a2f6fc8"; // Your Azure AD Application ID  
        public static string clientSecret = "6-uail.lzD55U4iVW~COEdM87nfH1t5wK_"; // Client secret generated in your App  
        public static string authority = $"https://login.microsoftonline.com/f8a63935-0df8-47dc-90ed-1d177984b4a0"; // Azure AD App Tenant ID  
        public static string resourceUrl = "https://securepay.crm.dynamics.com/"; // Your Dynamics 365 Organization URL  
        public static string BaseAddress = "https://securepay.crm.dynamics.com/api/data/v9.1/";

        public static async Task<HttpResponseMessage> CrmRequest(HttpMethod httpMethod, string entitiyUrl, string body = null)
        {
            try
            {
                var accessToken = await AccessTokenGenerator();
                var client = new HttpClient();
                var requestUri = BaseAddress + entitiyUrl;
                var msg = new HttpRequestMessage(httpMethod, requestUri);
                msg.Headers.Add("OData-MaxVersion", "4.0");
                msg.Headers.Add("OData-Version", "4.0");
                msg.Headers.Add("Prefer", "odata.include-annotations=\"*\"");

                // Passing AccessToken in Authentication header  
                msg.Headers.Add("Authorization", $"Bearer {accessToken}");

                if (body != null)
                    msg.Content = new StringContent(body, UnicodeEncoding.UTF8, "application/json");
                return await client.SendAsync(msg).ConfigureAwait(true);
            }
            catch (AggregateException ae)
            {
                return null;
            }
        }

        public static async Task<string> AccessTokenGenerator()
        {
            var credentials = new ClientCredential(clientId, clientSecret);
            var authContext = new Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContext(authority);
            var result = await authContext.AcquireTokenAsync(resourceUrl, credentials);
            return result.AccessToken;
        }


    }
}
