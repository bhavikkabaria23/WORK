﻿using System;
using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Core.Caching;
using Nop.Core.Infrastructure;
using Nop.Services.Configuration;
using Nop.Services.Media;
using Nop.Web.Framework.Components;
using ShopFast.Plugin.Misc.Core.Services;
using ShopFast.Plugin.Misc.QuickCheckout.Models;
using System.Linq;
using Nop.Web.Areas.Admin.Models.Orders;
using Nop.Services.Catalog;
using Nop.Web.Models.Order;

namespace ShopFast.Plugin.Misc.QuickCheckout
{
    [ViewComponent(Name = "QuickCheckoutWidget")]
    public class QuickCheckoutWidgetViewComponent : NopViewComponent
    {       
        public IViewComponentResult Invoke(string widgetZone, object additionalData)
        {
            if (additionalData == null)
            {
                return null;
            }
            var orderDetailsModel = (OrderDetailsModel)additionalData;
            var orderId = orderDetailsModel.Id;
            var order = EngineContext.Current.Resolve<IITPOrderService>().GetOrderById(orderId);

            if (order != null && order.OrderTotal > 0 && order.OrderItems.Any())
            {
                var payments = EngineContext.Current.Resolve<IITPPartialPaymentService>().GetOrderPayments(order)
                    .Select(p => new OrderModel
                    {
                        CreatedOn = p.CreatedOnUtc,
                        OrderTotal = EngineContext.Current.Resolve<IPriceFormatter>().FormatPrice(p.OrderTotal, true, false),
                        PaymentStatus = p.PaymentStatus.ToString(),
                        PaymentMethod = p.PaymentMethodSystemName,
                        CustomerEmail = p.Customer != null ? p.Customer.Email : ""
                    })
                    .ToList();

                return View(GetViewname("PaymentSection"),
                    new OrderPaymentsModel
                    {
                        OrderId = order.Id,
                        Payments = payments
                    }
                );
            }
            return null;
        }

        [NonAction]
        protected string GetViewname(string viewname)
        {
            return "~/Plugins/ShopFast.Misc.QuickCheckout/Views/QuickCheckout/" + viewname + ".cshtml";
        }
    }
}
