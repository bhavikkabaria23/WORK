﻿using Nop.Core.Domain.Orders;
using Nop.Services.Orders;
using Nop.Services.Payments;
using ShopFast.Plugin.Misc.Core.Domain;

namespace ShopFast.Plugin.Misc.Core.Services
{
    public interface IITPOrderProcessingService : IOrderProcessingService
    {
        /// <summary>
        /// Places an order
        /// </summary>
        /// <param name="processPaymentRequest">Process payment request</param>
        /// <param name="paymentOperationType">Payment operation type</param>
        /// <returns>Place order result</returns>
        PlaceOrderResult PlaceOrder(ProcessPaymentRequest processPaymentRequest, PaymentOperationType paymentOperationType,
            out Order paymentOrder);

        /// <summary>
        /// Places an order
        /// </summary>
        /// <param name="processPaymentRequest">Process payment request</param>
        /// <param name="paymentOperationType">Payment operation type</param>
        /// <param name="paymentOrder">Partial Payment order</param>
        /// <returns>Place order result</returns>
        PlaceOrderResult PlacePartiallyPaidOrder(ProcessPaymentRequest processPaymentRequest, out Order paymentOrder);
    }
}
