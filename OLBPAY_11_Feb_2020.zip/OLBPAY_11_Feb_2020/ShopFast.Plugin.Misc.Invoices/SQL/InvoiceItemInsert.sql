﻿INSERT [Product] ([ProductTypeId], [ParentGroupedProductId], [VisibleIndividually],
 [Name], [ShortDescription], [FullDescription], [AdminComment], [ProductTemplateId], [VendorId],
  [ShowOnHomePage], [MetaKeywords], [MetaDescription], [MetaTitle], [AllowCustomerReviews], 
  [ApprovedRatingSum], [NotApprovedRatingSum], [ApprovedTotalReviews], [NotApprovedTotalReviews],
   [SubjectToAcl], [LimitedToStores], [Sku], [ManufacturerPartNumber], [Gtin], [IsGiftCard], [GiftCardTypeId],
    [OverriddenGiftCardAmount], [RequireOtherProducts], [RequiredProductIds], [AutomaticallyAddRequiredProducts],
	 [IsDownload], [DownloadId], [UnlimitedDownloads], [MaxNumberOfDownloads], [DownloadExpirationDays], [DownloadActivationTypeId], [HasSampleDownload], [SampleDownloadId], [HasUserAgreement], [UserAgreementText], [IsRecurring], 
	 [RecurringCycleLength], [RecurringCyclePeriodId], [RecurringTotalCycles], [IsRental],
	  [RentalPriceLength], [RentalPricePeriodId], [IsShipEnabled], [IsFreeShipping], [ShipSeparately],
	   [AdditionalShippingCharge], [DeliveryDateId], [IsTaxExempt], [TaxCategoryId], [IsTelecommunicationsOrBroadcastingOrElectronicServices], [ManageInventoryMethodId], [UseMultipleWarehouses], [WarehouseId], 
	   [StockQuantity], [DisplayStockAvailability], [DisplayStockQuantity], [MinStockQuantity], [LowStockActivityId], [NotifyAdminForQuantityBelow], [BackorderModeId], [AllowBackInStockSubscriptions], [OrderMinimumQuantity], [OrderMaximumQuantity], [AllowedQuantities], [AllowAddingOnlyExistingAttributeCombinations], [NotReturnable], [DisableBuyButton], [DisableWishlistButton], [AvailableForPreOrder], [PreOrderAvailabilityStartDateTimeUtc], [CallForPrice], [Price], [OldPrice], [ProductCost], [CustomerEntersPrice], [MinimumCustomerEnteredPrice], [MaximumCustomerEnteredPrice], [BasepriceEnabled], [BasepriceAmount], [BasepriceUnitId], [BasepriceBaseAmount], [BasepriceBaseUnitId], [MarkAsNew], [MarkAsNewStartDateTimeUtc], [MarkAsNewEndDateTimeUtc], [HasTierPrices], [HasDiscountsApplied], [Weight], [Length], [Width], [Height], [AvailableStartDateTimeUtc], [AvailableEndDateTimeUtc], [DisplayOrder], [Published], [Deleted], [CreatedOnUtc], [UpdatedOnUtc], [ProductAvailabilityRangeId]) VALUES (5, 0, 1,
	   %InvoiceItemName%, N'', N'', NULL, 1, 0, 0, NULL, NULL, NULL, 1, 4, 0, 1, 0, 0, 0, N'ShopFast.Plugins.Misc.Invoices.InvoiceItemProduct', NULL, NULL, 0, 0, NULL, 0, NULL, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, N'0', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, CAST(0.0000 AS Decimal(18, 4)),
	   2, %InvoiceItemIsTaxExempt%, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, N'0', 0, 0, 0, 0, 0, CAST(N'1900-03-17 00:00:00.000' AS DateTime), 0,
	   %InvoiceItemPrice%, CAST(0.0000 AS Decimal(18, 4)), CAST(0.0000 AS Decimal(18, 4)), 1, CAST(0.0000 AS Decimal(18, 4)), CAST(1000000.0000 AS Decimal(18, 4)), 0, CAST(0.0000 AS Decimal(18, 4)), 0, CAST(0.0000 AS Decimal(18, 4)), 0, 0, CAST(N'2014-12-05 13:54:12.113' AS DateTime), CAST(N'2014-12-05 13:54:12.113' AS DateTime), 1, 1, CAST(2.0000 AS Decimal(18, 4)), CAST(3.0000 AS Decimal(18, 4)), CAST(2.0000 AS Decimal(18, 4)), CAST(3.0000 AS Decimal(18, 4)), CAST(N'1900-01-01 00:00:00.000' AS DateTime), CAST(N'1900-01-02 00:00:00.000' AS DateTime), 0, 1, 0, CAST(N'2014-12-05 13:54:12.113' AS DateTime), CAST(N'2014-12-05 13:54:12.113' AS DateTime), 0)


UPDATE [Product] SET CustomerEntersPrice = 1, MinimumCustomerEnteredPrice = 0, 
	MaximumCustomerEnteredPrice = 1000000, IsShipEnabled = 0 
	WHERE Sku = 'ShopFast.Plugins.Misc.Invoices.InvoiceItemProduct';
