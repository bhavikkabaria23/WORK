﻿using Nop.Web.Framework.Mvc;
using Nop.Web.Framework.Models;


namespace ShopFast.Plugin.Misc.Invoices.Models
{
    public class InvoiceListModel : BaseNopModel
    {
        public int OrderId { get; set; }
        public string FullName { get; set; }
        public string Company { get; set; }
        public string Amount { get; set; }
        public string Due { get; set; }
        public string Created { get; set; }
        public string Status { get; set; }
        public string PaymentMethodSystemName { get; set; }
        public string EditLink { get; set; }
        public bool Paid { get; set; }
    }

    public partial class InvoiceGridListModel : BasePagedListModel<InvoiceListModel>
    {
    }
}
