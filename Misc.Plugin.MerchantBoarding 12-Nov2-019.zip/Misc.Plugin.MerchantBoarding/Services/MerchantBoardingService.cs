﻿using Misc.Plugin.MerchantBoarding.Domain;
using Misc.Plugin.MerchantBoarding.Models;
using Nop.Core;
using Nop.Core.Data;
using Nop.Services.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Misc.Plugin.MerchantBoarding.Mapper;

namespace Misc.Plugin.MerchantBoarding.Services
{
    public class MerchantBoardingService : IMerchantBoardingService
    {
        #region Fields
        private readonly IEventPublisher _eventPublisher;
        private readonly IRepository<MB_MerchantInformation> _merchantInformationRepository;
        private readonly IWorkContext _workContext;
        #endregion

        public MerchantBoardingService(IEventPublisher eventPublisher,
           IRepository<MB_MerchantInformation> merchantInformationRepository,
           IWorkContext workContext
            )
        {
            this._eventPublisher = eventPublisher;
            this._merchantInformationRepository = merchantInformationRepository;
            this._workContext = workContext;
        }

        //public virtual IEnumerable<IDF_Sections> GetSections()
        //{
        //    return _sectionRepository.Table;
        //}

        //public virtual IEnumerable<IDF_Questions> GetQuestions()
        //{
        //    return _questionRepository.Table;
        //}

        //public virtual IEnumerable<IDF_Controls> GetControls()
        //{
        //    return _controlRepository.Table;
        //}

        //public virtual IEnumerable<IDF_ControlItems> GetControlItemss()
        //{
        //    return _controlItemRepository.Table;
        //}

        //public virtual IEnumerable<IDF_Customer> GetCustomerData(int customerId)
        //{
        //    return _customerRepository.Table.Where(c => c.CustomerId == customerId);
        //}

        //public virtual void AddUpdateIssuerForm(List<IDF_Customer> customers, int customerId)
        //{
        //    if (customers == null)
        //        throw new ArgumentNullException("customers");
        //    var existingCustomers = _customerRepository.Table.Where(c => c.CustomerId == customerId).ToList();
        //    if (existingCustomers != null && existingCustomers.Any())
        //    {
        //        foreach (var cust in existingCustomers)
        //        {
        //            _customerRepository.Delete(cust);
        //            //event notification
        //            _eventPublisher.EntityDeleted(cust);
        //        }
        //    }

        //    foreach (var cust in customers)
        //    {
        //        // insert
        //        _customerRepository.Insert(cust);
        //        //event notification
        //        _eventPublisher.EntityInserted(cust);
        //    }
        //}

        //public virtual IDF_CRMCustomer GetCRMCustomer(int customerId)
        //{
        //    return _crmCustomerRepository.Table.FirstOrDefault(c => c.CustomerId == customerId);
        //}



        public virtual void AddUpdateEntity(MerchantInformationModel model)
        {
            if (model == null)
                throw new ArgumentNullException("MB_MerchantInformation");                        
            var existingEntity = _merchantInformationRepository.Table.FirstOrDefault(c => c.CustomerId == _workContext.CurrentCustomer.Id);
            if (existingEntity != null)
            {
                existingEntity = model.ToEntity(existingEntity);
                existingEntity.CustomerId = _workContext.CurrentCustomer.Id;
                _merchantInformationRepository.Update(existingEntity);
                //event notification
                _eventPublisher.EntityUpdated(existingEntity);
            }
            else
            {
                var entity = model.ToEntity();
                entity.CustomerId = _workContext.CurrentCustomer.Id;
                // insert
                _merchantInformationRepository.Insert(entity);
                //event notification
                _eventPublisher.EntityInserted(entity);
            }
        }

        //public virtual void InsertContactUsForm(ContactUs_FormData contactUs)
        //{
        //    if (contactUs == null)
        //        throw new ArgumentNullException("contactUs");

        //    _contactUsRepository.Insert(contactUs);

        //    //event notification
        //    _eventPublisher.EntityInserted(contactUs);
        //}

        //public virtual void UpdateContactUsForm(ContactUs_FormData contactUs)
        //{
        //    if (contactUs == null)
        //        throw new ArgumentNullException("contactUs");

        //    _contactUsRepository.Update(contactUs);

        //    //event notification
        //    _eventPublisher.EntityUpdated(contactUs);
        //}

        //public virtual void DeleteContactById(int Id)
        //{
        //    if (Id > 0)
        //    {
        //        var contact = _contactUsRepository.Table.FirstOrDefault(d => d.Id == Id);
        //        _contactUsRepository.Delete(contact);

        //        //event notification
        //        _eventPublisher.EntityDeleted(contact);
        //    }
        //}
    }
}
