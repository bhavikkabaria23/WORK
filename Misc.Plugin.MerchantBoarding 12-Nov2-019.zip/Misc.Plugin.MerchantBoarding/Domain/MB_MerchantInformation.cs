﻿using Nop.Core;

namespace Misc.Plugin.MerchantBoarding.Domain
{
    public class MB_MerchantInformation : BaseEntity
    {
        public int CustomerId { get; set; }

        public string FaxNumber { get; set; }
        public string MerchantName { get; set; }
        public bool IsMoreLocation { get; set; }
        public string LocationAddress { get; set; }
        public string City { get; set; }
        public string Zip { get; set; }
        public int SelectedState1 { get; set; }
        public string LocationAddress2 { get; set; }
        public string City2 { get; set; }
        public string Zip2 { get; set; }
        public int SelectedState2 { get; set; }
    }
}
