﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Misc.Plugin.MerchantBoarding.Models
{
    public class TINCheckModel
    {
        public string TIN { get; set; }
        public string LName { get; set; }
        public string FName { get; set; }
        public string GIIN { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip5 { get; set; }
        public string Zip4 { get; set; }
    }
    public class TINCheckResponse
    {
        public string JsonResponse { get; set; }
        public int TINNAME_CODE { get; set; }
        public string TINNAME_DETAILS { get; set; }
        public string CustomSuccessMessage { get; set; }
        public string CustomErrorMessage { get; set; }
        public bool IsTINCheckVerify { get; set; }
    }
}
