﻿using Nop.Core.Domain.Customers;
using Nop.Core.Infrastructure;
using Nop.Core.Plugins;
using Nop.Services.Common;
using Nop.Services.Customers;
using Misc.Plugin.MerchantBoarding.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Routing;
using Nop.Services.Localization;
using Nop.Web.Framework.Menu;

namespace Misc.Plugin.MerchantBoarding
{
    public class MerchantBoardingProvider : BasePlugin, IMiscPlugin, IAdminMenuPlugin
    {
        private readonly MerchantBoardingObjectContext _objectContext;

        public MerchantBoardingProvider(MerchantBoardingObjectContext objectContext)
        {
            this._objectContext = objectContext;
        }
        /// <summary>
        /// Gets a route for provider configuration
        /// </summary>
        /// <param name="actionName">Action name</param>
        /// <param name="controllerName">Controller name</param>
        /// <param name="routeValues">Route values</param>
        public void GetConfigurationRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "Configure";
            controllerName = "MerchantBoarding";
            routeValues = new RouteValueDictionary() { { "Namespaces", "Misc.Plugin.MerchantBoarding.Controllers" }, { "area", null } };
        }

        /// <summary>
        /// Install plugin
        /// </summary>  
        public override void Install()
        {
            //database objects
            _objectContext.Install();

            // Add "Merchant", "Partner" role if not exist
            if (EngineContext.Current.Resolve<ICustomerService>().GetCustomerRoleBySystemName("Merchant") == null)
            {
                CustomerRole role = new CustomerRole();
                role.Name = "Merchant";
                role.SystemName = "Merchant";
                role.Active = true;
                EngineContext.Current.Resolve<ICustomerService>().InsertCustomerRole(role);
            }
            if (EngineContext.Current.Resolve<ICustomerService>().GetCustomerRoleBySystemName("Partner") == null)
            {
                CustomerRole role = new CustomerRole();
                role.Name = "Partner";
                role.SystemName = "Partner";
                role.Active = true;
                EngineContext.Current.Resolve<ICustomerService>().InsertCustomerRole(role);
            }
            //--------------------------------

            //locales
            // Common
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.PleaseAccept", "Please accept the terms and condition");

            // Configuartion
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.Fields.EnableTINCheck", "Enable TINCheck");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.Fields.TINCheckModeId", "TINCheck ModeI");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.Fields.TINCheckTestUsername", "TINCheck Test Username");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.Fields.TINCheckTestPassword", "TINCheck Test Password");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.Fields.TINCheckLiveUsername", "TINCheck Live Username");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.Fields.TINCheckLivePassword", "TINCheck Live Password");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.Fields.EnableBlockScore", "Enable BlockScore");


            // My Account
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.MerchantFees", "Merchant Fees");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.PartnerFees", "Partner Fees");
            // Merchant boarding Register
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.MerchantBoarding", "Merchant Boarding");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.CorporationName", "Corporation Name");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.ContactName", "Contact Name");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.EmailAddress", "Email Address");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.TelephoneNumber", "Telephone Number");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.Password", "Password");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.MerchantRegisterConfirm", "By checking this box I am consenting to providing eVance and the subsidiaries of the OLB group all required information for the online application.");

            // Merchant Information
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.MerchantInformation", "Merchant Information");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.FaxNumber", "Fax Number");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.Cell", "Cell #");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.MerchantName", "Merchant Name(DBA or Trade Name)");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.LocationAddress", "Location Address");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.City", "City");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.State", "State");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.ZipCode", "Zip Code");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.LocationAddress2", "Location Address (2)");

            // Legal Information
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.LegalInformation", "Legal Information");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.LegalName", "Corporation/Legal Name (if different)");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.CorporateAddress", "Corporate Address (if diffrent)");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.Federal", "FEDERAL TAX ID OR SSN DETAILS");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.TaxId", "Federal Tax Id");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.SSN", "SSN");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.MCCCODE", "MCC CODE");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.IsMailingAddress", "Is Your mailing address same as Location Address?");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.MailingAddress", "Mailing Address");

            // Business Information
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.BusinessInformation", "Business Information");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.IsPaymentCard", "Do you currently Accept Payment Cards?");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.IsTerminated", "Has the merchant Been terminated from Accepting Cards?");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.IsSecurityBranch", "Have you had a Security Breach?");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.IfSoExplain?", "If so explain?");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.WhoWith", "Who is it with");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.PCIDDSCompliance", "Include latest proof of PCI DDS compliance");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.UploadDocument", "(Upload Document)");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.TypeOfBusiness", "Type of Business");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.TypeOfBusiness.Option1", "Individual/Sole Proprietor");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.TypeOfBusiness.Option2", "Partnership");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.TypeOfBusiness.Option3", "Corporation ");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.TypeOfBusiness.Option4", "Private");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.TypeOfBusiness.Option5", "LLC: state");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.TypeOfBusiness.Option6", "Goverment");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.TypeOfBusiness.Option7", "Publicly Traded");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.TypeOfBusiness.Option8", "Non Profit");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.EvidenceOf501(c)(3)Sstatus", "(provide evidence of 501(c)(3) status)");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.LengthBusinessYears", "LENGTH OF TIME IN BUSINESS (YEARS)");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.LengthBusinessMonths", "LENGTH OF TIME IN BUSINESS (MONTHS)");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.Year", "YEARS");
            this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.Month", "MONTHS");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");
            //this.AddOrUpdatePluginLocaleResource("Plugin.MerchantBoarding.", "");




            base.Install();
        }

        /// <summary>
        /// Uninstall plugin
        /// </summary>
        public override void Uninstall()
        {
            //database objects
            _objectContext.Uninstall();

            //locales
            //this.DeletePluginLocaleResource("");          

            base.Uninstall();
        }

        public void ManageSiteMap(SiteMapNode rootNode)
        {
            var menuItem1 = new SiteMapNode()
            {
                SystemName = "ResidualReports",
                Title = EngineContext.Current.Resolve<ILocalizationService>().GetResource("Admin.ResidualReport.Title"),
                Url = "/Admin/ResidualReports",
                Visible = true,
                IconClass = "fa-dot-circle-o"
            };
            var menuItem2 = new SiteMapNode()
            {
                SystemName = "TotalPayoutsReports",
                Title = EngineContext.Current.Resolve<ILocalizationService>().GetResource("Admin.PayoutsReport.Title"),
                Url = "/Admin/Payouts",
                Visible = true,
                IconClass = "fa-dot-circle-o"
            };
            var firstNode = new SiteMapNode()
            {
                SystemName = "Reports",
                Title = EngineContext.Current.Resolve<ILocalizationService>().GetResource("Admin.Report.Title"),
                Visible = true,
                IconClass = "fa-dot-circle-o"
            };            
            if (firstNode != null)
            {                
                firstNode.ChildNodes.Add(menuItem1);
                firstNode.ChildNodes.Add(menuItem2);
                rootNode.ChildNodes.Add(firstNode);
            }
            else
            {
                rootNode.ChildNodes.Add(menuItem1);
                rootNode.ChildNodes.Add(menuItem2);
            }
        }
    }
}
