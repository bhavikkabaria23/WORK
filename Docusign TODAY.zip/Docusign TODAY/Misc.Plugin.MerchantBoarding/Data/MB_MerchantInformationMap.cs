using Misc.Plugin.MerchantBoarding.Domain;
using Nop.Data.Mapping;

namespace Shopfast.Plugin.IssuerDocForm.Data
{
    public partial class MB_MerchantInformationMap : NopEntityTypeConfiguration<MB_MerchantInformation>
    {
        public MB_MerchantInformationMap()
        {
            this.ToTable("MB_MerchantInformation");
            this.HasKey(tr => tr.Id);            
        }
    }
}