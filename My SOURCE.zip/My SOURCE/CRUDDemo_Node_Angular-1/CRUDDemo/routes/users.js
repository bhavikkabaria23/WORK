var express = require('express');
var mongoose = require('mongoose');
var Users = mongoose.model('Users');
var router = express.Router();

/* GET users listing. */
router.get('/users', function (req, res, next) {
    debugger;
    Users.find(function (err, userList) {
        if (err) {
            return next(err);
        }
        res.json(userList);
    })
});

/* save new users by POST request. */
router.post('/users/create', function (req, res, next) {
    debugger;
    var user = new Users(req.body);

    Users.create(user, function (err, user) {
        if (err) {
            return next(err);
        }
        res.json(user);
    });
});

router.post('/users/authenticate', function (req, res, next) {
    debugger;
    var user = new Users(req.body);

    Users.findOne({ Email: user.Email, Password: user.Password }, function (err, user) {
        if (err) {
            return next(err);
        }
        res.json(user);
    });
});


module.exports = router;
