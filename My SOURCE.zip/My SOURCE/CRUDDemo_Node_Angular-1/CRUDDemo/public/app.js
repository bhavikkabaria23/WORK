﻿(function () {
    'use strict';

    angular.module('CRUDDemo', ['ui.router', 'ngMaterial'])
    .config(config)
    .run(run);

    function config($stateProvider, $urlRouterProvider) {
        $stateProvider.state('login', {
            url: '/login',
            templateUrl: 'Login/Login.html',
            controller: 'LoginCtrl'
        })
        .state('register', {
            url: '/register',
            templateUrl: 'Register/Register.html',
            controller: 'RegisterCtrl'
        })
        .state('home', {
            url: '/',
            templateUrl: 'Home/Home.html',
            controller: 'HomeCtrl'
        });

        $urlRouterProvider.otherwise('login');
    }

    function run($rootScope, $state) {
        $rootScope.globals = sessionStorage["user"] || {};
        //if ($rootScope.globals.currentUser) {
        //    $http.defaults.headers.common['Authorization'] = 'Basic ' + $rootScope.globals.currentUser.authdata; // jshint ignore:line
        //}

        $rootScope.$on('$stateChangeStart', function (event, toState, toParams) {
            var loggedIn = $rootScope.globals.currentUser;

            var restrictedPage = (toState.name == 'login' || toState.name == 'register' || toState.name == 'index') == false;
            if (restrictedPage && !loggedIn) {
                event.preventDefault();
                $state.go('login');
            }
        });
    }
})();