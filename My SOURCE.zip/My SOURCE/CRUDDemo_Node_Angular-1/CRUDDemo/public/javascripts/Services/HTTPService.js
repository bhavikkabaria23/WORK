﻿(function () {
    'use strict';

    angular.module('CRUDDemo')
    .factory('HTTPService', ['$http', function ($http) {
        var service = {};

        service.AjaxGet = AjaxGet;
        service.AjaxPost = AjaxPost;

        return service;

        function AjaxGet(url) {
            return $http.get(url).then(handleSuccess, handleError);
        }

        function AjaxPost(url, params) {
            return $http.post(url, params).then(handleSuccess, handleError);
        }

        //Result handling functions
        function handleSuccess(res) {
            return { success: true, data: res.data };
        }

        function handleError(res) {
            return { success: false, data: res };
        }

    }]);
})();