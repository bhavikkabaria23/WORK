﻿(function () {
    'use strict';

    angular.module('CRUDDemo')
    .controller('RegisterCtrl', ['$scope', '$state', 'HTTPService', function ($scope, $state, HTTPService) {
        $scope.gender = [{ name: 'Male' }, { name: 'Female' }];


        $scope.CreateUser = function () {
            debugger;
            HTTPService.AjaxPost('/users/create', $scope.user).then(function (res) {
                debugger;
                if (res.success) {
                    $state.go('home');
                }
                else {
                    alert('some error occured');
                }
            });
        }
    }]);
})();