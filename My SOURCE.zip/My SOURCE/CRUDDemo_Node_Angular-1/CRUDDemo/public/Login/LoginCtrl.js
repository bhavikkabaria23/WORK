﻿(function () {
    'use strict';

    angular.module('CRUDDemo')
    .controller('LoginCtrl', ['$scope', '$state', 'HTTPService', function ($scope, $state, HTTPService) {
        //$scope.test = "This is login page";

        $scope.GetAllUsers = function () {
            HTTPService.AjaxGet('/users').then(function (res) {
                alert(res);
            }, function (err) {
                alert(err);
            });
        }

    }]);
})();