﻿(function () {
    'use strict';

    angular.module('CRUDDemo')
    .controller('HomeCtrl', ['$scope', '$state', function ($scope, $state) {
        $scope.test = "This is Home page";

    }]);
})();