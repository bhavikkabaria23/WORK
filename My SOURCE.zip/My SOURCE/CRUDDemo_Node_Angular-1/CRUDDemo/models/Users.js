﻿var mongoose = require('mongoose');

var userSchema = new mongoose.Schema({
    FirstName: String,
    LastName: String,
    Gender: String,
    Email: String,
    Password: String,
    DOB: Date
});

mongoose.model('Users', userSchema);