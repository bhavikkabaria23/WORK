
var mongoose = require('mongoose');
var Schema = mongoose.Schema;



var TempDataSchema = new Schema({
    CreatedDate: Date,
    InstantSMSReferral: Number,
    InstantSMSReminder: Number,
    InstantSMSSaving: Number,
    InstantSMSError: Number    
});

module.exports = mongoose.model('TempData', TempDataSchema);