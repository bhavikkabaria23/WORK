var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var SiteSchema = new Schema({
    siteName: String
});

var CustomersSchema = new Schema({
    Name: String,
    Age: Number,
    Address: String,
    Country: String,
    State: String,
    City: String,
    Zipcode: String,
    IsAdmin: Boolean,
    Sites: [SiteSchema],
    Created: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Customers', CustomersSchema);