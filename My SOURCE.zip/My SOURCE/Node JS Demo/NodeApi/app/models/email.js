

var mongoose = require('mongoose');
var Schema = mongoose.Schema;



var EmailsSchema = new Schema({
    Emails: String,
    ReceiverName: String    
});

module.exports = mongoose.model('Email', EmailsSchema);