// call the packages we need
var express = require('express');        // call express
var path = require('path');
var app = express();                 // define our app using express
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
//mongoose.connect('mongodb://redeal:passw0rd123@35.163.222.141:27018/Redeal');
mongoose.connect('mongodb://localhost/Redeal');
//mongoose.connect('mongodb://localhost/NodeDB');
var Customer = require('./app/models/customer2');
var TempData = require('./app/models/tempdata');
var Email = require('./app/models/email');
// configure app to use bodyParser()
// this will let us get the data from a POST
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'Client')));

var port = process.env.PORT || 8080;        // set our port

// ROUTES FOR OUR API
// =============================================================================
var router = express.Router();              // get an instance of the express Router

// middleware to use for all requests
router.use(function (req, res, next) {
    // do logging
    console.log('Something is happening.');
    next(); // make sure we go to the next routes and don't stop here
});

// test route to make sure everything is working (accessed at GET http://localhost:8080/api)
router.get('/', function (req, res) {
    res.json({ message: 'Welcome to customer api!' });
});

// more routes for our API will happen here
// on routes that end in /customers
// ----------------------------------------------------

router.route('/customers')
    // create a customer (accessed at POST http://localhost:8080/api/customers)
    .post(function (req, res) {

        var customer = new Customer();      // create a new instance of the customer model
        // customer.Name = req.body.Name;  
        // customer.Age = req.body.Age;        
        // customer.Address = req.body.Address;
        // customer.Country = req.body.Country;
        // customer.State = req.body.State;
        // customer.City = req.body.City;
        // customer.Zipcode = req.body.Zipcode;
        // customer.IsAdmin = req.body.IsAdmin;        
        // customer.Sites.push({ siteName: req.body.siteName });

        // save the customer and check for errors
        customer.save(function (err) {
            if (err)
                res.send(err);

            res.json({ message: 'customer created!' });
        });
    })
    // get all the customers (accessed at GET http://localhost:8080/api/customers)
    .get(function (req, res) {             
        Customer.find(function (err, cust) {
            if (err)
                res.send(err);            
            res.json(cust);
        });
        // Email.find(function (err, em) {                  
        //     if (err)
        //         res.send(err);            
        //     res.json(em);
        // });
    });

router.route('/customers/:customer_id')
    // get the customer with that id (accessed at GET http://localhost:8080/api/customers/customer_id)
    .get(function (req, res) {
        Customer.findById(req.params.customer_id, function (err, customer) {
            if (err)
                res.send(err);
            res.json(customer);
        });
    })
    // update the customer with this id (accessed at PUT http://localhost:8080/api/customers/customer_id)
    .put(function (req, res) {

        // use our customer model to find the customer we want
        Customer.findById(req.params.customer_id, function (err, customer) {
            if (err)
                res.send(err);
            // customer.Name = req.body.Name;
            // customer.Age = req.body.Age;
            // customer.Address = req.body.Address;
            // customer.Country = req.body.Country;
            // customer.State = req.body.State;
            // customer.City = req.body.City;
            // customer.Zipcode = req.body.Zipcode;
            // // save the customer
            // customer.save(function (err) {
            //     if (err)
            //         res.send(err);
            //     res.json({ message: 'Customer updated!' });
            // });
        });
    })
    // delete the customer with this id (accessed at DELETE http://localhost:8080/api/customers/customer_id)
    .delete(function (req, res) {
        Customer.remove({
            _id: req.params.customer_id
        }, function (err, customer) {
            if (err)
                res.send(err);

            res.json({ message: 'Customer Successfully deleted' });
        });
    });
// REGISTER OUR ROUTES -------------------------------
// all of our routes will be prefixed with /api
app.use('/api', router);

// START THE SERVER
// =============================================================================
app.listen(port);
console.log('Node API is started on port ' + port);