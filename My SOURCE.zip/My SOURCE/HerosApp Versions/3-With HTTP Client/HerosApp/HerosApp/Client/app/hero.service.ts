﻿import { Hero } from './hero';
import { HEROES } from './mock-heroes';
import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/Rx';
import { HTTP_PROVIDERS,Http, Response } from '@angular/http';
import { Headers, RequestOptions } from '@angular/http';

@Injectable()
export class HeroService {
    private url = '/api/bears';  // URL to web api    
    constructor(private http: Http) { }
    getHeroes(): Observable<any> {        
        //return Promise.resolve(HEROES);
        let response = this.http.get(this.url)
            .map(response => response.json())
            //.subscribe(result => this.result = result)                    
        // let response =  this.http.get(url).map(res => res).catch(this.handleError);                                 
        return response;
    }

    // See the "Take it slow" appendix
    getHeroesSlowly() {
        return new Promise<Hero[]>(resolve =>
            setTimeout(() => resolve(HEROES), 2000) // 2 seconds
        );
    }

    getHero(id: number): Observable<any>  {
        let response = this.http.get(this.url+"/"+id)
            .map(response => response.json())                                
        // let response =  this.http.get(url).map(res => res).catch(this.handleError);                                 
        return response;
    }

    save(hero: Hero): Observable<any>  {
        if (hero.id) {
        return this.updateHero(hero);
        }
    }

    private updateHero (hero:Hero)    
    {
        let body = JSON.stringify(hero);
        debugger;
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });

        let response = this.http.put(this.url+"/"+hero.id, body, options)
                        .map(response => response.json())
                        .catch(this.handleError);                        
        return response;        
   }

   private handleError (error: any) {
    // In a real world app, we might use a remote logging infrastructure
    // We'd also dig deeper into the error to get a better message
    let errMsg = (error.message) ? error.message :
      error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(errMsg); // log to console instead
    return Observable.throw(errMsg);
  }
}


/*
Copyright 2016 Google Inc. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/