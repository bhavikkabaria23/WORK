"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var mock_heroes_1 = require('./mock-heroes');
var core_1 = require('@angular/core');
var Rx_1 = require('rxjs/Rx');
var http_1 = require('@angular/http');
var http_2 = require('@angular/http');
var HeroService = (function () {
    function HeroService(http) {
        this.http = http;
        this.url = '/api/bears'; // URL to web api    
    }
    HeroService.prototype.getHeroes = function () {
        //return Promise.resolve(HEROES);
        var response = this.http.get(this.url)
            .map(function (response) { return response.json(); });
        //.subscribe(result => this.result = result)                    
        // let response =  this.http.get(url).map(res => res).catch(this.handleError);                                 
        return response;
    };
    // See the "Take it slow" appendix
    HeroService.prototype.getHeroesSlowly = function () {
        return new Promise(function (resolve) {
            return setTimeout(function () { return resolve(mock_heroes_1.HEROES); }, 2000);
        } // 2 seconds
         // 2 seconds
        );
    };
    HeroService.prototype.getHero = function (id) {
        var response = this.http.get(this.url + "/" + id)
            .map(function (response) { return response.json(); });
        // let response =  this.http.get(url).map(res => res).catch(this.handleError);                                 
        return response;
    };
    HeroService.prototype.save = function (hero) {
        if (hero.id) {
            return this.updateHero(hero);
        }
    };
    HeroService.prototype.updateHero = function (hero) {
        var body = JSON.stringify(hero);
        debugger;
        var headers = new http_2.Headers({ 'Content-Type': 'application/json' });
        var options = new http_2.RequestOptions({ headers: headers });
        var response = this.http.put(this.url + "/" + hero.id, body, options)
            .map(function (response) { return response.json(); })
            .catch(this.handleError);
        return response;
    };
    HeroService.prototype.handleError = function (error) {
        // In a real world app, we might use a remote logging infrastructure
        // We'd also dig deeper into the error to get a better message
        var errMsg = (error.message) ? error.message :
            error.status ? error.status + " - " + error.statusText : 'Server error';
        console.error(errMsg); // log to console instead
        return Rx_1.Observable.throw(errMsg);
    };
    HeroService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_1.Http])
    ], HeroService);
    return HeroService;
}());
exports.HeroService = HeroService;
/*
Copyright 2016 Google Inc. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/ 
//# sourceMappingURL=hero.service.js.map