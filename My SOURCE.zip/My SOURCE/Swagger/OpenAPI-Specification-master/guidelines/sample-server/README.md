### Running the sample server

```bash
npm install
node server.js
```
