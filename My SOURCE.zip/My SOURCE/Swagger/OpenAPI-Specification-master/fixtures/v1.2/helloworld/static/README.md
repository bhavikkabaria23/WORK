# Static Hello World Sample Files

This sample project provides the static files to be hosted in your web server, following the Hello World sample described in the [wiki](https://github.com/swagger-api/swagger-spec/wiki/Hello-World-Sample).
