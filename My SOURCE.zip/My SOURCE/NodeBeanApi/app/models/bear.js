var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var TypeSchema = new Schema({    
    typeName: String    
});

var BearSchema = new Schema({    
    name: String,
    age: String,
    type:[TypeSchema]
});

module.exports = mongoose.model('Bear', BearSchema);