﻿using Nop.Core.Infrastructure;
using Shopfast.Plugin.Custom.Models.NopCore.Custom;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using Shopfast.Plugin.Custom.Models.NopAdmin.Vendors;
using Nop.Services.Localization;
using Nop.Data;
using System.Web.Mvc;

namespace Shopfast.Plugin.Custom.Services.Custom
{
    public class CustomCommonService : ICustomCommonService
    {
        #region Fields
        private readonly IDbContext _dbContext;
        private readonly ILocalizationService _localizationService;

        #endregion

        #region Ctor
        public CustomCommonService(
              IDbContext dbContext,
            ILocalizationService localizationService
            )
        {
            this._localizationService = localizationService;                                          
            this._dbContext = dbContext;
        }
        #endregion

        #region Demo site
        public virtual int GetNextRunJobTime(string applicationName)
        {
            var pJobName = EngineContext.Current.Resolve<Nop.Core.Data.IDataProvider>().GetParameter();
            pJobName.ParameterName = "jobname";
            pJobName.Value = applicationName + "_DemoSiteDB";
            pJobName.DbType = DbType.String;

            var jobDetails = EngineContext.Current.Resolve<Nop.Data.IDbContext>().SqlQuery<SQLJobDetails>("sp_job_calculate_next_run_time_min @jobname", pJobName).FirstOrDefault();
            int cntMin = jobDetails.job_next_scheduled_in_min;

            return cntMin;
            //var products2 = _dbContext.ExecuteStoredProcedureList<SQLJobDetails>(
            // "sp_GetSQLJobDetailsForDemoSite",
            // pJobName, pReturnVals);
        }
        #endregion

        #region Vendor Customization - Custom fields
        public virtual VendorModelCustom GetVendorsCustomFields(int vendorId)
        {
            var model =
               _dbContext.SqlQuery<VendorModelCustom>(
                   "select top 1 OfferingSize,IndustryType,AcceptingInvestment from Vendor where id=@p0", vendorId)
                   .FirstOrDefault() ?? new VendorModelCustom();
            model.AvailableAcceptingInvestment.Add(new SelectListItem
            {
                Text = _localizationService.GetResource("AcceptingInvestment.Select"),
                Value = "0"
            });
            model.AvailableAcceptingInvestment.Add(new SelectListItem
            {
                Text = _localizationService.GetResource("AcceptingInvestment.International"),
                Value = "1"
            });
            model.AvailableAcceptingInvestment.Add(new SelectListItem
            {
                Text = _localizationService.GetResource("AcceptingInvestment.Domestic"),
                Value = "2"
            });
            if (Convert.ToInt32(model.AcceptingInvestment) > 0)
            {
                model.AcceptingInvestmentText = model.AvailableAcceptingInvestment.FirstOrDefault(a => a.Value == model.AcceptingInvestment.ToString()).Text;
            }
            return model;
        }

        #endregion
    }
}