﻿using Nop.Core.Data;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.News;
using Nop.Core.Domain.Stores;
using Nop.Core.Infrastructure;
using Nop.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Services
{
    public partial class NewsServiceCustom : INewsServiceCustom
    {

         #region Fields
        
        private readonly IRepository<StoreMapping> _storeMappingRepository;
        private readonly CatalogSettings _catalogSettings;
        private readonly IRepository<NewsItem> _newsItemRepository;

        #endregion

        #region Ctor

        public NewsServiceCustom(
            IRepository<StoreMapping> storeMappingRepository,
            CatalogSettings catalogSettings,
            IRepository<NewsItem> newsItemRepository)
        {            
            this._storeMappingRepository = storeMappingRepository;
            this._catalogSettings = catalogSettings;
            this._newsItemRepository = newsItemRepository;
        }

        #endregion

        #region Additional Methods

        /// <summary>
        /// Gets all news
        /// </summary>
        /// <param name="languageId">Language identifier; 0 if you want to get all records</param>
        /// <param name="storeId">Store identifier; 0 if you want to get all records</param>
        /// <param name="pageIndex">Page index</param>
        /// <param name="pageSize">Page size</param>
        /// <param name="showHidden">A value indicating whether to show hidden records</param>
        /// <returns>News items</returns>
        public virtual List<NewsItem> GetAllNews(int languageId, int storeId, int MainPageNewsCount, bool showHidden = false)
        {
            var query = _newsItemRepository.Table;
            if (languageId > 0)
                query = query.Where(n => languageId == n.LanguageId);
            if (!showHidden)
            {
                var utcNow = DateTime.UtcNow;
                query = query.Where(n => n.Published);
                query = query.Where(n => !n.StartDateUtc.HasValue || n.StartDateUtc <= utcNow);
                query = query.Where(n => !n.EndDateUtc.HasValue || n.EndDateUtc >= utcNow);
            }
            query = query.OrderByDescending(n => n.StartDateUtc ?? n.CreatedOnUtc);

            //Store mapping
            if (storeId > 0 && !_catalogSettings.IgnoreStoreLimitations)
            {
                query = from n in query
                        join sm in _storeMappingRepository.Table
                        on new { c1 = n.Id, c2 = "NewsItem" } equals new { c1 = sm.EntityId, c2 = sm.EntityName } into n_sm
                        from sm in n_sm.DefaultIfEmpty()
                        where !n.LimitedToStores || storeId == sm.StoreId
                        select n;

                //only distinct items (group by ID)
                query = from n in query
                        group n by n.Id
                            into nGroup
                            orderby nGroup.Key
                            select nGroup.FirstOrDefault();
                query = query.OrderByDescending(n => n.StartDateUtc ?? n.CreatedOnUtc);
            }

            return query.Take<NewsItem>(MainPageNewsCount).ToList<NewsItem>();           
        }
        public virtual List<NewsItem> GetAllMainStoreNews(string applicationName, int languageId, int storeId, int MainPageNewsCount)
        {
            DbParameter parameter = EngineContext.Current.Resolve<IDataProvider>().GetParameter();
            parameter.ParameterName = "dbPrefix";
            parameter.Value = applicationName;
            parameter.DbType = DbType.String;
            IDbContext dbContext = EngineContext.Current.Resolve<IDbContext>();
            object[] objArray = new object[] { parameter };
            var query = dbContext.SqlQuery<NewsItem>("Get_News @dbPrefix", objArray);
            if (languageId > 0)
            {
                query =
                    from n in query
                    where languageId == n.LanguageId
                    select n;
            }
            query =
                from n in query
                orderby n.CreatedOnUtc descending
                select n;
            //Store mapping
            if (storeId > 0 && !_catalogSettings.IgnoreStoreLimitations)
            {
                query = from n in query
                        join sm in _storeMappingRepository.Table
                        on new { c1 = n.Id, c2 = "NewsItem" } equals new { c1 = sm.EntityId, c2 = sm.EntityName } into n_sm
                        from sm in n_sm.DefaultIfEmpty()
                        where !n.LimitedToStores || storeId == sm.StoreId
                        select n;

                //only distinct items (group by ID)
                query = from n in query
                        group n by n.Id
                            into nGroup
                            orderby nGroup.Key
                            select nGroup.FirstOrDefault();
                query = query.OrderByDescending(n => n.CreatedOnUtc);
            }

            return query.Take<NewsItem>(MainPageNewsCount).ToList<NewsItem>();
        }
        #endregion

    }
}