﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
//using MessagingToolkit.QRCode.Codec;
using System.Drawing.Imaging;

namespace Shopfast.Plugin.Custom.Helper
{
    public partial class CommonHelperCustom
    {
        /// <summary>
        /// Generate the QR code image based on code string
        /// </summary>
        /// <param name="code"></param>
        /// <param name="IsCodeAsUrl"></param>
        /// <returns></returns>
        public static string GenerateQRCodeImage(string code, bool IsCodeAsUrl = false)
        {
            string pathUrl = string.Empty;
            //QRCodeEncoder encoder = new QRCodeEncoder();
            //Bitmap img = encoder.Encode(code);
            //CreateDirectory("/Content/QRCode");
            //if (IsCodeAsUrl)
            //{
            //    code = "domainURL";
            //}
            //pathUrl = "Content/QRCode/" + DateTime.Now.ToString("yyyyMMdd_hhss") + code + ".jpg";
            //img.Save(HttpContext.Current.Server.MapPath("/Content/QRCode/") + DateTime.Now.ToString("yyyyMMdd_hhss") + code + ".jpg", ImageFormat.Jpeg);
            return pathUrl;
        }

        /// <summary>
        /// Create directory based on path
        /// </summary>
        /// <param name="str">path</param>        
        public static void CreateDirectory(string path)
        {
            if (!Directory.Exists(HttpContext.Current.Server.MapPath(path)))
            {
                Directory.CreateDirectory(HttpContext.Current.Server.MapPath(path));
            }
        }
    }
}