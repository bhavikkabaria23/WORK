﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Nop.Web.Controllers;
using System.Configuration;

namespace Shopfast.Plugin.Custom.Filters.Web
{
    public class GlobalFilterProvider : IFilterProvider
    {
        public IEnumerable<Filter> GetFilters(ControllerContext controllerContext, ActionDescriptor actionDescriptor)
        {

            //if (Convert.ToBoolean(ConfigurationManager.AppSettings["IsNewMultisite"]))
            //{
                if (HttpContext.Current.Request.Url.ToString().Contains("store-registration/?accountid") ||
                    HttpContext.Current.Request.Url.ToString().Contains("store-plan") ||
                    HttpContext.Current.Request.Url.ToString().Contains("store-checkout") ||
                     controllerContext.HttpContext.Request.HttpMethod == "POST" ||
                    controllerContext.IsChildAction)     
                {
                    return new Filter[] { };                   
                }
                else
                {
                    return new[]
                {
                        new Filter(new GlobalFilterAttribute(), FilterScope.Action, null)
                    };
                }
            //}

            //return new Filter[] { };

        }
    }
}