﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Nop.Core.Infrastructure;
using Nop.Data;

namespace Shopfast.Plugin.Custom.Filters.Admin
{
    public class VendorFilterAttribute : ActionFilterAttribute
    {      
        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            var form = filterContext.HttpContext.Request.Unvalidated.Form;
            int vendorId = 0;
            if (filterContext.ActionDescriptor.ActionName.ToLower() == "create")
            {
                vendorId = int.Parse(HttpContext.Current.Session["Admin_VendorController_Create_Vendor_Id"].ToString());
                HttpContext.Current.Session["Admin_VendorController_Create_Vendor_Id"] = null;
            }
            else
            {
                if (form != null)
                {
                    vendorId = int.Parse(form["Id"]);
                }
            }          
            if (vendorId > 0)
            {            
                var dbContext = EngineContext.Current.Resolve<IDbContext>();                

                var OfferingSize = form["OfferingSize"];
                var IndustryType = form["IndustryType"];
                var AcceptingInvestment = form["AcceptingInvestment"];
                dbContext.ExecuteSqlCommand("update Vendor SET OfferingSize=@p0, IndustryType=@p1,AcceptingInvestment=@p2 WHERE id=@p3", false, null,
                   OfferingSize, IndustryType, AcceptingInvestment, vendorId);
            }

        }
    }
}