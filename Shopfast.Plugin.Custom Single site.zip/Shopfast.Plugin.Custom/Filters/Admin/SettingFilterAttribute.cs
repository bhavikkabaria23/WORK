﻿using Nop.Admin.Controllers;
using Nop.Admin.Models.Settings;
using Nop.Core;
using Nop.Core.Data;
using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Services.Configuration;
using Nop.Services.Stores;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Themes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Shopfast.Plugin.Custom.Filters.Admin
{
    public class SettingFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {

        }
        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            if (filterContext.Controller.ControllerContext.HttpContext.Request.HttpMethod == "POST")
            {
                var form = filterContext.HttpContext.Request.Unvalidated.Form;
                if (form != null)
                {

                    //var storeScope = ((SettingController)filterContext.Controller).GetActiveStoreScopeConfiguration(EngineContext.Current.Resolve<IStoreService>(), EngineContext.Current.Resolve<IWorkContext>());

                    //var storeInformationSettings = EngineContext.Current.Resolve <ISettingService>().LoadSetting<StoreInformationSettings>(storeScope);
                    //var p = Expression.Parameter(typeof(StoreInformationSettings), "Person");

                    //var param = Expression.Parameter(typeof(StoreInformationSettings), "p");

                    //Expression parent = Expression.Property(param, "TwitterLink");

                    //if (!parent.Type.IsValueType)
                    //{
                    //    var x1 = Expression.Lambda<Func<StoreInformationSettings, object>>(parent, param).Compile();
                    //}
                    //var convert = Expression.Convert(parent, typeof(object));
                    //var x2 = Expression.Lambda<Func<StoreInformationSettings, object>>(convert, param).Compile();

                    //if (storeScope == 0)
                    //    _settingService.SaveSetting(storeInformationSettings, x => x.DefaultStoreThemeForAdmin, storeScope, false);
                    //else if (storeScope > 0)
                    //    _settingService.DeleteSetting(storeInformationSettings, x => x.DefaultStoreThemeForAdmin, storeScope);

                    var DefaultStoreThemeForAdmin = form["DefaultStoreThemeForAdmin"];
                    var dbContext = EngineContext.Current.Resolve<IDbContext>();
                    int cnt = dbContext.SqlQuery<int>("select count(*) from Setting where Name =@p0", "storeinformationsettings.defaultstorethemeforadmin").FirstOrDefault();
                    if (cnt > 0)
                    {
                        dbContext.ExecuteSqlCommand("update Setting SET Value=@p0 WHERE Name=@p1", false, null,
                        DefaultStoreThemeForAdmin, "storeinformationsettings.defaultstorethemeforadmin");
                    }
                    else
                    {
                        dbContext.ExecuteSqlCommand("insert into Setting (Name,Value,StoreId) VALUES (@p0,@p1,@p2)", false, null,
                        "storeinformationsettings.defaultstorethemeforadmin", DefaultStoreThemeForAdmin, 0);
                    }

                }
            }          
        }
    }
}