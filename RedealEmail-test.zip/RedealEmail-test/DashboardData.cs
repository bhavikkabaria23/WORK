using MongoDB.Driver;
using Microsoft.Extensions.Configuration;
using MongoDB.Bson;
using System;
using System.Globalization;

namespace Redeal.EmailSender
{
    public static class DashboardData
    {
        static IConfiguration config = new ConfigurationBuilder().AddJsonFile("appsettings.json", true, true).Build();
        static string _sConnectionString = config["ConnectionString"];
        static MongoClient _oMongoClient = new MongoClient(_sConnectionString);
        static IMongoDatabase _oIMongoDatabase = _oMongoClient.GetDatabase("Redeal");
        static IMongoCollection<BsonDocument> _oDailyDealImpressions = _oIMongoDatabase.GetCollection<BsonDocument>("DailyDealImpressions");
        static IMongoCollection<BsonDocument> _oRedealCampaignMongoCollection = _oIMongoDatabase.GetCollection<BsonDocument>("Campaigns");

        #region DB Fields

        public static string _sInstantApiCalled = "InstantApiCalled";
        public static string _sInstantImpression = "InstantImpression";
        public static string _sInstantNoDeal = "InstantNoDeal";
        public static string _sInstantExpired = "InstantExpired";
        public static string _sInstantPause = "InstantPause";
        public static string _sInstantError = "InstantError";

        public static string _sTargetApiCalled = "TargetApiCalled";
        public static string _sTargetImpression = "TargetImpression";
        public static string _sTargetNoDeal = "TargetNoDeal";
        public static string _sTargetExpired = "TargetExpired";
        public static string _sTargetPause = "TargetPause";
        public static string _sTargetError = "TargetError";

        public static string _sActionApiCalled = "ActionApiCalled";
        public static string _sActionImpression = "ActionImpression";
        public static string _sActionNoDeal = "ActionNoDeal";
        public static string _sActionExpired = "ActionExpired";
        public static string _sActionPause = "ActionPause";
        public static string _sActionError = "ActionError";

        public static string _sLandingApiCalled = "LandingApiCalled";
        public static string _sLandingImpression = "LandingImpression";
        public static string _sLandingError = "LandingError";

        public static string _sTargetLandingApiCalled = "TargetLandingApiCalled";
        public static string _sTargetLandingImpression = "TargetLandingImpression";
        public static string _sTargetLandingError = "TargetLandingError";

        public static string _sActionLandingApiCalled = "ActionLandingApiCalled";
        public static string _sActionLandingImpression = "ActionLandingImpression";
        public static string _sActionLandingError = "ActionLandingError";

        public static string _sFriendRecallApiCalled = "FriendRecallApiCalled";
        public static string _sFriendRecallImpression = "FriendRecallImpression";
        public static string _sFriendRecallError = "FriendRecallError";

        public static string _sTargetFriendRecallApiCalled = "TargetFriendRecallApiCalled";
        public static string _sTargetFriendRecallImpression = "TargetFriendRecallImpression";
        public static string _sTargetFriendRecallError = "TargetFriendRecallError";

        public static string _sActionFriendRecallApiCalled = "ActionFriendRecallApiCalled";
        public static string _sActionFriendRecallImpression = "ActionFriendRecallImpression";
        public static string _sActionFriendRecallError = "ActionFriendRecallError";

        public static string _sCustomerRecallApiCalled = "CustomerRecallApiCalled";
        public static string _sCustomerRecallImpression = "CustomerRecallImpression";
        public static string _sCustomerRecallError = "CustomerRecallError";

        public static string _sTargetCustomerRecallApiCalled = "TargetCustomerRecallApiCalled";
        public static string _sTargetCustomerRecallImpression = "TargetCustomerRecallImpression";
        public static string _sTargetCustomerRecallError = "TargetCustomerRecallError";

        public static string _sActionCustomerRecallApiCalled = "ActionCustomerRecallApiCalled";
        public static string _sActionCustomerRecallImpression = "ActionCustomerRecallImpression";
        public static string _sActionCustomerRecallError = "ActionCustomerRecallError";

        public static string _sInstantCustomerOptin = "InstantCustomerOptIn";
        public static string _sTargetCustomerOptIn = "TargetCustomerOptIn";
        public static string _sActionCustomerOptIn = "ActionCustomerOptIn";

        public static string _sInstantFriendOptIn = "InstantFriendOptIn";
        public static string _sTargetFriendOptIn = "TargetFriendOptIn";
        public static string _sActionFriendOptIn = "ActionFriendOptIn";

        public static string _sInstantLowCode = "InstantLowCode";
        public static string _sTargetLowCode = "TargetLowCode";
        public static string _sActionLowCode = "ActionLowCode";

        public static string _sInstantSMSReferral = "InstantSMSReferral";
        public static string _sInstantSMSReminder = "InstantSMSReminder";
        public static string _sInstantSMSSaving = "InstantSMSSaving";
        public static string _sInstantSMSFailed = "InstantSMSFailed";
        public static string _sInstantSMSError = "InstantSMSError";

        public static string _sTargetSMSReferral = "TargetSMSReferral";
        public static string _sTargetSMSReminder = "TargetSMSReminder";
        public static string _sTargetSMSSaving = "TargetSMSSaving";
        public static string _sTargetSMSFailed = "TargetSMSFailed";
        public static string _sTargetSMSError = "TargetSMSError";

        public static string _sActionSMSReferral = "ActionSMSReferral";
        public static string _sActionSMSReminder = "ActionSMSReminder";
        public static string _sActionSMSSaving = "ActionSMSSaving";
        public static string _sActionSMSFailed = "ActionSMSFailed";
        public static string _sActionSMSError = "ActionSMSError";

        public static string _sInstantEmailReferral = "InstantEmailReferral";
        public static string _sInstantEmailReminder = "InstantEmailReminder";
        public static string _sInstantEmailSaving = "InstantEmailSaving";
        public static string _sInstantEmailFailed = "InstantEmailFailed";
        public static string _sInstantEmailError = "InstantEmailError";

        public static string _sTargetEmailReferral = "TargetEmailReferral";
        public static string _sTargetEmailReminder = "TargetEmailReminder";
        public static string _sTargetEmailSaving = "TargetEmailSaving";
        public static string _sTargetEmailFailed = "TargetEmailFailed";
        public static string _sTargetEmailError = "TargetEmailError";

        public static string _sActionEmailReferral = "ActionEmailReferral";
        public static string _sActionEmailReminder = "ActionEmailReminder";
        public static string _sActionEmailSaving = "ActionEmailSaving";
        public static string _sActionEmailFailed = "ActionEmailFailed";
        public static string _sActionEmailError = "ActionEmailError";
        #endregion

        #region Common Values
        public static string _sCreatedDate = "CreatedDate";
        public static string _sCreated = "Created";
        public static string _sCampaignId = "CampaignId";

        #endregion
        public static void ParseDashboardData(int _iReferral, int _iReminder, int _iSaving, int _iFailed, int _iError, ObjectId _oCampaignId)
        {
            String _sType = "instant";
            BsonDocument _activeCampaign = GetActiveCampaignDetail(_oCampaignId);
            if (_activeCampaign.AsBsonDocument != BsonNull.Value)
            {
                if (_activeCampaign["IsActionDeal"].AsBoolean == true) _sType = "action";
                else if (_activeCampaign["IsTargetCampaign"].AsBoolean == true) _sType = "target";
            }

            DateTime _dtCurrentDate = DateTime.UtcNow;
            string _sMonthName = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(_dtCurrentDate.Month);
            string _sDate = string.Concat(_dtCurrentDate.Day.ToString(), "-", _sMonthName, "-", _dtCurrentDate.Year.ToString());

            var checkFilter = Builders<BsonDocument>.Filter.Eq(_sCreatedDate, _sDate) & Builders<BsonDocument>.Filter.Eq(_sCampaignId, _oCampaignId);
            if (_oDailyDealImpressions.Find(checkFilter).CountDocuments() > 0)
            {
                _oDailyDealImpressions.UpdateOneAsync(checkFilter, Builders<BsonDocument>.Update
                    .Inc(_sInstantEmailReferral, _sType == "instant" ? _iReferral : 0)
                    .Inc(_sInstantEmailReminder, _sType == "instant" ? _iReminder : 0)
                    .Inc(_sInstantEmailSaving, _sType == "instant" ? _iSaving : 0)
                    .Inc(_sInstantEmailFailed, _sType == "instant" ? _iFailed : 0)
                    .Inc(_sInstantEmailError, _sType == "instant" ? _iError : 0)

                    .Inc(_sTargetEmailReferral, _sType == "target" ? _iReferral : 0)
                    .Inc(_sTargetEmailReminder, _sType == "target" ? _iReminder : 0)
                    .Inc(_sTargetEmailSaving, _sType == "target" ? _iSaving : 0)
                    .Inc(_sTargetEmailFailed, _sType == "target" ? _iFailed : 0)
                    .Inc(_sTargetEmailError, _sType == "target" ? _iError : 0)

                    .Inc(_sActionEmailReferral, _sType == "action" ? _iReferral : 0)
                    .Inc(_sActionEmailReminder, _sType == "action" ? _iReminder : 0)
                    .Inc(_sActionEmailSaving, _sType == "action" ? _iSaving : 0)
                    .Inc(_sActionEmailFailed, _sType == "action" ? _iFailed : 0)
                    .Inc(_sActionEmailError, _sType == "action" ? _iError : 0)
                   );
            }
            else
            {
                #region Insert
                _oDailyDealImpressions.InsertOneAsync(new BsonDocument {
                    {_sInstantApiCalled, 0},
                    {_sInstantImpression, 0},
                    {_sInstantNoDeal, 0},
                    {_sInstantExpired, 0},
                    {_sInstantPause, 0},
                    {_sInstantError, 0},

                    {_sTargetApiCalled, 0},
                    {_sTargetImpression, 0},
                    {_sTargetNoDeal, 0},
                    {_sTargetExpired, 0},
                    {_sTargetPause, 0},
                    {_sTargetError, 0},

                    {_sActionApiCalled, 0},
                    {_sActionImpression, 0},
                    {_sActionNoDeal, 0},
                    {_sActionExpired, 0},
                    {_sActionPause, 0},
                    {_sActionError, 0},

                    {_sLandingApiCalled, 0},
                    {_sLandingImpression, 0},
                    {_sLandingError, 0},

                    {_sTargetLandingApiCalled, 0},
                    {_sTargetLandingImpression, 0},
                    {_sTargetLandingError, 0},

                    {_sActionLandingApiCalled, 0},
                    {_sActionLandingImpression, 0},
                    {_sActionLandingError, 0},

                    {_sFriendRecallApiCalled, 0 },
                    {_sFriendRecallImpression, 0 },
                    {_sFriendRecallError,  0 },
                    {_sTargetFriendRecallApiCalled, 0 },
                    {_sTargetFriendRecallImpression, 0 },
                    {_sTargetFriendRecallError,  0 },
                    {_sActionFriendRecallApiCalled, 0 },
                    {_sActionFriendRecallImpression, 0 },
                    {_sActionFriendRecallError, 0 },

                    {_sCustomerRecallApiCalled, 0 },
                    {_sCustomerRecallImpression, 0 },
                    {_sCustomerRecallError, 0 },
                    {_sTargetCustomerRecallApiCalled, 0 },
                    {_sTargetCustomerRecallImpression, 0 },
                    {_sTargetCustomerRecallError, 0 },
                    {_sActionCustomerRecallApiCalled, 0 },
                    {_sActionCustomerRecallImpression, 0 },
                    {_sActionCustomerRecallError, 0 },

                    {_sActionCustomerOptIn, 0 },
                    {_sTargetCustomerOptIn, 0},
                    {_sInstantCustomerOptin, 0},

                    {_sActionFriendOptIn, 0},
                    {_sTargetFriendOptIn, 0},
                    {_sInstantFriendOptIn, 0},
                    {_sInstantLowCode, 0},
                    {_sTargetLowCode, 0},
                    {_sActionLowCode, 0},

                    {_sInstantSMSReferral, 0},
                    {_sInstantSMSReminder, 0},
                    {_sInstantSMSSaving, 0},
                    {_sInstantSMSFailed, 0},
                    {_sInstantSMSError, 0},

                    {_sTargetSMSReferral, 0},
                    {_sTargetSMSReminder, 0},
                    {_sTargetSMSSaving, 0},
                    {_sTargetSMSFailed, 0},
                    {_sTargetSMSError, 0},

                    {_sActionSMSReferral, 0},
                    {_sActionSMSReminder, 0},
                    {_sActionSMSSaving, 0},
                    {_sActionSMSFailed, 0},
                    {_sActionSMSError, 0},

                    {_sInstantEmailReferral, _sType == "instant" ? _iReferral : 0},
                    {_sInstantEmailReminder, _sType == "instant" ? _iReminder : 0},
                    {_sInstantEmailSaving, _sType == "instant" ? _iSaving : 0},
                    {_sInstantEmailFailed, _sType == "instant" ? _iFailed : 0},
                    {_sInstantEmailError, _sType == "instant" ? _iError : 0},

                    {_sTargetEmailReferral, _sType == "target" ? _iReferral : 0},
                    {_sTargetEmailReminder, _sType == "target" ? _iReminder : 0},
                    {_sTargetEmailSaving, _sType == "target" ? _iSaving : 0},
                    {_sTargetEmailFailed, _sType == "target" ? _iFailed : 0},
                    {_sTargetEmailError, _sType == "target" ? _iError : 0},

                    {_sActionEmailReferral, _sType == "action" ? _iReferral : 0},
                    {_sActionEmailReminder, _sType == "action" ? _iReminder : 0},
                    {_sActionEmailSaving, _sType == "action" ? _iSaving : 0},
                    {_sActionEmailFailed, _sType == "action" ? _iFailed : 0},
                    {_sActionEmailError, _sType == "action" ? _iError : 0},

                    {_sCreatedDate,_sDate },
                    {_sCreated,_dtCurrentDate },
                    {_sCampaignId,_oCampaignId}
                });

                #endregion
            }
        }


        public static BsonDocument GetActiveCampaignDetail(ObjectId _oCampaignId)
        {
            BsonDocument _oCampaign = new BsonDocument();
            var _filterCampaignBuilder = Builders<BsonDocument>.Filter;
            _oCampaign = _oRedealCampaignMongoCollection.Find(_filterCampaignBuilder.Eq("_id", _oCampaignId)).Project<BsonDocument>(Builders<BsonDocument>.Projection.Include(x => x["_id"]).Include(x => x["IsTargetCampaign"]).Include(x => x["IsActionDeal"])).FirstOrDefault();
            return _oCampaign;
        }
    }
}