﻿using Microsoft.Extensions.Configuration;
using MongoDB.Bson;
using MongoDB.Driver;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using SendGrid;
using SendGrid.Helpers.Mail;
using Sentry;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Mail;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web;
using System.Xml;
namespace Redeal.EmailSender
{
    static class Program
    {
        static IConfiguration config = new ConfigurationBuilder().AddJsonFile("appsettings.json", true, true).Build();

        #region Global Variables
        static string MailAccount = config["MailAccount"];
        static string SiteImageUrlBase = config["SiteImageUrlBase"];
        static string CampaignLogSubject = config["CampaignLogSubject"];
        static string CampaignLogBody = config["CampaignLogBody"];
        static string CampaignLogEmails = config["CampaignLogEmails"]; // prod emails
        static string TestCampaignLogEmails = config["TestCampaignLogEmails"]; // test emails
        static string Environment = config["ManagerHost"].ToString().ToLower() == "https://manager.redeal.se" ? "prod" : "test";
        static string DealSoonExpireSubject = config["DealSoonExpireSubject"];
        static string DealSoonExpireBody = config["DealSoonExpireBody"];
        static string ManagerHost = config["ManagerHost"];
        static string _sMailAccount = config["SMailAccount"];
        static string _sCronHubURL = config["CronHubURL"];
        static string _sCronHub = config["CronHub"];
        static string _sCurrentProvider = "sendgrid";
        #endregion

        #region Mongo Collections
        static string _sConnectionString = config["ConnectionString"];
        static MongoClient _oMongoClient = new MongoClient(_sConnectionString);
        static IMongoDatabase _oIMongoDatabase = _oMongoClient.GetDatabase("Redeal");
        static IMongoCollection<BsonDocument> _campaignCollection = _oIMongoDatabase.GetCollection<BsonDocument>("Campaigns");
        static IMongoCollection<BsonDocument> _emailCollection = _oIMongoDatabase.GetCollection<BsonDocument>("Emails");
        static IMongoCollection<BsonDocument> _siteCollection = _oIMongoDatabase.GetCollection<BsonDocument>("Companies");
        static IMongoCollection<BsonDocument> _dailyDetailcollection = _oIMongoDatabase.GetCollection<BsonDocument>("DailyStatisticsDetail");
        static IMongoCollection<BsonDocument> _oFeatureListCollection = _oIMongoDatabase.GetCollection<BsonDocument>("FeatureList");
        #endregion

        #region AWSResourceHelper Variables
        static WebClient _oWebClient = new WebClient();
        static XmlDocument _oXmlDocument = new XmlDocument();
        static string AWSResourcePath = config["AWSResourcePath"];
        static DateTime lastSent = DateTime.MinValue;
        #endregion

        #region SendGrid Templates        
        static string _sCampaignLogTemplateId = config["CampaignLogTemplateId"];
        static string _sCodeSavingEmailTemplateId = config["CodeSavingEmailTemplateId"];
        static string _sLinkInvitationEmailTemplateId = config["LinkInvitationEmailTemplateId"];
        static string _sLowCodeEmailTemplateId = config["LowCodeEmailTemplateId"];
        static string _sLowReferralsTemplateId = config["LowReferralsTemplateId"];
        static string _sLowReferralsExpiredId = config["LowReferralsExpiredId"];
        static string _sReminderEmailTemplateId = config["ReminderEmailTemplateId"];
        #endregion

        static void Main(string[] args)
        {
            while (true)
            {
                TimeSpan timeSinceLastSent = DateTime.Now - lastSent;
                if (timeSinceLastSent.Minutes >= 4 && _sCronHub == "true")
                {
                    lastSent = DateTime.Now;
                    using (HttpClient cons = new HttpClient())
                    {
                        HttpResponseMessage res = cons.GetAsync(_sCronHubURL).Result;
                    }
                }
                GetAndSend();
                Thread.Sleep(200);
            }
        }

        static bool GetAndSend()
        {
            BsonDocument email = new BsonDocument();
            string result2 = "No error";
            BsonDocument campaign = new BsonDocument();
            string _sCompanyName = "null";
            string _sSiteName = "null";
            try
            {
                email = _emailCollection.FindOneAndUpdate(Builders<BsonDocument>.Filter.Where((v => (v["DelayDate"] <= DateTime.Now && v["Type"] != EmailType.ReminderEmail && v["Status"] == EmailStatus.Ready) || (v["Status"] == EmailStatus.Failed && v["Failurs"] < 3))),
                 Builders<BsonDocument>.Update.Set(v => v["Status"], EmailStatus.Sending));
                // email = _emailCollection.Find<BsonDocument>(Builders<BsonDocument>.Filter.Eq(x => x["_id"], ObjectId.Parse("5d0a3e9efb24b00002d5f7f2"))).FirstOrDefault();

                if (email == null)
                {
                    Thread.Sleep(3000);
                    return false;
                }

                if (!email.Contains("IsTestEmail"))
                {
                    email.Add("IsTestEmail", false);
                }

                var _oLEmailId = new ObjectId();
                ObjectId.TryParse(email["_id"].ToRedealString(), out _oLEmailId);

                List<string> emailKeys = new List<string>();
                if (email["AdditionalData"] != null)
                {
                    if (!string.IsNullOrEmpty(email["AdditionalData"]["CampaignId"].ToRedealString()))
                    {
                        var _oLCampaignId = new ObjectId();
                        ObjectId.TryParse(email["AdditionalData"]["CampaignId"].ToRedealString(), out _oLCampaignId);
                        var _oCampaignCondition = Builders<BsonDocument>.Filter.Eq("_id", _oLCampaignId);
                        campaign = _campaignCollection.Find(_oCampaignCondition)
                        .Project<BsonDocument>(Builders<BsonDocument>.Projection
                            .Include(v => v["SiteId"])
                            .Include(v => v["Language"])
                            .Include(v => v["Name"])
                            .Include(v => v["IsTargetCampaign"])
                            .Include(v => v["IsShowEmailCode"])
                            .Include(v => v["Settings"])
                            .Include(v => v["EmailCodeSavingButtonText"])
                            .Include(v => v["EmailLinkInvitationButtonText"])
                            .Include(v => v["EmailReminderButtonText"])
                            .Include(v => v["IsDisableFriendCode"])
                            ).FirstOrDefault();
                    }
                    foreach (var d in email["AdditionalData"].ToBsonDocument())
                    {
                        emailKeys.Add("[" + d.Name + " , " + (d.Value ?? "N/A") + "]");
                    }
                    result2 = string.Join("    ||     ", emailKeys);
                }
                else
                {
                    result2 = "Additional data is null...";
                }

                if (campaign == null && email["Type"] != EmailType.DailyStatistics && email["IsTestEmail"] == false)
                {
                    SetSentStatusAsync(_oLEmailId, EmailStatus.Failed, email["DelayDate"].ToUniversalTime(), email["Failurs"].ToRedealInt32());
                    return false;
                }
                if (email["Type"] != EmailType.DailyStatistics)
                {
                    var emailMessage = PrepareEmailMessage(email, _sConnectionString, campaign);

                    SenGridMail(emailMessage.SendGridEmailProvider);
                    SetSentStatusAsync(_oLEmailId, EmailStatus.Sent, email["DelayDate"].ToUniversalTime(), email["Failurs"].ToRedealInt32());

                    if (email["IsTestEmail"] == false && (email["Type"] == EmailType.LinkInvitationEmail || email["Type"] == EmailType.CodeSaving || email["Type"] == EmailType.ReminderEmail))
                    {
                        #region "Update IsSent Flag into DailyStaticsDetail"

                        #region For Customer
                        if (email["Type"] != EmailType.ReminderEmail)
                        {
                            //FOR CUSTOMER
                            var _customerIdfilter = Builders<BsonDocument>.Filter.Eq("CustomerId", email["UserId"]);
                            var _customerfilter = Builders<BsonDocument>.Filter;
                            var _referCustomerUserfilter = _customerfilter.And(_customerfilter.Eq("CampaignId", campaign["_id"].ToRedealObjectId()),
                                        _customerfilter.ElemMatch("CustomerIds", _customerIdfilter));

                            var _customerupdate = Builders<BsonDocument>.Update;
                            var _referCustomerUserSetSent = _customerupdate.Set(x => x["CustomerIds"][-1]["IsSent"], true).Set(x => x["CustomerIds"][-1]["SentDate"], DateTime.UtcNow);

                            _dailyDetailcollection.UpdateOne(_referCustomerUserfilter, _referCustomerUserSetSent);

                            //FOR FRIEND
                            var _referUserIdfilter = Builders<BsonDocument>.Filter.Eq("ReferUserId", email["UserId"]);
                            if (email["Type"] != EmailType.CodeSaving)
                            {
                                var _referfilter = Builders<BsonDocument>.Filter;
                                var _referUserfilter = _referfilter.And(_referfilter.Eq("CampaignId", campaign["_id"].ToRedealObjectId()),
                                            _referfilter.ElemMatch("Referrals", _referUserIdfilter));

                                var _referupdate = Builders<BsonDocument>.Update;
                                var _referUserSetSent = _referupdate.Set(x => x["Referrals"][-1]["IsSent"], true).Set(x => x["Referrals"][-1]["IsSentDate"], DateTime.UtcNow);

                                _dailyDetailcollection.UpdateOne(_referUserfilter, _referUserSetSent);
                            }

                            if (email["Type"] == EmailType.CodeSaving)
                            {
                                _referUserIdfilter = Builders<BsonDocument>.Filter.Eq("ReferUserId", email["UserId"]);
                                var _friendfilter = Builders<BsonDocument>.Filter;
                                var _referfriendUserfilter = _friendfilter.And(_friendfilter.Eq("CampaignId", campaign["_id"].ToRedealObjectId()),
                                    _friendfilter.ElemMatch("Referrals", _referUserIdfilter));

                                BsonDocument _friendMail = _dailyDetailcollection.Find(_referfriendUserfilter).FirstOrDefault();
                                if (_friendMail != null && _friendMail["_id"] != new ObjectId())
                                {
                                    var _friendupdate = Builders<BsonDocument>.Update;
                                    BsonValue _friendEmails = _friendMail["Referrals"].AsBsonArray.Where(x => x["SavedSent"] == false).FirstOrDefault();
                                    if (_friendEmails != null && _friendEmails["ReferUserId"] != new ObjectId())
                                    {
                                        var _referFriendUserSetSent = _friendupdate.Set(x => x["Referrals"][-1]["SavedSent"], true)
                                        .Set(x => x["Referrals"][-1]["SavedSentDate"], DateTime.UtcNow);
                                        _dailyDetailcollection.UpdateOne(_referfriendUserfilter, _referFriendUserSetSent);
                                    }
                                }
                            }
                        }
                        else if (email["Type"] == EmailType.ReminderEmail)
                        {
                            #region For Customer
                            var _customerIdfilter = Builders<BsonDocument>.Filter.Eq("CustomerId", email["UserId"]);
                            var _remindbyEmailfilter = Builders<BsonDocument>.Filter.Eq("ReminderbyEmail", true);
                            var _customerfilter = Builders<BsonDocument>.Filter;
                            var _referCustomerUserfilter = _customerfilter.And(_customerfilter.Eq("CampaignId", campaign["_id"].ToRedealObjectId()),
                                _customerfilter.ElemMatch("CustomerIds", _customerIdfilter), _customerfilter.ElemMatch("CustomerIds", _remindbyEmailfilter));

                            BsonDocument _firstReminder = _dailyDetailcollection.Find(_referCustomerUserfilter).FirstOrDefault();

                            //FOR FIRST REMINDER
                            if (_firstReminder != null && _firstReminder["_id"] != new ObjectId())
                            {
                                var _customerupdate = Builders<BsonDocument>.Update;
                                BsonValue _firstReminderCustomerIds = _firstReminder["CustomerIds"].AsBsonArray.Where(x => x["FirstReminderSent"] == false && x["SecondReminderSent"] == false && x["CustomerId"] == email["UserId"]).FirstOrDefault();
                                BsonValue _secondReminderCustomerIds = _firstReminder["CustomerIds"].AsBsonArray.Where(x => x["FirstReminderSent"] == true && x["SecondReminderSent"] == false && x["CustomerId"] == email["UserId"]).FirstOrDefault();
                                if (_firstReminderCustomerIds != null && _firstReminderCustomerIds["CustomerId"] != new ObjectId())
                                {
                                    var _referCustomerUserSetSent = _customerupdate.Set(x => x["CustomerIds"][-1]["FirstReminderSent"], true)
                                    .Set(x => x["CustomerIds"][-1]["FirstReminderSentDate"], DateTime.UtcNow);
                                    _dailyDetailcollection.UpdateOne(_referCustomerUserfilter, _referCustomerUserSetSent);
                                }
                                else if (_secondReminderCustomerIds != null && _secondReminderCustomerIds["CustomerId"] != new ObjectId())
                                {
                                    var _referCustomerUserSetSent = _customerupdate.Set(x => x["CustomerIds"][-1]["SecondReminderSent"], true)
                                    .Set(x => x["CustomerIds"][-1]["SecondReminderSentDate"], DateTime.UtcNow);
                                    _dailyDetailcollection.UpdateOne(_referCustomerUserfilter, _referCustomerUserSetSent);
                                }
                            }
                            #endregion

                            #region For Friend

                            var _referUserIdfilter = Builders<BsonDocument>.Filter.Eq("ReferUserId", email["UserId"]);
                            var _friendfilter = Builders<BsonDocument>.Filter;
                            var _referfriendUserfilter = _friendfilter.And(_friendfilter.Eq("CampaignId", campaign["_id"].ToRedealObjectId()),
                                _friendfilter.ElemMatch("Referrals", _referUserIdfilter), _friendfilter.ElemMatch("Referrals", _remindbyEmailfilter));

                            BsonDocument _firstFriendReminder = _dailyDetailcollection.Find(_referfriendUserfilter).FirstOrDefault();

                            //FOR FIRST REMINDER
                            if (_firstFriendReminder != null && _firstFriendReminder["_id"] != new ObjectId())
                            {
                                var _friendupdate = Builders<BsonDocument>.Update;
                                BsonValue _firstReminderFriendIds = _firstFriendReminder["Referrals"].AsBsonArray.Where(x => x["FirstReminderSent"] == false && x["SecondReminderSent"] == false && x["ReferUserId"] == email["UserId"]).FirstOrDefault();
                                BsonValue _secondReminderFriends = _firstFriendReminder["Referrals"].AsBsonArray.Where(x => x["FirstReminderSent"] == true && x["SecondReminderSent"] == false && x["ReferUserId"] == email["UserId"]).FirstOrDefault();
                                if (_firstReminderFriendIds != null && _firstReminderFriendIds["ReferUserId"] != new ObjectId())
                                {
                                    var _referFriendUserSetSent = _friendupdate.Set(x => x["Referrals"][-1]["FirstReminderSent"], true)
                                    .Set(x => x["Referrals"][-1]["FirstReminderSentDate"], DateTime.UtcNow);
                                    _dailyDetailcollection.UpdateOne(_referfriendUserfilter, _referFriendUserSetSent);
                                }
                                else if (_secondReminderFriends != null && _secondReminderFriends["ReferUserId"] != new ObjectId())
                                {
                                    var _referFriendUserSetSent = _friendupdate.Set(x => x["Referrals"][-1]["SecondReminderSent"], true)
                                    .Set(x => x["Referrals"][-1]["SecondReminderSentDate"], DateTime.UtcNow);
                                    _dailyDetailcollection.UpdateOne(_referfriendUserfilter, _referFriendUserSetSent);
                                }
                            }
                            #endregion
                        }
                        #endregion

                        #endregion
                    }
                    _sCompanyName = email["Company"].AsBsonDocument.Contains("Name") ? email["Company"]["Name"].ToRedealString() : string.Empty;
                    _sSiteName = email["Site"].AsBsonDocument.Contains("Name") ? email["Site"]["Name"].ToRedealString() : string.Empty;

                    if (campaign != null)
                    {
                        if (email["IsTestEmail"] == false)
                        {
                            if (email["Type"] == EmailType.LinkInvitationEmail)
                            {
                                DashboardData.ParseDashboardData(1, 0, 0, 0, 0, campaign["_id"].AsObjectId);
                            }
                            else if (email["Type"] == EmailType.CodeSaving)
                            {
                                DashboardData.ParseDashboardData(0, 0, 1, 0, 0, campaign["_id"].AsObjectId);
                            }

                        }

                    }
                }
                else
                {

                    var ReceiverEmails = email["Receiver"].ToString().Split(',');
                    SendGridMessage _oLSendGridMessage = new SendGridMessage();
                    _oLSendGridMessage.EmailId = email["_id"].ToRedealObjectId();
                    _oLSendGridMessage.SGFrom = MailAccount;
                    _oLSendGridMessage.SGSender = MailAccount;
                    _oLSendGridMessage.SGTo.Add(new EmailAddress()
                    {
                        Email = ReceiverEmails[0].ToRedealString(),
                    });
                    if (ReceiverEmails.Count() > 1 && !string.IsNullOrEmpty(ReceiverEmails[1]))
                    {
                        _oLSendGridMessage.SGBcc.Add(new EmailAddress()
                        {
                            Email = ReceiverEmails[1].ToRedealString(),
                        });
                    }
                    _oLSendGridMessage.SGHtmlBody = email["AdditionalData"]["Body"].ToRedealString();
                    _oLSendGridMessage.SGSubject = "Redeal - API Status";
                    SenGridMail(_oLSendGridMessage);
                    SetSentStatusAsync(_oLEmailId, EmailStatus.Sent, email["DelayDate"].ToUniversalTime(), email["Failurs"].ToRedealInt32());

                }
            }
            catch (Exception exception)
            {
                AddLogToDB.AddLog("Email Id :- " + email["_id"].ToRedealObjectId().ToString() + exception.InnerException, "Error");
                String _emailid = email["_id"].ToRedealObjectId().ToString();
                SetSentStatusAsync(email["_id"].ToRedealObjectId(), EmailStatus.Failed, email["DelayDate"].ToUniversalTime(), email["Failurs"].ToRedealInt32());
                if (campaign != null)
                {
                    if (email["IsTestEmail"] == false)
                    {
                        try
                        {
                            DashboardData.ParseDashboardData(0, 0, 0, 1, 1, campaign["_id"].AsObjectId);
                        }
                        catch (Exception ex)
                        {
                            AddLogToDB.AddLog("Email Id :- " + email["_id"].ToRedealObjectId().ToString() + ex.InnerException, "Error");
                        }
                    }
                }
                if (_sCronHub == "true")
                {//error for santry
                    using (SentrySdk.Init("http://4de915a11dae49ba821fd2efeedaf899@sentry.io/1410898"))
                    {

                        SentrySdk.CaptureEvent(new SentryEvent(exception));
                    }

                }

                return false;
            }
            return true;
        }

        static void SetSentStatusAsync(ObjectId id, EmailStatus status, DateTime _dtDelayDate, int _failures)
        {
            var updateBuilder = Builders<BsonDocument>.Update;
            if (status == EmailStatus.Failed)
            {

                if (_failures == 0) _dtDelayDate = _dtDelayDate.AddMinutes(60);
                else if (_failures == 1) _dtDelayDate = _dtDelayDate.AddMinutes(90);
                else if (_failures == 2) _dtDelayDate = _dtDelayDate.AddMinutes(120);
                _emailCollection.FindOneAndUpdate(Builders<BsonDocument>.Filter.Where(v => v["Status"] == EmailStatus.Sending && v["_id"] == id),
                updateBuilder.Combine(updateBuilder.Set(v => v["Status"], EmailStatus.Failed), updateBuilder.Set(v => v["DelayDate"], _dtDelayDate), updateBuilder.Inc(v => v["Failurs"], 1)));
            }
            else if (status == EmailStatus.Sent)
                _emailCollection.FindOneAndUpdate(Builders<BsonDocument>.Filter.Where(v => v["Status"] == EmailStatus.Sending && v["_id"] == id),
                Builders<BsonDocument>.Update.Set(v => v["Status"], status));
        }
        static void SetSendGridResponse(SendGridMessage _pMessage)
        {
            _emailCollection.FindOneAndUpdate(Builders<BsonDocument>.Filter.Where(e => e["Status"] == EmailStatus.Sending && e["_id"] == _pMessage.EmailId),
            Builders<BsonDocument>.Update.Combine(Builders<BsonDocument>.Update.Set(s => s["TrackingId"], _pMessage.TrackingId),
            Builders<BsonDocument>.Update.Set(s => s["SendGridResponse"], _pMessage.SendGridResponse),
            Builders<BsonDocument>.Update.Set(s => s["EmailTemplate"], _pMessage.SGHtmlBody)
            ));
        }

        #region Smtp Utils
        public static EmailMessage PrepareEmailMessage(BsonDocument _oRedealEmail, string _sConnectionString, BsonDocument _oCampaign)
        {
            MailAddress _oFrom = null;
            MailAddress _oSender = null;
            string _sSubject = "";
            string _sTag = string.Empty;
            string _sHtmlBody = "";
            var _oStoreImage = string.Empty;
            String _sSiteEmail = string.Empty;

            if (_oCampaign != null && _oCampaign.Contains("SiteId"))
            {
                if (_oCampaign["SiteId"] != null && _oCampaign["SiteId"] != new ObjectId())
                {
                    var _oCompany = _siteCollection.Find(Builders<BsonDocument>.Filter.ElemMatch("Sites",
                                            Builders<BsonDocument>.Filter.Eq("_id", _oCampaign["SiteId"].ToRedealObjectId()))).Project<BsonDocument>(
                                            Builders<BsonDocument>.Projection.ElemMatch("Sites",
                                            Builders<BsonDocument>.Filter.Eq("_id", _oCampaign["SiteId"].ToRedealObjectId()))).FirstOrDefault();

                    if (_oCompany["Sites"][0].AsBsonDocument.Contains("Email"))
                    {
                        _sSiteEmail = _oCompany["Sites"][0]["Email"].ToRedealString();
                    }
                    else
                    {
                        _sSiteEmail = _oRedealEmail["Company"]["Email"].ToRedealString();
                    }
                }
            }

            if (_oRedealEmail["Type"] != EmailType.LowCodeMail && _oRedealEmail["Type"] != EmailType.LowReferralsMail && _oRedealEmail["Type"] != EmailType.PackageExpiredMail)
                _oStoreImage = GetStoreImage(_oRedealEmail);

            var _oGetCultureFormat = GetCultureFormat(_oRedealEmail["Language"].AsInt32);
            var _oCultureInfo = new CultureInfo(_oGetCultureFormat);

            DateTimeFormatInfo _oDateTimeFormatInfo = _oCultureInfo.DateTimeFormat;
            Dictionary<string, string> _oEmailDictionary = new Dictionary<string, string>();
            _oEmailDictionary = GetResourceList(ResourceType.Email, _oRedealEmail["Language"].AsInt32);

            #region Common Values
            if (_oRedealEmail["Site"] == BsonNull.Value)
            {
                _oRedealEmail["Site"] = new BsonDocument();
            }
            if (_oRedealEmail["Company"] == BsonNull.Value)
            {
                _oRedealEmail["Company"] = new BsonDocument();
            }

            string _sSiteName = _oRedealEmail["Site"].AsBsonDocument.Contains("Name") ? _oRedealEmail["Site"]["Name"].ToRedealString() : string.Empty;

            string _sAdditionalDataURL = _oRedealEmail["AdditionalData"].AsBsonDocument.Contains("URL") ? _oRedealEmail["AdditionalData"]["URL"].ToRedealString() : string.Empty;

            string _sAdditionalDataUrl = _oRedealEmail["AdditionalData"].AsBsonDocument.Contains("Url") ? _oRedealEmail["AdditionalData"]["Url"].ToRedealString() : string.Empty;

            string _sAdditionalDataTerms = _oRedealEmail["AdditionalData"].AsBsonDocument.Contains("Terms") ? _oRedealEmail["AdditionalData"]["Terms"].ToRedealString() : string.Empty;

            string _sAdditionalDataHeaderUserAppeal = _oRedealEmail["AdditionalData"].AsBsonDocument.Contains("HeaderUserAppeal") ? _oRedealEmail["AdditionalData"]["HeaderUserAppeal"].ToRedealString() : string.Empty;

            string _sAdditionalDataNostoScript = _oRedealEmail["AdditionalData"].AsBsonDocument.Contains("NostoScript") ? _oRedealEmail["AdditionalData"]["NostoScript"].ToRedealString() : string.Empty;

            bool _bIsShowEmailCode = false;
            if (_oCampaign != null)
                _bIsShowEmailCode = _oCampaign.Contains("IsShowEmailCode") ? _oCampaign["IsShowEmailCode"].ToRedealBoolean() : false;

            string _sCompanyName = _oRedealEmail["Company"].AsBsonDocument.Contains("Name") ? _oRedealEmail["Company"]["Name"].ToRedealString() : string.Empty;

            string _sCompanyCity = _oRedealEmail["Company"].AsBsonDocument.Contains("City") ? _oRedealEmail["Company"]["City"].ToRedealString() : string.Empty;

            string _sCompanyPhone = _oRedealEmail["Company"].AsBsonDocument.Contains("Phone") ? _oRedealEmail["Company"]["Phone"].ToRedealString() : string.Empty;

            string _sCompanyPostalCode = _oRedealEmail["Company"].AsBsonDocument.Contains("PostalCode") ? _oRedealEmail["Company"]["PostalCode"].ToRedealString() : string.Empty;

            string _sCompanyStreet = _oRedealEmail["Company"].AsBsonDocument.Contains("Street") ? _oRedealEmail["Company"]["Street"].ToRedealString() : string.Empty;

            string _sCompanyEmail = _oRedealEmail["Company"].AsBsonDocument.Contains("Email") ? _oRedealEmail["Company"]["Email"].ToRedealString() : string.Empty;

            string _sSiteEmailSender = _oRedealEmail["Site"].AsBsonDocument.Contains("EmailSender") ? _oRedealEmail["Site"]["EmailSender"].ToRedealString() : string.Empty;

            string _sSiteEmailSubject = _oRedealEmail["Site"].AsBsonDocument.Contains("EmailSubject") ? _oRedealEmail["Site"]["EmailSubject"].ToRedealString() : string.Empty;

            string _sSiteURL = _oRedealEmail["Site"].AsBsonDocument.Contains("URL") ? _oRedealEmail["Site"]["URL"].ToRedealString() : string.Empty;

            string _sAdditionalDataCustomMessage = _oRedealEmail["AdditionalData"].AsBsonDocument.Contains("CustomMessage") ? _oRedealEmail["AdditionalData"]["CustomMessage"].ToRedealString() : string.Empty;

            string _sAdditionalDataTitle = _oRedealEmail["AdditionalData"].AsBsonDocument.Contains("Title") ? _oRedealEmail["AdditionalData"]["Title"].ToRedealString() : string.Empty;

            string _sAdditionalDataBody = _oRedealEmail["AdditionalData"].AsBsonDocument.Contains("Body") ? _oRedealEmail["AdditionalData"]["Body"].ToRedealString() : string.Empty;

            string _sAdditionalDataTermsDelivery = _oRedealEmail["AdditionalData"].AsBsonDocument.Contains("TermsDelivery") ? _oRedealEmail["AdditionalData"]["TermsDelivery"].ToRedealString() : string.Empty;

            string _sAdditionalDataSenderName = _oRedealEmail["AdditionalData"].AsBsonDocument.Contains("SenderName") ? _oRedealEmail["AdditionalData"]["SenderName"].ToRedealString() : string.Empty;

            string _sAdditionalDataSubject = _oRedealEmail["AdditionalData"].AsBsonDocument.Contains("Subject") ? _oRedealEmail["AdditionalData"]["Subject"].ToRedealString() : string.Empty;

            string _sAdditionalDataCampaignUrl = _oRedealEmail["AdditionalData"].AsBsonDocument.Contains("CampaignUrl") ? _oRedealEmail["AdditionalData"]["CampaignUrl"].ToRedealString() : string.Empty;

            string _sAdditionalDataCampaignName = _oRedealEmail["AdditionalData"].AsBsonDocument.Contains("CampaignName") ? _oRedealEmail["AdditionalData"]["CampaignName"].ToRedealString() : string.Empty;

            string _sAdditionalDataDescription = _oRedealEmail["AdditionalData"].AsBsonDocument.Contains("Description") ? _oRedealEmail["AdditionalData"]["Description"].ToRedealString() : string.Empty;

            string _sAdditionalDataActionBy = _oRedealEmail["AdditionalData"].AsBsonDocument.Contains("ActionBy") ? _oRedealEmail["AdditionalData"]["ActionBy"].ToRedealString() : string.Empty;

            string _sAdditionalDataExpiryDate = _oRedealEmail["AdditionalData"].AsBsonDocument.Contains("ExpiryDate") ? _oRedealEmail["AdditionalData"]["ExpiryDate"].ToRedealString() : string.Empty;

            string _sEmailCodeSavingButtonText, _sEmailLinkInvitationButtonText, _sEmailReminderButtonText;
            _sEmailCodeSavingButtonText = _sEmailLinkInvitationButtonText = _sEmailReminderButtonText = "GET YOUR CODE";

            if (_oCampaign != null)
            {
                if (_oCampaign.Contains("EmailCodeSavingButtonText"))
                {
                    _sEmailCodeSavingButtonText = (!string.IsNullOrEmpty(_oCampaign["EmailCodeSavingButtonText"].ToRedealString())) ? _oCampaign["EmailCodeSavingButtonText"].ToRedealString() : _sEmailCodeSavingButtonText;
                }
                if (_oCampaign.Contains("EmailLinkInvitationButtonText"))
                {
                    _sEmailLinkInvitationButtonText = (!string.IsNullOrEmpty(_oCampaign["EmailLinkInvitationButtonText"].ToRedealString())) ? _oCampaign["EmailLinkInvitationButtonText"].ToRedealString() : _sEmailLinkInvitationButtonText;
                }
                if (_oCampaign.Contains("EmailReminderButtonText"))
                {
                    _sEmailReminderButtonText = (!string.IsNullOrEmpty(_oCampaign["EmailReminderButtonText"].ToRedealString())) ? _oCampaign["EmailReminderButtonText"].ToRedealString() : _sEmailReminderButtonText;
                }
            }

            #endregion
            bool _bIsLowCodeEmail = false;
            switch (_oRedealEmail["Type"].ToEmailTypeEnum())
            {
                case EmailType.CodeSaving:
                    var _oCodeSavingEmailModel = new CodeSavingEmailModel
                    {
                        StoreName = _sSiteName,
                        StoreImage = _oStoreImage,
                        CampaignImage = GetCampaignImage(_oRedealEmail, _sConnectionString),
                        EmailButtonBackgroundColor = SetBackgrounColor(_oRedealEmail, _oCampaign),
                        EmailButtonTextColor = SetTextColor(_oRedealEmail, _oCampaign),
                        StoreUrl = _sAdditionalDataURL,
                        Codes = new List<EmailCodeInfo>(),
                        Terms = _sAdditionalDataTerms,
                        HeaderUserAppeal = _sAdditionalDataHeaderUserAppeal,
                        NostoScript = _sAdditionalDataNostoScript,
                        IsShowCode = _bIsShowEmailCode,
                        Company = new EmailCompanyInfo
                        {
                            CompanyName = _sCompanyName,
                            CompanyCity = _sCompanyCity,
                            CompanyPhone = _sCompanyPhone,
                            CompanyPostalCode = _sCompanyPostalCode,
                            CompanyStreet = _sCompanyStreet,
                            Email = _sSiteEmail
                        },
                        ResourceEmailText = new ResourceEmailTextModel
                        {
                            CodeSaving_TitleOne = _oEmailDictionary["CodeSaving_TitleOne"].ToRedealString(),
                            Hi = _oEmailDictionary["Hi"].ToRedealString(),
                            CodeSaving_TextOne = _oEmailDictionary["CodeSaving_TextOne"].ToRedealString(),
                            CodeSaving_CallToAction = _sEmailCodeSavingButtonText,
                            NeedHelp = _oEmailDictionary["NeedHelp"].ToRedealString(),
                            Reminder_UseThisCode = _oEmailDictionary["Reminder_UseThisCode"].ToRedealString(),
                            CodeSaving_ValueOfCodeIs = _oEmailDictionary["CodeSaving_ValueOfCodeIs"].ToRedealString(),
                            CodeSaving_AndExpires = _oEmailDictionary["CodeSaving_AndExpires"].ToRedealString()
                        },
                    };

                    if (_oCodeSavingEmailModel.IsShowCode)
                    {
                        foreach (var code in _oRedealEmail["Codes"].AsBsonArray)
                        {
                            if (!string.IsNullOrEmpty(code["ExpirationDateString"].ToRedealString()))
                            {
                                try
                                {
                                    code["ExpirationDate"] = GetCountryDate(_oRedealEmail["Language"].AsInt32, code["ExpirationDateString"].ToRedealString());
                                }
                                catch
                                {
                                    code["ExpirationDate"] = SplitDate(code["ExpirationDate"].ToRedealString(), _oRedealEmail, _oCampaign);
                                }
                            }
                            else
                            {
                                if (!CheckMonthNameExist(code["ExpirationDate"].ToRedealString()))
                                {
                                    try
                                    {
                                        DateTime _dtCultureDate = Convert.ToDateTime(code["ExpirationDate"].ToRedealString());
                                        string monthName = new CultureInfo(_oCultureInfo.Name).DateTimeFormat.GetMonthName(_dtCultureDate.Month);
                                        code["ExpirationDate"] = string.Concat(_dtCultureDate.Day, " ", monthName, " ", _dtCultureDate.Year);
                                    }
                                    catch
                                    {
                                        code["ExpirationDate"] = SplitDate(code["ExpirationDate"].ToRedealString(), _oRedealEmail, _oCampaign);
                                    }
                                }
                                else
                                {
                                    code["ExpirationDate"] = SplitDate(code["ExpirationDate"].ToRedealString(), _oRedealEmail, _oCampaign);
                                }
                            }
                            _oCodeSavingEmailModel.Codes.Add(new EmailCodeInfo
                            {
                                Code = code["Code"].ToRedealString(),
                                Pin = code["Pin"].ToRedealString(),
                                ExpirationDate = code["ExpirationDate"].ToRedealString(),
                                ValueAmount = string.IsNullOrWhiteSpace(code["Value"].ToRedealString()) ? string.Empty : string.Format("{0}", code["Value"].ToRedealString()),
                                IsActual = code["IsActual"].ToRedealBoolean()
                            });

                            if (code["Code"].ToRedealString() == "0" && _oCampaign.ToRedealBsonValue("IsDisableFriendCode") != BsonNull.Value && _oCampaign["IsDisableFriendCode"].ToRedealBoolean() == true)
                            {
                                _oCodeSavingEmailModel.IsShowCode = false;
                            }
                        }
                    }

                    _oFrom = new MailAddress(_sCompanyEmail, _sSiteEmailSender);
                    _oSender = new MailAddress(_sCompanyEmail, _sSiteEmailSender);
                    _sSubject = _sSiteEmailSubject;
                    _sTag = "StoringCode";
                    System.Threading.Thread.CurrentThread.CurrentUICulture = new CultureInfo(_oGetCultureFormat, false);
                    _sHtmlBody = EmailBuilder<CodeSavingEmailModel>.GetBodyAsHtml(_oCodeSavingEmailModel, _sCodeSavingEmailTemplateId, EmailType.CodeSaving, _oRedealEmail["_id"].ToRedealString());
                    break;
                case EmailType.LinkInvitationEmail:
                    var codeValue = string.Empty;
                    var expirationDate = string.Empty;
                    var customMessage = string.Empty;
                    customMessage = _sAdditionalDataCustomMessage;

                    var inviteBody = new LinkInvitationEmailModel
                    {
                        CodeValue = codeValue,
                        ExpirationDate = expirationDate,
                        Url = _sAdditionalDataUrl,
                        StoreName = _sSiteName,
                        StoreImage = _oStoreImage,
                        CampaignImage = GetCampaignImage(_oRedealEmail, _sConnectionString),
                        EmailButtonBackgroundColor = SetBackgrounColor(_oRedealEmail, _oCampaign),
                        EmailButtonTextColor = SetTextColor(_oRedealEmail, _oCampaign),
                        StoreUrl = _sSiteURL,
                        Terms = _sAdditionalDataTerms,
                        Title = _sAdditionalDataTitle,
                        BodyText = _sAdditionalDataBody,
                        HeaderUserAppeal = _sAdditionalDataHeaderUserAppeal,
                        NostoScript = _sAdditionalDataNostoScript,
                        TermsDelivery = _sAdditionalDataTermsDelivery,
                        Company = new EmailCompanyInfo
                        {
                            CompanyName = _sCompanyName,
                            CompanyCity = _sCompanyCity,
                            CompanyPhone = _sCompanyPhone,
                            CompanyPostalCode = _sCompanyPostalCode,
                            CompanyStreet = _sCompanyStreet,
                            Email = _sSiteEmail
                        },
                        ResourceEmailText = new ResourceEmailTextModel
                        {
                            LinkInvitation_CallToAction = _sEmailLinkInvitationButtonText,
                            NeedHelp = _oEmailDictionary["NeedHelp"].ToRedealString()
                        },
                        CustomMessage = customMessage
                    };

                    if (!string.IsNullOrEmpty(customMessage))
                        inviteBody.BodyText = string.Empty;

                    _oFrom = new MailAddress(MailAccount, _sAdditionalDataSenderName);
                    _oSender = new MailAddress(MailAccount, _sAdditionalDataSenderName);
                    _sSubject = _sAdditionalDataSubject;
                    _sTag = "FriendInvitation";
                    System.Threading.Thread.CurrentThread.CurrentUICulture = new CultureInfo(_oGetCultureFormat, false);
                    _sHtmlBody = EmailBuilder<LinkInvitationEmailModel>.GetBodyAsHtml(inviteBody, _sLinkInvitationEmailTemplateId, EmailType.LinkInvitationEmail, _oRedealEmail["_id"].ToRedealString());
                    break;
                case EmailType.ReminderEmail:
                    var reminderModel = new CodeSavingEmailModel
                    {
                        UserName = _oRedealEmail["ReceiverName"].ToRedealString(),
                        StoreName = _sSiteName,
                        StoreImage = _oStoreImage,
                        CampaignImage = GetCampaignImage(_oRedealEmail, _sConnectionString),
                        EmailButtonBackgroundColor = SetBackgrounColor(_oRedealEmail, _oCampaign),
                        EmailButtonTextColor = SetTextColor(_oRedealEmail, _oCampaign),
                        StoreUrl = _oRedealEmail["IsTestEmail"] == true ? _sAdditionalDataUrl : _sSiteURL,
                        Codes = new List<EmailCodeInfo>(),
                        Terms = _sAdditionalDataTerms,
                        HeaderUserAppeal = _sAdditionalDataHeaderUserAppeal,
                        NostoScript = _sAdditionalDataNostoScript,
                        CustomMessage = _sAdditionalDataCustomMessage,
                        IsShowCode = _bIsShowEmailCode,
                        Company = new EmailCompanyInfo
                        {
                            CompanyName = _sCompanyName,
                            CompanyCity = _sCompanyCity,
                            CompanyPhone = _sCompanyPhone,
                            CompanyPostalCode = _sCompanyPostalCode,
                            CompanyStreet = _sCompanyStreet,
                            Email = _sSiteEmail
                        },
                        ResourceEmailText = new ResourceEmailTextModel
                        {
                            Reminder_Title = _oEmailDictionary["Reminder_Title"].ToRedealString(),
                            Hi = _oEmailDictionary["Hi"].ToRedealString(),
                            Reminder_CallToAction = _sEmailReminderButtonText,
                            NeedHelp = _oEmailDictionary["NeedHelp"].ToRedealString(),
                            Reminder_UseThisCode = _oEmailDictionary["Reminder_UseThisCode"].ToRedealString(),
                            Reminder_ValueOfCodeIs = _oEmailDictionary["Reminder_ValueOfCodeIs"].ToRedealString(),
                            Reminder_AndExpires = _oEmailDictionary["Reminder_AndExpires"].ToRedealString()
                        },
                    };

                    if (reminderModel.IsShowCode)
                    {
                        if (_oRedealEmail["Codes"] != null)
                        {
                            foreach (var code in _oRedealEmail["Codes"].AsBsonArray)
                            {
                                if (!string.IsNullOrEmpty(code["ExpirationDateString"].ToRedealString()))
                                {
                                    try
                                    {
                                        code["ExpirationDate"] = GetCountryDate(_oRedealEmail["Language"].AsInt32, code["ExpirationDateString"].ToRedealString());
                                    }
                                    catch
                                    {
                                        code["ExpirationDate"] = SplitDate(code["ExpirationDate"].ToRedealString(), _oRedealEmail, _oCampaign);
                                    }
                                }
                                else
                                {
                                    if (!CheckMonthNameExist(code["ExpirationDate"].ToRedealString()))
                                    {
                                        try
                                        {
                                            DateTime _dtCultureDate = Convert.ToDateTime(code["ExpirationDate"].ToRedealString());
                                            string monthName = new CultureInfo(_oCultureInfo.Name).DateTimeFormat.GetMonthName(_dtCultureDate.Month);
                                            code["ExpirationDate"] = string.Concat(_dtCultureDate.Day, " ", monthName, " ", _dtCultureDate.Year);
                                        }
                                        catch
                                        {
                                            code["ExpirationDate"] = SplitDate(code["ExpirationDate"].ToRedealString(), _oRedealEmail, _oCampaign);
                                        }
                                    }
                                    else
                                    {
                                        code["ExpirationDate"] = SplitDate(code["ExpirationDate"].ToRedealString(), _oRedealEmail, _oCampaign);
                                    }
                                }
                                reminderModel.Codes.Add(new EmailCodeInfo
                                {
                                    Code = code["Code"].ToRedealString(),
                                    Pin = code["Pin"].ToRedealString(),
                                    ExpirationDate = code["ExpirationDate"].ToRedealString(),
                                    ValueAmount = string.IsNullOrWhiteSpace(code["Value"].ToRedealString()) ? string.Empty : string.Format("{0}", code["Value"].ToRedealString()),
                                    IsActual = code["IsActual"].ToRedealBoolean()
                                });
                            }
                        }
                    }

                    _oFrom = new MailAddress(_sCompanyEmail, _sSiteEmailSender);
                    _oSender = new MailAddress(_sCompanyEmail, _sSiteEmailSender);
                    _sSubject = _sSiteEmailSubject;
                    _sTag = "RemindEmail";
                    System.Threading.Thread.CurrentThread.CurrentUICulture = new CultureInfo(_oGetCultureFormat, false);
                    _sHtmlBody = EmailBuilder<CodeSavingEmailModel>.GetBodyAsHtml(reminderModel, _sReminderEmailTemplateId, EmailType.ReminderEmail, _oRedealEmail["_id"].ToRedealString());
                    break;
                case EmailType.DealLogEmail:
                    var _oCampaignLogModel = new CampaignLogModel()
                    {
                        CustomMessage = CampaignLogBody,
                        CampaignUrl = _sAdditionalDataCampaignUrl,
                        CampaignName = _sAdditionalDataCampaignName,
                        Description = _sAdditionalDataDescription,
                        ActionBy = _sAdditionalDataActionBy,
                        Created = _oRedealEmail["Created"].ToUniversalTime(),
                        SiteName = _sSiteName,
                        CompanyName = _sCompanyName
                    };
                    _sSubject = CampaignLogSubject;
                    _oFrom = new MailAddress(MailAccount);
                    _oSender = new MailAddress(MailAccount);
                    _oRedealEmail["Receiver"] = SetEmailReceiver(_oRedealEmail, _oCampaign);
                    _sHtmlBody = EmailBuilder<CampaignLogModel>.GetBodyAsHtml(_oCampaignLogModel, _sCampaignLogTemplateId, EmailType.DealLogEmail, _oRedealEmail["_id"].ToRedealString());
                    break;
                case EmailType.DealSoonExpireEmail:
                    _oCampaignLogModel = new CampaignLogModel()
                    {
                        CampaignUrl = _sAdditionalDataCampaignUrl,
                        CampaignName = _sAdditionalDataCampaignName,
                        Description = _sAdditionalDataDescription,
                        ActionBy = _sAdditionalDataActionBy,
                        Created = _oRedealEmail["Created"].ToUniversalTime(),
                        ExpiryDate = _sAdditionalDataExpiryDate,
                        SiteName = _sSiteName,
                        CompanyName = _sCompanyName
                    };
                    _oCampaignLogModel.CustomMessage = (!string.IsNullOrEmpty(DealSoonExpireBody)) ? string.Format(DealSoonExpireBody, _oCampaignLogModel.CampaignName, _oCampaignLogModel.ExpiryDate) : DealSoonExpireBody;
                    _sSubject = DealSoonExpireSubject;
                    _oFrom = new MailAddress(MailAccount);
                    _oSender = new MailAddress(MailAccount);
                    _oRedealEmail["Receiver"] = SetEmailReceiver(_oRedealEmail, _oCampaign);
                    _sHtmlBody = EmailBuilder<CampaignLogModel>.GetBodyAsHtml(_oCampaignLogModel, _sCampaignLogTemplateId, EmailType.DealSoonExpireEmail, _oRedealEmail["_id"].ToRedealString());
                    break;
                case EmailType.LowCodeMail:
                    _bIsLowCodeEmail = true;
                    var mailModel = new LowCodeCampaignModel
                    {
                        CampaignId = _oRedealEmail["AdditionalData"].AsBsonDocument.Contains("CampaignId") ? _oRedealEmail["AdditionalData"]["CampaignId"].ToRedealString() : string.Empty,
                        Deal = _oRedealEmail["AdditionalData"].AsBsonDocument.Contains("Deal") ? _oRedealEmail["AdditionalData"]["Deal"].ToRedealString() : string.Empty,
                        CompanyName = _oRedealEmail["AdditionalData"].AsBsonDocument.Contains("CompanyName") ? _oRedealEmail["AdditionalData"]["CompanyName"].ToRedealString() : string.Empty,
                        Site = _oRedealEmail["AdditionalData"].AsBsonDocument.Contains("Site") ? _oRedealEmail["AdditionalData"]["Site"].ToRedealString() : string.Empty
                    };
                    _sSubject = "Your codes are running low for " + _oCampaign["Name"].ToRedealString();
                    _oFrom = new MailAddress(MailAccount);
                    _oSender = new MailAddress(MailAccount);
                    _sHtmlBody = EmailBuilder<LowCodeCampaignModel>.GetBodyAsHtml(mailModel, _sLowCodeEmailTemplateId, EmailType.LowCodeMail, _oRedealEmail["_id"].ToRedealString());
                    break;
                case EmailType.LowReferralsMail:
                    var LowReferralmailModel = new LowCodeCampaignModel
                    {
                        CampaignId = _oRedealEmail["AdditionalData"].AsBsonDocument.Contains("CampaignId") ? _oRedealEmail["AdditionalData"]["CampaignId"].ToRedealString() : string.Empty,
                        Deal = _oRedealEmail["AdditionalData"].AsBsonDocument.Contains("Deal") ? _oRedealEmail["AdditionalData"]["Deal"].ToRedealString() : string.Empty,
                        CompanyName = _oRedealEmail["AdditionalData"].AsBsonDocument.Contains("CompanyName") ? _oRedealEmail["AdditionalData"]["CompanyName"].ToRedealString() : string.Empty,
                        Site = _oRedealEmail["AdditionalData"].AsBsonDocument.Contains("Site") ? _oRedealEmail["AdditionalData"]["Site"].ToRedealString() : string.Empty
                    };
                    _sSubject = "Referral Limit Is Approaching, Only 10% Remain " + LowReferralmailModel.Site.ToRedealString();
                    _oFrom = new MailAddress(MailAccount);
                    _oSender = new MailAddress(MailAccount);
                    _sHtmlBody = EmailBuilder<LowCodeCampaignModel>.GetBodyAsHtml(LowReferralmailModel, _sLowReferralsTemplateId, EmailType.LowReferralsMail, _oRedealEmail["_id"].ToRedealString());
                    break;
                case EmailType.PackageExpiredMail:
                    var PackageExpiremailModel = new LowCodeCampaignModel
                    {
                        CampaignId = _oRedealEmail["AdditionalData"].AsBsonDocument.Contains("CampaignId") ? _oRedealEmail["AdditionalData"]["CampaignId"].ToRedealString() : string.Empty,
                        Deal = _oRedealEmail["AdditionalData"].AsBsonDocument.Contains("Deal") ? _oRedealEmail["AdditionalData"]["Deal"].ToRedealString() : string.Empty,
                        CompanyName = _oRedealEmail["AdditionalData"].AsBsonDocument.Contains("CompanyName") ? _oRedealEmail["AdditionalData"]["CompanyName"].ToRedealString() : string.Empty,
                        Site = _oRedealEmail["AdditionalData"].AsBsonDocument.Contains("Site") ? _oRedealEmail["AdditionalData"]["Site"].ToRedealString() : string.Empty
                    };
                    _sSubject = "The Referral Service Is Temporarily Deactivated " + PackageExpiremailModel.Site.ToRedealString();
                    _oFrom = new MailAddress(MailAccount);
                    _oSender = new MailAddress(MailAccount);
                    _sHtmlBody = EmailBuilder<LowCodeCampaignModel>.GetBodyAsHtml(PackageExpiremailModel, _sLowReferralsExpiredId, EmailType.PackageExpiredMail, _oRedealEmail["_id"].ToRedealString());
                    break;
            }
            EmailMessage _oLEmailMessage = new EmailMessage();

            SendGridMessage _oLSendGrid = new SendGridMessage();
            _oLSendGrid.EmailId = _oRedealEmail["_id"].ToRedealObjectId();
            _oLSendGrid.SGFrom = MailAccount;
            _oLSendGrid.SGSender = _oSender.DisplayName;
            _oLSendGrid.SGSubject = _sSubject;
            _oLSendGrid.SGTo.Add(new EmailAddress()
            {
                Email = _oRedealEmail["Receiver"].ToRedealString()
            });
            if (_bIsLowCodeEmail)
            {
                _oLSendGrid.SGTo.Add(new EmailAddress()
                {
                    Email = config["LowCodeReceiver"]
                });
            }
            _oLSendGrid.SGPlainText = "Redeal email body";
            _oLSendGrid.SGHtmlBody = _sHtmlBody;
            _oLEmailMessage.SendGridEmailProvider = _oLSendGrid;


            return _oLEmailMessage;
        }
        public static void SenGridMail(SendGridMessage _pMessage)
        {
            var _oClient = new SendGridClient(config["SendGridApiKey"]);
            var _sFrom = new EmailAddress(_pMessage.SGFrom, _pMessage.SGSender);
            var _oMessage = MailHelper.CreateSingleEmailToMultipleRecipients(_sFrom, _pMessage.SGTo, _pMessage.SGSubject, _pMessage.SGPlainText, _pMessage.SGHtmlBody);
            // Stop tracking click from body and show the priginal link.
            _oMessage.SetClickTracking(false, true);
            var _oResponse = _oClient.SendEmailAsync(_oMessage).Result;
            if (_oResponse != null)
            {
                IEnumerable<string> _lLValues;
                if (_oResponse.Headers.TryGetValues("X-Message-Id", out _lLValues) && _lLValues != null && _lLValues.Any())
                {
                    _pMessage.TrackingId = _lLValues.FirstOrDefault();
                }
                _pMessage.SendGridResponse = JsonConvert.SerializeObject(_oResponse);
                SetSendGridResponse(_pMessage);
            }
        }

        static string GetStoreImage(BsonDocument email)
        {
            if (email["Site"].AsBsonDocument.Contains("Image"))
                return HttpUtility.UrlPathEncode(string.Format("{0}/Images/Logos/{1}", SiteImageUrlBase, email["Site"]["Image"].ToRedealString()));
            else
                return string.Empty;
        }

        static string GetCampaignImage(BsonDocument email, string _connectionString)
        {
            var campaignImage = "";
            string campaignId = "";
            if (email["AdditionalData"].AsBsonDocument.Contains("HeaderImage"))
            {
                campaignImage = email["AdditionalData"]["HeaderImage"].ToRedealString();
                campaignImage = HttpUtility.UrlPathEncode(string.Format("{0}{1}", SiteImageUrlBase, campaignImage.Replace(@"\", "/")));
            }

            if (!string.IsNullOrEmpty(email["AdditionalData"]["CampaignId"].ToRedealString()))
            {
                campaignId = email["AdditionalData"]["CampaignId"].ToRedealString();
            }
            if (string.IsNullOrEmpty(campaignImage) && !string.IsNullOrEmpty(campaignId))
            {
                var _oCampaignCondition = Builders<BsonDocument>.Filter.Eq("_id", campaignId.ToRedealObjectId());
                var campaign = _campaignCollection.Find(_oCampaignCondition)
                .Project<BsonDocument>(Builders<BsonDocument>.Projection
                    .Include(v => v["Settings"]["FriendHeaderImage"])
                    .Include(v => v["Settings"]["HeaderImage"])
                    .Include(v => v["Settings"]["FriendHeaderImage"])).FirstOrDefault();

                if (campaign != null)
                {
                    string _sFriendHeaderImage = campaign["Settings"]["FriendHeaderImage"].ToRedealString();
                    string _sHeaderImage = campaign["Settings"]["HeaderImage"].ToRedealString();

                    if (email["Type"] == EmailType.LinkInvitationEmail && !string.IsNullOrEmpty(_sFriendHeaderImage))
                        _sHeaderImage = _sFriendHeaderImage;

                    if (!string.IsNullOrEmpty(_sHeaderImage))
                        campaignImage = HttpUtility.UrlPathEncode(string.Format("{0}{1}", SiteImageUrlBase, _sHeaderImage.Replace(@"\", "/")));
                }
            }
            return campaignImage;
        }

        static string SetBackgrounColor(BsonDocument email, BsonDocument campaign)
        {
            if (campaign != null && campaign.Contains("Settings"))
            {
                if (campaign["Settings"].AsBsonDocument.Contains("PopupButtonBackgroundColor"))
                    return campaign["Settings"]["PopupButtonBackgroundColor"].ToRedealString();
            }
            return string.Empty;
        }

        static string SetTextColor(BsonDocument email, BsonDocument campaign)
        {
            if (campaign != null && campaign.Contains("Settings"))
            {
                if (campaign["Settings"].AsBsonDocument.Contains("PopupButtonTextColor"))
                    return campaign["Settings"]["PopupButtonTextColor"].ToRedealString();
            }

            return string.Empty;
        }
        static bool CheckMonthNameExist(String _sDate)
        {
            _sDate = _sDate.Replace("PM", "").Replace("AM", "");
            if (Regex.Matches(_sDate, @"[a-zA-Z]").Count > 0)
                return true;
            else
                return false;
        }
        static string SplitDate(string dateString, BsonDocument _oRedealEmail, BsonDocument _oCampaign)
        {
            string finalDate = dateString;
            try
            {
                if (!string.IsNullOrEmpty(dateString))
                {
                    var dateArray = dateString.Split(':');
                    if (dateArray != null && dateArray.Length > 0)
                    {
                        int idx = dateArray[0].LastIndexOf(' ');
                        finalDate = dateArray[0].Substring(0, idx);
                    }
                }
            }
            catch (Exception)
            {
            }
            return finalDate;
        }
        static string SetEmailReceiver(BsonDocument _pEmail, BsonDocument _pCampaign)
        {
            List<string> _lReceivers = new List<string>();
            string _sCampaignLogEmails = string.Empty;
            if (Environment == "prod") // for pro 
            {
                bool IsExcludeByAdmin = false;
                var _bCampaignSettings = _pCampaign.ToRedealBsonValue("Settings");
                if (_bCampaignSettings != null && !_bCampaignSettings.IsBsonNull)
                {
                    IsExcludeByAdmin = _bCampaignSettings.ToRedealBsonValue("IsExcludeByAdmin").ToRedealBoolean();
                }
                if (IsExcludeByAdmin)
                {
                    _sCampaignLogEmails = TestCampaignLogEmails;
                }
                else
                {
                    _sCampaignLogEmails = CampaignLogEmails;
                }
            }
            else // for test or dev
            {
                _sCampaignLogEmails = TestCampaignLogEmails;
            }
            if (!string.IsNullOrEmpty(_sCampaignLogEmails))
            {
                string[] _aEmails = _sCampaignLogEmails.Split(',');
                foreach (var e in _aEmails)
                {
                    _lReceivers.Add(e);
                }
            }
            string _sReceiver = _pEmail["Receiver"].ToRedealString();
            _pEmail["Receiver"] = String.Join(",", _lReceivers.ToArray());
            if (!string.IsNullOrEmpty(_sReceiver))
            {
                _pEmail["Receiver"] = String.Join(",", _pEmail["Receiver"], _sReceiver);
            }
            return _pEmail["Receiver"].ToRedealString();
        }
        #endregion

        #region AWS Resource Helper

        static Dictionary<string, string> GetResourceList(ResourceType _oResourceType, int _oLanguage)
        {
            Dictionary<string, string> _oDictionary = new Dictionary<string, string>();
            try
            {
                GetXmlDocument(_oResourceType, _oLanguage);

                XmlNodeList resources = _oXmlDocument.SelectNodes("root/data");
                List<string> _lstList = new List<string>();

                foreach (XmlNode node in resources)
                {
                    _oDictionary.Add(node.Attributes[0].Value, node.InnerText.Trim());
                }
            }
            catch (Exception)
            {
            }
            return _oDictionary;
        }

        static void GetXmlDocument(ResourceType _oResourceType, int _oLanguage)
        {
            String _oValueTo = String.Empty;
            string _oPath = AWSResourcePath;
            _oPath = String.Format(_oPath, GetBranch(_oResourceType), GetLanguageCode(_oLanguage));
            Stream _oStream = _oWebClient.OpenRead(_oPath);
            StreamReader _oStreamReader = new StreamReader(_oStream);
            String _oContent = _oStreamReader.ReadToEnd();
            _oXmlDocument.LoadXml(_oContent);
        }

        static string GetBranch(ResourceType _oResourceType)
        {
            switch (_oResourceType)
            {
                case ResourceType.Branch:
                    return "Branch";
                case ResourceType.Popup:
                    return "Popup";
                case ResourceType.Email:
                    return "Email";
                case ResourceType.Sms:
                    return "Sms";
                default:
                    return null;
            }
        }

        static string GetLanguageCode(int _oLanguage)
        {
            return LanguageHelper.GetPOEditorCodeFromValue(_oLanguage);
        }
        #endregion

        #region Common Methods
        public static string GetCultureFormat(int language)
        {
            return LanguageHelper.GetCultureFromValue(language);
        }
        static string GetCountryDate(int language, string dateString)
        {
            DateTime date = DateTime.ParseExact(dateString, "d-M-yyyy", null);
            return date.ToString("dd MMMM yyyy", new CultureInfo(GetCultureFormat(language)));
        }
        #endregion

        #region Extension
        public static string ToRedealString(this object _value)
        {
            if (_value != BsonNull.Value)
            {
                if (string.IsNullOrEmpty(Convert.ToString(_value)))
                    return string.Empty;
                else
                    return Convert.ToString(_value);
            }
            return string.Empty;
        }
        public static Int32 ToRedealInt32(this object _value)
        {
            if (_value.ToRedealString() == null && string.IsNullOrEmpty(_value.ToRedealString()))
                return 0;
            else
                return Convert.ToInt32(_value.ToRedealString());
        }
        public static Boolean ToRedealBoolean(this object _value)
        {
            Boolean _oBoolean;
            string _valueString = _value.ToRedealString();
            if (string.IsNullOrEmpty(_valueString))
                _oBoolean = false;
            else
            {
                if ((_valueString.ToLower() == "true") || (_valueString.ToLower() == "false"))
                    _oBoolean = Convert.ToBoolean(_valueString);
                else
                    Boolean.TryParse(_valueString, out _oBoolean);
            }
            return _oBoolean;
        }
        public static ObjectId ToRedealObjectId(this object _value)
        {
            return ObjectId.Parse(_value.ToRedealString());
        }
        public static EmailType ToEmailTypeEnum(this object _value)
        {
            EmailType _oEmailType;
            Enum.TryParse(_value.ToRedealString(), out _oEmailType);
            return _oEmailType;
        }
        public static BsonValue ToRedealBsonValue(this BsonDocument _pBson, string _sField)
        {
            if (_pBson != null && !_pBson.IsBsonNull && _pBson.Contains(_sField))
            {
                return _pBson[_sField];
            }
            return BsonNull.Value;
        }

        public static BsonValue ToRedealBsonValue(this BsonValue _pBson, string _sField)
        {
            if (_pBson != null && !_pBson.IsBsonNull && _pBson.ToBsonDocument().Contains(_sField))
            {
                return _pBson[_sField];
            }
            return BsonNull.Value;
        }
        #endregion

        #region Add Log To Database
        public static class AddLogToDB
        {
            static IConfiguration config = new ConfigurationBuilder().AddJsonFile("appsettings.json", true, true).Build();
            static string _sConnectionString = config["ConnectionString"];
            static MongoClient _oMongoClient = new MongoClient(_sConnectionString);
            static IMongoDatabase _oIMongoDatabase = _oMongoClient.GetDatabase("Redeal");
            static IMongoCollection<ServicesStatus> _ServicesStatusCollection = _oIMongoDatabase.GetCollection<ServicesStatus>("ServicesStatus");
            public static void AddLog(String _sError, String _sType = null)
            {
                var _dLCompareDate = DateTime.UtcNow.AddDays(-7);
                var _ServicesStatusCondition = Builders<ServicesStatus>.Filter.Where(s => s.ServiceType == "EmailSender" && s.ServiceCheckDate <= _dLCompareDate);
                _ServicesStatusCollection.DeleteMany(_ServicesStatusCondition);

                var _dLCompareDate1 = DateTime.UtcNow.AddMinutes(-10);
                var _ServicesStatusCondition1 = Builders<ServicesStatus>.Filter.Where(s => s.ServiceType == "EmailSender" && s.ServiceCheckDate <= _dLCompareDate1 && s.Error == "Running");
                _ServicesStatusCollection.DeleteMany(_ServicesStatusCondition1);

                if (!string.IsNullOrEmpty(_sError))
                {
                    _ServicesStatusCollection.InsertOne(new ServicesStatus
                    {
                        ServiceType = "EmailSender",
                        ServiceStatus = _sType == null ? "Live" : _sType,
                        ServiceCheckDate = DateTime.UtcNow,
                        Error = _sError
                    });
                }
            }
        }
        #endregion

        #region Entities
        public class ServicesStatus
        {
            public ObjectId Id { get; set; }
            public String ServiceType { get; set; }//Reminder, SMS, Email
            public String ServiceStatus { get; set; }//Live , Error
            public DateTime ServiceCheckDate { get; set; }
            public String Error { get; set; }

        }
        #endregion
    }


    #region Enums
    public enum EmailType
    {
        CodeSaving,
        ActivateCampaignEmail,
        NotificationCampaignEmail,
        EmailFriendInvitation,
        LinkInvitationEmail,
        ReminderEmail,
        LowCodeMail,
        DealLogEmail,
        DealSoonExpireEmail,
        DailyStatistics,
        LowReferralsMail,
        PackageExpiredMail
    }
    public enum EmailStatus
    {
        Ready,
        Sending,
        Failed,
        Sent,
        WaitingNews
    }
    public enum Language
    {
        sv,
        en,
        no,
        ru,
        fi,
        da,
        de,
        fr,
        nl,
        pl,
        ja,
        ko,
        cs,
        it,
        es,
        zhcn
    }

    public enum ResourceType
    {
        Branch,
        Popup,
        Email,
        Sms
    }
    #endregion

    #region Email Models
    public class CampaignLogModel
    {
        public CampaignLogModel()
        {
            Fields = new List<FieldSet>();
        }
        public string CampaignName { get; set; }
        public ObjectId CampaignId { get; set; }
        public string Action { get; set; }
        public string ActionBy { get; set; }
        public string Description { get; set; }
        public DateTime Created { get; set; }
        public bool CampaignDeleted { get; set; }
        public string CustomMessage { get; set; }
        public string CampaignUrl { get; set; }
        public string ExpiryDate { get; set; }
        public List<FieldSet> Fields { get; set; }
        public string SiteName { get; set; }
        public string CompanyName { get; set; }
    }
    public class FieldSet
    {
        public string FieldName { get; set; }
        public string OldValue { get; set; }
        public string NewValue { get; set; }
    }
    public class LinkInvitationEmailModel
    {
        public string Title { get; set; }

        public string BodyText { get; set; }

        public string UserName { get; set; }

        public string StoreName { get; set; }

        public string StoreImage { get; set; }

        public string CampaignImage { get; set; }

        public string StoreUrl { get; set; }

        public EmailCompanyInfo Company { get; set; }

        public EmailStaticContent StaticContent { get; set; }

        public string CodeValue { get; set; }

        public string ExpirationDate { get; set; }

        public string Terms { get; set; }

        public string Url { get; set; }

        public string HeaderUserAppeal { get; set; }

        public string NostoScript { get; set; }

        public string TermsDelivery { get; set; }

        public string CustomMessage { get; set; }

        public string EmailButtonBackgroundColor { get; set; }

        public string EmailButtonTextColor { get; set; }

        public ResourceEmailTextModel ResourceEmailText { get; set; }
    }
    public class ResourceEmailTextModel
    {
        public string CodeSaving_TitleOne { get; set; }
        public string Hi { get; set; }
        public string CodeSaving_TextOne { get; set; }
        public string CodeSaving_CallToAction { get; set; }
        public string NeedHelp { get; set; }
        public string LinkInvitation_CallToAction { get; set; }
        public string Reminder_Title { get; set; }
        public string Reminder_CallToAction { get; set; }
        public string Reminder_UseThisCode { get; set; }
        public string CodeSaving_ValueOfCodeIs { get; set; }
        public string CodeSaving_AndExpires { get; set; }
        public string Reminder_ValueOfCodeIs { get; set; }
        public string Reminder_AndExpires { get; set; }
    }
    public class CodeSavingEmailModel
    {
        public string UserName { get; set; }

        public string StoreName { get; set; }

        public string StoreImage { get; set; }

        public string CampaignImage { get; set; }

        public string StoreUrl { get; set; }

        public List<EmailCodeInfo> Codes { get; set; }

        public EmailCompanyInfo Company { get; set; }

        public EmailStaticContent StaticContent { get; set; }

        public string Terms { get; set; }

        public string HeaderUserAppeal { get; set; }

        public string NostoScript { get; set; }

        public string CustomMessage { get; set; }

        public string EmailButtonBackgroundColor { get; set; }

        public string EmailButtonTextColor { get; set; }

        public ResourceEmailTextModel ResourceEmailText { get; set; }

        public bool IsShowCode { get; set; }
    }
    public class EmailCompanyInfo
    {
        public string CompanyName { get; set; }

        public string CompanyStreet { get; set; }

        public string CompanyCity { get; set; }

        public string CompanyPostalCode { get; set; }

        public string CompanyPhone { get; set; }

        public string Email { get; set; }
    }
    public class EmailCodeInfo
    {
        public string Code { get; set; }

        public string Pin { get; set; }

        public string ValueAmount { get; set; }

        public string ExpirationDate { get; set; }

        public bool IsActual { get; set; }
    }
    public class EmailStaticContent
    {
        public string GreetingTitle { get; set; }

        public string GreetingDescription { get; set; }

        public string WellcomeText { get; set; }
    }
    public class LowCodeCampaignModel
    {
        public string CampaignId { get; set; }

        public string CompanyName { get; set; }

        public string Site { get; set; }

        public string Deal { get; set; }
    }

    public class EmailMessage
    {
        public EmailMessage()
        {
            GmailEmailProvider = new MailMessage();
            SendGridEmailProvider = new SendGridMessage();
        }
        public MailMessage GmailEmailProvider { get; set; }
        public SendGridMessage SendGridEmailProvider { get; set; }

    }
    public class SendGridMessage
    {
        public SendGridMessage()
        {
            SGTo = new List<EmailAddress>();
            SGBcc = new List<EmailAddress>();
        }
        public ObjectId EmailId { get; set; }
        public string SGFrom { get; set; }
        public string SGSender { get; set; }
        public string SGSubject { get; set; }
        public List<EmailAddress> SGTo { get; set; }
        public List<EmailAddress> SGBcc { get; set; }
        public string SGPlainText { get; set; }
        public string SGHtmlBody { get; set; }
        public string TrackingId { get; set; }
        public string SendGridResponse { get; set; }
    }
    #endregion

    #region Email Body Builder

    public static class EmailBuilder<T> where T : class
    {
        static IConfiguration config = new ConfigurationBuilder().AddJsonFile("appsettings.json", true, true).Build();
        private readonly static string EmailTemplatePath = config["EmailTemplatePath"];
        static String SiteImageUrlBase = config["SiteImageUrlBase"];
        static String _sImageHost = config["ImageHost"];
        static String _sWebURL = config["webURL"];
        static string _sSendGridApiUrl = config["SendGridApiUrl"];
        static string _sViewInBrowser = config["ViewInBrowser"];
        static string _sViewInBrowserUrl = config["ViewInBrowserUrl"];

        public static string GetBodyAsHtml(T model, string _pTemplateId, EmailType _oEmailType, string _pEmailId)
        {
            var emailBody = string.Empty;
            WebClient _oWebClient = new WebClient();

            try
            {
                if (model == null)
                    throw new NullReferenceException("the model is null or empty!");

                string _oPath = EmailTemplatePath;
                String _sTemplate = string.Empty;
                try
                {
                    using (var client = new HttpClient())
                    {
                        client.BaseAddress = new Uri(_sSendGridApiUrl);
                        client.DefaultRequestHeaders.Accept.Clear();
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", config["SendGridApiKey"]);
                        HttpRequestMessage req = new HttpRequestMessage(HttpMethod.Get, "v3/templates/" + _pTemplateId);
                        HttpResponseMessage httpRequest = client.SendAsync(req, HttpCompletionOption.ResponseContentRead).Result;
                        var _oResult = JObject.Parse(httpRequest.Content.ReadAsStringAsync().Result);
                        if (_oResult != null)
                        {
                            var _lLSenfGridTemplateVersions = _oResult.GetValue("versions").ToList();
                            if (_lLSenfGridTemplateVersions != null && _lLSenfGridTemplateVersions.Any() && _lLSenfGridTemplateVersions[0] != null)
                            {
                                _sTemplate = _lLSenfGridTemplateVersions[0].SelectToken("html_content").ToString();
                            }
                        }

                    }
                }
                catch (Exception)
                {
                    return emailBody;
                }
                emailBody = ReplaceToken(model, _sTemplate, _oEmailType, _pEmailId);

                var pm = new PreMailer.Net.PreMailer(emailBody);
                var result = pm.MoveCssInline();

                if (!string.IsNullOrEmpty(result.Html))
                    emailBody = result.Html;
            }
            catch (Exception)
            {
            }

            return emailBody;
        }

        static string ReplaceToken(T model, string _pTemplate, EmailType _pType, string _pEmailId)
        {
            if (_pType == EmailType.CodeSaving)
            {
                #region Code Saving Email 
                CodeSavingEmailModel _oCodeSavingEmailModel = (CodeSavingEmailModel)Convert.ChangeType(model, typeof(CodeSavingEmailModel));
                string _sTitle = string.Empty;
                string _sCampaignImageClass = "hide-section", _sStoreImageClass = "hide-section", _sNostoScriptClass = "hide-section";
                string _sTermsClass = "hide-section", _sHiClass = "hide-section", _sIsShowCodeClass = "hide-section";

                if (!string.IsNullOrEmpty(_oCodeSavingEmailModel.HeaderUserAppeal))
                {
                    _sTitle = _oCodeSavingEmailModel.HeaderUserAppeal;
                    _sHiClass = string.Empty;
                }
                else
                    _sTitle = _oCodeSavingEmailModel.ResourceEmailText.CodeSaving_TitleOne;

                if (!string.IsNullOrEmpty(_oCodeSavingEmailModel.CampaignImage))
                    _sCampaignImageClass = string.Empty;
                if (!string.IsNullOrEmpty(_oCodeSavingEmailModel.StoreImage))
                    _sStoreImageClass = string.Empty;
                if (!string.IsNullOrEmpty(_oCodeSavingEmailModel.NostoScript))
                    _sNostoScriptClass = string.Empty;
                if (!string.IsNullOrEmpty(_oCodeSavingEmailModel.Terms))
                    _sTermsClass = string.Empty;
                if (_oCodeSavingEmailModel.IsShowCode == true)
                    _sIsShowCodeClass = string.Empty;

                _oCodeSavingEmailModel.EmailButtonBackgroundColor = (!string.IsNullOrEmpty(_oCodeSavingEmailModel.EmailButtonBackgroundColor)) ?
                _oCodeSavingEmailModel.EmailButtonBackgroundColor :
                "#4F993D";
                _oCodeSavingEmailModel.EmailButtonTextColor = (!string.IsNullOrEmpty(_oCodeSavingEmailModel.EmailButtonTextColor))
                ? _oCodeSavingEmailModel.EmailButtonTextColor :
                "#ffffff";
                var nostowidth = (!string.IsNullOrEmpty(_oCodeSavingEmailModel.NostoScript)) ? "Width:auto !important;" : "";

                _pTemplate =
                    _pTemplate.Replace("{{_sTitle}}", _sTitle).
                    Replace("{{_sCampaignImageClass}}", _sCampaignImageClass).
                    Replace("{{_sCampaignImage}}", _oCodeSavingEmailModel.CampaignImage).
                    Replace("{{_sStoreImageClass}}", _sStoreImageClass).
                    Replace("{{_sStoreImage}}", _oCodeSavingEmailModel.StoreImage).
                    Replace("{{_snostowidth}}", nostowidth).
                    Replace("{{_sHiClass}}", _sHiClass).
                    Replace("{{_sResourceEmailText_Hi}}", _oCodeSavingEmailModel.ResourceEmailText.Hi).
                    Replace("{{_sResourceEmailText_CodeSaving_TextOne}}", string.Format(_oCodeSavingEmailModel.ResourceEmailText.CodeSaving_TextOne, _oCodeSavingEmailModel.StoreName)).
                    Replace("{{_sIsShowCodeClass}}", _sIsShowCodeClass).
                    Replace("{{_sEmailText_Reminder_UseThisCode}}", _oCodeSavingEmailModel.ResourceEmailText.Reminder_UseThisCode).
                    Replace("{{_sCode}}", _oCodeSavingEmailModel.IsShowCode == true ? _oCodeSavingEmailModel.Codes.FirstOrDefault().Code : string.Empty).
                    Replace("{{_sEmailText_CodeSaving_ValueOfCodeIs}}", _oCodeSavingEmailModel.ResourceEmailText.CodeSaving_ValueOfCodeIs).
                    Replace("{{_sValueAmount}}", _oCodeSavingEmailModel.IsShowCode == true ? _oCodeSavingEmailModel.Codes.FirstOrDefault().ValueAmount : string.Empty).
                    Replace("{{_sEmailText_CodeSaving_AndExpires}}", _oCodeSavingEmailModel.ResourceEmailText.CodeSaving_AndExpires).
                    Replace("{{_sExpirationDate}}", _oCodeSavingEmailModel.IsShowCode == true ? _oCodeSavingEmailModel.Codes.FirstOrDefault().ExpirationDate : string.Empty).
                    Replace("{{_sNostoScriptClass}}", _sNostoScriptClass).
                    Replace("{{_sNostoScript}}", _oCodeSavingEmailModel.NostoScript).
                    Replace("{{_sEmailButtonTextColor}}", _oCodeSavingEmailModel.EmailButtonTextColor).
                    Replace("{{_sEmailButtonBackgroundColor}}", _oCodeSavingEmailModel.EmailButtonBackgroundColor).
                    Replace("{{_sStoreUrl}}", _oCodeSavingEmailModel.StoreUrl).
                    Replace("{{_sResourceEmailText_CodeSaving_CallToAction}}", _oCodeSavingEmailModel.ResourceEmailText.CodeSaving_CallToAction).
                    Replace("{{_sTermsClass}}", _sTermsClass).
                    Replace("{{_sTerms}}", _oCodeSavingEmailModel.Terms).
                    Replace("{{_sResourceEmailText_NeedHelp}}", _oCodeSavingEmailModel.ResourceEmailText.NeedHelp).
                    Replace("{{_sCompany_CompanyName}}", _oCodeSavingEmailModel.Company.CompanyName).
                    Replace("{{_sCompany_Email}}", _oCodeSavingEmailModel.Company.Email).
                    Replace("{{_sImageHost}}", SiteImageUrlBase);
                #endregion
            }
            else if (_pType == EmailType.LinkInvitationEmail)
            {
                #region Link Invitation Email
                LinkInvitationEmailModel _oLinkInvitationEmailModel = (LinkInvitationEmailModel)Convert.ChangeType(model, typeof(LinkInvitationEmailModel));
                string _sTitle = string.Empty;
                string _sCampaignImageClass = "hide-section", _sStoreImageClass = "hide-section", _sNostoScriptClass = "hide-section";
                string _sTermsClass = "hide-section", _sHiClass = "hide-section", _sCustomMessageClass = "hide-section";
                string _sBodyTextClass = "hide-section", _sTermsDeliveryClass = "hide-section";

                if (!string.IsNullOrEmpty(_oLinkInvitationEmailModel.HeaderUserAppeal))
                {
                    _sTitle = _oLinkInvitationEmailModel.HeaderUserAppeal;
                    _sHiClass = String.Empty;
                }
                else
                    _sTitle = _oLinkInvitationEmailModel.Title;

                if (!string.IsNullOrEmpty(_oLinkInvitationEmailModel.CampaignImage))
                    _sCampaignImageClass = String.Empty;
                if (!string.IsNullOrEmpty(_oLinkInvitationEmailModel.StoreImage))
                    _sStoreImageClass = String.Empty;
                if (!string.IsNullOrEmpty(_oLinkInvitationEmailModel.BodyText))
                    _sBodyTextClass = "";
                if (!string.IsNullOrEmpty(_oLinkInvitationEmailModel.CustomMessage))
                    _sCustomMessageClass = String.Empty;
                if (!string.IsNullOrEmpty(_oLinkInvitationEmailModel.NostoScript))
                    _sNostoScriptClass = String.Empty;
                if (!string.IsNullOrEmpty(_oLinkInvitationEmailModel.Terms))
                    _sTermsClass = String.Empty;
                if (!string.IsNullOrEmpty(_oLinkInvitationEmailModel.TermsDelivery))
                    _sTermsDeliveryClass = String.Empty;

                _oLinkInvitationEmailModel.EmailButtonBackgroundColor = (!string.IsNullOrEmpty(_oLinkInvitationEmailModel.EmailButtonBackgroundColor))
                                                                        ? _oLinkInvitationEmailModel.EmailButtonBackgroundColor : "#4F993D";
                _oLinkInvitationEmailModel.EmailButtonTextColor = (!string.IsNullOrEmpty(_oLinkInvitationEmailModel.EmailButtonTextColor))
                                                                ? _oLinkInvitationEmailModel.EmailButtonTextColor : "#ffffff";
                var nostowidth = (!string.IsNullOrEmpty(_oLinkInvitationEmailModel.NostoScript)) ? "Width:auto !important;" : "";

                _pTemplate = _pTemplate.Replace("{{_sTitle}}", _sTitle).
                    Replace("{{_sTitle1}}", _oLinkInvitationEmailModel.Title).
                    Replace("{{_sCampaignImageClass}}", _sCampaignImageClass).
                    Replace("{{_sCampaignImage}}", _oLinkInvitationEmailModel.CampaignImage).
                    Replace("{{_sStoreImageClass}}", _sStoreImageClass).
                    Replace("{{_sStoreImage}}", _oLinkInvitationEmailModel.StoreImage).
                    Replace("{{_snostowidth}}", nostowidth).
                    Replace("{{_sHiClass}}", _sHiClass).
                    Replace("{{_sBodyTextClass}}", _sBodyTextClass).
                    Replace("{{_sBodyText}}", _oLinkInvitationEmailModel.BodyText).
                    Replace("{{_sCustomMessageClass}}", _sCustomMessageClass).
                    Replace("{{_sCustomMessage}}", _oLinkInvitationEmailModel.CustomMessage).
                    Replace("{{_sNostoScriptClass}}", _sNostoScriptClass).
                    Replace("{{_sNostoScript}}", _oLinkInvitationEmailModel.NostoScript).
                    Replace("{{_sEmailButtonTextColor}}", _oLinkInvitationEmailModel.EmailButtonTextColor).
                    Replace("{{_sEmailButtonBackgroundColor}}", _oLinkInvitationEmailModel.EmailButtonBackgroundColor).
                    Replace("{{_sResourceEmailText_LinkInvitation_CallToAction}}", _oLinkInvitationEmailModel.ResourceEmailText.LinkInvitation_CallToAction).
                    Replace("{{_sUrl}}", _oLinkInvitationEmailModel.Url).
                    Replace("{{_sTermsClass}}", _sTermsClass).
                    Replace("{{_sTerms}}", _oLinkInvitationEmailModel.Terms).
                    Replace("{{_sTermsDeliveryClass}}", _sTermsDeliveryClass).
                    Replace("{{_sTermsDelivery}}", _oLinkInvitationEmailModel.TermsDelivery).
                    Replace("{{_sResourceEmailText_NeedHelp}}", _oLinkInvitationEmailModel.ResourceEmailText.NeedHelp).
                    Replace("{{_sCompany_CompanyName}}", _oLinkInvitationEmailModel.Company.CompanyName).
                    Replace("{{_sCompany_Email}}", _oLinkInvitationEmailModel.Company.Email).
                    Replace("{{_sImageHost}}", SiteImageUrlBase);
                #endregion
            }
            else if (_pType == EmailType.ReminderEmail)
            {
                #region Reminder Email
                CodeSavingEmailModel _oCodeSavingEmailModel = (CodeSavingEmailModel)Convert.ChangeType(model, typeof(CodeSavingEmailModel));
                string _sCampaignImageClass = "hide-section", _sStoreImageClass = "hide-section", _sCustomMessageClass = "hide-section";
                string _sNostoScriptClass = "hide-section", _sTermsClass = "hide-section", _sIsShowCodeClass = "hide-section";

                if (!string.IsNullOrEmpty(_oCodeSavingEmailModel.CampaignImage))
                    _sCampaignImageClass = string.Empty;
                if (!string.IsNullOrEmpty(_oCodeSavingEmailModel.StoreImage))
                    _sStoreImageClass = string.Empty;
                if (!string.IsNullOrEmpty(_oCodeSavingEmailModel.CustomMessage))
                    _sCustomMessageClass = string.Empty;
                if (!string.IsNullOrEmpty(_oCodeSavingEmailModel.NostoScript))
                    _sNostoScriptClass = string.Empty;
                if (!string.IsNullOrEmpty(_oCodeSavingEmailModel.Terms))
                    _sTermsClass = string.Empty;
                if (_oCodeSavingEmailModel.IsShowCode == true)
                    _sIsShowCodeClass = string.Empty;

                _oCodeSavingEmailModel.EmailButtonBackgroundColor = (!string.IsNullOrEmpty(_oCodeSavingEmailModel.EmailButtonBackgroundColor)) ?
                                                                    _oCodeSavingEmailModel.EmailButtonBackgroundColor : "#4F993D";
                _oCodeSavingEmailModel.EmailButtonTextColor = (!string.IsNullOrEmpty(_oCodeSavingEmailModel.EmailButtonTextColor)) ?
                                                            _oCodeSavingEmailModel.EmailButtonTextColor : "#ffffff";
                var nostowidth = (!string.IsNullOrEmpty(_oCodeSavingEmailModel.NostoScript)) ? "Width:auto !important;" : "";

                _pTemplate = _pTemplate.Replace("{{_sResourceEmailText_Reminder_Title}}", _oCodeSavingEmailModel.ResourceEmailText.Reminder_Title).
                            Replace("{{_sCampaignImageClass}}", _sCampaignImageClass).
                            Replace("{{_sCampaignImage}}", _oCodeSavingEmailModel.CampaignImage).
                            Replace("{{_sStoreImageClass}}", _sStoreImageClass).
                            Replace("{{_sStoreImage}}", _oCodeSavingEmailModel.StoreImage).
                            Replace("{{_snostowidth}}", nostowidth).
                            Replace("{{_sResourceEmailText_Hi}}", _oCodeSavingEmailModel.ResourceEmailText.Hi).
                            Replace("{{_sCustomMessageClass}}", _sCustomMessageClass).
                            Replace("{{_sCustomMessage}}", _oCodeSavingEmailModel.CustomMessage).
                            Replace("{{_sIsShowCodeClass}}", _sIsShowCodeClass).
                            Replace("{{_sEmailText_Reminder_UseThisCode}}", _oCodeSavingEmailModel.ResourceEmailText.Reminder_UseThisCode).
                            Replace("{{_sCode}}", _oCodeSavingEmailModel.IsShowCode == true ? _oCodeSavingEmailModel.Codes.FirstOrDefault().Code : string.Empty).
                            Replace("{{_sEmailText_Reminder_ValueOfCodeIs}}", _oCodeSavingEmailModel.ResourceEmailText.Reminder_ValueOfCodeIs).
                            Replace("{{_sValueAmount}}", _oCodeSavingEmailModel.IsShowCode == true ? _oCodeSavingEmailModel.Codes.FirstOrDefault().ValueAmount : string.Empty).
                            Replace("{{_sEmailText_Reminder_AndExpires}}", _oCodeSavingEmailModel.ResourceEmailText.Reminder_AndExpires).
                            Replace("{{_sExpirationDate}}", _oCodeSavingEmailModel.IsShowCode == true ? _oCodeSavingEmailModel.Codes.FirstOrDefault().ExpirationDate : string.Empty).
                            Replace("{{_sNostoScriptClass}}", _sNostoScriptClass).
                            Replace("{{_sNostoScript}}", _oCodeSavingEmailModel.NostoScript).
                            Replace("{{_sEmailButtonTextColor}}", _oCodeSavingEmailModel.EmailButtonTextColor).
                            Replace("{{_sEmailButtonBackgroundColor}}", _oCodeSavingEmailModel.EmailButtonBackgroundColor).
                            Replace("{{_sStoreUrl}}", _oCodeSavingEmailModel.StoreUrl).
                            Replace("{{_sResourceEmailText_Reminder_CallToAction}}", _oCodeSavingEmailModel.ResourceEmailText.Reminder_CallToAction).
                            Replace("{{_sTermsClass}}", _sTermsClass).
                            Replace("{{_sTerms}}", _oCodeSavingEmailModel.Terms).
                            Replace("{{_sResourceEmailText_NeedHelp}}", _oCodeSavingEmailModel.ResourceEmailText.NeedHelp).
                            Replace("{{_sCompany_CompanyName}}", _oCodeSavingEmailModel.Company.CompanyName).
                            Replace("{{_sCompany_Email}}", _oCodeSavingEmailModel.Company.Email).
                            Replace("{{_sImageHost}}", SiteImageUrlBase);
                #endregion
            }
            else if (_pType == EmailType.DealLogEmail || _pType == EmailType.DealSoonExpireEmail)
            {
                #region Deal Log OR Deal Expire Soon
                CampaignLogModel _oCampaignLogModel = (CampaignLogModel)Convert.ChangeType(model, typeof(CampaignLogModel));
                string _sActionByClass = "hide-section";

                if (!string.IsNullOrEmpty(_oCampaignLogModel.ActionBy))
                    _sActionByClass = string.Empty;

                _pTemplate = _pTemplate.Replace("{{_sCustomMessage}}", _oCampaignLogModel.CustomMessage).
                            Replace("{{_sCampaignUrl}}", _oCampaignLogModel.CampaignUrl).
                            Replace("{{_sCampaignName}}", _oCampaignLogModel.CampaignName).
                            Replace("{{_sDescription}}", _oCampaignLogModel.Description).
                            Replace("{{_sActionByClass}}", _sActionByClass).
                            Replace("{{_sActionBy}}", _oCampaignLogModel.ActionBy).
                            Replace("{{_sCreated}}", _oCampaignLogModel.Created.ToRedealString()).
                            Replace("{{_sCustomMessage}}", _oCampaignLogModel.CustomMessage).
                            Replace("{{_sSiteName}}", _oCampaignLogModel.SiteName).
                            Replace("{{_sCompanyName}}", _oCampaignLogModel.CompanyName);
                #endregion
            }
            else if (_pType == EmailType.LowCodeMail || _pType == EmailType.LowReferralsMail || _pType == EmailType.PackageExpiredMail)
            {
                #region Low Code Email
                LowCodeCampaignModel _oLowCodeCampaignModel = (LowCodeCampaignModel)Convert.ChangeType(model, typeof(LowCodeCampaignModel));

                _pTemplate = _pTemplate.Replace("{{_sImageHost}}", _sImageHost).
                            Replace("{{_sCompanyName}}", _oLowCodeCampaignModel.CompanyName).
                            Replace("{{_sSite}}", _oLowCodeCampaignModel.Site).
                            Replace("{{_sDeal}}", _oLowCodeCampaignModel.Deal).
                            Replace("{{_swebURL}}", _sWebURL).
                            Replace("{{_sCampaignId}}", _oLowCodeCampaignModel.CampaignId);
                #endregion
            }


            string _sIsShowInBrowser = "hide-section";
            if (_sViewInBrowser == "true")
                _sIsShowInBrowser = "hide-in-browser";
            _pTemplate = _pTemplate.Replace("{{_sIsShowInBrowser}}", _sIsShowInBrowser).
            Replace("{{_sViewInBrowserUrl}}", _sViewInBrowserUrl + "/" + _pEmailId);
            return _pTemplate;
        }

    }
    #endregion

    #region  Language Helper

    public static class LanguageHelper
    {
        static IConfiguration config = new ConfigurationBuilder().AddJsonFile("appsettings.json", true, true).Build();
        private static readonly string _sConnectionString = config["ConnectionString"];
        private static readonly string _sDbName = "Redeal";
        private static MongoClient _oMongoClient = new MongoClient(_sConnectionString);
        private static IMongoDatabase _oIMongoDatabase = _oMongoClient.GetDatabase(_sDbName);
        private static IMongoCollection<BsonDocument> _oRedealLanguageMongoCollection = _oIMongoDatabase.GetCollection<BsonDocument>("Language");

        public static string GetPOEditorCodeFromValue(int _iValue)
        {
            BsonDocument _oLanguagePOEditor = new BsonDocument();
            _oLanguagePOEditor = _oRedealLanguageMongoCollection.Find(Builders<BsonDocument>.Filter.Eq(x => x["Value"], _iValue)).Project<BsonDocument>(Builders<BsonDocument>.Projection.Include("POEditorCode").Exclude("_id")).FirstOrDefault();
            if (_oLanguagePOEditor != null && _oLanguagePOEditor.Contains("POEditorCode"))
                return _oLanguagePOEditor["POEditorCode"].ToString();
            else
                return "sv";
        }

        public static string GetCultureFromValue(int _iValue)
        {
            BsonDocument _oLanguagePOEditor = new BsonDocument();
            _oLanguagePOEditor = _oRedealLanguageMongoCollection.Find(Builders<BsonDocument>.Filter.Eq(x => x["Value"], _iValue)).Project<BsonDocument>(Builders<BsonDocument>.Projection.Include("Culture").Exclude("_id")).FirstOrDefault();
            if (_oLanguagePOEditor != null && _oLanguagePOEditor.Contains("Culture"))
                return _oLanguagePOEditor["Culture"].ToString();
            else
                return "sv-SE";
        }

    }

    #endregion
}

