﻿using DocuSign.eSign.Api;
using DocuSign.eSign.Client;
using DocuSign.eSign.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TelephoneWeb.Controllers
{
    public class DocusignDemoController : Controller
    {
        // GET: DocusignDemo
        public ActionResult Index()
        {
            var model = new Student();
            return View(model);
        }

        [HttpPost]
        public ActionResult Index(Student model)
        {
            model = DocuSignGenerate(model);
            return View(model);
        }

        private Student DocuSignGenerate(Student model)
        {
            // initialize client for desired environment (for production change to www)
            ApiClient apiClient = new ApiClient("https://demo.docusign.net/restapi");
            var baseUrl = "https://demo.docusign.net/restapi";
            Configuration.Default.ApiClient = apiClient;

            // configure 'X-DocuSign-Authentication' header
            string authHeader = string.Concat("{", string.Format("\"Username\":\"{0}\",\"Password\":\"{1}\",\"IntegratorKey\":\"{2}\"",
                "jmartin@evanceprocessing.com", "Qw1declc3!", "0e22f21b-d194-4336-a1fa-8cc9b76eaf45"), "}");
            if (!Configuration.Default.DefaultHeader.Any())
                Configuration.Default.AddDefaultHeader("X-DocuSign-Authentication", authHeader);

            /* ---------- Step 1: Login API ----------  */
            // login call is available in the authentication api 
            AuthenticationApi authApi = new AuthenticationApi();
            LoginInformation loginInfo = authApi.Login();

            // parse the first account ID that is returned (user might belong to multiple accounts)
            var accountId = loginInfo.LoginAccounts[0].AccountId;
            baseUrl = loginInfo.LoginAccounts[0].BaseUrl;

            // Update ApiClient with the new base url from login call
            apiClient = new ApiClient(baseUrl.Substring(0, baseUrl.IndexOf("v") - 1));
            Configuration.Default.ApiClient = apiClient;

            /* ---------- Step 2: Create Envelope API ---------- */
            // create a new envelope which we will use to send the signature request            
            EnvelopeDefinition envDef = new EnvelopeDefinition();
            envDef.EmailSubject = "demo_pdf_subject - "+model.Name1;

            // Add a document to the envelope
            var pdf = Server.MapPath("/Content/Date.pdf");
            byte[] investorPdfFileBytes = System.IO.File.ReadAllBytes(pdf);
            var investorPdfDocument = new Document();
            investorPdfDocument.DocumentBase64 = System.Convert.ToBase64String(investorPdfFileBytes);
            investorPdfDocument.Name = "Date.pdf";
            investorPdfDocument.DocumentId = "1";
            envDef.Documents = new List<Document>();
            envDef.Documents.Add(investorPdfDocument);

            // Add a recipient to sign the documeent
            Signer signer = new Signer();
            signer.Email = "bhavik@gmail.com";
            signer.Name = "Bhavik";
            signer.RecipientId = "1";
            signer.ClientUserId = "123";

            // Create a |SignHere| tab somewhere on the document for the recipient to sign
            signer.Tabs = new Tabs();
            signer.Tabs.SignHereTabs = new List<SignHere>();
            SignHere signHere = new SignHere();
            signHere.DocumentId = "1";
            signHere.PageNumber = "1";
            signHere.RecipientId = "1";
            signHere.XPosition = "120";
            signHere.YPosition = "250";
            signer.Tabs.SignHereTabs.Add(signHere);


            envDef.Recipients = new Recipients();
            envDef.Recipients.Signers = new List<Signer>();
            envDef.Recipients.Signers.Add(signer);

            // set envelope status to "sent" to immediately send the signature request
            envDef.Status = "sent";
            // |EnvelopesApi| contains methods related to creating and sending Envelopes (aka signature requests)
            EnvelopesApi envelopesApi = new EnvelopesApi();
            EnvelopeSummary envelopeSummary = envelopesApi.CreateEnvelope(accountId, envDef);
            RecipientViewRequest viewOptions = new RecipientViewRequest()
            {
                //ReturnUrl = String.Format("{0}/crowdpay/SigningResult?documentType={1}&productId={2}", "https://crowdignition.com/", "SubscriptionAgreementTemplateId", 0),
                ReturnUrl = "http://localhost:63652/",
                ClientUserId = "123",  // must match clientUserId set in step #2!
                AuthenticationMethod = "email",
                UserName = "Bhavik",
                Email = "bhavik@gmail.com",
            };

            // create the recipient view(aka signing URL)
            //ViewUrl recipientView = envelopesApi.CreateRecipientView(accountId, envelopeSummary.EnvelopeId, viewOptions);
            ViewUrl recipientView = envelopesApi.CreateRecipientView(accountId, envelopeSummary.EnvelopeId, viewOptions);

            model.RecipientViewUrl = recipientView.Url;

            return model;
        }
    }

    public class Student
    {
        public string Name1 { get; set; }
        public string Signature1 { get; set; }
        public string RecipientViewUrl { get; set; }
    }
}