﻿using Misc.Plugin.MerchantBoarding.Domain;
using Misc.Plugin.MerchantBoarding.Models;
using Nop.Core.Infrastructure.Mapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Misc.Plugin.MerchantBoarding.Mapper
{
    public static class MappingExtensions
    {
        public static TDestination MapTo<TSource, TDestination>(this TSource source)
        {
            return AutoMapperConfiguration.Mapper.Map<TSource, TDestination>(source);
        }

        public static TDestination MapTo<TSource, TDestination>(this TSource source, TDestination destination)
        {
            return AutoMapperConfiguration.Mapper.Map(source, destination);
        }

        #region Merchant
        public static MB_MerchantInformation ToEntity(this MerchantInformationModel model)
        {
            return model.MapTo<MerchantInformationModel, MB_MerchantInformation>();
        }
        public static MB_MerchantInformation ToEntity(this MerchantInformationModel model, MB_MerchantInformation destination)
        {
            return model.MapTo(destination);
        }
        #endregion

        public static string Mask(this string source, int start, int maskLength)
        {
            if (!string.IsNullOrEmpty(source))
            {
                return source.Mask(start, maskLength, 'X');
            }
            else
            {
                return "000000000";
            }
        }

        public static string Mask(this string source, int start, int maskLength, char maskCharacter)
        {
            if (start > source.Length - 1)
            {
                //throw new ArgumentException("Start position is greater than string length");
                return "000000000";
            }

            if (maskLength > source.Length)
            {
                //throw new ArgumentException("Mask length is greater than string length");
                return "000000000";
            }

            if (start + maskLength > source.Length)
            {
                //throw new ArgumentException("Start position and mask length imply more characters than are present");
                return "000000000";
            }

            string mask = new string(maskCharacter, maskLength);
            string unMaskStart = source.Substring(0, start);
            string unMaskEnd = source.Substring(start + maskLength, source.Length - maskLength);

            return unMaskStart + mask + unMaskEnd;
        }
    }
}
