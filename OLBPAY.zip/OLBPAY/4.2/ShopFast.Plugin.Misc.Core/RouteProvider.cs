﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Nop.Web.Framework.Localization;
using Nop.Web.Framework.Mvc.Routing;
namespace ShopFast.Plugin.Misc.Core
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(IRouteBuilder routeBuilder)
        {
            routeBuilder.MapLocalizedRoute("Shopfast.Plugin.Misc.Core.API.GetRewardPointsBalance",
                           "Plugins/API/GetRewardPointsBalance/{id}",
                           new { controller = "ShopFastApi", action = "GetRewardPointsBalance" },
                           new { id = @"\d+" },
                           new[] { "Shopfast.Plugin.Misc.Core.Controllers" }
                      );



        }

        public int Priority
        {
            get
            {
                return 0;
            }
        }
    }
}
