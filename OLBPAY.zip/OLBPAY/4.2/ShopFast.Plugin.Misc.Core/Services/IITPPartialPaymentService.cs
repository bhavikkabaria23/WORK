﻿using System;
using System.Collections.Generic;
using Nop.Core;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Services.Configuration;
using Nop.Services.Orders;
using Nop.Services.Payments;

namespace ShopFast.Plugin.Misc.Core.Services
{
    /// <summary>
    /// Payment service with partial payment support
    /// </summary>
    public partial interface IITPPartialPaymentService : IPaymentService
    {
        /// <summary>
        /// Process a payment
        /// </summary>
        /// <param name="processPaymentRequest">Payment info required for an order processing</param>
        /// <param name="paymentOrder">Created order which contains data about proceeded partial payment</param>
        /// <returns>Process payment result</returns>
        ProcessPaymentResult ProcessPayment(ProcessPaymentRequest processPaymentRequest, out Order paymentOrder);

        Order InsertPartialPaymentOrder(ProcessPaymentRequest processPaymentRequest, ProcessPaymentResult processPaymentResult, int parentOrderId, string paymentSystemName, decimal paymentTotal = decimal.Zero, int? customerId = null);

        void UpdateOrderPaymentStatus(Order parentOrder);

        ICollection<Order> GetOrderPayments(Order parentOrder, Customer paymentCustomer = null);

        void InsertPartialPaymentAttribute(Order parentOrder, Order payment, int storeId = 0);

        decimal GetAmountPaid(Order order, bool onlyPaid = false);

        decimal GetRemainingBalance(List<Order> orders, bool onlyPaid = false);

        decimal GetRemainingBalance(Order order, bool onlyPaid = false);

        ProcessPaymentResult ProcessPaymentForMultipleOrders(ProcessPaymentRequest processPaymentRequest,
            List<Order> orders);

        ProcessPaymentResult ProcessPaymentForMultipleOrders(ProcessPaymentRequest processPaymentRequest,
            List<Order> orders, out Order paymentOrder);
    }
}
