﻿using System;
using System.Collections.Generic;
using System.Linq;
using Nop.Core;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Discounts;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Shipping;
using Nop.Core.Domain.Tax;
using Nop.Services.Catalog;
using Nop.Services.Common;
using Nop.Services.Directory;
using Nop.Services.Discounts;
using Nop.Services.Orders;
using Nop.Services.Payments;
using Nop.Services.Shipping;
using Nop.Services.Tax;
using Nop.Web.Models.ShoppingCart;
using ShopFast.Plugin.Misc.Core.Models;
using Nop.Core.Infrastructure;

namespace ShopFast.Plugin.Misc.Core.Services
{
    public class ITPInvoiceTotalCalculationService : OrderTotalCalculationService, IITPInvoiceTotalCalculationService
    {
        private readonly TipsCheckoutAttributeParser _tipsCheckoutAttributeParser;
        private IStoreContext _storeContext;
        private IGenericAttributeService _genericAttributeService;
        private ICheckoutAttributeParser _checkoutAttributeParser2 ;
        private IPriceCalculationService _priceCalculationService ;
        private ITaxService _taxService2 ;
        private ShoppingCartSettings _shoppingCartSettings2;
        private readonly IPaymentService _paymentService2;
        private readonly RewardPointsSettings _rewardPointsSettings2;
        private readonly IGiftCardService _giftCardService2;
        private readonly InvoiceItemAttributeParser _invoiceItemAttributeParser;
        private readonly TaxSettings _taxSettings2;
        private readonly ICurrencyService _currencyService;
        private readonly IPriceFormatter _priceFormatter;
        private readonly IWorkContext _workContext;
        private readonly ITaxService _taxService;
        private readonly TaxSettings _taxSettings;
        private readonly RewardPointsSettings _rewardPointsSettings;
        private readonly IITPPartialPaymentService _partialPaymentService;
        private readonly IOrderService _orderService;
        //nop3.7 upgrade begin
        private readonly IRewardPointService _rewardPointService;
        //nop3.7 upgrade begin                
        private readonly IShippingPluginManager _shippingPluginManager;
        private readonly IShoppingCartService _shoppingCartService;




        public ITPInvoiceTotalCalculationService(TipsCheckoutAttributeParser tipsCheckoutAttributeParser, 
            IWorkContext workContext, 
            IStoreContext storeContext, 
            IPriceCalculationService priceCalculationService, 
            ITaxService taxService, 
            IShippingService shippingService, 
            IPaymentService paymentService, 
            ICheckoutAttributeParser checkoutAttributeParser, 
            IDiscountService discountService, 
            IGiftCardService giftCardService, 
            IGenericAttributeService genericAttributeService, 
            IRewardPointService rewardPointService,
            TaxSettings taxSettings, 
            RewardPointsSettings rewardPointsSettings, 
            ShippingSettings shippingSettings, 
            ShoppingCartSettings shoppingCartSettings, 
            CatalogSettings catalogSettings, 
            IPaymentService paymentService2, 
            RewardPointsSettings rewardPointsSettings2, 
            IGiftCardService giftCardService2, 
            InvoiceItemAttributeParser invoiceItemAttributeParser, 
            TaxSettings taxSettings2, 
            ICurrencyService currencyService, 
            IPriceFormatter priceFormatter, 
            IWorkContext workContext1, 
            ITaxService taxService1, 
            TaxSettings taxSettings1, 
            RewardPointsSettings rewardPointsSettings1, 
            IITPPartialPaymentService partialPaymentService, 
            IOrderService orderService,
            IShippingPluginManager shippingPluginManager,
            IShoppingCartService shoppingCartService
            )
            : base(catalogSettings,
            checkoutAttributeParser,
            discountService,
            genericAttributeService,
            giftCardService,
            paymentService,
            priceCalculationService,
            rewardPointService,
            shippingPluginManager,
            shippingService,
            shoppingCartService,
            storeContext,
            taxService,
            workContext,
            rewardPointsSettings,
            shippingSettings,
            shoppingCartSettings,
            taxSettings)
        {
            _tipsCheckoutAttributeParser = tipsCheckoutAttributeParser;
            _storeContext = storeContext;
            _genericAttributeService = genericAttributeService;
            _checkoutAttributeParser2 = checkoutAttributeParser;
            _priceCalculationService = priceCalculationService;
            _taxService2 = taxService;
            _shoppingCartSettings2 = shoppingCartSettings;
            _paymentService2 = paymentService2;
            _rewardPointsSettings2 = rewardPointsSettings2;
            _giftCardService2 = giftCardService2;
            _invoiceItemAttributeParser = invoiceItemAttributeParser;
            _taxSettings2 = taxSettings2;
            _currencyService = currencyService;
            _priceFormatter = priceFormatter;
            _workContext = workContext1;
            _taxService = taxService1;
            _taxSettings = taxSettings1;
            _rewardPointsSettings = rewardPointsSettings1;
            _partialPaymentService = partialPaymentService;
            _orderService = orderService;
            _shippingPluginManager = shippingPluginManager;
        }

        /// <summary>
        /// Gets shopping cart subtotal
        /// </summary>
        /// <param name="cart">Cart</param>
        /// <param name="includingTax">A value indicating whether calculated price should include tax</param>
        /// <param name="discountAmount">Applied discount amount</param>
        /// <param name="appliedDiscount">Applied discount</param>
        /// <param name="subTotalWithoutDiscount">Sub total (without discount)</param>
        /// <param name="subTotalWithDiscount">Sub total (with discount)</param>
        public virtual void GetInvoiceSubTotal(IList<ShoppingCartItem> cart,
            bool includingTax,
            out decimal discountAmount, out List<DiscountForCaching> appliedDiscounts,
            out decimal subTotalWithoutDiscount, out decimal subTotalWithDiscount)
        {
            SortedDictionary<decimal, decimal> taxRates;
            GetInvoiceSubTotal(cart, includingTax,
                out discountAmount, out appliedDiscounts,
                out subTotalWithoutDiscount, out subTotalWithDiscount, out taxRates);
        }

        /// <summary>
        /// Gets shopping cart subtotal
        /// </summary>
        /// <param name="cart">Cart</param>
        /// <param name="includingTax">A value indicating whether calculated price should include tax</param>
        /// <param name="discountAmount">Applied discount amount</param>
        /// <param name="appliedDiscount">Applied discount</param>
        /// <param name="subTotalWithoutDiscount">Sub total (without discount)</param>
        /// <param name="subTotalWithDiscount">Sub total (with discount)</param>
        public virtual void GetInvoiceSubTotal(IList<ShoppingCartItem> cart,
            bool includingTax,
            out decimal discountAmount, out List<DiscountForCaching> appliedDiscounts,
            out decimal subTotalWithoutDiscount, out decimal subTotalWithDiscount,
            out SortedDictionary<decimal, decimal> taxRates)
        {

            discountAmount = decimal.Zero;
            appliedDiscounts = null;
            subTotalWithoutDiscount = decimal.Zero;
            subTotalWithDiscount = decimal.Zero;
            taxRates = new SortedDictionary<decimal, decimal>();

            if (cart.Count == 0)
                return;

            //get the customer 
           var customer = cart.FirstOrDefault(item => item.Customer != null)?.Customer;

            //sub totals
            decimal subTotalExclTaxWithoutDiscount = decimal.Zero;
            decimal subTotalInclTaxWithoutDiscount = decimal.Zero;
            foreach (var shoppingCartItem in cart)
            {
                decimal sciSubTotal = _priceCalculationService.GetSubTotal(shoppingCartItem);

                decimal taxRate;
                decimal sciExclTax = _taxService2.GetProductPrice(shoppingCartItem.Product, sciSubTotal, false, customer, out taxRate);
                decimal sciInclTax = _taxService2.GetProductPrice(shoppingCartItem.Product, sciSubTotal, true, customer, out taxRate);

                var iiam = _invoiceItemAttributeParser.GetInvoiceItemAttributeMapping(shoppingCartItem.AttributesXml);
                if (iiam != null && !iiam.Taxable)
                {
                    sciInclTax = sciExclTax;
                }
                subTotalExclTaxWithoutDiscount += sciExclTax;
                subTotalInclTaxWithoutDiscount += sciInclTax;

                //tax rates
                decimal sciTax = sciInclTax - sciExclTax;
                if (taxRate > decimal.Zero && sciTax > decimal.Zero)
                {
                    if (!taxRates.ContainsKey(taxRate))
                    {
                        taxRates.Add(taxRate, sciTax);
                    }
                    else
                    {
                        taxRates[taxRate] = taxRates[taxRate] + sciTax;
                    }
                }
            }

            //checkout attributes
            if (customer != null)
            {
                var checkoutAttributesXml = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.CheckoutAttributes, _storeContext.CurrentStore.Id);
                var attributeValues = _checkoutAttributeParser2.ParseCheckoutAttributeValues(checkoutAttributesXml);
                if (attributeValues != null)
                {
                    foreach (var attributeValue in attributeValues)
                    {
                        decimal taxRate;

                        decimal caExclTax = _taxService2.GetCheckoutAttributePrice(attributeValue, false, customer, out taxRate);
                        decimal caInclTax = _taxService2.GetCheckoutAttributePrice(attributeValue, true, customer, out taxRate);

                        subTotalExclTaxWithoutDiscount += caExclTax;
                        subTotalInclTaxWithoutDiscount += caInclTax;

                        //tax rates
                        decimal caTax = caInclTax - caExclTax;
                        if (taxRate > decimal.Zero && caTax > decimal.Zero)
                        {
                            if (!taxRates.ContainsKey(taxRate))
                            {
                                taxRates.Add(taxRate, caTax);
                            }
                            else
                            {
                                taxRates[taxRate] = taxRates[taxRate] + caTax;
                            }
                        }
                    }
                }
            }

            //checkout tip attributes
            if (customer != null)
            {
                var checkoutAttributesXml = EngineContext.Current.Resolve<IGenericAttributeService>().GetAttribute<string>(customer,NopCustomerDefaults.CheckoutAttributes, _storeContext.CurrentStore.Id);
                var attributeInterestValues = _tipsCheckoutAttributeParser.ParseInterestValues(checkoutAttributesXml);
                if (attributeInterestValues != null)
                {
                    foreach (var attributeValue in attributeInterestValues)
                    {
                        decimal tip = 0;
                        decimal.TryParse(attributeValue.Intrest, out tip);
                        decimal caExclTax = subTotalExclTaxWithoutDiscount * tip / 100;
                        decimal caInclTax = subTotalExclTaxWithoutDiscount * tip / 100;
                        subTotalExclTaxWithoutDiscount += caExclTax;
                        subTotalInclTaxWithoutDiscount += caInclTax;
                    }
                }

                var attributeAmountValues = _tipsCheckoutAttributeParser.ParseAmountValues(checkoutAttributesXml);
                if (attributeAmountValues != null)
                {
                    foreach (var attributeValue in attributeAmountValues)
                    {
                        decimal tip = 0;
                        decimal.TryParse(attributeValue, out tip);
                        subTotalExclTaxWithoutDiscount += tip;
                        subTotalInclTaxWithoutDiscount += tip;
                    }
                }
            }
            //subtotal without discount
            if (includingTax)
                subTotalWithoutDiscount = subTotalInclTaxWithoutDiscount;
            else
                subTotalWithoutDiscount = subTotalExclTaxWithoutDiscount;
            if (subTotalWithoutDiscount < decimal.Zero)
                subTotalWithoutDiscount = decimal.Zero;

            if (_shoppingCartSettings2.RoundPricesDuringCalculation)
                subTotalWithoutDiscount = _priceCalculationService.RoundPrice(subTotalWithoutDiscount);

            //We calculate discount amount on order subtotal excl tax (discount first)
            //calculate discount amount ('Applied to order subtotal' discount)
            decimal discountAmountExclTax = GetOrderSubtotalDiscount(customer, subTotalExclTaxWithoutDiscount, out appliedDiscounts);
            if (subTotalExclTaxWithoutDiscount < discountAmountExclTax)
                discountAmountExclTax = subTotalExclTaxWithoutDiscount;
            decimal discountAmountInclTax = discountAmountExclTax;
            //subtotal with discount (excl tax)
            decimal subTotalExclTaxWithDiscount = subTotalExclTaxWithoutDiscount - discountAmountExclTax;
            decimal subTotalInclTaxWithDiscount = subTotalExclTaxWithDiscount;

            //add tax for shopping items & checkout attributes
            var tempTaxRates = new Dictionary<decimal, decimal>(taxRates);
            foreach (KeyValuePair<decimal, decimal> kvp in tempTaxRates)
            {
                decimal taxRate = kvp.Key;
                decimal taxValue = kvp.Value;

                if (taxValue != decimal.Zero)
                {
                    //discount the tax amount that applies to subtotal items
                    if (subTotalExclTaxWithoutDiscount > decimal.Zero)
                    {
                        decimal discountTax = taxRates[taxRate] * (discountAmountExclTax / subTotalExclTaxWithoutDiscount);
                        discountAmountInclTax += discountTax;
                        taxValue = taxRates[taxRate] - discountTax;
                        if (_shoppingCartSettings2.RoundPricesDuringCalculation)
                            taxValue = _priceCalculationService.RoundPrice(taxValue);
                        taxRates[taxRate] = taxValue;
                    }

                    //subtotal with discount (incl tax)
                    subTotalInclTaxWithDiscount += taxValue;
                }
            }

            if (_shoppingCartSettings2.RoundPricesDuringCalculation)
            {
                discountAmountInclTax = _priceCalculationService.RoundPrice(discountAmountInclTax);
                discountAmountExclTax = _priceCalculationService.RoundPrice(discountAmountExclTax);
            }

            if (includingTax)
            {
                subTotalWithDiscount = subTotalInclTaxWithDiscount;
                discountAmount = discountAmountInclTax;
            }
            else
            {
                subTotalWithDiscount = subTotalExclTaxWithDiscount;
                discountAmount = discountAmountExclTax;
            }

            if (subTotalWithDiscount < decimal.Zero)
                subTotalWithDiscount = decimal.Zero;

            
            
            if (_shoppingCartSettings2.RoundPricesDuringCalculation)
                subTotalWithDiscount = _priceCalculationService.RoundPrice(subTotalWithDiscount);
        }

        /// <summary>
        /// Gets shopping cart total
        /// </summary>
        /// <param name="cart">Cart</param>
        /// <param name="appliedGiftCards">Applied gift cards</param>
        /// <param name="discountAmount">Applied discount amount</param>
        /// <param name="appliedDiscount">Applied discount</param>
        /// <param name="redeemedRewardPoints">Reward points to redeem</param>
        /// <param name="redeemedRewardPointsAmount">Reward points amount in primary store currency to redeem</param>
        /// <param name="ignoreRewardPonts">A value indicating whether we should ignore reward points (if enabled and a customer is going to use them)</param>
        /// <param name="usePaymentMethodAdditionalFee">A value indicating whether we should use payment method additional fee when calculating order total</param>
        /// <returns>Shopping cart total;Null if shopping cart total couldn't be calculated now</returns>
        public virtual decimal? GetInvoiceTotal(IList<ShoppingCartItem> cart,
            out decimal discountAmount, out List<DiscountForCaching> appliedDiscounts,
            out List<AppliedGiftCard> appliedGiftCards,
            out int redeemedRewardPoints, out decimal redeemedRewardPointsAmount,
            bool? useRewardPoints = null, bool usePaymentMethodAdditionalFee = true)
        {
            redeemedRewardPoints = 0;
            redeemedRewardPointsAmount = decimal.Zero;

            var customer = cart.FirstOrDefault(item => item.Customer != null)?.Customer;
            string paymentMethodSystemName = "";
            if (customer != null)
            {
                paymentMethodSystemName = _genericAttributeService.GetAttribute<string>(customer,
                    NopCustomerDefaults.SelectedPaymentMethodAttribute, _storeContext.CurrentStore.Id);
            }


            //subtotal without tax
            decimal orderSubTotalDiscountAmount;
            List<DiscountForCaching> orderSubTotalAppliedDiscounts;
            decimal subTotalWithoutDiscountBase;
            decimal subTotalWithDiscountBase;
            GetShoppingCartSubTotal(cart, false,
                out orderSubTotalDiscountAmount, out orderSubTotalAppliedDiscounts,
                out subTotalWithoutDiscountBase, out subTotalWithDiscountBase);
            //subtotal with discount
            decimal subtotalBase = subTotalWithDiscountBase;

            //LoadAllShippingRateComputationMethods
            var shippingRateComputationMethods = _shippingPluginManager.LoadActivePlugins(_workContext.CurrentCustomer, _storeContext.CurrentStore.Id);

            //shipping without tax
            decimal? shoppingCartShipping = GetShoppingCartShippingTotal(cart, false, shippingRateComputationMethods);



            //payment method additional fee without tax
            decimal paymentMethodAdditionalFeeWithoutTax = decimal.Zero;
            if (usePaymentMethodAdditionalFee && !String.IsNullOrEmpty(paymentMethodSystemName))
            {
                decimal paymentMethodAdditionalFee = _paymentService2.GetAdditionalHandlingFee(cart,
                    paymentMethodSystemName);
                paymentMethodAdditionalFeeWithoutTax =
                    _taxService2.GetPaymentMethodAdditionalFee(paymentMethodAdditionalFee,
                        false, customer);
            }




            //tax
            var shoppingCartTax = GetTaxTotal(cart, shippingRateComputationMethods, usePaymentMethodAdditionalFee);





            //order total
            decimal resultTemp = decimal.Zero;
            resultTemp += subtotalBase;
            if (shoppingCartShipping.HasValue)
            {
                resultTemp += shoppingCartShipping.Value;
            }
            resultTemp += paymentMethodAdditionalFeeWithoutTax;
            resultTemp += shoppingCartTax;
            if (_shoppingCartSettings2.RoundPricesDuringCalculation)
                resultTemp = _priceCalculationService.RoundPrice(resultTemp);

            #region Order total discount

            discountAmount = GetOrderTotalDiscount(customer, resultTemp, out appliedDiscounts);

            //sub totals with discount        
            if (resultTemp < discountAmount)
                discountAmount = resultTemp;

            //reduce subtotal
            resultTemp -= discountAmount;

            if (resultTemp < decimal.Zero)
                resultTemp = decimal.Zero;
            if (_shoppingCartSettings2.RoundPricesDuringCalculation)
                resultTemp = _priceCalculationService.RoundPrice(resultTemp);

            #endregion

            #region Applied gift cards

            //let's apply gift cards now (gift cards that can be used)
            appliedGiftCards = new List<AppliedGiftCard>();
            AppliedGiftCards(cart, appliedGiftCards, customer, ref resultTemp);            

            #endregion

            if (resultTemp < decimal.Zero)
                resultTemp = decimal.Zero;
            if (_shoppingCartSettings2.RoundPricesDuringCalculation)
                resultTemp = _priceCalculationService.RoundPrice(resultTemp);

            if (!shoppingCartShipping.HasValue)
            {
                //we have errors
                return null;
            }

            decimal orderTotal = resultTemp;

            //reward points
            SetRewardPoints(ref redeemedRewardPoints, ref redeemedRewardPointsAmount, useRewardPoints, customer, orderTotal);

            orderTotal = orderTotal - redeemedRewardPointsAmount;
            if (_shoppingCartSettings2.RoundPricesDuringCalculation)
                orderTotal = _priceCalculationService.RoundPrice(orderTotal);
            return orderTotal;
        }

        /// <summary>
        /// Gets tax
        /// </summary>
        /// <param name="cart">Shopping cart</param>
        /// <param name="taxRates">Tax rates</param>
        /// <param name="usePaymentMethodAdditionalFee">A value indicating whether we should use payment method additional fee when calculating tax</param>
        /// <returns>Tax total</returns>
        public virtual decimal GetTaxTotal(IList<ShoppingCartItem> cart, IList<IShippingRateComputationMethod> shippingRateComputationMethods,
            out SortedDictionary<decimal, decimal> taxRates, bool usePaymentMethodAdditionalFee = true)
        {
            if (cart == null)
                throw new ArgumentNullException("cart");

            taxRates = new SortedDictionary<decimal, decimal>();

            var customer = cart.FirstOrDefault(item => item.Customer != null)?.Customer;

            string paymentMethodSystemName = "";
            if (customer != null)
            {
                paymentMethodSystemName = _genericAttributeService.GetAttribute<string>(customer,
                    NopCustomerDefaults.SelectedPaymentMethodAttribute, _storeContext.CurrentStore.Id);
            }

            //order sub total (items + checkout attributes)
            decimal subTotalTaxTotal = decimal.Zero;
            decimal orderSubTotalDiscountAmount;
            List<DiscountForCaching> orderSubTotalAppliedDiscounts;
            decimal subTotalWithoutDiscountBase;
            decimal subTotalWithDiscountBase;
            SortedDictionary<decimal, decimal> orderSubTotalTaxRates;
            GetInvoiceSubTotal(cart, false,
                out orderSubTotalDiscountAmount, out orderSubTotalAppliedDiscounts,
                out subTotalWithoutDiscountBase, out subTotalWithDiscountBase,
                out orderSubTotalTaxRates);
            foreach (KeyValuePair<decimal, decimal> kvp in orderSubTotalTaxRates)
            {
                decimal taxRate = kvp.Key;
                decimal taxValue = kvp.Value;
                subTotalTaxTotal += taxValue;

                if (taxRate > decimal.Zero && taxValue > decimal.Zero)
                {
                    if (!taxRates.ContainsKey(taxRate))
                        taxRates.Add(taxRate, taxValue);
                    else
                        taxRates[taxRate] = taxRates[taxRate] + taxValue;
                }
            }

            //payment method additional fee
            decimal paymentMethodAdditionalFeeTax = decimal.Zero;
            if (usePaymentMethodAdditionalFee && _taxSettings2.PaymentMethodAdditionalFeeIsTaxable)
            {
                decimal taxRate;
                decimal paymentMethodAdditionalFee = _paymentService2.GetAdditionalHandlingFee(cart, paymentMethodSystemName);
                decimal paymentMethodAdditionalFeeExclTax = _taxService2.GetPaymentMethodAdditionalFee(paymentMethodAdditionalFee, false, customer, out taxRate);
                decimal paymentMethodAdditionalFeeInclTax = _taxService2.GetPaymentMethodAdditionalFee(paymentMethodAdditionalFee, true, customer, out taxRate);

                paymentMethodAdditionalFeeTax = paymentMethodAdditionalFeeInclTax - paymentMethodAdditionalFeeExclTax;
                //ensure that tax is equal or greater than zero
                if (paymentMethodAdditionalFeeTax < decimal.Zero)
                    paymentMethodAdditionalFeeTax = decimal.Zero;

                //tax rates
                if (taxRate > decimal.Zero && paymentMethodAdditionalFeeTax > decimal.Zero)
                {
                    if (!taxRates.ContainsKey(taxRate))
                        taxRates.Add(taxRate, paymentMethodAdditionalFeeTax);
                    else
                        taxRates[taxRate] = taxRates[taxRate] + paymentMethodAdditionalFeeTax;
                }
            }

            //add at least one tax rate (0%)
            if (taxRates.Count == 0)
                taxRates.Add(decimal.Zero, decimal.Zero);

            //summarize taxes
            decimal taxTotal = subTotalTaxTotal + + paymentMethodAdditionalFeeTax;
            //ensure that tax is equal or greater than zero
            if (taxTotal < decimal.Zero)
                taxTotal = decimal.Zero;
            //round tax
            if (_shoppingCartSettings2.RoundPricesDuringCalculation)
                taxTotal = _priceCalculationService.RoundPrice(taxTotal);
            return taxTotal;
        }      

        public override void GetShoppingCartSubTotal(IList<ShoppingCartItem> cart,
            bool includingTax,
            out decimal discountAmount, out List<DiscountForCaching> appliedDiscounts,
            out decimal subTotalWithoutDiscount, out decimal subTotalWithDiscount)
        {
            GetInvoiceSubTotal(cart, includingTax, 
                out discountAmount, out appliedDiscounts,
                out subTotalWithoutDiscount, out subTotalWithDiscount);
        }

        public override void GetShoppingCartSubTotal(IList<ShoppingCartItem> cart,
            bool includingTax,
            out decimal discountAmount, out List<DiscountForCaching> appliedDiscounts,
            out decimal subTotalWithoutDiscount, out decimal subTotalWithDiscount,
            out SortedDictionary<decimal, decimal> taxRates)
        {
            GetInvoiceSubTotal(cart, includingTax,
                out discountAmount, out appliedDiscounts,
                out subTotalWithoutDiscount, out subTotalWithDiscount,
                out taxRates);
        }

        public override decimal? GetShoppingCartTotal(IList<ShoppingCartItem> cart,
            out decimal discountAmount, out List<DiscountForCaching> appliedDiscounts,
            out List<AppliedGiftCard> appliedGiftCards,
            out int redeemedRewardPoints, out decimal redeemedRewardPointsAmount,
            bool? useRewardPoints = null, bool usePaymentMethodAdditionalFee = true)
        {
            return GetInvoiceTotal(cart,
                out discountAmount, out appliedDiscounts,
                out appliedGiftCards,
                out redeemedRewardPoints, out redeemedRewardPointsAmount,
                useRewardPoints, usePaymentMethodAdditionalFee);
        }
    }
}
