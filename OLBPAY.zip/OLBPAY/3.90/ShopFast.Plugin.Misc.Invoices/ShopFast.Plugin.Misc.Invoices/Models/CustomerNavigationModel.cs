﻿using Nop.Web.Framework.Mvc;

namespace ShopFast.Plugin.Misc.Invoices.Models
{
    public partial class CustomerNavigationModel : BaseNopModel
    {
        public bool HidePaidOrders { get; set; }
        public bool HideUnpaidOrders { get; set; }

        public CustomerNavigationEnum SelectedTab { get; set; }
    }

    public enum CustomerNavigationEnum
    {
        PaidOrders = 21,
        UnpaidOrders = 22,
    }
}
