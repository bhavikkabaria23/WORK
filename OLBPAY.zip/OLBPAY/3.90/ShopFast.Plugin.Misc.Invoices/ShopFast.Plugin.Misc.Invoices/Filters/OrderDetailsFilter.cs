﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using Nop.Core.Infrastructure;
using Nop.Services.Orders;
using Nop.Web.Models.Order;
using ShopFast.Plugin.Misc.Core.Services;

namespace ShopFast.Plugin.Misc.Invoices.Filters
{
    public class OrderDetailsFilter : ActionFilterAttribute
    {
        private readonly IOrderService _orderService;
        private readonly InvoiceItemAttributeParser _invoiceItemAttributeParser;

        public OrderDetailsFilter()
        {
            _orderService = EngineContext.Current.Resolve<IOrderService>();
            _invoiceItemAttributeParser = EngineContext.Current.Resolve<InvoiceItemAttributeParser>();
        }

        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            var request = filterContext.RequestContext.HttpContext.Request;
            if (request.RequestType != "GET")
                return;

            var model = filterContext.Controller.ViewData.Model as OrderDetailsModel;
            if (model != null && (filterContext.Result as ViewResult) != null)
            {
                foreach (var orderItemModel in model.Items)
                {
                    var orderItem = _orderService.GetOrderItemById(orderItemModel.Id);
                    var iiam = _invoiceItemAttributeParser.GetInvoiceItemAttributeMapping(orderItem.AttributesXml);
                    if (iiam != null)
                    {
                        orderItemModel.ProductName = iiam.Description;
                    }
                }

                filterContext.Controller.ViewData.Model = model;
            }
        }
    }
}
