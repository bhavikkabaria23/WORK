﻿using System;

namespace ShopFast.Plugin.Misc.Core.Models
{
    public class TipModel
    {
        public String Amount;
        public String Intrest;
    }
}