﻿using System.Collections.Generic;
using System.Linq;
using Nop.Core.Data;
using Nop.Core.Domain.Catalog;

namespace ShopFast.Plugin.Misc.Core.Services
{
    public class WeightProductTemplateService
    {
        private readonly IRepository<ProductTemplate> _productTemplateRepository;

        #region Ctor

        /// <summary>
        /// Ctor
        /// </summary>
        /// <param name="productTemplateRepository">Product template repository</param>
        public WeightProductTemplateService(IRepository<ProductTemplate> productTemplateRepository)
        {
            _productTemplateRepository = productTemplateRepository;
        }

        #endregion

        /// <summary>
        /// Gets all product weight templates
        /// </summary>
        /// <returns>Product templates</returns>
        public virtual IList<ProductTemplate> GetAllWeightProductTemplates()
        {
            var query = from pt in _productTemplateRepository.Table
                        where pt.ViewPath.Contains("ProductWeight")
                        orderby pt.DisplayOrder
                        select pt;

            var templates = query.ToList();
            return templates;
        }

        /// <summary>
        /// check if it is product weight templates
        /// </summary>
        /// <returns>Product templates</returns>
        public virtual bool IsWeightProductTemplate(int productTemplateId)
        {
            IList<ProductTemplate> allWeightProductTemplates = GetAllWeightProductTemplates();
            if (allWeightProductTemplates != null)
            {
                var template =  allWeightProductTemplates.FirstOrDefault(x => x.Id == productTemplateId);
                if (template != null)
                    return true;
            }
            return false;
        }
    }
}
