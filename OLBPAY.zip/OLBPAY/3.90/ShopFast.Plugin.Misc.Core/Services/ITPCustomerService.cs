using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Nop.Admin.Extensions;
using Nop.Admin.Models.Catalog;
using Nop.Core;
using Nop.Core.Caching;
using Nop.Core.Data;
using Nop.Core.Domain.Blogs;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Common;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Forums;
using Nop.Core.Domain.News;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Core.Domain.Polls;
using Nop.Core.Domain.Shipping;
using Nop.Data;
using Nop.Services.Catalog;
using Nop.Services.Common;
using Nop.Services.Customers;
using Nop.Services.Events;
using Nop.Services.Orders;

namespace ShopFast.Plugin.Misc.Core.Services
{
    /// <summary>
    /// Order service
    /// </summary>
    public partial class ITPCustomerService : CustomerService, IITPCustomerService
    {
        #region Fields

        private readonly IRepository<Customer> _customerRepository;
        private readonly IRepository<CustomerPassword> _customerPasswordRepository;
        private readonly IRepository<CustomerRole> _customerRoleRepository;
        private readonly IRepository<GenericAttribute> _gaRepository;
        private readonly IRepository<Order> _orderRepository;
        private readonly IRepository<ForumPost> _forumPostRepository;
        private readonly IRepository<ForumTopic> _forumTopicRepository;
        private readonly IRepository<BlogComment> _blogCommentRepository;
        private readonly IRepository<NewsComment> _newsCommentRepository;
        private readonly IRepository<PollVotingRecord> _pollVotingRecordRepository;
        private readonly IRepository<ProductReview> _productReviewRepository;
        private readonly IRepository<ProductReviewHelpfulness> _productReviewHelpfulnessRepository;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly IDataProvider _dataProvider;
        private readonly IDbContext _dbContext;
        private readonly ICacheManager _cacheManager;
        private readonly IEventPublisher _eventPublisher;
        private readonly CustomerSettings _customerSettings;
        private readonly CommonSettings _commonSettings;

        #endregion

        #region Ctor

        /// <summary>
        /// Ctor
        /// </summary>
        public ITPCustomerService(ICacheManager cacheManager,
            IRepository<Customer> customerRepository,
            IRepository<CustomerPassword> customerPasswordRepository,
            IRepository<CustomerRole> customerRoleRepository,
            IRepository<GenericAttribute> gaRepository,
            IRepository<Order> orderRepository,
            IRepository<ForumPost> forumPostRepository,
            IRepository<ForumTopic> forumTopicRepository,
            IRepository<BlogComment> blogCommentRepository,
            IRepository<NewsComment> newsCommentRepository,
            IRepository<PollVotingRecord> pollVotingRecordRepository,
            IRepository<ProductReview> productReviewRepository,
            IRepository<ProductReviewHelpfulness> productReviewHelpfulnessRepository,
            IGenericAttributeService genericAttributeService,
            IDataProvider dataProvider,
            IDbContext dbContext,
            IEventPublisher eventPublisher,
            CustomerSettings customerSettings,
            CommonSettings commonSettings)
            : base(cacheManager, customerRepository, customerPasswordRepository, customerRoleRepository, gaRepository, orderRepository, forumPostRepository,
                forumTopicRepository, blogCommentRepository, newsCommentRepository, pollVotingRecordRepository, productReviewRepository,
                productReviewHelpfulnessRepository, genericAttributeService, dataProvider, dbContext, eventPublisher, customerSettings,
                commonSettings)
        {
            this._cacheManager = cacheManager;
            this._customerRepository = customerRepository;
            this._customerPasswordRepository = customerPasswordRepository;
            this._customerRoleRepository = customerRoleRepository;
            this._gaRepository = gaRepository;
            this._orderRepository = orderRepository;
            this._forumPostRepository = forumPostRepository;
            this._forumTopicRepository = forumTopicRepository;
            this._blogCommentRepository = blogCommentRepository;
            this._newsCommentRepository = newsCommentRepository;
            this._pollVotingRecordRepository = pollVotingRecordRepository;
            this._productReviewRepository = productReviewRepository;
            this._productReviewHelpfulnessRepository = productReviewHelpfulnessRepository;
            this._genericAttributeService = genericAttributeService;
            this._dataProvider = dataProvider;
            this._dbContext = dbContext;
            this._eventPublisher = eventPublisher;
            this._customerSettings = customerSettings;
            this._commonSettings = commonSettings;
        }

        #endregion

        /// <summary>
        /// Gets all customers
        /// </summary>
        /// <returns>Customer collection</returns>
        public virtual IPagedList<Customer> GetFilteredCustomers(string filter = null,
            bool filterByEmail = false,
            bool filterByUsername = false,
            bool filterByFirstName = false,
            bool filterByLastName = false,
            //bool filterByDayOfBirth = false, 
            //bool filterByMonthOfBirth = false,
            bool filterByCompany = false,
            bool filterByPhone = false,
            bool filterByZipPostalCode = false,
            //bool loadOnlyWithShoppingCart = false, 
            //ShoppingCartType? sct = null, 
            int[] customerRoleIds = null,
            int pageIndex = 0, int pageSize = 2147483647)
        {
            var query1 = from c in _customerRepository.Table
                join ga in _gaRepository.Table on c.Id equals ga.EntityId
                where //(filterByEmail && !String.IsNullOrEmpty(c.Email) && c.Email.Contains(filter)) ||
                    ((ga.KeyGroup == "Customer")
                       && ((filterByUsername && !String.IsNullOrEmpty(c.Username) && c.Username.Contains(filter))
                           ||
                           (filterByFirstName && ga.Key == "FirstName" && !String.IsNullOrEmpty(ga.Value) &&
                            ga.Value.Contains(filter))
                           ||
                           (filterByLastName && ga.Key == "LastName" && !String.IsNullOrEmpty(ga.Value) &&
                            ga.Value.Contains(filter))
                           ||
                           (filterByCompany && ga.Key == "Company" && !String.IsNullOrEmpty(ga.Value) &&
                            ga.Value.Contains(filter))
                           ||
                           (filterByPhone && ga.Key == "Phone" && !String.IsNullOrEmpty(ga.Value) &&
                            ga.Value.Contains(filter))
                           ||
                           (filterByZipPostalCode && ga.Key == "ZipPostalCode" && !String.IsNullOrEmpty(ga.Value) &&
                            ga.Value.Contains(filter))
                           ))
                orderby c.Email ascending
                select c;
            var query2 = from c in _customerRepository.Table
                where filterByEmail && !String.IsNullOrEmpty(c.Email) && c.Email.Contains(filter)
                //orderby c.Email ascending
                select c;
            
            query1 = query1.Where(c => !c.Deleted);
            query2 = query2.Where(c => !c.Deleted);

            if (customerRoleIds != null && customerRoleIds.Length > 0)
            {
                query1 = query1.Where(c => c.CustomerRoles.Select(cr => cr.Id).Intersect(customerRoleIds).Any());
                query2 = query2.Where(c => c.CustomerRoles.Select(cr => cr.Id).Intersect(customerRoleIds).Any());
            }

            var customers = query1.ToList();
            customers.AddRange(query2.ToList());

            return new PagedList<Customer>(customers, pageIndex, pageSize);

            /*query = query.Where(c => !c.Deleted);

            if (customerRoleIds != null && customerRoleIds.Length > 0)
                query = query.Where(c => c.CustomerRoles.Select(cr => cr.Id).Intersect(customerRoleIds).Any());

            //query = query.OrderByDescending(c => c.CreatedOnUtc);

            var customers = new PagedList<Customer>(query, pageIndex, pageSize);
            return customers;*/
        }

    }
}
