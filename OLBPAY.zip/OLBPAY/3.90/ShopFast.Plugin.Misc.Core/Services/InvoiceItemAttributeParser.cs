﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Xml;
using System.Xml.Serialization;
using Nop.Core.Domain.Catalog;
using Nop.Data;
using Nop.Services.Catalog;
using ShopFast.Plugin.Misc.Core.Domain;

namespace ShopFast.Plugin.Misc.Core.Services
{
    public class InvoiceItemAttributeParser : ProductAttributeParser
    {
        private readonly IDbContext _context;
        private readonly IProductAttributeService _productAttributeService;

        public InvoiceItemAttributeParser(IDbContext context,
            IProductAttributeService productAttributeService)
            : base (context, productAttributeService)
        {
            this._context = context;
            this._productAttributeService = productAttributeService;
        }

        public string AddInvoiceItemAttributes(string attributesXml, InvoiceItemAttributeMapping invoiceItemAttributeMapping)
        {
            return AddInvoiceItemAttributes(attributesXml, invoiceItemAttributeMapping.InvoiceId,
                invoiceItemAttributeMapping.Description, invoiceItemAttributeMapping.Taxable);
        }

        /// <summary>
        /// Add invoice item attrbibutes
        /// </summary>
        /// <param name="attributesXml">Attributes in XML format</param>
        /// <param name="invoiceId">Invoice Id</param>
        /// <param name="description">Description</param>
        /// <param name="taxable">Taxable</param>
        /// <returns>Attributes</returns>
        public string AddInvoiceItemAttributes(string attributesXml, int invoiceId, string description, bool taxable)
        {
            string result = string.Empty;
            try
            {
                description = description.Trim();

                var xmlDoc = new XmlDocument();
                if (String.IsNullOrEmpty(attributesXml))
                {
                    var element1 = xmlDoc.CreateElement("Attributes");
                    xmlDoc.AppendChild(element1);
                }
                else
                {
                    xmlDoc.LoadXml(attributesXml);
                }

                var rootElement = (XmlElement)xmlDoc.SelectSingleNode(@"//Attributes");

                var invoiceItemElement = (XmlElement)xmlDoc.SelectSingleNode(@"//Attributes/InvoiceItem");
                if (invoiceItemElement == null)
                {
                    invoiceItemElement = xmlDoc.CreateElement("InvoiceItem");
                    rootElement.AppendChild(invoiceItemElement);
                }

                var recipientNameElement = xmlDoc.CreateElement("InvoiceId");
                recipientNameElement.InnerText = invoiceId.ToString();
                invoiceItemElement.AppendChild(recipientNameElement);

                var recipientEmailElement = xmlDoc.CreateElement("Description");
                recipientEmailElement.InnerText = description;
                invoiceItemElement.AppendChild(recipientEmailElement);

                var senderNameElement = xmlDoc.CreateElement("Taxable");
                senderNameElement.InnerText = taxable.ToString();
                invoiceItemElement.AppendChild(senderNameElement);

                result = xmlDoc.OuterXml;
            }
            catch (Exception exc)
            {
                Debug.Write(exc.ToString());
            }
            return result;
        }

        /// <summary>
        /// Get invoice item attrbibutes
        /// </summary>
        /// <param name="attributesXml">Attributes</param>
        public InvoiceItemAttributeMapping GetInvoiceItemAttributeMapping(string attributesXml)
        {
            try
            {
                var invoiceItemAttributeMapping = new InvoiceItemAttributeMapping();

                var xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(attributesXml);

                var invoiceIdElement = (XmlElement)xmlDoc.SelectSingleNode(@"//Attributes/InvoiceItem/InvoiceId");
                var descriptionElement = (XmlElement)xmlDoc.SelectSingleNode(@"//Attributes/InvoiceItem/Description");
                var taxableElement = (XmlElement)xmlDoc.SelectSingleNode(@"//Attributes/InvoiceItem/Taxable");

                if (invoiceIdElement != null)
                    invoiceItemAttributeMapping.InvoiceId = Int32.Parse(invoiceIdElement.InnerText);
                if (descriptionElement != null)
                    invoiceItemAttributeMapping.Description = descriptionElement.InnerText;
                if (taxableElement != null)
                    invoiceItemAttributeMapping.Taxable = Boolean.Parse(taxableElement.InnerText);

                return invoiceItemAttributeMapping;
            }
            catch (Exception exc)
            {
                Debug.Write(exc.ToString());
                return null;
            }
        }

        /// <summary>
        /// Get invoice item attrbibutes
        /// </summary>
        /// <param name="attributesXml1">Attributes 1</param>
        /// <param name="attributesXml2">Attributes 2</param>
        public bool AreInvoiceItemAttributesEqual(string attributesXml1, string attributesXml2)
        {
            var iiam1 = GetInvoiceItemAttributeMapping(attributesXml1);
            var iiam2 = GetInvoiceItemAttributeMapping(attributesXml2);

            if (iiam1 == null || iiam2 == null)
                return false;

            return iiam1.InvoiceId == iiam2.InvoiceId 
                && iiam1.Description == iiam2.Description 
                && iiam1.Taxable == iiam2.Taxable;
        }


        /*private const string AttributeNodeName = "Attributes";
        private const string VariantAttributeNodeName = "InvoiceItemVariantAttribute";
        private const string VariantAttributeValueNodeName = "InvoiceItemVariantAttributeValue";
        /// <summary>
        /// Adds an attribute
        /// </summary>
        /// <param name="attributesXml">Attributes in XML format</param>
        /// <param name="productAttributeMapping">Product attribute mapping</param>
        /// <param name="value">Value</param>
        /// <returns>Attributes</returns>
        public virtual string AddProductAttribute(string attributesXml,
            ProductAttributeMapping productAttributeMapping, string value)
        {
            int productAttributeMappingId = productAttributeMapping.Id;

            string result = string.Empty;
            try
            {
                var xmlDoc = new XmlDocument();

                if (String.IsNullOrEmpty(attributesXml))
                {
                    var attributesExt = xmlDoc.CreateElement(AttributeNodeName);
                    xmlDoc.AppendChild(attributesExt);
                }
                else
                {
                    xmlDoc.LoadXml(attributesXml);
                }
                var rootElement = (XmlElement)xmlDoc.SelectSingleNode(@"//" + AttributeNodeName);

                if (rootElement == null)
                {
                    var attributesExt = xmlDoc.CreateElement(AttributeNodeName);
                    xmlDoc.AppendChild(attributesExt);
                    rootElement = attributesExt;
                }

                XmlElement attributeElement = null;
                //find existing
                var invoiceItemVariantAttributes = xmlDoc.SelectNodes(@"//" + AttributeNodeName + "/"
                    + VariantAttributeNodeName);
                foreach (XmlNode productVariantAttribute in invoiceItemVariantAttributes)
                {
                    if (productVariantAttribute.Attributes != null &&
                        productVariantAttribute.Attributes["ID"] != null)
                    {
                        string str1 = productVariantAttribute.Attributes["ID"].InnerText.Trim();
                        int id;
                        if (int.TryParse(str1, out id))
                        {
                            if (id == productAttributeMappingId)
                            {
                                attributeElement = (XmlElement)productVariantAttribute;
                                break;
                            }
                        }
                    }
                }

                //create new one if not found
                if (attributeElement == null)
                {
                    attributeElement = xmlDoc.CreateElement(VariantAttributeNodeName);
                    attributeElement.SetAttribute("ID", productAttributeMappingId.ToString());
                    rootElement.AppendChild(attributeElement);
                }


                var attributeValueElement = xmlDoc.CreateElement(VariantAttributeValueNodeName);
                attributeElement.AppendChild(attributeValueElement);

                var attributeValueValueElement = xmlDoc.CreateElement("Value");
                attributeValueValueElement.InnerText = value;
                attributeValueElement.AppendChild(attributeValueValueElement);

                result = xmlDoc.OuterXml;
            }
            catch (Exception exc)
            {
                Debug.Write(exc.ToString());
            }
            return result;
        }

        public string ConvertInvoiceAttributesToXml(string attributesXml, int invoiceId,
            string description, bool taxable)
        {
            attributesXml = AddProductAttribute(attributesXml, new ProductAttributeMapping { Id = 1 },
                invoiceId.ToString());
            attributesXml = AddProductAttribute(attributesXml, new ProductAttributeMapping { Id = 1 },
                description);
            attributesXml = AddProductAttribute(attributesXml, new ProductAttributeMapping { Id = 1 },
                taxable.ToString());
            return "";//attributesXml;
        }

        public InvoiceItemAttributeMapping GetInvoiceItemAttributeMapping(string xmlString)
        {
            if (xmlString == null)
            {
                return null;
            }
            var values = ParseValues(xmlString, 1);
            if (values.Count < 3)
            {
                return null;
            }

            try
            {
                return null;
                InvoiceItemAttributeMapping result = new InvoiceItemAttributeMapping
                {
                    InvoiceId = Int32.Parse(values[0]),
                    Description = values[1],
                    Taxable = Boolean.Parse(values[2])
                };
                return result;
            }
            catch (Exception exc)
            {
                return null;
            }
        }

        /// <summary>
        /// Gets selected product attribute values
        /// </summary>
        /// <param name="attributesXml">Attributes in XML format</param>
        /// <param name="productAttributeMappingId">Product attribute mapping identifier</param>
        /// <returns>Product attribute values</returns>
        public virtual IList<string> ParseValues(string attributesXml, int productAttributeMappingId)
        {
            var selectedValues = new List<string>();
            try
            {
                var xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(attributesXml);

                var nodeList1 = xmlDoc.SelectNodes(@"//" + AttributeNodeName + "/" + VariantAttributeNodeName);
                foreach (XmlNode node1 in nodeList1)
                {
                    if (node1.Attributes != null && node1.Attributes["ID"] != null)
                    {
                        string str1 = node1.Attributes["ID"].InnerText.Trim();
                        int id;
                        if (int.TryParse(str1, out id))
                        {
                            if (id == productAttributeMappingId)
                            {
                                var nodeList2 = node1.SelectNodes(VariantAttributeValueNodeName + @"/Value");
                                foreach (XmlNode node2 in nodeList2)
                                {
                                    string value = node2.InnerText.Trim();
                                    selectedValues.Add(value);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception exc)
            {
                Debug.Write(exc.ToString());
            }
            return selectedValues;
        }*/
    }
}
