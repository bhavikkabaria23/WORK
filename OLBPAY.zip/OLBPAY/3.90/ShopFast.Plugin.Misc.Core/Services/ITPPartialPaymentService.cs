﻿using System;
using System.Collections.Generic;
using System.Linq;
using Nop.Core;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Common;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Directory;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Core.Domain.Shipping;
using Nop.Core.Plugins;
using Nop.Services.Catalog;
using Nop.Services.Common;
using Nop.Services.Configuration;
using Nop.Services.Customers;
using Nop.Services.Directory;
using Nop.Services.Orders;
using Nop.Services.Payments;
using Nop.Services.Security;
using SystemCustomerAttributeNames = ShopFast.Plugin.Misc.Core.Extensions.SystemCustomerAttributeNames;

namespace ShopFast.Plugin.Misc.Core.Services
{
    /// <summary>
    /// Payment service with partial payment support
    /// </summary>
    public partial class ITPPartialPaymentService : PaymentService, IITPPartialPaymentService
    {
        #region Fields

        private readonly IGenericAttributeService _genericAttributeService;
        private readonly IOrderService _orderService;
        private readonly IWorkContext _workContext;
        private readonly IStoreContext _storeContext;
        private readonly ICurrencyService _currencyService;
        private readonly ICustomerService _customerService;
        private readonly IPluginFinder _pluginFinder;
        private readonly ISettingService _settingService;
        private readonly IPriceFormatter _priceFormatter;

        private readonly PaymentSettings _paymentSettings;
        private readonly ShoppingCartSettings _shoppingCartSettings;
        private readonly CurrencySettings _currencySettings;
        private readonly IEncryptionService _encryptionService;
        private readonly ICustomNumberFormatter _customNumberFormatter;

        #endregion

        #region Ctor

        public ITPPartialPaymentService(
            PaymentSettings paymentSettings, 
            IPluginFinder pluginFinder,
            ISettingService settingService,
            ShoppingCartSettings shoppingCartSettings,
            IGenericAttributeService genericAttributeService,
            IOrderService orderService,
            IWorkContext workContext,
            IStoreContext storeContext,
            ICurrencyService currencyService,
            CurrencySettings currencySettings,
            IPriceFormatter priceFormatter, 
            ICustomerService customerService, 
            IEncryptionService encryptionService,
            ICustomNumberFormatter customNumberFormatter) 
            : base(paymentSettings, pluginFinder, settingService, shoppingCartSettings)
        {
            _paymentSettings = paymentSettings;
            _pluginFinder = pluginFinder;
            _settingService = settingService;
            _shoppingCartSettings = shoppingCartSettings;
            _genericAttributeService = genericAttributeService;
            _orderService = orderService;
            _workContext = workContext;
            _storeContext = storeContext;
            _currencyService = currencyService;
            _currencySettings = currencySettings;
            _priceFormatter = priceFormatter;
            _customerService = customerService;
            _encryptionService = encryptionService;
            this._customNumberFormatter = customNumberFormatter;
        }

        #endregion

        #region Utilites

        protected virtual void CheckOrderStatus(Order order)
        {
            if (order == null)
                throw new ArgumentNullException("order");

            var payments = GetOrderPayments(order);
            if (payments.Any())
            {
                if (GetRemainingBalance(order, true) == decimal.Zero
                    && order.PaymentStatus != PaymentStatus.Paid)
                {
                    order.PaymentStatus = PaymentStatus.Paid;
                    _orderService.UpdateOrder(order);
                }
            }

            if (order.PaymentStatus == PaymentStatus.Paid && !order.PaidDateUtc.HasValue)
            {
                //ensure that paid date is set
                order.PaidDateUtc = DateTime.UtcNow;
                _orderService.UpdateOrder(order);
            }

            if (order.OrderStatus == OrderStatus.Pending)
            {
                if (order.PaymentStatus == PaymentStatus.Authorized ||
                    order.PaymentStatus == PaymentStatus.Paid)
                {
                    order.OrderStatus = OrderStatus.Processing;
                    _orderService.UpdateOrder(order);
                }
            }

            if (order.OrderStatus == OrderStatus.Pending)
            {
                if (order.ShippingStatus == ShippingStatus.PartiallyShipped ||
                    order.ShippingStatus == ShippingStatus.Shipped ||
                    order.ShippingStatus == ShippingStatus.Delivered)
                {
                    order.OrderStatus = OrderStatus.Processing;
                    _orderService.UpdateOrder(order);
                }
            }

            if (order.OrderStatus != OrderStatus.Cancelled &&
                order.OrderStatus != OrderStatus.Complete)
            {
                if (order.PaymentStatus == PaymentStatus.Paid)
                {
                    if (order.ShippingStatus == ShippingStatus.ShippingNotRequired || order.ShippingStatus == ShippingStatus.Delivered)
                    {
                        order.OrderStatus = OrderStatus.Complete;
                        _orderService.UpdateOrder(order);
                    }
                }
            }
        }

        #endregion

        #region Methods

        #region Get partial payment data

        public Order InsertPartialPaymentOrder(ProcessPaymentRequest processPaymentRequest, ProcessPaymentResult processPaymentResult, 
            int parentOrderId, string paymentMethodSystemName, decimal paymentTotal = decimal.Zero, int? customerId = null)
        {
            //if (!processPaymentResult.Success)
            //    return null;

            var parentOrder = _orderService.GetOrderById(parentOrderId);
            if (parentOrder == null)
                return null;

            Customer customer = null;
            if (customerId != null)
                customer = _customerService.GetCustomerById((int) customerId);
            if (customer == null)
                customer = parentOrder.Customer;
            //customer = _workContext.CurrentCustomer;

            var currencyTmp = _currencyService.GetCurrencyById(customer.GetAttribute<int>(
               Nop.Core.Domain.Customers.SystemCustomerAttributeNames.CurrencyId,
               _storeContext.CurrentStore.Id));
            var customerCurrency = (currencyTmp != null && currencyTmp.Published)
                ? currencyTmp : _workContext.WorkingCurrency;
            var primaryStoreCurrency = _currencyService.GetCurrencyById(_currencySettings.PrimaryStoreCurrencyId);
            var customerCurrencyRate = customerCurrency.Rate / primaryStoreCurrency.Rate;

            var paymentOrder = new Order
            {
                OrderGuid = Guid.NewGuid(),
                Customer = customer,
                BillingAddress = customer.BillingAddress,
                CreatedOnUtc = DateTime.UtcNow,
                StoreId = _storeContext.CurrentStore.Id,
                ShippingStatus = ShippingStatus.ShippingNotRequired,
                OrderStatus = OrderStatus.Complete,

                CustomerCurrencyCode = customerCurrency.CurrencyCode,
                CurrencyRate = customerCurrencyRate,
                OrderTotal = paymentTotal,
                OrderSubtotalInclTax = paymentTotal,
                OrderSubtotalExclTax = paymentTotal,
                OrderTax = decimal.Zero,

                PaymentStatus = processPaymentResult.NewPaymentStatus,
                PaymentMethodSystemName = paymentMethodSystemName,
                //PaidDateUtc = DateTime.UtcNow,
            };

            paymentOrder.AllowStoringCreditCardNumber = processPaymentResult.AllowStoringCreditCardNumber;
            paymentOrder.CardType = processPaymentResult.AllowStoringCreditCardNumber
                ? _encryptionService.EncryptText(processPaymentRequest.CreditCardType)
                : string.Empty;
            paymentOrder.CardName = processPaymentResult.AllowStoringCreditCardNumber
                ? _encryptionService.EncryptText(processPaymentRequest.CreditCardName)
                : string.Empty;
            paymentOrder.CardNumber = processPaymentResult.AllowStoringCreditCardNumber
                ? _encryptionService.EncryptText(processPaymentRequest.CreditCardNumber)
                : string.Empty;
            paymentOrder.MaskedCreditCardNumber = _encryptionService.EncryptText(
                GetMaskedCreditCardNumber(processPaymentRequest.CreditCardNumber));
            paymentOrder.CardCvv2 = processPaymentResult.AllowStoringCreditCardNumber
                ? _encryptionService.EncryptText(processPaymentRequest.CreditCardCvv2)
                : string.Empty;
            paymentOrder.CardExpirationMonth = processPaymentResult.AllowStoringCreditCardNumber
                ? _encryptionService.EncryptText(processPaymentRequest.CreditCardExpireMonth.ToString())
                : string.Empty;
            paymentOrder.CardExpirationYear = processPaymentResult.AllowStoringCreditCardNumber
                ? _encryptionService.EncryptText(processPaymentRequest.CreditCardExpireYear.ToString())
                : string.Empty;
            paymentOrder.PaymentMethodSystemName = processPaymentRequest.PaymentMethodSystemName;
            paymentOrder.AuthorizationTransactionId = processPaymentResult.AuthorizationTransactionId;
            paymentOrder.AuthorizationTransactionCode = processPaymentResult.AuthorizationTransactionCode;
            paymentOrder.AuthorizationTransactionResult = processPaymentResult.AuthorizationTransactionResult;
            paymentOrder.CaptureTransactionId = processPaymentResult.CaptureTransactionId;
            paymentOrder.CaptureTransactionResult = processPaymentResult.CaptureTransactionResult;
            paymentOrder.SubscriptionTransactionId = processPaymentResult.SubscriptionTransactionId;
            paymentOrder.PaymentStatus = processPaymentResult.NewPaymentStatus;
            paymentOrder.CustomOrderNumber = string.Empty;
            _orderService.InsertOrder(paymentOrder);

            //generate and set custom order number
            paymentOrder.CustomOrderNumber = _customNumberFormatter.GenerateOrderCustomNumber(paymentOrder);
            _orderService.UpdateOrder(parentOrder);

            InsertPartialPaymentAttribute(parentOrder, paymentOrder, _storeContext.CurrentStore.Id);

            UpdateOrderPaymentStatus(parentOrder);

            return paymentOrder;
        }
        
        /// <summary>
        /// Check if order is completly paid
        /// </summary>
        public void UpdateOrderPaymentStatus(Order parentOrder)
        {
            if (GetRemainingBalance(parentOrder, true) == decimal.Zero)
            {
                parentOrder.PaymentStatus = PaymentStatus.Paid;
                var payments = GetOrderPayments(parentOrder);
                foreach (var payment in payments)
                {
                    if (payment.PaymentStatus != PaymentStatus.Paid)
                    {
                        parentOrder.PaymentStatus = PaymentStatus.Pending;
                    }
                }
            }
            else
            {
                parentOrder.PaymentStatus = PaymentStatus.Pending;
            }
        }

        public ICollection<Order> GetOrderPayments(Order parentOrder, Customer paymentCustomer = null)
        {
            if (parentOrder == null)
                return null;

            ICollection<Order> payments = _genericAttributeService.GetAttributesForEntity(parentOrder.Id, "Order")
                .Where(ga => ga.Key == SystemCustomerAttributeNames.PartialPaymentId)
                .Select(ga => _orderService.GetOrderById(Int32.Parse(ga.Value)))
                .Distinct()
                .ToList();

            if (paymentCustomer != null)
                payments = payments.Where(p => p.Customer == paymentCustomer).ToList();

            return payments;
        }

        public void InsertPartialPaymentAttribute(Order parentOrder, Order payment, int storeId = 0)
        {
            _genericAttributeService.InsertAttribute(new GenericAttribute
            {
                EntityId = payment.Id,
                KeyGroup = "Order",
                Key = SystemCustomerAttributeNames.InvoiceType,
                Value = "PartialPayment",
                StoreId = storeId
            });

            _genericAttributeService.InsertAttribute(new GenericAttribute
            {
                EntityId = parentOrder.Id,
                KeyGroup = "Order",
                Key = SystemCustomerAttributeNames.PartialPaymentId,
                Value = payment.Id.ToString(),
                StoreId = storeId
            });
        }

        public decimal GetAmountPaid(Order order, bool onlyPaid = false)
        {
            var result = decimal.Zero;
            GetOrderPayments(order).ToList().ForEach(p => 
                result += p.PaymentStatus == PaymentStatus.Paid || !onlyPaid
                    ? p.OrderTotal 
                    : decimal.Zero);

            return result;
        }

        public decimal GetRemainingBalance(List<Order> orders, bool onlyPaid = false)
        {
            return orders.Sum(order => GetRemainingBalance(order, onlyPaid));
        }

        public decimal GetRemainingBalance(Order order, bool onlyPaid = false)
        {
            return order.OrderTotal - GetAmountPaid(order, onlyPaid);
        }

        public virtual ProcessPaymentResult ProcessPaymentForMultipleOrders(ProcessPaymentRequest processPaymentRequest,
            List<Order> orders)
        {
            Order paymentOrder;
            return ProcessPaymentForMultipleOrders(processPaymentRequest, orders, out paymentOrder);
        }

        public virtual ProcessPaymentResult ProcessPaymentForMultipleOrders(ProcessPaymentRequest processPaymentRequest, 
            List<Order> orders, out Order paymentOrder)
        {
            paymentOrder = null;
            orders.Sort((order1, order2) => order1.CreatedOnUtc.CompareTo(order2.CreatedOnUtc));
            if (GetRemainingBalance(orders) < processPaymentRequest.OrderTotal)
            {
                //Order requires less amount to pay
                var result = new ProcessPaymentResult
                {
                    Errors = new List<string>() { "Amount is higher than remaining balance" }
                };
                return result;
            }

            ProcessPaymentResult processPaymentResult = null;
            decimal remainingBalance = processPaymentRequest.OrderTotal;
            List<Order> ordersFullyPaid = new List<Order>();
            Dictionary<Order, decimal> ordersPartiallyPaid = new Dictionary<Order, decimal>();

            processPaymentRequest.InitialOrderId = 0;

            //We should define which orders we can pay fully and which will be paid partially
            foreach (var order in orders)
            { 
                if (remainingBalance == decimal.Zero)
                    break;

                order.PaymentMethodSystemName = processPaymentRequest.PaymentMethodSystemName;
                _orderService.UpdateOrder(order);

                if (remainingBalance - GetRemainingBalance(order) < decimal.Zero)
                {
                    ordersPartiallyPaid.Add(order, remainingBalance);
                    break;
                }

                // if it last payment for this order (order was )
                var orderRemainingBalance = GetRemainingBalance(order);
                if (order.OrderTotal > orderRemainingBalance && remainingBalance >= orderRemainingBalance)
                {
                    ordersPartiallyPaid.Add(order, GetRemainingBalance(order));
                    remainingBalance -= GetRemainingBalance(order);
                    continue;
                }

                ordersFullyPaid.Add(order);
                remainingBalance -= GetRemainingBalance(order);
            }

            //We should strip out any white space or dash in the CC number entered.
            if (!String.IsNullOrWhiteSpace(processPaymentRequest.CreditCardNumber))
            {
                processPaymentRequest.CreditCardNumber = processPaymentRequest.CreditCardNumber.Replace(" ", "");
                processPaymentRequest.CreditCardNumber = processPaymentRequest.CreditCardNumber.Replace("-", "");
            }
            var paymentMethod = LoadPaymentMethodBySystemName(processPaymentRequest.PaymentMethodSystemName);
            if (paymentMethod == null)
                throw new NopException("Payment method couldn't be loaded");
            processPaymentResult = paymentMethod.ProcessPayment(processPaymentRequest);

            if (processPaymentResult.Success)
            {
                foreach (var order in ordersPartiallyPaid.Keys)
                {
                    paymentOrder = InsertPartialPaymentOrder(processPaymentRequest, processPaymentResult, order.Id,
                        processPaymentRequest.PaymentMethodSystemName, ordersPartiallyPaid[order]);

                    CheckOrderStatus(order);
                }
                
                foreach (var order in ordersFullyPaid)
                {
                    order.PaymentStatus = processPaymentResult.NewPaymentStatus;
                    order.PaymentMethodSystemName = processPaymentRequest.PaymentMethodSystemName;
                    _orderService.UpdateOrder(order);

                    CheckOrderStatus(order);

                    if (paymentOrder == null)
                        paymentOrder = order;
                }
            }

            return processPaymentResult;
        }

        #endregion

        #region Overloaded methods from PaymentService


        /// <summary>
        /// Process a payment
        /// </summary>
        /// <param name="processPaymentRequest">Payment info required for an order processing</param>
        /// <returns>Process payment result</returns>
        public override ProcessPaymentResult ProcessPayment(ProcessPaymentRequest processPaymentRequest)
        {
            Order paymentOrder = null;
            var processPaymentResult = ProcessPayment(processPaymentRequest, out paymentOrder);
            return processPaymentResult;
        }

        /// <summary>
        /// Process a payment
        /// </summary>
        /// <param name="processPaymentRequest">Payment info required for an order processing</param>
        /// <param name="paymentOrder">Created order which contains data about proceeded partial payment</param>
        /// <returns>Process payment result</returns>
        public virtual ProcessPaymentResult ProcessPayment(ProcessPaymentRequest processPaymentRequest,
            out Order paymentOrder)
        {
            paymentOrder = null;

            if (processPaymentRequest.OrderTotal == decimal.Zero)
            {
                var result = new ProcessPaymentResult
                {
                    NewPaymentStatus = PaymentStatus.Paid
                };
                return result;
            }

            var order = _orderService.GetOrderById(processPaymentRequest.InitialOrderId);
            if (order == null)
            {
                return new ProcessPaymentResult()
                {
                    Errors = new List<string>() {"Order not found"}
                };
            }

            if (GetRemainingBalance(order) < processPaymentRequest.OrderTotal)
            {
                //Order requires less amount to pay
                var result = new ProcessPaymentResult
                {
                    Errors = new List<string>() { "Amount is higher than remaining balance" }
                };
                return result;
            }

            //We should strip out any white space or dash in the CC number entered.
            if (!String.IsNullOrWhiteSpace(processPaymentRequest.CreditCardNumber))
            {
                processPaymentRequest.CreditCardNumber = processPaymentRequest.CreditCardNumber.Replace(" ", "");
                processPaymentRequest.CreditCardNumber = processPaymentRequest.CreditCardNumber.Replace("-", "");
            }

            var paymentMethod = LoadPaymentMethodBySystemName(processPaymentRequest.PaymentMethodSystemName);
            if (paymentMethod == null)
                throw new NopException("Payment method couldn't be loaded");
            var processPaymentResult = paymentMethod.ProcessPayment(processPaymentRequest);
            if (processPaymentResult.Success)
            {
                paymentOrder = InsertPartialPaymentOrder(processPaymentRequest, processPaymentResult, 
                    processPaymentRequest.InitialOrderId, processPaymentRequest.PaymentMethodSystemName, 
                    processPaymentRequest.OrderTotal, processPaymentRequest.CustomerId);
            }

            return processPaymentResult;
        }

        /// <summary>
        /// Post process payment (used by payment gateways that require redirecting to a third-party URL)
        /// </summary>
        /// <param name="postProcessPaymentRequest">Payment info required for an order processing</param>
        public override void PostProcessPayment(PostProcessPaymentRequest postProcessPaymentRequest)
        {
            //already paid or order.OrderTotal == decimal.Zero
            if (postProcessPaymentRequest.Order.PaymentStatus == PaymentStatus.Paid)
                return;

            var paymentMethod = LoadPaymentMethodBySystemName(postProcessPaymentRequest.Order.PaymentMethodSystemName);
            if (paymentMethod == null)
                throw new NopException("Payment method couldn't be loaded");
            paymentMethod.PostProcessPayment(postProcessPaymentRequest);
        }


        /// <summary>
        /// Refunds a payment
        /// </summary>
        /// <param name="refundPaymentRequest">Request</param>
        /// <returns>Result</returns>
        public override RefundPaymentResult Refund(RefundPaymentRequest refundPaymentRequest)
        {
            var payments = GetOrderPayments(refundPaymentRequest.Order);
            if (payments.Any())
            {
                var result = new RefundPaymentResult
                {
                    Errors = new List<string>() { "Can't refund a partially paid order"}
                };
                return result;
            }

            var paymentMethod = LoadPaymentMethodBySystemName(refundPaymentRequest.Order.PaymentMethodSystemName);
            if (paymentMethod == null)
                throw new NopException("Payment method couldn't be loaded");
            return paymentMethod.Refund(refundPaymentRequest);
        }

        /// <summary>
        /// Voids a payment
        /// </summary>
        /// <param name="voidPaymentRequest">Request</param>
        /// <returns>Result</returns>
        public override VoidPaymentResult Void(VoidPaymentRequest voidPaymentRequest)
        {
            var payments = GetOrderPayments(voidPaymentRequest.Order);
            if (payments.Any())
            {
                var result = new VoidPaymentResult
                {
                    Errors = new List<string>() { "Can't void a partially paid order" }
                };
                return result;
            }

            var paymentMethod = LoadPaymentMethodBySystemName(voidPaymentRequest.Order.PaymentMethodSystemName);
            if (paymentMethod == null)
                throw new NopException("Payment method couldn't be loaded");
            return paymentMethod.Void(voidPaymentRequest);
        }

        /// <summary>
        /// Process recurring payment
        /// </summary>
        /// <param name="processPaymentRequest">Payment info required for an order processing</param>
        /// <returns>Process payment result</returns>
        public override ProcessPaymentResult ProcessRecurringPayment(ProcessPaymentRequest processPaymentRequest)
        {
            if (processPaymentRequest.OrderTotal == decimal.Zero)
            {
                var result = new ProcessPaymentResult
                {
                    NewPaymentStatus = PaymentStatus.Paid
                };
                return result;
            }
            //?????????????????????????????????????????????????????????
            var paymentMethod = LoadPaymentMethodBySystemName(processPaymentRequest.PaymentMethodSystemName);
            if (paymentMethod == null)
                throw new NopException("Payment method couldn't be loaded");
            return paymentMethod.ProcessRecurringPayment(processPaymentRequest);
        }

        /// <summary>
        /// Cancels a recurring payment
        /// </summary>
        /// <param name="cancelPaymentRequest">Request</param>
        /// <returns>Result</returns>
        public override CancelRecurringPaymentResult CancelRecurringPayment(CancelRecurringPaymentRequest cancelPaymentRequest)
        {
            if (cancelPaymentRequest.Order.OrderTotal == decimal.Zero)
                return new CancelRecurringPaymentResult();

            var paymentMethod = LoadPaymentMethodBySystemName(cancelPaymentRequest.Order.PaymentMethodSystemName);
            if (paymentMethod == null)
                throw new NopException("Payment method couldn't be loaded");
            return paymentMethod.CancelRecurringPayment(cancelPaymentRequest);
        }

        #endregion

        #endregion
    }
}
