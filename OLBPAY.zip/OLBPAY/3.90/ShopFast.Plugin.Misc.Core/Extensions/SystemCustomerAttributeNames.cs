﻿namespace ShopFast.Plugin.Misc.Core.Extensions
{
    public class SystemCustomerAttributeNames
    {
        public static string Weight { get { return "Stock weight"; } }

        public static string InvoiceType { get { return "InvoiceType"; } }

        public static string PartialPaymentId { get { return "PartialPaymentId"; } }
    }
}
