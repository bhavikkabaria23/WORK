﻿using System;
using System.Collections.Generic;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Orders;
using Nop.Services.Payments;
using System.Net;
using System.IO;
using System.Text;
using System.Net.Http;
using System.Web;
using System.Net.Http.Headers;
using NopGuru.Nop.Plugins.Payments.Vipps.Models;
using System.Globalization;
using Nop.Services.Customers;
using System.Linq;
using Nop.Services.Plugins;
using Microsoft.AspNetCore.Http;
using Nop.Core;

namespace NopGuru.Nop.Plugins.Payments.Vipps
{
    /// <summary>
    /// NopGuru.Nop.Plugins.Payments.Vipps processor
    /// </summary>
    public class VippsPaymentProcessor : BasePlugin, IPaymentMethod
    {
        #region Fields

        private readonly ILocalizationService _localizationService;
        private readonly VippsPaymentSettings _VippsPaymentSettings;
        private readonly ISettingService _settingService;
        private readonly IOrderTotalCalculationService _orderTotalCalculationService;
        private readonly ICustomerService _customerService;
        private readonly IOrderService _orderService;
        private readonly IWebHelper _webHelper;
        private readonly IPaymentService _paymentService;



        #endregion

        #region Ctor

        public VippsPaymentProcessor(ILocalizationService localizationService,
            IPaymentService paymentService,
            VippsPaymentSettings VippsPaymentSettings,
            ISettingService settingService, IOrderTotalCalculationService orderTotalCalculationService,
            ICustomerService customerService,
            IOrderService orderService,
            IWebHelper webHelper)
        {
            this._localizationService = localizationService;
            _paymentService = paymentService;
            this._VippsPaymentSettings = VippsPaymentSettings;
            this._settingService = settingService;
            this._orderTotalCalculationService = orderTotalCalculationService;
            this._customerService = customerService;
            this._orderService = orderService;
            _webHelper = webHelper;
        }

        #endregion

        #region Utilities
        private PaymentResponse VippsAPI(ProcessPaymentRequest request, out string error)
        {
            error = "";
          
            var paymentResponse = new PaymentResponse();
            if (Convert.ToInt32(request.OrderTotal) < 100 || Convert.ToInt32(request.OrderTotal) > 9999999)
            {
                error = _localizationService.GetResource("Plugins.Payments.Vipps.Fields.InvalidAmount");
                return paymentResponse;
            }
            try
            {
                var client = new HttpClient();
                var queryString = HttpUtility.ParseQueryString(string.Empty);

                // Request headers
                client.DefaultRequestHeaders.Add("client_id", _VippsPaymentSettings.ClientId);
                client.DefaultRequestHeaders.Add("client_secret", _VippsPaymentSettings.ClientSecret);
                client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", _VippsPaymentSettings.SubscriptionKeyToken);

                var uriToken = _VippsPaymentSettings.BaseAPIUrl + "/accessToken/get";

                HttpResponseMessage responseToken;

                // Request body
                byte[] byteData = Encoding.UTF8.GetBytes("{body}");

                using (var content = new ByteArrayContent(byteData))
                {
                    //content.Headers.ContentType = new MediaTypeHeaderValue("application/json; charset=utf-8");
                    responseToken = client.PostAsync(uriToken, content).Result;
                    if (responseToken.IsSuccessStatusCode)
                    {
                        var tokenResult = responseToken.Content.ReadAsAsync<TokenResult>().Result;
                        client = new HttpClient();

                        //var date = new DateTimeOffset(2016, 3, 29, 12, 20, 35, 93, TimeSpan.FromHours(-5));
                        var date = new DateTimeOffset(DateTime.Now);

                        // Request headers
                        client.DefaultRequestHeaders.Add("Authorization", "Bearer " + tokenResult.access_token);
                        client.DefaultRequestHeaders.Add("X-Request-Id", _VippsPaymentSettings.RequestId);
                        client.DefaultRequestHeaders.Add("X-TimeStamp", FormatIso8601(date));
                        //client.DefaultRequestHeaders.Add("X-TimeStamp", "2014-06-24T08:34:25-07:00");
                        client.DefaultRequestHeaders.Add("X-Source-Address", _VippsPaymentSettings.SourceAddress);
                        client.DefaultRequestHeaders.Add("X-App-Id", _VippsPaymentSettings.ClientId);
                        client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", _VippsPaymentSettings.SubscriptionKeyPayment);
                        //client.DefaultRequestHeaders.Add("Content-Type", "application/json");

                        var uriPayment = _VippsPaymentSettings.BaseAPIUrl + "/Ecomm/v1/payments";

                        HttpResponseMessage responsePayment;

                        // Request body

                        Random ran = new Random();
                        int orderId = ran.Next();
                        string mobileNumber = Convert.ToString(request.CustomValues.FirstOrDefault(c => c.Key == "MobileNumber").Value);

                        string bodyContent = "{{" +
         "\"merchantInfo\": {{" +
         "\"merchantSerialNumber\": \"{0}\"," +
         "\"callBack\": \"{1}\"" +
         "}}," +
         "\"customerInfo\": {{" +
         "\"mobileNumber\":\"{2}\"" +
         "}}," +
         "\"transaction\": {{" +
         "\"orderId\": \"{3}\"," +
              //"\"refOrderId\": \"{4}\"," +
         "\"amount\": {4}," +
         "\"transactionText\": \"{5}\"," +
         "\"timeStamp\":\"{6}\"" +
         "}}" +
         "}}";


                        //            string bodyContent = "{" +
                        //"\"merchantInfo\": {" +
                        //"\"merchantSerialNumber\": \"" + _VippsPaymentSettings.MerchantSerialNumber + "\"," +
                        //"\"callBack\": \"" + _VippsPaymentSettings.PaymentCallBackUrl + "\"" +
                        //"}," +
                        //"\"customerInfo\": {" +
                        //"\"mobileNumber\":\"" + mobileNumber + "\"" +
                        //"}," +
                        //"\"transaction\": {" +
                        //"\"orderId\": \"" + request.InitialOrderId + "\"," +
                        //     "\"refOrderId\": \"" + request.OrderGuid + "\"," +
                        //"\"amount\": " + request.OrderTotal + "," +
                        //"\"transactionText\": \"" + _VippsPaymentSettings.TransactionText + "\"," +
                        //"\"timeStamp\":\"" + FormatIso8601(date) + "\"" +
                        //"}" +
                        //"}";

                        // bodyContent = string.Format(bodyContent,
                        //_VippsPaymentSettings.MerchantSerialNumber,
                        //_VippsPaymentSettings.PaymentCallBackUrl,
                        //mobileNumber,
                        //    "878798",
                        // "119930211",
                        ////request.OrderGuid.ToString(),
                        ////request.OrderGuid.ToString(),
                        //Convert.ToInt32(request.OrderTotal),
                        //_VippsPaymentSettings.TransactionText,
                        //"2014-06-24T08:34:25-07:00"
                        ////FormatIso8601(date)
                        //);

                        bodyContent = string.Format(bodyContent,
                            _VippsPaymentSettings.MerchantSerialNumber,
                      _VippsPaymentSettings.PaymentCallBackUrl,
                        mobileNumber,
                            orderId.ToString(),
                            //request.OrderGuid.ToString(),
                            Convert.ToInt32(request.OrderTotal * 100),
                            _VippsPaymentSettings.TransactionText,
                            "2014-06-24T08:34:25-07:00");

                        byteData = Encoding.UTF8.GetBytes(bodyContent);

                        using (var contentPayment = new ByteArrayContent(byteData))
                        {
                            contentPayment.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                            responsePayment = client.PostAsync(uriPayment, contentPayment).Result;
                            if (responsePayment.IsSuccessStatusCode)
                            {
                                paymentResponse = responsePayment.Content.ReadAsAsync<PaymentResponse>().Result;
                                if (!string.IsNullOrEmpty(paymentResponse.errorCode))
                                {
                                    error = "errorCode = " + paymentResponse.errorCode + " ,errorGroup = " + paymentResponse.errorGroup + " ,errorMessage = " + paymentResponse.errorMessage+ ", ";
                                }                          
                            }
                            else
                            {
                                error += "Status Code = " + responsePayment.StatusCode + " ,Request = " + responsePayment.RequestMessage;
                            }
                        }
                    }
                }
                return paymentResponse;
            }
            catch (Exception ex)
            {
                // Something else went wrong, e.g. invalid arguments passed to the order object.
                error = ex.Message;
                return paymentResponse;
            }
        }

        private PaymentResponse VippsCaptureAPI(CapturePaymentRequest request, out string error)
        {
            error = "";

            var paymentResponse = new PaymentResponse();
            if (request.Order != null)
            {
                try
                {
                    var client = new HttpClient();
                    var queryString = HttpUtility.ParseQueryString(string.Empty);

                    // Request headers
                    client.DefaultRequestHeaders.Add("client_id", _VippsPaymentSettings.ClientId);
                    client.DefaultRequestHeaders.Add("client_secret", _VippsPaymentSettings.ClientSecret);
                    client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", _VippsPaymentSettings.SubscriptionKeyToken);

                    var uriToken = _VippsPaymentSettings.BaseAPIUrl + "/accessToken/get";

                    HttpResponseMessage responseToken;

                    // Request body
                    byte[] byteData = Encoding.UTF8.GetBytes("{body}");

                    using (var content = new ByteArrayContent(byteData))
                    {
                        responseToken = client.PostAsync(uriToken, content).Result;
                        if (responseToken.IsSuccessStatusCode)
                        {
                            var tokenResult = responseToken.Content.ReadAsAsync<TokenResult>().Result;
                            client = new HttpClient();

                            var date = new DateTimeOffset(DateTime.Now);

                            // Request headers
                            client.DefaultRequestHeaders.Add("Authorization", "Bearer " + tokenResult.access_token);
                            client.DefaultRequestHeaders.Add("X-Request-Id", _VippsPaymentSettings.RequestId);
                            client.DefaultRequestHeaders.Add("X-TimeStamp", FormatIso8601(date));
                            client.DefaultRequestHeaders.Add("X-Source-Address", _VippsPaymentSettings.SourceAddress);
                            client.DefaultRequestHeaders.Add("X-App-Id", _VippsPaymentSettings.ClientId);
                            client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", _VippsPaymentSettings.SubscriptionKeyPayment);

                            // request.Order.CaptureTransactionId is passed as a Vipps Order id which was added as CaptureTransactionId when initiate payment
                            var uriPayment = _VippsPaymentSettings.BaseAPIUrl + "/Ecomm/v1/payments/" + request.Order.CaptureTransactionId.ToString() + "/capture";

                            HttpResponseMessage responsePayment;

                            // Request body                                               

                            string bodyContent = "{{" +
             "\"merchantInfo\": {{" +
                    "\"merchantSerialNumber\": \"{0}\"" +
                "}}," +
             "\"transaction\": {{" +
                    "\"amount\": {1}," +
                    "\"transactionText\": \"{2}\"" +
                "}}" +
             "}}";
                            bodyContent = string.Format(bodyContent,
                                _VippsPaymentSettings.MerchantSerialNumber,
                                Convert.ToInt32(request.Order.OrderTotal * 100),
                                _VippsPaymentSettings.TransactionText);

                            byteData = Encoding.UTF8.GetBytes(bodyContent);

                            using (var contentPayment = new ByteArrayContent(byteData))
                            {
                                contentPayment.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                                responsePayment = client.PostAsync(uriPayment, contentPayment).Result;
                                if (responsePayment.IsSuccessStatusCode)
                                {
                                    paymentResponse = responsePayment.Content.ReadAsAsync<PaymentResponse>().Result;
                                    if (!string.IsNullOrEmpty(paymentResponse.errorCode))
                                    {
                                        error = "errorCode = " + paymentResponse.errorCode + " ,errorGroup = " + paymentResponse.errorGroup + " ,errorMessage = " + paymentResponse.errorMessage + ", ";
                                    }
                                }
                                else
                                {
                                    if (responsePayment.StatusCode.ToString().ToLower() == "paymentrequired")
                                    {
                                        error = "Betaling mislyktes. Husk å bekrefte i Vipps-appen.";
                                    }
                                    else
                                    {
                                        error += " Status Code = " + responsePayment.StatusCode + " ,Request = " + responsePayment.RequestMessage;
                                    }
                                }
                            }
                        }
                    }
                    return paymentResponse;
                }
                catch (Exception ex)
                {
                    // Something else went wrong, e.g. invalid arguments passed to the order object.
                    error = ex.Message;
                    return paymentResponse;
                }
            }
            error = "Order is not exist";
            return paymentResponse;
        }

        public static string FormatIso8601(DateTimeOffset dto)
        {
            string format = dto.Offset == TimeSpan.Zero
                ? "yyyy-MM-ddTHH:mm:ss.fffZ"
                : "yyyy-MM-ddTHH:mm:ss.fffzzz";

            return dto.ToString(format, CultureInfo.InvariantCulture);
        }
        #endregion

        #region Methods

        /// <summary>
        /// Process a payment
        /// </summary>
        /// <param name="processPaymentRequest">Payment info required for an order processing</param>
        /// <returns>Process payment result</returns>
        public ProcessPaymentResult ProcessPayment(ProcessPaymentRequest processPaymentRequest)
        {
            var result = new ProcessPaymentResult();
            string error = "";
            var paymentResponse = VippsAPI(processPaymentRequest, out error);
            if (string.IsNullOrEmpty(error))
            {               
                //if (paymentResponse.transactionInfo.status.ToLower() == "cancel" ||
                //    paymentResponse.transactionInfo.status.ToLower() == "autocancel" ||
                //    paymentResponse.transactionInfo.status.ToLower() == "failed")
                //{
                //    result.NewPaymentStatus = PaymentStatus.Pending;
                //}
                //else if (paymentResponse.transactionInfo.status.ToLower() == "void")
                //{mo
                //    result.NewPaymentStatus = PaymentStatus.Voided;
                //}
                //else
                //{
                //    result.NewPaymentStatus = PaymentStatus.Paid;
                //}

                if (paymentResponse.transactionInfo.status.ToLower() == "cancel" ||
                   paymentResponse.transactionInfo.status.ToLower() == "autocancel" ||
                   paymentResponse.transactionInfo.status.ToLower() == "failed")
                {
                    result.NewPaymentStatus = PaymentStatus.Pending;
                }
                else if(paymentResponse.transactionInfo.status.ToLower() == "void")
                {
                    result.NewPaymentStatus = PaymentStatus.Voided;
                }
                else // status = "INITIATE"
                {
                    result.NewPaymentStatus = PaymentStatus.Authorized;
                    result.CaptureTransactionResult = paymentResponse.transactionInfo.status;
                    result.SubscriptionTransactionId = paymentResponse.transactionInfo.transactionId;
                    result.CaptureTransactionId = paymentResponse.orderId;

                    // Capture Payment manually
                    //CapturePaymentRequest captureRequest = new CapturePaymentRequest();
                    //captureRequest.Order = new Order()
                    //    {
                    //    OrderTotal = Convert.ToDecimal(paymentResponse.transactionInfo.amount),
                    //    CaptureTransactionId = paymentResponse.orderId
                    //};

                    //var captureResult = Capture(captureRequest);
                    //if (captureResult.Errors != null && captureResult.Errors.Any())
                    //{
                    //    result.Errors = captureResult.Errors;
                    //}
                    //else
                    //{
                    //    result.CaptureTransactionResult = captureResult.CaptureTransactionResult;
                    //    result.CaptureTransactionId = captureResult.CaptureTransactionId;
                    //}
                }                               
            }
            else
            {
                result.AddError(error);
            }
            return result;
        }

        protected string GetRequestData(string url, out string error)
        {
            string responseData = "";
            error = "";
            try
            {
                WebRequest request = WebRequest.Create(url); //Type url here
                using (WebResponse response = request.GetResponse())
                {
                    using (StreamReader responseReader = new StreamReader(response.GetResponseStream()))
                    {
                        responseData = responseReader.ReadToEnd();
                    }
                }
            }
            catch (WebException wex)
            {
                error = wex.Message;
            }
            catch (Exception ex)
            {
                error = ex.Message;
            }
            return responseData;
        }

        /// <summary>
        /// Post process payment (used by payment gateways that require redirecting to a third-party URL)
        /// </summary>
        /// <param name="postProcessPaymentRequest">Payment info required for an order processing</param>
        public void PostProcessPayment(PostProcessPaymentRequest postProcessPaymentRequest)
        {
            //nothing
        }

        /// <summary>
        /// Returns a value indicating whether payment method should be hidden during checkout
        /// </summary>
        /// <param name="cart">Shoping cart</param>
        /// <returns>true - hide; false - display.</returns>
        public bool HidePaymentMethod(IList<ShoppingCartItem> cart)
        {
            //you can put any logic here
            //for example, hide this payment method if all products in the cart are downloadable
            //or hide this payment method if current customer is from certain country
            return false;
        }

        /// <summary>
        /// Gets additional handling fee
        /// </summary>
        /// <returns>Additional handling fee</returns>
        public decimal GetAdditionalHandlingFee(IList<ShoppingCartItem> cart)
        {
            return _paymentService.CalculateAdditionalFee(cart,
              _VippsPaymentSettings.AdditionalFee, _VippsPaymentSettings.AdditionalFeePercentage);
        }

        /// <summary>
        /// Captures payment
        /// </summary>
        /// <param name="capturePaymentRequest">Capture payment request</param>
        /// <returns>Capture payment result</returns>
        public CapturePaymentResult Capture(CapturePaymentRequest capturePaymentRequest)
        {
            var result = new CapturePaymentResult();
            string error = "";
            var paymentResponse = VippsCaptureAPI(capturePaymentRequest, out error);
            if (string.IsNullOrEmpty(error))
            {
                // Stutus can be "checkout_incomplete" or "created" or "checkout_complete"
                if (paymentResponse.transactionInfo.status.ToLower() == "cancel" ||
                    paymentResponse.transactionInfo.status.ToLower() == "autocancel" ||
                    paymentResponse.transactionInfo.status.ToLower() == "failed")
                {
                    result.NewPaymentStatus = PaymentStatus.Pending;
                }
                else if (paymentResponse.transactionInfo.status.ToLower() == "void")
                {
                    result.NewPaymentStatus = PaymentStatus.Voided;
                }

                else if (paymentResponse.transactionInfo.status.ToLower() == "capture")
                {
                    result.NewPaymentStatus = PaymentStatus.Paid;
                }
                else
                {
                    result.NewPaymentStatus = PaymentStatus.Pending;
                }
                result.CaptureTransactionResult = paymentResponse.transactionInfo.status;                
                result.CaptureTransactionId = paymentResponse.orderId;
            }
            else
            {
                result.AddError(error);
            }
            return result;
        }

        /// <summary>
        /// Refunds a payment
        /// </summary>
        /// <param name="refundPaymentRequest">Request</param>
        /// <returns>Result</returns>
        public RefundPaymentResult Refund(RefundPaymentRequest refundPaymentRequest)
        {
            var result = new RefundPaymentResult();
            result.AddError("Refund method not supported");
            return result;
        }

        /// <summary>
        /// Voids a payment
        /// </summary>
        /// <param name="voidPaymentRequest">Request</param>
        /// <returns>Result</returns>
        public VoidPaymentResult Void(VoidPaymentRequest voidPaymentRequest)
        {
            var result = new VoidPaymentResult();
            result.AddError("Void method not supported");
            return result;
        }

        /// <summary>
        /// Process recurring payment
        /// </summary>
        /// <param name="processPaymentRequest">Payment info required for an order processing</param>
        /// <returns>Process payment result</returns>
        public ProcessPaymentResult ProcessRecurringPayment(ProcessPaymentRequest processPaymentRequest)
        {
            var result = new ProcessPaymentResult();
            result.AddError("Recurring payment not supported");
            return result;
        }

        /// <summary>
        /// Cancels a recurring payment
        /// </summary>
        /// <param name="cancelPaymentRequest">Request</param>
        /// <returns>Result</returns>
        public CancelRecurringPaymentResult CancelRecurringPayment(CancelRecurringPaymentRequest cancelPaymentRequest)
        {
            //always success
            return new CancelRecurringPaymentResult();
        }

        /// <summary>
        /// Gets a value indicating whether customers can complete a payment after order is placed but not completed (for redirection payment methods)
        /// </summary>
        /// <param name="order">Order</param>
        /// <returns>Result</returns>
        public bool CanRePostProcessPayment(Order order)
        {
            if (order == null)
                throw new ArgumentNullException("order");

            //it's not a redirection payment method. So we always return false
            return false;
        }

        /// <summary>
        /// Validate payment form
        /// </summary>
        /// <param name="form">The parsed form values</param>
        /// <returns>List of validating errors</returns>
        public IList<string> ValidatePaymentForm(IFormCollection form)
        {
            var warnings = new List<string>();

            ////validate
            //var validator = new PaymentInfoValidator(_localizationService);
            //var model = new PaymentInfoModel
            //{
            //    CardholderName = form["CardholderName"],
            //    CardNumber = form["CardNumber"],
            //    CardCode = form["CardCode"],
            //    ExpireMonth = form["ExpireMonth"],
            //    ExpireYear = form["ExpireYear"]
            //};
            //var validationResult = validator.Validate(model);
            //if (!validationResult.IsValid)
            //    warnings.AddRange(validationResult.Errors.Select(error => error.ErrorMessage));

            return warnings;
        }

        /// <summary>
        /// Get payment information
        /// </summary>
        /// <param name="form">The parsed form values</param>
        /// <returns>Payment info holder</returns>
        public ProcessPaymentRequest GetPaymentInfo(IFormCollection form)
        {
            var paymentInfo = new ProcessPaymentRequest();
            //paymentInfo.CreditCardType = form["CreditCardType"];
            //paymentInfo.CreditCardName = form["CardholderName"];
            //paymentInfo.CreditCardNumber = form["CardNumber"];
            //paymentInfo.CreditCardExpireMonth = int.Parse(form["ExpireMonth"]);
            //paymentInfo.CreditCardExpireYear = int.Parse(form["ExpireYear"]);
            //paymentInfo.CreditCardCvv2 = form["CardCode"];
            paymentInfo.CustomValues.Add("MobileNumber", form["MobileNumber"]);
            return paymentInfo;
        }

        /// <summary>
        /// Gets a configuration page URL
        /// </summary>
        public override string GetConfigurationPageUrl()
        {
            return $"{_webHelper.GetStoreLocation()}Admin/PaymentsVipps/Configure";
        }

        /// <summary>
        /// Gets a name of a view component for displaying plugin in public store ("payment info" checkout step)
        /// </summary>
        /// <returns>View component name</returns>
        public string GetPublicViewComponentName()
        {
            return "PaymentsVipps";
        }

        public override void Install()
        {
            //locales
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.AdditionalFee", "Additional fee");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.AdditionalFee.Hint", "Enter additional fee to charge your customers.");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.AdditionalFeePercentage", "Additional fee. Use percentage");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.AdditionalFeePercentage.Hint", "Determines whether to apply a percentage additional fee to the order total. If not enabled, a fixed value is used.");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.BaseAPIUrl", "Base API Url");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.BaseAPIUrlHelp", "Don't include / at the end of URL");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.BaseAPIUrl.Hint", "Base API Url.");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.ClientId", "Client Id");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.ClientId.Hint", "Client Id.");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.ClientSecret", "Client Secret");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.ClientSecret.Hint", "Client Secret.");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.SubscriptionKeyToken", "Subscription Key for Token");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.SubscriptionKeyToken.Hint", "Subscription Key for Token.");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.RequestId", "Request Id");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.RequestId.Hint", "Request Id.");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.SourceAddress", "Source Address (IP Address)");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.SourceAddress.Hint", "Source Address (IP Address).");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.SubscriptionKeyPayment", "Subscription Key for Payment");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.SubscriptionKeyPayment.Hint", "Subscription Key for Payment.");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.MerchantSerialNumber", "Merchant Serial Number");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.MerchantSerialNumber.Hint", "Merchant Serial Number.");            
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.TransactionText", "Transaction Text");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.TransactionText.Hint", "Transaction Text.");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.PaymentCallBackUrl", "Payment Call Back Url");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.PaymentCallBackUrl.Hint", "Payment Call Back Url.");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.PaymentMethodDescription", "Pay by credit / debit card");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.InvalidAmount", "Amount is invalid. Minimum amount value should be 100 and maximum amount value should be 9999999.");


            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.Vipps.Fields.MobileNumber.Required", "Mobile Number is required");


            base.Install();
        }

        public override void Uninstall()
        {
            //settings
            _settingService.DeleteSetting<VippsPaymentSettings>();

            //locales
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.AdditionalFee");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.AdditionalFee.Hint");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.AdditionalFeePercentage");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.AdditionalFeePercentage.Hint");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.BaseAPIUrl");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.BaseAPIUrl.Hint");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.ClientId");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.ClientId.Hint");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.ClientSecret");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.ClientSecret.Hint");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.SubscriptionKeyToken");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.SubscriptionKeyToken.Hint");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.RequestId");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.RequestId.Hint");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.SourceAddress");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.SourceAddress.Hint");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.SubscriptionKeyPayment");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.SubscriptionKeyPayment.Hint");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.MerchantSerialNumber");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.MerchantSerialNumber.Hint");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.MobileNumber");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.MobileNumber.Hint");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.TransactionText");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.TransactionText.Hint");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.PaymentCallBackUrl");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.PaymentCallBackUrl.Hint");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.PaymentMethodDescription");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.Vipps.Fields.InvalidAmount");

            base.Uninstall();
        }


        #endregion

        #region Properties

        /// <summary>
        /// Gets a value indicating whether capture is supported
        /// </summary>
        public bool SupportCapture
        {
            get
            {
                return true;
            }
        }

        /// <summary>
        /// Gets a value indicating whether partial refund is supported
        /// </summary>
        public bool SupportPartiallyRefund
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// Gets a value indicating whether refund is supported
        /// </summary>
        public bool SupportRefund
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// Gets a value indicating whether void is supported
        /// </summary>
        public bool SupportVoid
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// Gets a recurring payment type of payment method
        /// </summary>
        public RecurringPaymentType RecurringPaymentType
        {
            get
            {
                return RecurringPaymentType.Manual;
            }
        }

        /// <summary>
        /// Gets a payment method type
        /// </summary>
        public PaymentMethodType PaymentMethodType
        {
            get
            {
                return PaymentMethodType.Standard;
            }
        }

        /// <summary>
        /// Gets a value indicating whether we should display a payment information page for this plugin
        /// </summary>
        public bool SkipPaymentInfo
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// Gets a payment method description that will be displayed on checkout pages in the public store
        /// </summary>
        public string PaymentMethodDescription
        {
            //return description of this payment method to be display on "payment method" checkout step. good practice is to make it localizable
            //for example, for a redirection payment method, description may be like this: "You will be redirected to PayPal site to complete the payment"
            get { return _localizationService.GetResource("Plugins.Payments.Vipps.Fields.PaymentMethodDescription"); }
        }

        #endregion

    }
}
