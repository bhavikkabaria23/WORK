using Nop.Core.Configuration;

namespace NopGuru.Nop.Plugins.Payments.Vipps
{
    public class VippsPaymentSettings : ISettings
    {
        public bool AdditionalFeePercentage { get; set; }
       
        public decimal AdditionalFee { get; set; }

        public string BaseAPIUrl { get; set; }

        public string ClientId { get; set; }

        public string ClientSecret { get; set; }

        public string SubscriptionKeyToken { get; set; }

        public string RequestId { get; set; }        

        public string SourceAddress { get; set; }

        public string SubscriptionKeyPayment { get; set; }

        public string MerchantSerialNumber { get; set; }

        //public string MobileNumber { get; set; }        

        public string TransactionText { get; set; }

        public string PaymentCallBackUrl { get; set; }


    }
}
