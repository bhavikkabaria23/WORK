﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Nop.Web.Framework.Mvc.ModelBinding;
using Nop.Web.Framework.Models;

namespace NopGuru.Nop.Plugins.Payments.Vipps.Models
{
    public class ConfigurationModel : BaseNopModel
    {
        public int ActiveStoreScopeConfiguration { get; set; }

        [NopResourceDisplayName("Plugins.Payments.Vipps.Fields.AdditionalFeePercentage")]
        public bool AdditionalFeePercentage { get; set; }
        public bool AdditionalFeePercentage_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugins.Payments.Vipps.Fields.AdditionalFee")]
        public decimal AdditionalFee { get; set; }
        public bool AdditionalFee_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugins.Payments.Vipps.Fields.BaseAPIUrl")]
        public string BaseAPIUrl { get; set; }
        public bool BaseAPIUrl_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugins.Payments.Vipps.Fields.ClientId")]
        public string ClientId { get; set; }
        public bool ClientId_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugins.Payments.Vipps.Fields.ClientSecret")]
        public string ClientSecret { get; set; }
        public bool ClientSecret_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugins.Payments.Vipps.Fields.SubscriptionKeyToken")]
        public string SubscriptionKeyToken { get; set; }
        public bool SubscriptionKeyToken_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugins.Payments.Vipps.Fields.RequestId")]
        public string RequestId { get; set; }
        public bool RequestId_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugins.Payments.Vipps.Fields.SourceAddress")]
        public string SourceAddress { get; set; }
        public bool SourceAddress_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugins.Payments.Vipps.Fields.SubscriptionKeyPayment")]
        public string SubscriptionKeyPayment { get; set; }
        public bool SubscriptionKeyPayment_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugins.Payments.Vipps.Fields.MerchantSerialNumber")]
        public string MerchantSerialNumber { get; set; }
        public bool MerchantSerialNumber_OverrideForStore { get; set; }

        //[NopResourceDisplayName("Plugins.Payments.Vipps.Fields.MobileNumber")]
        //public string MobileNumber { get; set; }
        //public bool MobileNumber_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugins.Payments.Vipps.Fields.TransactionText")]
        public string TransactionText { get; set; }
        public bool TransactionText_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugins.Payments.Vipps.Fields.PaymentCallBackUrl")]
        public string PaymentCallBackUrl { get; set; }
        public bool PaymentCallBackUrl_OverrideForStore { get; set; }       
    }
}