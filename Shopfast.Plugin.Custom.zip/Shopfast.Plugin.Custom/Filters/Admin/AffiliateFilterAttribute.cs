﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Services.Catalog;
using Nop.Services.Common;

namespace Shopfast.Plugin.Custom.Filters.Admin
{
    public class AffiliateFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {           
        }


        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            var form = filterContext.HttpContext.Request.Unvalidated.Form;
            int affiliateId = 0;
            if (filterContext.ActionDescriptor.ActionName == "Create")
            {
                affiliateId = int.Parse(HttpContext.Current.Session["Admin_AffiliateController_Create_Affiliate_Id"].ToString());
                HttpContext.Current.Session["Admin_AffiliateController_Create_Affiliate_Id"] = null;
            }
            else
            {
                if (form != null)
                {
                    affiliateId = int.Parse(form["Id"]);
                }
            }          
            if (affiliateId > 0)
            {
                var LogoId = int.Parse(form["LogoId"]);                
                var dbContext = EngineContext.Current.Resolve<IDbContext>();                                
                dbContext.ExecuteSqlCommand("update Affiliate SET LogoId=@p0 WHERE id=@p1", false, null,
                   LogoId, affiliateId);
            }
        }
    }
}