﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Nop.Admin.Controllers;

namespace Shopfast.Plugin.Custom.Filters.Admin
{
    public class CustomerAdminFilterProvider : IFilterProvider
    {
        public IEnumerable<Filter> GetFilters(ControllerContext controllerContext, ActionDescriptor actionDescriptor)
        {
            if ((actionDescriptor.ControllerDescriptor.ControllerType == typeof(CustomerController)) &&
                (actionDescriptor.ActionName.Equals("Edit")) &&
                 controllerContext.HttpContext.Request.HttpMethod == "POST")
            {
                
                return new[]
                    {
                        new Filter(new CustomerAdminFilterAttribute(), FilterScope.Action, null)
                    };
            }

            return new Filter[] { };
        }
    }
}