﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Services.Catalog;
using Nop.Services.Common;

namespace Shopfast.Plugin.Custom.Filters.Admin
{
    public class ProductFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {

            //var form = filterContext.HttpContext.Request.Unvalidated.Form;
            //var productId = int.Parse(form["Id"]);
            //HttpContext.Current.Items["productId"] = productId;
            //var qrCode = form["QrCode"];
            ////var productService = EngineContext.Current.Resolve<IProductService>();
            ////var product = productService.GetProductById(productId);
            ////if (product != null)
            ////{
            ////    var genericAttributeService = EngineContext.Current.Resolve<IGenericAttributeService>();
            ////    genericAttributeService.SaveAttribute(product, "QrCode", qrCode);
            ////}

            //var dbContext = EngineContext.Current.Resolve<IDbContext>();

            //dbContext.ExecuteSqlCommand("update Product SET QrCode=@p0  WHERE id=@p1", false, null,
            //   qrCode,productId);
        }


        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {

            // Think for how to delete all barcode images ********************

            //var form = filterContext.HttpContext.Request.Unvalidated.Form;

            //var result = filterContext.Result as RedirectToRouteResult;
            //if (result != null)
            //{
            //    var productId = int.Parse(form["Id"]);
            //    if (productId == 0)
            //    {
            //        productId = (int)filterContext.HttpContext.Items["productId"];
            //    }
            //    if (productId > 0)
            //    {
            //        var BarcodeId = int.Parse(form["BarcodeId"]);
            //        var ShowOnPointOfSale = Convert.ToBoolean(form["ShowOnPointOfSale"].Split(',')[0]);
            //        var dbContext = EngineContext.Current.Resolve<IDbContext>();
            //        dbContext.ExecuteSqlCommand("update Product SET BarcodeId=@p0, ShowOnPointOfSale=@p1  WHERE id=@p2", false, null,
            //           BarcodeId, ShowOnPointOfSale, productId);
            //    }
            //}


            var form = filterContext.HttpContext.Request.Unvalidated.Form;
            int productId = 0;
            if (filterContext.ActionDescriptor.ActionName == "Create")
            {
                productId = int.Parse(HttpContext.Current.Session["Admin_ProductController_Create_Product_Id"].ToString());
                HttpContext.Current.Session["Admin_ProductController_Create_Product_Id"] = null;
            }
            else
            {
                if (form != null)
                {
                    productId = int.Parse(form["Id"]);
                }
            }          
            if (productId > 0)
            {
                var BarcodeId = int.Parse(form["BarcodeId"]);
                var ShowOnPointOfSale = Convert.ToBoolean(form["ShowOnPointOfSale"].Split(',')[0]);
                var dbContext = EngineContext.Current.Resolve<IDbContext>();
                var CustomFullDescription = form["CustomFullDescription"];
                var VideoUrl = form["VideoUrl"];
                dbContext.ExecuteSqlCommand("update Product SET BarcodeId=@p0, ShowOnPointOfSale=@p1,CustomFullDescription=@p2, VideoUrl=@p3 WHERE id=@p4", false, null,
                   BarcodeId, ShowOnPointOfSale,CustomFullDescription, VideoUrl, productId);
            }

        }
    }
}