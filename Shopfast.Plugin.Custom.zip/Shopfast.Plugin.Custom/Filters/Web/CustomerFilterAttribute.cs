﻿using Nop.Core;
using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Services.Payments;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Orders;
using Nop.Services.Orders;
using Nop.Web.Models.Checkout;
using Nop.Core.Data;
using Nop.Web.Models.Customer;
using Nop.Services.Customers;

namespace Shopfast.Plugin.Custom.Filters.Web
{
    public class CustomerFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (filterContext.ActionDescriptor.ActionName.ToLower().Equals("login"))
            {
                if (MultisiteHelper.IsAdminSite)
                {
                    if (filterContext.ActionParameters.ContainsKey("checkoutAsGuest"))
                    {
                        var param1 = filterContext.ActionParameters["checkoutAsGuest"];
                        if (param1 != null)
                        {
                            bool checkoutAsGuest = Convert.ToBoolean(param1);
                            if (checkoutAsGuest == true)
                            {
                                if (!EngineContext.Current.Resolve<OrderSettings>().AnonymousCheckoutAllowed)
                                {
                                    var result = new HttpUnauthorizedResult();
                                    filterContext.Result = result;
                                    return;
                                }
                                else
                                {

                                    var result = new RedirectResult("/checkout");
                                    filterContext.Result = result;
                                    return;
                                }
                            }
                        }
                    }
                }
            }
        }


        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            if (filterContext.ActionDescriptor.ActionName.ToLower().Equals("resellersignup"))
            {
                bool IsError = false;
                var ModelState = filterContext.Controller.ViewData.ModelState;
                if (ModelState != null)
                {
                    IsError = filterContext.Controller.ViewData.ModelState.Values.Any(m => m.Errors.Count() > 0);
                }
                if (!IsError)
                {
                    string Email = filterContext.HttpContext.Request.Form["Email"];
                    if (!string.IsNullOrEmpty(Email))
                    {
                        var customer = EngineContext.Current.Resolve<ICustomerService>().GetCustomerByEmail(Email);
                        var registeredRole = EngineContext.Current.Resolve<ICustomerService>().GetCustomerRoleBySystemName(SystemCustomerRoleNames.Vendors);
                        if (registeredRole != null)
                        {
                            customer.CustomerRoles.Add(registeredRole);
                            EngineContext.Current.Resolve<ICustomerService>().UpdateCustomer(customer);
                        }
                    }
                }
            }
        }
    }
}