﻿using Nop.Web.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Shopfast.Plugin.Custom.Filters.Web
{
    public class ShoppingCartFilterProvider : IFilterProvider
    {
        public IEnumerable<Filter> GetFilters(ControllerContext controllerContext, ActionDescriptor actionDescriptor)
        {
            if ((actionDescriptor.ControllerDescriptor.ControllerType == typeof(ShoppingCartController)) &&
                (actionDescriptor.ActionName.ToLower().Equals("addproducttocart_details") ||
                actionDescriptor.ActionName.ToLower().Equals("cart") ||
                actionDescriptor.ActionName.ToLower().Equals("updatecart") ||
                actionDescriptor.ActionName.ToLower().Equals("ordersummary")))
            {
                return new[]
                    {
                        new Filter(new ShoppingCartFilterAttribute(), FilterScope.Action, null)
                    };
            }

            return new Filter[] { };
        }
    }
}