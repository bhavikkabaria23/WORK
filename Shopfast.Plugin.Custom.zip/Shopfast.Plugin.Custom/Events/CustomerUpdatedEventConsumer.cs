﻿using Nop.Core.Data;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Customers;
using Nop.Core.Events;
using Nop.Services.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Events
{
    public class CustomerUpdatedEventConsumer : IConsumer<EntityInserted<Customer>>
    {
        public void HandleEvent(EntityInserted<Customer> eventMessage)
        {


            // This only for Sub domain                        
            //if (!MultisiteHelper.IsAdminSite)
            //{
            //    if (eventMessage.Entity.IsAdmin())
            //    {
            //        if (!string.IsNullOrEmpty(MultisiteHelper.SubDomain) &&
            //            !string.IsNullOrEmpty(oldEmailId) && !string.IsNullOrEmpty(eventMessage.Entity.Email))
            //        {
            //            //Update admin customer emailId to Sites Table. Not in used. because 
            //            // it is covered in below "UpdateCustomerByStore" method
            //            //MultisiteHelper.UpdateCustomerEmailId(oldEmailId, customer.Email, MultisiteHelper.SubDomain);

            //            //Update admin customer emailid,username and password to Subdomain store
            //            MultisiteHelper.UpdateCustomerByStore(oldEmailId, eventMessage.Entity.Email, eventMessage.Entity.Username);
            //        }
            //    }
            //}

            //var id = eventMessage.Entity.IsAdmin();
            //System.Web.HttpContext.Current.Session["Admin_ProductController_Create_Product_Id"] = id;
        }
    }
}