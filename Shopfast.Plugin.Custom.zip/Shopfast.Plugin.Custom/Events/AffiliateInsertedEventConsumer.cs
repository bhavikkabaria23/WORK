﻿using Nop.Core.Domain.Affiliates;
using Nop.Core.Events;
using Nop.Services.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Events
{
    public class AffiliateInsertedEventConsumer : IConsumer<EntityInserted<Affiliate>>
    {
        public void HandleEvent(EntityInserted<Affiliate> eventMessage)
        {
            var id = eventMessage.Entity.Id;
            System.Web.HttpContext.Current.Session["Admin_AffiliateController_Create_Affiliate_Id"] = id;
        }
    }
}