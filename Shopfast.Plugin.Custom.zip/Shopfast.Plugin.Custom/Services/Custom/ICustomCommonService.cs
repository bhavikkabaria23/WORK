﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Shopfast.Plugin.Custom.Models.NopAdmin.Vendors;

namespace Shopfast.Plugin.Custom.Services.Custom
{
    public interface ICustomCommonService
    {
        int GetNextRunJobTime(string applicationName);
        VendorModelCustom GetVendorsCustomFields(int vendorId);
    }
}