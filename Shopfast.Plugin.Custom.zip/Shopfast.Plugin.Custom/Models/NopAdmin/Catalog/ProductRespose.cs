﻿using MultiSite.Models;
using Nop.Admin.Models.Catalog;
using Nop.Core.Domain.Catalog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Models.NopAdmin.Catalog
{
    public class ProductRespose
    {
        public ProductRespose()
        {
            MonthlyPackageList = new List<AppProductListModel>();
            YearlyPackageList = new List<AppProductListModel>();
        }
        public List<AppProductListModel> MonthlyPackageList { get; set; }
        public List<AppProductListModel> YearlyPackageList { get; set; }        
        //public Product product { get; set; }
    }

    public class CheckoutResponse
    {
        public CheckoutResponse()
        {
            CheckoutTransactionResult = new OrderCompleted();
        }
        public OrderCompleted CheckoutTransactionResult { get; set; }
    }

    public class StoreCheckoutModel
    {
        public StoreCheckoutModel()
        {
            GetProductsResult = new List<Product>();
            ownerModel = new SiteRegistrationModel();
            ProductAttributes = new List<ProductAttributeModel>();
        }
        public List<Product> GetProductsResult { get; set; }
        public AppProductListModel product { get; set; }
        public SiteRegistrationModel ownerModel { get; set; }
        public string cardNumber { get; set; }
        public string Expires { get; set; }
        public string CVV { get; set; }
        public string password { get; set; }
        public List<ProductAttributeModel> ProductAttributes { get; set; }
    }

    public class OrderCompleted
    {
        /// <summary>
        /// Gets or sets a placed order unique identifier.
        /// </summary>        
        public int OrderId { get; set; }                
        /// <summary>
        /// Gets or sets a placed order payment transact mode.
        /// </summary>        
        public string TransactMode { get; set; }

        /// <summary>
        /// Gets or sets a placed order payment method (Card Type).
        /// </summary>        
        public string PaymentMethod { get; set; }

        /// <summary>
        /// Gets or sets a placed order payment authorization code.
        /// </summary>        
        public string AuthorizationCode { get; set; }

        /// <summary>
        /// Gets or sets a placed order payment transaction identifier.
        /// </summary>        
        public string TransactionId { get; set; }

        /// <summary>
        /// Gets or sets a true if order has been placed, otherwise false.
        /// </summary>        
        public bool Status { get; set; }

        /// <summary>
        /// Gets or sets an order transaction message.
        /// </summary>        
        public string Message { get; set; }
    }

    public class CheckoutTransaction
    {
        /// <summary>
        /// Gets or sets order products.
        /// </summary>        
        public string Products { get; set; }
        /// <summary>
        /// Gets or sets order product quantities.
        /// </summary>        
        public string Quantities { get; set; }
        /// <summary>
        /// Gets or sets order product attributes.
        /// </summary>        
        public string Attributes { get; set; }
        /// <summary>
        /// Gets or sets order total price.
        /// </summary>        
        public double TotalAmount { get; set; }
        /// <summary>
        /// Gets or sets customer email address.
        /// </summary>        
        public string Email { get; set; }
        /// <summary>
        /// Gets or sets credit card type.
        /// </summary>        
        public string CardType { get; set; }
        /// <summary>
        /// Gets or sets credit card name.
        /// </summary>        
        public string CardName { get; set; }
        /// <summary>
        /// Gets or sets credit card number.
        /// </summary>        
        public string CardNumber { get; set; }
        /// <summary>
        /// Gets or sets credit card expiry month.
        /// </summary>        
        public string ExpiryMonth { get; set; }
        /// <summary>
        /// Gets or sets credit card expiry year.
        /// </summary>        
        public string ExpiryYear { get; set; }
        /// <summary>
        /// Gets or sets card verification value.
        /// </summary>        
        public string VerifyCode { get; set; }
        /// <summary>
        /// Gets or sets checkout transaction type (swipe|check|cash|card|terminal|payment-data).
        /// </summary>        
        public string TransactionType { get; set; }
        /// <summary>
        /// Gets or sets Base64 String signature image.
        /// </summary>        
        public string Signature { get; set; }
        /// <summary>
        /// Gets or sets status which indicates whether use customer's balance reward point for the order.
        /// </summary>        
        public bool UseRewardPoints { get; set; }
        /// <summary>
        /// Gets or sets temporary order number.
        /// </summary>        
        public string TempOrderNumber { get; set; }
        /// <summary>
        /// Gets or sets credit card track data information captured from card reader.
        /// </summary>        
        public string CardTrackData { get; set; }
        /// <summary>
        /// Gets or sets card reader device model.
        /// </summary>        
        public string CardReaderDeviceModel { get; set; }
        /// <summary>
        /// Gets or sets card reader device number.
        /// </summary>        
        public string CardReaderDeviceNumber { get; set; }
        /// <summary>
        /// Gets or sets encrypted payment data.
        /// </summary>        
        public string PaymentData { get; set; }
    }

    public partial class ProductAttributeModel
    {
        /// <summary>
        /// Gets or sets the product attribute mapping identifier.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the product attribute identifier.
        /// </summary>
        public int ProductAttributeId { get; set; }

        /// <summary>
        /// Gets or sets the product attribute name.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the product attribute description.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets a value a text prompt
        /// </summary>
        public string TextPrompt { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the entity is required
        /// </summary>
        public bool IsRequired { get; set; }

        /// <summary>
        /// Default value for textboxes
        /// </summary>
        public string DefaultValue { get; set; }

        /// <summary>
        /// Allowed file extensions for customer uploaded files
        /// </summary>
        public IList<string> AllowedFileExtensions { get; set; }

        /// <summary>
        /// Gets or sets the attribute control type identifier
        /// </summary>
        public int AttributeControlTypeId { get; set; }

        /// <summary>
        /// Gets or sets the attribute control type name
        /// </summary>
        public string AttributeControlType { get; set; }

        /// <summary>
        /// Gets or sets the attribute values
        /// </summary>
        public IList<ProductAttributeValueModel> Values { get; set; }

        /// <summary>
        /// Gets or sets the display order
        /// </summary>
        public int DisplayOrder { get; set; }
    }
    public partial class ProductAttributeValueModel
    {
        /// <summary>
        /// Gets or sets the product attribute mapping identifier.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the product attribute value name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the color RGB value (used with "Color squares" attribute type)
        /// </summary>
        public string ColorSquaresRgb { get; set; }

        /// <summary>
        /// Gets or sets the price adjustment (used only with AttributeValueType.Simple)
        /// </summary>
        public string PriceAdjustment { get; set; }

        /// <summary>
        /// Gets or sets the weight adjustment (used only with AttributeValueType.Simple)
        /// </summary>
        public decimal PriceAdjustmentValue { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the value is pre-selected
        /// </summary>
        public bool IsPreSelected { get; set; }

        /// <summary>
        /// Gets or sets the picture (identifier) associated with this value (Scale: 1024)
        /// </summary>
        public string PictureUrl { get; set; }

        /// <summary>
        /// Gets or sets the picture (identifier) associated with this value
        /// </summary>
        public string FullSizePictureUrl { get; set; }
    }
}