﻿using System.Collections.Generic;

namespace Shopfast.Plugin.Custom.Models.NopAdmin.Catalog
{
    /// <summary>
    /// Represents a product list of tablet/mobile application.
    /// </summary>
    public partial class AppProductListModel
    {
        /// <summary>
        /// Gets or sets the product identifier.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the short description.
        /// </summary>
        public string ShortDescription { get; set; }

        /// <summary>
        /// Gets or sets the full description.
        /// </summary>
        public string FullDescription { get; set; }

        /// <summary>
        /// Gets or sets the SKU.
        /// </summary>
        public string Sku { get; set; }

        /// <summary>
        /// Gets or sets the Global Trade Item Number (GTIN). These identifiers include UPC (in North America), EAN (in Europe), JAN (in Japan), and ISBN (for books).
        /// </summary>
        public string Gtin { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the product is gift card
        /// </summary>
        public bool IsGiftCard { get; set; }

        /// <summary>
        /// Gets or sets the tax rate.
        /// </summary>
        public decimal TaxRate { get; set; }

        /// <summary>
        /// Gets or sets a value indicating how to manage inventory.
        /// </summary>
        public int ManageInventoryMethodId { get; set; }

        /// <summary>
        /// Gets or sets the stock quantity.
        /// </summary>
        public int StockQuantity { get; set; }

        /// <summary>
        /// Gets or sets the price.
        /// </summary>
        public decimal Price { get; set; }
        
        /// <summary>
        /// Gets or sets a value indicating whether a customer enters price.
        /// </summary>
        public bool CustomerEntersPrice { get; set; }

        /// <summary>
        /// Gets or sets the minimum price entered by a customer.
        /// </summary>
        public decimal MinimumCustomerEnteredPrice { get; set; }

        /// <summary>
        /// Gets or sets the maximum price entered by a customer.
        /// </summary>
        public decimal MaximumCustomerEnteredPrice { get; set; }

        /// <summary>
        /// Gets or sets the collection of product pictures (Scale: 300)
        /// </summary>
        public ICollection<ProductPictureModel> ProductPictures { get; set; }

        /// Gets or sets the collection of product large pictures (Scale: 1024)
        /// </summary>
        public ICollection<ProductPictureModel> ProductFullSizePictures { get; set; }

        /// <summary>
        /// Gets or sets the product category identifiers.
        /// </summary>
        public string ProductCategories { get; set; }

        /// <summary>
        /// Gets or sets the product attributes
        /// </summary>
        public ICollection<ProductAttributeModel> ProductAttributes { get; set; }

        public ICollection<ProductSpecificationAttributeModel> ProductSpecificationAttributes { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the entity is published
        /// </summary>
        public bool Published { get; set; }

        /// <summary>
        /// Gets or sets a display order.
        /// </summary>
        public int DisplayOrder { get; set; }        

        #region Nested classes

        /// <summary>
        /// Represents a product picture.
        /// </summary>
        public partial class ProductPictureModel
        {
            /// <summary>
            /// Gets or sets a picture url.
            /// </summary>
            public string PictureUrl { get; set; }

            /// <summary>
            /// Gets or sets a display order.
            /// </summary>
            public int DisplayOrder { get; set; }
        }

        /// <summary>
        /// Represents a product attribute.
        /// </summary>
        public partial class ProductAttributeModel
        {
            /// <summary>
            /// Gets or sets the product attribute mapping identifier.
            /// </summary>
            public int Id { get; set; }

            /// <summary>
            /// Gets or sets the product attribute identifier.
            /// </summary>
            public int ProductAttributeId { get; set; }

            /// <summary>
            /// Gets or sets the product attribute name.
            /// </summary>
            public string Name { get; set; }

            /// <summary>
            /// Gets or sets the product attribute description.
            /// </summary>
            public string Description { get; set; }

            /// <summary>
            /// Gets or sets a value a text prompt
            /// </summary>
            public string TextPrompt { get; set; }

            /// <summary>
            /// Gets or sets a value indicating whether the entity is required
            /// </summary>
            public bool IsRequired { get; set; }

            /// <summary>
            /// Default value for textboxes
            /// </summary>
            public string DefaultValue { get; set; }
            
            /// <summary>
            /// Allowed file extensions for customer uploaded files
            /// </summary>
            public IList<string> AllowedFileExtensions { get; set; }

            /// <summary>
            /// Gets or sets the attribute control type identifier
            /// </summary>
            public int AttributeControlTypeId { get; set; }

            /// <summary>
            /// Gets or sets the attribute control type name
            /// </summary>
            public string AttributeControlType { get; set; }

            /// <summary>
            /// Gets or sets the attribute values
            /// </summary>
            public IList<ProductAttributeValueModel> Values { get; set; }

            /// <summary>
            /// Gets or sets the display order
            /// </summary>
            public int DisplayOrder { get; set; }
        }

        /// <summary>
        /// Represents a product attribute value.
        /// </summary>
        public partial class ProductAttributeValueModel
        {
            /// <summary>
            /// Gets or sets the product attribute mapping identifier.
            /// </summary>
            public int Id { get; set; }

            /// <summary>
            /// Gets or sets the product attribute value name
            /// </summary>
            public string Name { get; set; }

            /// <summary>
            /// Gets or sets the color RGB value (used with "Color squares" attribute type)
            /// </summary>
            public string ColorSquaresRgb { get; set; }

            /// <summary>
            /// Gets or sets the price adjustment (used only with AttributeValueType.Simple)
            /// </summary>
            public string PriceAdjustment { get; set; }

            /// <summary>
            /// Gets or sets the weight adjustment (used only with AttributeValueType.Simple)
            /// </summary>
            public decimal PriceAdjustmentValue { get; set; }

            /// <summary>
            /// Gets or sets a value indicating whether the value is pre-selected
            /// </summary>
            public bool IsPreSelected { get; set; }

            /// <summary>
            /// Gets or sets the picture (identifier) associated with this value (Scale: 1024)
            /// </summary>
            public string PictureUrl { get; set; }

            /// <summary>
            /// Gets or sets the picture (identifier) associated with this value
            /// </summary>
            public string FullSizePictureUrl { get; set; }
        }

        public partial class ProductSpecificationAttributeModel
        {
            public int Id { get; set; }

            public string AttributeTypeName { get; set; }

            public string AttributeName { get; set; }

            public string ValueRaw { get; set; }

            public bool AllowFiltering { get; set; }

            public bool ShowOnProductPage { get; set; }

            public int DisplayOrder { get; set; }
        }

        #endregion
    }
}
