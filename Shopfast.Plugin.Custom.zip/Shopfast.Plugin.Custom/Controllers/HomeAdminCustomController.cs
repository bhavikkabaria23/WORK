﻿using Nop.Admin.Controllers;
using Nop.Admin.Models.News;
using Nop.Core.Data;
using Nop.Core.Domain.News;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Nop.Admin.Extensions;
using Shopfast.Plugin.Custom.Services;
using Nop.Core;

namespace Shopfast.Plugin.Custom.Controllers
{
    public class HomeAdminCustomController : BaseAdminController
    {
        #region Fields
        private readonly IStoreContext _storeContext;       
        private readonly IWorkContext _workContext;
        private readonly INewsServiceCustom _newsServiceCustom;
        private readonly NewsSettings _newsSettings;
        #endregion

        #region Ctor

        public HomeAdminCustomController(IStoreContext storeContext,             
            IWorkContext workContext,            
            INewsServiceCustom newsServiceCustom,
            NewsSettings newsSettings)
        {
            this._storeContext = storeContext;            
            this._workContext = workContext;
            this._newsServiceCustom = newsServiceCustom;
            this._newsSettings = newsSettings;
        }
        #endregion

        public ActionResult DashboardNews()
        {
            ActionResult viewBag;
            try
            {
                List<NewsItemModel> newsItemModels = new List<NewsItemModel>();
                List<NewsItem> allMainStoreNews = this._newsServiceCustom.GetAllNews(this._workContext.WorkingLanguage.Id, this._storeContext.CurrentStore.Id, this._newsSettings.MainPageNewsCount);
                foreach (NewsItem allMainStoreNew in allMainStoreNews)
                {
                    NewsItemModel model = allMainStoreNew.ToModel();
                    model.StartDate = allMainStoreNew.StartDateUtc;
                    model.EndDate = allMainStoreNew.EndDateUtc;
                    model.CreatedOn = allMainStoreNew.CreatedOnUtc;
                    newsItemModels.Add(model);
                }
                viewBag = base.PartialView(newsItemModels);
            }
            catch (Exception exception)
            {
                ((dynamic)base.ViewBag).error = exception.Message;
                viewBag = (ActionResult)this.Content(((dynamic)base.ViewBag).feedUrl);
            }
            return viewBag;
        }
    }
}