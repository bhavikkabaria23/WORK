﻿using Nop.Core;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Directory;
using Nop.Core.Domain.Discounts;
using Nop.Core.Domain.Orders;
using Nop.Core.Infrastructure;
using Nop.Services.Catalog;
using Nop.Services.Customers;
using Nop.Services.Directory;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Media;
using Nop.Services.Orders;
using Nop.Services.Security;
using Nop.Services.Tax;
using Nop.Web.Controllers;
using Nop.Web.Factories;
using Nop.Web.Framework.Themes;
using Nop.Web.Models.ShoppingCart;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Shopfast.Plugin.Custom.Controllers
{
    public class ShoppingCartCustomWebController : BasePublicController
    {
        #region Fields
        
        private readonly IPermissionService _permissionService;
        private readonly IWorkContext _workContext;
        private readonly IStoreContext _storeContext;
        private readonly IShoppingCartService _shoppingCartService;
        private readonly ITaxService _taxService;
        private readonly ICurrencyService _currencyService;
        private readonly IPriceFormatter _priceFormatter;
        private readonly IPriceCalculationService _priceCalculationService;
        private readonly ICustomerService _customerService;
        private readonly IShoppingCartModelFactory _shoppingCartModelFactory;


        //private readonly IProductAttributeService _productAttributeService;
        //private readonly IProductAttributeParser _productAttributeParser;
        //private readonly IDownloadService _downloadService;
        //private readonly ShoppingCartSettings _shoppingCartSettings;
        //private readonly IProductService _productService;
        //private readonly ILocalizationService _localizationService;
        //private readonly ICustomerActivityService _customerActivityService;

        #endregion

        #region Constructors
        public ShoppingCartCustomWebController(IPermissionService permissionService,
        IWorkContext workContext,
            IStoreContext storeContext,
            IShoppingCartService shoppingCartService,
            ITaxService taxService,
            ICurrencyService currencyService,
            IPriceFormatter priceFormatter,
            IPriceCalculationService priceCalculationService,
            ICustomerService customerService,
             IShoppingCartModelFactory shoppingCartModelFactory)
        {
            this._workContext = workContext;
            this._storeContext = storeContext;
            this._shoppingCartService = shoppingCartService;
            this._taxService = taxService;
            this._priceFormatter = priceFormatter;
            this._priceCalculationService = priceCalculationService;
            this._permissionService = permissionService;
            this._currencyService = currencyService;
            this._customerService = customerService;
            this._shoppingCartModelFactory = shoppingCartModelFactory;
        }
        #endregion

        //#region Utilities
        ///// <summary>
        ///// Parse product attributes on the product details page
        ///// </summary>
        ///// <param name="product">Product</param>
        ///// <param name="form">Form</param>
        ///// <returns>Parsed attributes</returns>
        //[NonAction]
        //protected virtual string ParseProductAttributes(Product product, FormCollection form)
        //{
        //    string attributesXml = "";

        //    #region Product attributes

        //    var productAttributes = _productAttributeService.GetProductAttributeMappingsByProductId(product.Id);
        //    foreach (var attribute in productAttributes)
        //    {
        //        string controlId = string.Format("product_attribute_{0}", attribute.Id);
        //        switch (attribute.AttributeControlType)
        //        {
        //            case AttributeControlType.DropdownList:
        //            case AttributeControlType.RadioList:
        //            case AttributeControlType.ColorSquares:
        //                {
        //                    var ctrlAttributes = form[controlId];
        //                    if (!String.IsNullOrEmpty(ctrlAttributes))
        //                    {
        //                        int selectedAttributeId = int.Parse(ctrlAttributes);
        //                        if (selectedAttributeId > 0)
        //                            attributesXml = _productAttributeParser.AddProductAttribute(attributesXml,
        //                                attribute, selectedAttributeId.ToString());
        //                    }
        //                }
        //                break;
        //            case AttributeControlType.Checkboxes:
        //                {
        //                    var ctrlAttributes = form[controlId];
        //                    if (!String.IsNullOrEmpty(ctrlAttributes))
        //                    {
        //                        foreach (var item in ctrlAttributes.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
        //                        {
        //                            int selectedAttributeId = int.Parse(item);
        //                            if (selectedAttributeId > 0)
        //                                attributesXml = _productAttributeParser.AddProductAttribute(attributesXml,
        //                                    attribute, selectedAttributeId.ToString());
        //                        }
        //                    }
        //                }
        //                break;
        //            case AttributeControlType.ReadonlyCheckboxes:
        //                {
        //                    //load read-only (already server-side selected) values
        //                    var attributeValues = _productAttributeService.GetProductAttributeValues(attribute.Id);
        //                    foreach (var selectedAttributeId in attributeValues
        //                        .Where(v => v.IsPreSelected)
        //                        .Select(v => v.Id)
        //                        .ToList())
        //                    {
        //                        attributesXml = _productAttributeParser.AddProductAttribute(attributesXml,
        //                            attribute, selectedAttributeId.ToString());
        //                    }
        //                }
        //                break;
        //            case AttributeControlType.TextBox:
        //            case AttributeControlType.MultilineTextbox:
        //                {
        //                    var ctrlAttributes = form[controlId];
        //                    if (!String.IsNullOrEmpty(ctrlAttributes))
        //                    {
        //                        string enteredText = ctrlAttributes.Trim();
        //                        attributesXml = _productAttributeParser.AddProductAttribute(attributesXml,
        //                            attribute, enteredText);
        //                    }
        //                }
        //                break;
        //            case AttributeControlType.Datepicker:
        //                {
        //                    var day = form[controlId + "_day"];
        //                    var month = form[controlId + "_month"];
        //                    var year = form[controlId + "_year"];
        //                    DateTime? selectedDate = null;
        //                    try
        //                    {
        //                        selectedDate = new DateTime(Int32.Parse(year), Int32.Parse(month), Int32.Parse(day));
        //                    }
        //                    catch { }
        //                    if (selectedDate.HasValue)
        //                    {
        //                        attributesXml = _productAttributeParser.AddProductAttribute(attributesXml,
        //                            attribute, selectedDate.Value.ToString("D"));
        //                    }
        //                }
        //                break;
        //            case AttributeControlType.FileUpload:
        //                {
        //                    Guid downloadGuid;
        //                    Guid.TryParse(form[controlId], out downloadGuid);
        //                    var download = _downloadService.GetDownloadByGuid(downloadGuid);
        //                    if (download != null)
        //                    {
        //                        attributesXml = _productAttributeParser.AddProductAttribute(attributesXml,
        //                                attribute, download.DownloadGuid.ToString());
        //                    }
        //                }
        //                break;
        //            default:
        //                break;
        //        }
        //    }
        //    //validate conditional attributes (if specified)
        //    foreach (var attribute in productAttributes)
        //    {
        //        var conditionMet = _productAttributeParser.IsConditionMet(attribute, attributesXml);
        //        if (conditionMet.HasValue && !conditionMet.Value)
        //        {
        //            attributesXml = _productAttributeParser.RemoveProductAttribute(attributesXml, attribute);
        //        }
        //    }

        //    #endregion

        //    #region Gift cards

        //    if (product.IsGiftCard)
        //    {
        //        string recipientName = "";
        //        string recipientEmail = "";
        //        string senderName = "";
        //        string senderEmail = "";
        //        string giftCardMessage = "";
        //        foreach (string formKey in form.AllKeys)
        //        {
        //            if (formKey.Equals(string.Format("giftcard_{0}.RecipientName", product.Id), StringComparison.InvariantCultureIgnoreCase))
        //            {
        //                recipientName = form[formKey];
        //                continue;
        //            }
        //            if (formKey.Equals(string.Format("giftcard_{0}.RecipientEmail", product.Id), StringComparison.InvariantCultureIgnoreCase))
        //            {
        //                recipientEmail = form[formKey];
        //                continue;
        //            }
        //            if (formKey.Equals(string.Format("giftcard_{0}.SenderName", product.Id), StringComparison.InvariantCultureIgnoreCase))
        //            {
        //                senderName = form[formKey];
        //                continue;
        //            }
        //            if (formKey.Equals(string.Format("giftcard_{0}.SenderEmail", product.Id), StringComparison.InvariantCultureIgnoreCase))
        //            {
        //                senderEmail = form[formKey];
        //                continue;
        //            }
        //            if (formKey.Equals(string.Format("giftcard_{0}.Message", product.Id), StringComparison.InvariantCultureIgnoreCase))
        //            {
        //                giftCardMessage = form[formKey];
        //                continue;
        //            }
        //        }

        //        attributesXml = _productAttributeParser.AddGiftCardAttribute(attributesXml,
        //            recipientName, recipientEmail, senderName, senderEmail, giftCardMessage);
        //    }

        //    #endregion

        //    return attributesXml;
        //}

        ///// <summary>
        ///// Parse product rental dates on the product details page
        ///// </summary>
        ///// <param name="product">Product</param>
        ///// <param name="form">Form</param>
        ///// <param name="startDate">Start date</param>
        ///// <param name="endDate">End date</param>
        //[NonAction]
        //protected virtual void ParseRentalDates(Product product, FormCollection form,
        //    out DateTime? startDate, out DateTime? endDate)
        //{
        //    startDate = null;
        //    endDate = null;

        //    string startControlId = string.Format("rental_start_date_{0}", product.Id);
        //    string endControlId = string.Format("rental_end_date_{0}", product.Id);
        //    var ctrlStartDate = form[startControlId];
        //    var ctrlEndDate = form[endControlId];
        //    try
        //    {
        //        //currenly we support only this format (as in the \Views\Product\_RentalInfo.cshtml file)
        //        const string datePickerFormat = "MM/dd/yyyy";
        //        startDate = DateTime.ParseExact(ctrlStartDate, datePickerFormat, CultureInfo.InvariantCulture);
        //        endDate = DateTime.ParseExact(ctrlEndDate, datePickerFormat, CultureInfo.InvariantCulture);
        //    }
        //    catch
        //    {
        //    }
        //}

        ///// <summary>
        ///// Prepare shopping cart model
        ///// </summary>
        ///// <param name="model">Model instance</param>
        ///// <param name="cart">Shopping cart</param>
        ///// <param name="isEditable">A value indicating whether cart is editable</param>
        ///// <param name="validateCheckoutAttributes">A value indicating whether we should validate checkout attributes when preparing the model</param>
        ///// <param name="prepareEstimateShippingIfEnabled">A value indicating whether we should prepare "Estimate shipping" model</param>
        ///// <param name="setEstimateShippingDefaultAddress">A value indicating whether we should prefill "Estimate shipping" model with the default customer address</param>
        ///// <param name="prepareAndDisplayOrderReviewData">A value indicating whether we should prepare review data (such as billing/shipping address, payment or shipping data entered during checkout)</param>
        ///// <returns>Model</returns>
        //[NonAction]
        //protected virtual void PrepareShoppingCartModel(ShoppingCartModel model,
        //    IList<ShoppingCartItem> cart, bool isEditable = true,
        //    bool validateCheckoutAttributes = false,
        //    bool prepareEstimateShippingIfEnabled = true, bool setEstimateShippingDefaultAddress = true,
        //    bool prepareAndDisplayOrderReviewData = false)
        //{
        //    if (cart == null)
        //        throw new ArgumentNullException("cart");

        //    if (model == null)
        //        throw new ArgumentNullException("model");

        //    model.OnePageCheckoutEnabled = _orderSettings.OnePageCheckoutEnabled;

        //    if (cart.Count == 0)
        //        return;

        //    #region Simple properties

        //    model.IsEditable = isEditable;
        //    model.ShowProductImages = _shoppingCartSettings.ShowProductImagesOnShoppingCart;
        //    model.ShowSku = _catalogSettings.ShowProductSku;
        //    var checkoutAttributesXml = _workContext.CurrentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CheckoutAttributes, _genericAttributeService, _storeContext.CurrentStore.Id);
        //    model.CheckoutAttributeInfo = _checkoutAttributeFormatter.FormatAttributes(checkoutAttributesXml, _workContext.CurrentCustomer);
        //    bool minOrderSubtotalAmountOk = _orderProcessingService.ValidateMinOrderSubtotalAmount(cart);
        //    if (!minOrderSubtotalAmountOk)
        //    {
        //        decimal minOrderSubtotalAmount = _currencyService.ConvertFromPrimaryStoreCurrency(_orderSettings.MinOrderSubtotalAmount, _workContext.WorkingCurrency);
        //        model.MinOrderSubtotalWarning = string.Format(_localizationService.GetResource("Checkout.MinOrderSubtotalAmount"), _priceFormatter.FormatPrice(minOrderSubtotalAmount, true, false));
        //    }
        //    model.TermsOfServiceOnShoppingCartPage = _orderSettings.TermsOfServiceOnShoppingCartPage;
        //    model.TermsOfServiceOnOrderConfirmPage = _orderSettings.TermsOfServiceOnOrderConfirmPage;
        //    model.DisplayTaxShippingInfo = _catalogSettings.DisplayTaxShippingInfoShoppingCart;

        //    //gift card and gift card boxes
        //    model.DiscountBox.Display = _shoppingCartSettings.ShowDiscountBox;
        //    var discountCouponCode = _workContext.CurrentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.DiscountCouponCode);
        //    var discount = _discountService.GetDiscountByCouponCode(discountCouponCode);
        //    if (discount != null &&
        //        discount.RequiresCouponCode &&
        //        _discountService.ValidateDiscount(discount, _workContext.CurrentCustomer).IsValid)
        //        model.DiscountBox.CurrentCode = discount.CouponCode;
        //    model.GiftCardBox.Display = _shoppingCartSettings.ShowGiftCardBox;

        //    //cart warnings
        //    var cartWarnings = _shoppingCartService.GetShoppingCartWarnings(cart, checkoutAttributesXml, validateCheckoutAttributes);
        //    foreach (var warning in cartWarnings)
        //        model.Warnings.Add(warning);

        //    #endregion

        //    #region Checkout attributes

        //    var checkoutAttributes = _checkoutAttributeService.GetAllCheckoutAttributes(_storeContext.CurrentStore.Id, !cart.RequiresShipping());
        //    foreach (var attribute in checkoutAttributes)
        //    {
        //        var attributeModel = new ShoppingCartModel.CheckoutAttributeModel
        //        {
        //            Id = attribute.Id,
        //            Name = attribute.GetLocalized(x => x.Name),
        //            TextPrompt = attribute.GetLocalized(x => x.TextPrompt),
        //            IsRequired = attribute.IsRequired,
        //            AttributeControlType = attribute.AttributeControlType,
        //            DefaultValue = attribute.DefaultValue
        //        };
        //        if (!String.IsNullOrEmpty(attribute.ValidationFileAllowedExtensions))
        //        {
        //            attributeModel.AllowedFileExtensions = attribute.ValidationFileAllowedExtensions
        //                .Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
        //                .ToList();
        //        }

        //        if (attribute.ShouldHaveValues())
        //        {
        //            //values
        //            var attributeValues = _checkoutAttributeService.GetCheckoutAttributeValues(attribute.Id);
        //            foreach (var attributeValue in attributeValues)
        //            {
        //                var attributeValueModel = new ShoppingCartModel.CheckoutAttributeValueModel
        //                {
        //                    Id = attributeValue.Id,
        //                    Name = attributeValue.GetLocalized(x => x.Name),
        //                    ColorSquaresRgb = attributeValue.ColorSquaresRgb,
        //                    IsPreSelected = attributeValue.IsPreSelected,
        //                };
        //                attributeModel.Values.Add(attributeValueModel);

        //                //display price if allowed
        //                if (_permissionService.Authorize(StandardPermissionProvider.DisplayPrices))
        //                {
        //                    decimal priceAdjustmentBase = _taxService.GetCheckoutAttributePrice(attributeValue);
        //                    decimal priceAdjustment = _currencyService.ConvertFromPrimaryStoreCurrency(priceAdjustmentBase, _workContext.WorkingCurrency);
        //                    if (priceAdjustmentBase > decimal.Zero)
        //                        attributeValueModel.PriceAdjustment = "+" + _priceFormatter.FormatPrice(priceAdjustment);
        //                    else if (priceAdjustmentBase < decimal.Zero)
        //                        attributeValueModel.PriceAdjustment = "-" + _priceFormatter.FormatPrice(-priceAdjustment);
        //                }
        //            }
        //        }



        //        //set already selected attributes
        //        var selectedCheckoutAttributes = _workContext.CurrentCustomer.GetAttribute<string>(SystemCustomerAttributeNames.CheckoutAttributes, _genericAttributeService, _storeContext.CurrentStore.Id);
        //        switch (attribute.AttributeControlType)
        //        {
        //            case AttributeControlType.DropdownList:
        //            case AttributeControlType.RadioList:
        //            case AttributeControlType.Checkboxes:
        //            case AttributeControlType.ColorSquares:
        //                {
        //                    if (!String.IsNullOrEmpty(selectedCheckoutAttributes))
        //                    {
        //                        //clear default selection
        //                        foreach (var item in attributeModel.Values)
        //                            item.IsPreSelected = false;

        //                        //select new values
        //                        var selectedValues = _checkoutAttributeParser.ParseCheckoutAttributeValues(selectedCheckoutAttributes);
        //                        foreach (var attributeValue in selectedValues)
        //                            foreach (var item in attributeModel.Values)
        //                                if (attributeValue.Id == item.Id)
        //                                    item.IsPreSelected = true;
        //                    }
        //                }
        //                break;
        //            case AttributeControlType.ReadonlyCheckboxes:
        //                {
        //                    //do nothing
        //                    //values are already pre-set
        //                }
        //                break;
        //            case AttributeControlType.TextBox:
        //            case AttributeControlType.MultilineTextbox:
        //                {
        //                    if (!String.IsNullOrEmpty(selectedCheckoutAttributes))
        //                    {
        //                        var enteredText = _checkoutAttributeParser.ParseValues(selectedCheckoutAttributes, attribute.Id);
        //                        if (enteredText.Count > 0)
        //                            attributeModel.DefaultValue = enteredText[0];
        //                    }
        //                }
        //                break;
        //            case AttributeControlType.Datepicker:
        //                {
        //                    //keep in mind my that the code below works only in the current culture
        //                    var selectedDateStr = _checkoutAttributeParser.ParseValues(selectedCheckoutAttributes, attribute.Id);
        //                    if (selectedDateStr.Count > 0)
        //                    {
        //                        DateTime selectedDate;
        //                        if (DateTime.TryParseExact(selectedDateStr[0], "D", CultureInfo.CurrentCulture,
        //                                               DateTimeStyles.None, out selectedDate))
        //                        {
        //                            //successfully parsed
        //                            attributeModel.SelectedDay = selectedDate.Day;
        //                            attributeModel.SelectedMonth = selectedDate.Month;
        //                            attributeModel.SelectedYear = selectedDate.Year;
        //                        }
        //                    }

        //                }
        //                break;
        //            case AttributeControlType.FileUpload:
        //                {
        //                    if (!String.IsNullOrEmpty(selectedCheckoutAttributes))
        //                    {
        //                        var downloadGuidStr = _checkoutAttributeParser.ParseValues(selectedCheckoutAttributes, attribute.Id).FirstOrDefault();
        //                        Guid downloadGuid;
        //                        Guid.TryParse(downloadGuidStr, out downloadGuid);
        //                        var download = _downloadService.GetDownloadByGuid(downloadGuid);
        //                        if (download != null)
        //                            attributeModel.DefaultValue = download.DownloadGuid.ToString();
        //                    }
        //                }
        //                break;
        //            default:
        //                break;
        //        }

        //        model.CheckoutAttributes.Add(attributeModel);
        //    }

        //    #endregion

        //    #region Estimate shipping

        //    if (prepareEstimateShippingIfEnabled)
        //    {
        //        model.EstimateShipping.Enabled = cart.Count > 0 && cart.RequiresShipping() && _shippingSettings.EstimateShippingEnabled;
        //        if (model.EstimateShipping.Enabled)
        //        {
        //            //countries
        //            int? defaultEstimateCountryId = (setEstimateShippingDefaultAddress && _workContext.CurrentCustomer.ShippingAddress != null) ? _workContext.CurrentCustomer.ShippingAddress.CountryId : model.EstimateShipping.CountryId;
        //            model.EstimateShipping.AvailableCountries.Add(new SelectListItem { Text = _localizationService.GetResource("Address.SelectCountry"), Value = "0" });
        //            foreach (var c in _countryService.GetAllCountriesForShipping(_workContext.WorkingLanguage.Id))
        //                model.EstimateShipping.AvailableCountries.Add(new SelectListItem
        //                {
        //                    Text = c.GetLocalized(x => x.Name),
        //                    Value = c.Id.ToString(),
        //                    Selected = c.Id == defaultEstimateCountryId
        //                });
        //            //states
        //            int? defaultEstimateStateId = (setEstimateShippingDefaultAddress && _workContext.CurrentCustomer.ShippingAddress != null) ? _workContext.CurrentCustomer.ShippingAddress.StateProvinceId : model.EstimateShipping.StateProvinceId;
        //            var states = defaultEstimateCountryId.HasValue ? _stateProvinceService.GetStateProvincesByCountryId(defaultEstimateCountryId.Value, _workContext.WorkingLanguage.Id).ToList() : new List<StateProvince>();
        //            if (states.Count > 0)
        //                foreach (var s in states)
        //                    model.EstimateShipping.AvailableStates.Add(new SelectListItem
        //                    {
        //                        Text = s.GetLocalized(x => x.Name),
        //                        Value = s.Id.ToString(),
        //                        Selected = s.Id == defaultEstimateStateId
        //                    });
        //            else
        //                model.EstimateShipping.AvailableStates.Add(new SelectListItem { Text = _localizationService.GetResource("Address.OtherNonUS"), Value = "0" });

        //            if (setEstimateShippingDefaultAddress && _workContext.CurrentCustomer.ShippingAddress != null)
        //                model.EstimateShipping.ZipPostalCode = _workContext.CurrentCustomer.ShippingAddress.ZipPostalCode;
        //        }
        //    }

        //    #endregion

        //    #region Cart items

        //    foreach (var sci in cart)
        //    {
        //        var cartItemModel = new ShoppingCartModel.ShoppingCartItemModel
        //        {
        //            Id = sci.Id,
        //            Sku = sci.Product.FormatSku(sci.AttributesXml, _productAttributeParser),
        //            ProductId = sci.Product.Id,
        //            ProductName = sci.Product.GetLocalized(x => x.Name),
        //            ProductSeName = sci.Product.GetSeName(),
        //            Quantity = sci.Quantity,
        //            AttributeInfo = _productAttributeFormatter.FormatAttributes(sci.Product, sci.AttributesXml),
        //        };

        //        //allow editing?
        //        //1. setting enabled?
        //        //2. simple product?
        //        //3. has attribute or gift card?
        //        //4. visible individually?
        //        cartItemModel.AllowItemEditing = _shoppingCartSettings.AllowCartItemEditing &&
        //            sci.Product.ProductType == ProductType.SimpleProduct &&
        //            (!String.IsNullOrEmpty(cartItemModel.AttributeInfo) || sci.Product.IsGiftCard) &&
        //            sci.Product.VisibleIndividually;

        //        //allowed quantities
        //        var allowedQuantities = sci.Product.ParseAllowedQuantities();
        //        foreach (var qty in allowedQuantities)
        //        {
        //            cartItemModel.AllowedQuantities.Add(new SelectListItem
        //            {
        //                Text = qty.ToString(),
        //                Value = qty.ToString(),
        //                Selected = sci.Quantity == qty
        //            });
        //        }

        //        //recurring info
        //        if (sci.Product.IsRecurring)
        //            cartItemModel.RecurringInfo = string.Format(_localizationService.GetResource("ShoppingCart.RecurringPeriod"), sci.Product.RecurringCycleLength, sci.Product.RecurringCyclePeriod.GetLocalizedEnum(_localizationService, _workContext));

        //        //rental info
        //        if (sci.Product.IsRental)
        //        {
        //            var rentalStartDate = sci.RentalStartDateUtc.HasValue ? sci.Product.FormatRentalDate(sci.RentalStartDateUtc.Value) : "";
        //            var rentalEndDate = sci.RentalEndDateUtc.HasValue ? sci.Product.FormatRentalDate(sci.RentalEndDateUtc.Value) : "";
        //            cartItemModel.RentalInfo = string.Format(_localizationService.GetResource("ShoppingCart.Rental.FormattedDate"),
        //                rentalStartDate, rentalEndDate);
        //        }

        //        //unit prices
        //        if (sci.Product.CallForPrice)
        //        {
        //            cartItemModel.UnitPrice = _localizationService.GetResource("Products.CallForPrice");
        //        }
        //        else
        //        {
        //            decimal taxRate;
        //            decimal shoppingCartUnitPriceWithDiscountBase = _taxService.GetProductPrice(sci.Product, _priceCalculationService.GetUnitPrice(sci), out taxRate);
        //            decimal shoppingCartUnitPriceWithDiscount = _currencyService.ConvertFromPrimaryStoreCurrency(shoppingCartUnitPriceWithDiscountBase, _workContext.WorkingCurrency);
        //            cartItemModel.UnitPrice = _priceFormatter.FormatPrice(shoppingCartUnitPriceWithDiscount);
        //        }
        //        //subtotal, discount
        //        if (sci.Product.CallForPrice)
        //        {
        //            cartItemModel.SubTotal = _localizationService.GetResource("Products.CallForPrice");
        //        }
        //        else
        //        {
        //            //sub total
        //            Discount scDiscount;
        //            decimal shoppingCartItemDiscountBase;
        //            decimal taxRate;
        //            decimal shoppingCartItemSubTotalWithDiscountBase = _taxService.GetProductPrice(sci.Product, _priceCalculationService.GetSubTotal(sci, true, out shoppingCartItemDiscountBase, out scDiscount), out taxRate);
        //            decimal shoppingCartItemSubTotalWithDiscount = _currencyService.ConvertFromPrimaryStoreCurrency(shoppingCartItemSubTotalWithDiscountBase, _workContext.WorkingCurrency);
        //            cartItemModel.SubTotal = _priceFormatter.FormatPrice(shoppingCartItemSubTotalWithDiscount);

        //            //display an applied discount amount
        //            if (scDiscount != null)
        //            {
        //                shoppingCartItemDiscountBase = _taxService.GetProductPrice(sci.Product, shoppingCartItemDiscountBase, out taxRate);
        //                if (shoppingCartItemDiscountBase > decimal.Zero)
        //                {
        //                    decimal shoppingCartItemDiscount = _currencyService.ConvertFromPrimaryStoreCurrency(shoppingCartItemDiscountBase, _workContext.WorkingCurrency);
        //                    cartItemModel.Discount = _priceFormatter.FormatPrice(shoppingCartItemDiscount);
        //                }
        //            }
        //        }

        //        //picture
        //        if (_shoppingCartSettings.ShowProductImagesOnShoppingCart)
        //        {
        //            cartItemModel.Picture = PrepareCartItemPictureModel(sci,
        //                _mediaSettings.CartThumbPictureSize, true, cartItemModel.ProductName);
        //        }

        //        //item warnings
        //        var itemWarnings = _shoppingCartService.GetShoppingCartItemWarnings(
        //            _workContext.CurrentCustomer,
        //            sci.ShoppingCartType,
        //            sci.Product,
        //            sci.StoreId,
        //            sci.AttributesXml,
        //            sci.CustomerEnteredPrice,
        //            sci.RentalStartDateUtc,
        //            sci.RentalEndDateUtc,
        //            sci.Quantity,
        //            false);
        //        foreach (var warning in itemWarnings)
        //            cartItemModel.Warnings.Add(warning);

        //        model.Items.Add(cartItemModel);
        //    }

        //    #endregion

        //    #region Button payment methods

        //    var paymentMethods = _paymentService
        //        .LoadActivePaymentMethods(_workContext.CurrentCustomer.Id, _storeContext.CurrentStore.Id)
        //        .Where(pm => pm.PaymentMethodType == PaymentMethodType.Button)
        //        .Where(pm => !pm.HidePaymentMethod(cart))
        //        .ToList();
        //    foreach (var pm in paymentMethods)
        //    {
        //        if (cart.IsRecurring() && pm.RecurringPaymentType == RecurringPaymentType.NotSupported)
        //            continue;

        //        string actionName;
        //        string controllerName;
        //        RouteValueDictionary routeValues;
        //        pm.GetPaymentInfoRoute(out actionName, out controllerName, out routeValues);

        //        model.ButtonPaymentMethodActionNames.Add(actionName);
        //        model.ButtonPaymentMethodControllerNames.Add(controllerName);
        //        model.ButtonPaymentMethodRouteValues.Add(routeValues);
        //    }

        //    #endregion

        //    #region Order review data

        //    if (prepareAndDisplayOrderReviewData)
        //    {
        //        model.OrderReviewData.Display = true;

        //        //billing info
        //        var billingAddress = _workContext.CurrentCustomer.BillingAddress;
        //        if (billingAddress != null)
        //            model.OrderReviewData.BillingAddress.PrepareModel(
        //                address: billingAddress,
        //                excludeProperties: false,
        //                addressSettings: _addressSettings,
        //                addressAttributeFormatter: _addressAttributeFormatter);

        //        //shipping info
        //        if (cart.RequiresShipping())
        //        {
        //            model.OrderReviewData.IsShippable = true;

        //            if (_shippingSettings.AllowPickUpInStore)
        //            {
        //                model.OrderReviewData.SelectedPickUpInStore = _workContext.CurrentCustomer.GetAttribute<bool>(SystemCustomerAttributeNames.SelectedPickUpInStore, _storeContext.CurrentStore.Id);
        //            }

        //            if (!model.OrderReviewData.SelectedPickUpInStore)
        //            {
        //                var shippingAddress = _workContext.CurrentCustomer.ShippingAddress;
        //                if (shippingAddress != null)
        //                {
        //                    model.OrderReviewData.ShippingAddress.PrepareModel(
        //                        address: shippingAddress,
        //                        excludeProperties: false,
        //                        addressSettings: _addressSettings,
        //                        addressAttributeFormatter: _addressAttributeFormatter);
        //                }
        //            }


        //            //selected shipping method
        //            var shippingOption = _workContext.CurrentCustomer.GetAttribute<ShippingOption>(SystemCustomerAttributeNames.SelectedShippingOption, _storeContext.CurrentStore.Id);
        //            if (shippingOption != null)
        //                model.OrderReviewData.ShippingMethod = shippingOption.Name;
        //        }
        //        //payment info
        //        var selectedPaymentMethodSystemName = _workContext.CurrentCustomer.GetAttribute<string>(
        //            SystemCustomerAttributeNames.SelectedPaymentMethod, _storeContext.CurrentStore.Id);
        //        var paymentMethod = _paymentService.LoadPaymentMethodBySystemName(selectedPaymentMethodSystemName);
        //        model.OrderReviewData.PaymentMethod = paymentMethod != null ? paymentMethod.GetLocalizedFriendlyName(_localizationService, _workContext.WorkingLanguage.Id) : "";

        //        //custom values
        //        var processPaymentRequest = _httpContext.Session["OrderPaymentInfo"] as ProcessPaymentRequest;
        //        if (processPaymentRequest != null)
        //        {
        //            model.OrderReviewData.CustomValues = processPaymentRequest.CustomValues;
        //        }
        //    }
        //    #endregion
        //}
        //#endregion

        //#region Shopping cart
        //[HttpPost]
        //[ValidateInput(false)]
        //public ActionResult AddProductToCart_Details(int productId, int shoppingCartTypeId, FormCollection form)
        //{
        //    var product = _productService.GetProductById(productId);
        //    if (product == null)
        //    {
        //        return Json(new
        //        {
        //            redirect = Url.RouteUrl("HomePage"),
        //        });
        //    }

        //    //we can add only simple products
        //    if (product.ProductType != ProductType.SimpleProduct)
        //    {
        //        return Json(new
        //        {
        //            success = false,
        //            message = "Only simple products could be added to the cart"
        //        });
        //    }

        //    #region Update existing shopping cart item?
        //    int updatecartitemid = 0;
        //    foreach (string formKey in form.AllKeys)
        //        if (formKey.Equals(string.Format("addtocart_{0}.UpdatedShoppingCartItemId", productId), StringComparison.InvariantCultureIgnoreCase))
        //        {
        //            int.TryParse(form[formKey], out updatecartitemid);
        //            break;
        //        }
        //    ShoppingCartItem updatecartitem = null;
        //    if (_shoppingCartSettings.AllowCartItemEditing && updatecartitemid > 0)
        //    {
        //        var cart = _workContext.CurrentCustomer.ShoppingCartItems
        //            .Where(x => x.ShoppingCartType == ShoppingCartType.ShoppingCart)
        //            .LimitPerStore(_storeContext.CurrentStore.Id)
        //            .ToList();
        //        updatecartitem = cart.FirstOrDefault(x => x.Id == updatecartitemid);
        //        //not found?
        //        if (updatecartitem == null)
        //        {
        //            return Json(new
        //            {
        //                success = false,
        //                message = "No shopping cart item found to update"
        //            });
        //        }
        //        //is it this product?
        //        if (product.Id != updatecartitem.ProductId)
        //        {
        //            return Json(new
        //            {
        //                success = false,
        //                message = "This product does not match a passed shopping cart item identifier"
        //            });
        //        }
        //    }
        //    #endregion

        //    #region Customer entered price
        //    decimal customerEnteredPriceConverted = decimal.Zero;
        //    if (product.CustomerEntersPrice)
        //    {
        //        foreach (string formKey in form.AllKeys)
        //        {
        //            if (formKey.Equals(string.Format("addtocart_{0}.CustomerEnteredPrice", productId), StringComparison.InvariantCultureIgnoreCase))
        //            {
        //                decimal customerEnteredPrice;
        //                if (decimal.TryParse(form[formKey], out customerEnteredPrice))
        //                    customerEnteredPriceConverted = _currencyService.ConvertToPrimaryStoreCurrency(customerEnteredPrice, _workContext.WorkingCurrency);
        //                break;
        //            }
        //        }
        //    }
        //    #endregion

        //    #region Quantity

        //    int quantity = 1;
        //    foreach (string formKey in form.AllKeys)
        //        if (formKey.Equals(string.Format("addtocart_{0}.EnteredQuantity", productId), StringComparison.InvariantCultureIgnoreCase))
        //        {
        //            int.TryParse(form[formKey], out quantity);
        //            break;
        //        }

        //    #endregion

        //    //product and gift card attributes
        //    string attributes = ParseProductAttributes(product, form);

        //    //rental attributes
        //    DateTime? rentalStartDate = null;
        //    DateTime? rentalEndDate = null;
        //    if (product.IsRental)
        //    {
        //        ParseRentalDates(product, form, out rentalStartDate, out rentalEndDate);
        //    }

        //    //save item
        //    var addToCartWarnings = new List<string>();
        //    var cartType = (ShoppingCartType)shoppingCartTypeId;
        //    if (updatecartitem == null)
        //    {
        //        //add to the cart
        //        addToCartWarnings.AddRange(_shoppingCartService.AddToCart(_workContext.CurrentCustomer,
        //            product, cartType, _storeContext.CurrentStore.Id,
        //            attributes, customerEnteredPriceConverted,
        //            rentalStartDate, rentalEndDate, quantity, true));
        //    }
        //    else
        //    {
        //        var cart = _workContext.CurrentCustomer.ShoppingCartItems
        //            .Where(x => x.ShoppingCartType == ShoppingCartType.ShoppingCart)
        //            .LimitPerStore(_storeContext.CurrentStore.Id)
        //            .ToList();
        //        var otherCartItemWithSameParameters = _shoppingCartService.FindShoppingCartItemInTheCart(
        //            cart, cartType, product, attributes, customerEnteredPriceConverted,
        //            rentalStartDate, rentalEndDate);
        //        if (otherCartItemWithSameParameters != null &&
        //            otherCartItemWithSameParameters.Id == updatecartitem.Id)
        //        {
        //            //ensure it's other shopping cart cart item
        //            otherCartItemWithSameParameters = null;
        //        }
        //        //update existing item
        //        addToCartWarnings.AddRange(_shoppingCartService.UpdateShoppingCartItem(_workContext.CurrentCustomer,
        //            updatecartitem.Id, attributes, customerEnteredPriceConverted,
        //            rentalStartDate, rentalEndDate, quantity, true));
        //        if (otherCartItemWithSameParameters != null && addToCartWarnings.Count == 0)
        //        {
        //            //delete the same shopping cart item (the other one)
        //            _shoppingCartService.DeleteShoppingCartItem(otherCartItemWithSameParameters);
        //        }
        //    }

        //    #region Return result

        //    if (addToCartWarnings.Count > 0)
        //    {
        //        //cannot be added to the cart/wishlist
        //        //let's display warnings
        //        return Json(new
        //        {
        //            success = false,
        //            message = addToCartWarnings.ToArray()
        //        });
        //    }

        //    //added to the cart/wishlist
        //    switch (cartType)
        //    {
        //        case ShoppingCartType.Wishlist:
        //            {
        //                //activity log
        //                _customerActivityService.InsertActivity("PublicStore.AddToWishlist", _localizationService.GetResource("ActivityLog.PublicStore.AddToWishlist"), product.Name);

        //                if (_shoppingCartSettings.DisplayWishlistAfterAddingProduct)
        //                {
        //                    //redirect to the wishlist page
        //                    return Json(new
        //                    {
        //                        redirect = Url.RouteUrl("Wishlist"),
        //                    });
        //                }

        //                //display notification message and update appropriate blocks
        //                var updatetopwishlistsectionhtml = string.Format(_localizationService.GetResource("Wishlist.HeaderQuantity"),
        //                _workContext.CurrentCustomer.ShoppingCartItems
        //                .Where(sci => sci.ShoppingCartType == ShoppingCartType.Wishlist)
        //                .LimitPerStore(_storeContext.CurrentStore.Id)
        //                .ToList()
        //                .GetTotalProducts());

        //                return Json(new
        //                {
        //                    success = true,
        //                    message = string.Format(_localizationService.GetResource("Products.ProductHasBeenAddedToTheWishlist.Link"), Url.RouteUrl("Wishlist")),
        //                    updatetopwishlistsectionhtml = updatetopwishlistsectionhtml,
        //                });
        //            }
        //        case ShoppingCartType.ShoppingCart:
        //        default:
        //            {
        //                //activity log
        //                _customerActivityService.InsertActivity("PublicStore.AddToShoppingCart", _localizationService.GetResource("ActivityLog.PublicStore.AddToShoppingCart"), product.Name);

        //                if (_shoppingCartSettings.DisplayCartAfterAddingProduct)
        //                {
        //                    //redirect to the shopping cart page
        //                    return Json(new
        //                    {
        //                        redirect = Url.RouteUrl("ShoppingCart"),
        //                    });
        //                }

        //                //display notification message and update appropriate blocks
        //                var updatetopcartsectionhtml = string.Format(_localizationService.GetResource("ShoppingCart.HeaderQuantity"),
        //                _workContext.CurrentCustomer.ShoppingCartItems
        //                .Where(sci => sci.ShoppingCartType == ShoppingCartType.ShoppingCart)
        //                .LimitPerStore(_storeContext.CurrentStore.Id)
        //                .ToList()
        //                .GetTotalProducts());

        //                var updateflyoutcartsectionhtml = _shoppingCartSettings.MiniShoppingCartEnabled
        //                    ? this.RenderPartialViewToString("FlyoutShoppingCart", PrepareMiniShoppingCartModel())
        //                    : "";

        //                return Json(new
        //                {
        //                    success = true,
        //                    message = string.Format(_localizationService.GetResource("Products.ProductHasBeenAddedToTheCart.Link"), Url.RouteUrl("ShoppingCart")),
        //                    updatetopcartsectionhtml = updatetopcartsectionhtml,
        //                    updateflyoutcartsectionhtml = updateflyoutcartsectionhtml
        //                });
        //            }
        //    }


        //    #endregion
        //}
        //#endregion


        #region Additional Methods
        public ActionResult DeleteProductFromCart(int productId)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.EnableShoppingCart))
                return RedirectToRoute("HomePage");

            var cart = _workContext.CurrentCustomer.ShoppingCartItems
                .Where(sci => sci.ShoppingCartType == ShoppingCartType.ShoppingCart)
                .LimitPerStore(_storeContext.CurrentStore.Id)
                .ToList();
            if (cart.Any())
            {
                var cartItem = cart.SingleOrDefault(s => s.ProductId == productId);
                _shoppingCartService.DeleteShoppingCartItem(cartItem, ensureOnlyActiveCheckoutAttributes: true);
            }
            return Redirect(Request.UrlReferrer.ToString());
        }

        [HttpPost]
        public ActionResult FormatPrice(int productId = 0)
        {
            List<CartItem> lstSubTotal = new List<CartItem>();
            var cart = _workContext.CurrentCustomer.ShoppingCartItems
           .Where(sci => sci.ShoppingCartType == ShoppingCartType.ShoppingCart)
           .LimitPerStore(_storeContext.CurrentStore.Id)
           .ToList();
            if (productId > 0)
            {
                cart = cart.Where(p => p.ProductId == productId).ToList();

            }
            foreach (var sci in cart)
            {
                CartItem obj = new CartItem();
                List<Discount> scDiscount;
                decimal shoppingCartItemDiscountBase;
                decimal taxRate;
                decimal shoppingCartItemSubTotalWithDiscountBase = _taxService.GetProductPrice(sci.Product, _priceCalculationService.GetSubTotal(sci), out taxRate);
                decimal shoppingCartItemSubTotalWithDiscount = _currencyService.ConvertFromPrimaryStoreCurrency(shoppingCartItemSubTotalWithDiscountBase, _workContext.WorkingCurrency);
                obj.ProductId = sci.ProductId;
                obj.SubTotal = _priceFormatter.FormatPrice(shoppingCartItemSubTotalWithDiscount);
                lstSubTotal.Add(obj);
            }
            return Json(new
            {
                lstSubTotal = lstSubTotal
            });
        }

        public ActionResult ClearCartByCustomeremail(string customeremail)
        {
            if (!string.IsNullOrEmpty(customeremail))
            {
                var customer = _customerService.GetCustomerByEmail(Request["customeremail"]);
                if (customer != null)
                {
                    //load shopping cart
                    var cart = customer.ShoppingCartItems
                    .Where(x => x.ShoppingCartType == ShoppingCartType.ShoppingCart)
                    .Where(x => x.StoreId == _storeContext.CurrentStore.Id)
                    .ToList();
                    //clear shopping cart
                    cart.ToList().ForEach(sci => _shoppingCartService.DeleteShoppingCartItem(sci, false));
                }
            }
            return RedirectToRoute("HomePage");
        }

        public virtual ActionResult OrderSummaryLeft(bool? prepareAndDisplayOrderReviewData)
        {
            var cart = _workContext.CurrentCustomer.ShoppingCartItems
                .Where(sci => sci.ShoppingCartType == ShoppingCartType.ShoppingCart)
                .LimitPerStore(_storeContext.CurrentStore.Id)
                .ToList();
            var model = new ShoppingCartModel();
            model = _shoppingCartModelFactory.PrepareShoppingCartModel(model, cart,
                isEditable: false,
                prepareEstimateShippingIfEnabled: false,
                prepareAndDisplayOrderReviewData: prepareAndDisplayOrderReviewData.GetValueOrDefault());
            return PartialView(string.Format("/Themes/{0}/Views/ShoppingCartCustomWeb/OrderSummaryLeft.cshtml", EngineContext.Current.Resolve<IThemeContext>().WorkingThemeName), model);
        }

        public virtual ActionResult OrderTotalsLeft(bool isEditable)
        {
            var cart = _workContext.CurrentCustomer.ShoppingCartItems
                .Where(sci => sci.ShoppingCartType == ShoppingCartType.ShoppingCart)
                .LimitPerStore(_storeContext.CurrentStore.Id)
                .ToList();

            var model = _shoppingCartModelFactory.PrepareOrderTotalsModel(cart, isEditable);
            return PartialView(string.Format("/Themes/{0}/Views/ShoppingCartCustomWeb/OrderTotalsLeft.cshtml", EngineContext.Current.Resolve<IThemeContext>().WorkingThemeName), model);
        }

        public class CartItem
        {
            public int ProductId { get; set; }
            public string SubTotal { get; set; }
        }
        #endregion
    }
}