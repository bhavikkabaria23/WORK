﻿using Nop.Admin.Controllers;
using Nop.Admin.Models.Payments;
using Nop.Core.Plugins;
using Nop.Services.Payments;
using Nop.Services.Security;
using Nop.Web.Framework.Kendoui;
using Nop.Web.Framework.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Shopfast.Plugin.Custom.Extensions.NopAdmin;
using Shopfast.Plugin.Custom.Services.Payments;
using Nop.Core.Domain.Payments;
using Nop.Core;
using Nop.Services.Configuration;
using Shopfast.Plugin.Custom.Models.NopCore.Domain.Payments;
using Shopfast.Plugin.Custom.Models.NopAdmin.Payments;

namespace Shopfast.Plugin.Custom.Controllers
{
    public class PaymentAdminCustomController : BaseAdminController
    {
        #region Fields
        private readonly IPaymentService _paymentService;
        private readonly PaymentSettings _paymentSettings;
        private readonly PaymentSettingsCustom _paymentSettingsCustom;
        private readonly ISettingService _settingService;
        private readonly IPermissionService _permissionService;      
        private readonly IPluginFinder _pluginFinder;
        private readonly IWebHelper _webHelper;
		#endregion

		#region Constructors

        public PaymentAdminCustomController(IPaymentService paymentService,
            PaymentSettings paymentSettings,
            PaymentSettingsCustom paymentSettingsCustom,
            ISettingService settingService, 
            IPermissionService permissionService,            
            IPluginFinder pluginFinder,
            IWebHelper webHelper)
            
		{
            this._paymentService = paymentService;
            this._paymentSettings = paymentSettings;
            this._paymentSettingsCustom = paymentSettingsCustom;
            this._settingService = settingService;
            this._permissionService = permissionService;            
            this._pluginFinder = pluginFinder;
            this._webHelper = webHelper;            
		}

		#endregion 

        #region Methods
        [HttpPost]
        public ActionResult Methods(DataSourceRequest command)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManagePaymentMethods))
                return AccessDeniedView();

            var paymentMethodsModel = new List<PaymentMethodModelCustom>();
            var paymentMethods = _paymentService.LoadAllPaymentMethods();
            foreach (var paymentMethod in paymentMethods)
            {
                var tmp1 = paymentMethod.ToModelCustom();
                tmp1.IsActive = paymentMethod.IsPaymentMethodActive(_paymentSettings);
                tmp1.LogoUrl = paymentMethod.PluginDescriptor.GetLogoUrl(_webHelper);
                //primary payment method
                tmp1.IsPrimaryMethod = paymentMethod.IsPrimaryPaymentMethod(_paymentSettingsCustom);
                // Payment method IsTabletOnly
                tmp1.IsTabletOnly = paymentMethod.IsPaymentMethodForTabletOnly(_paymentSettingsCustom);
                //--------------------------------
                paymentMethodsModel.Add(tmp1);
            }
            paymentMethodsModel = paymentMethodsModel.ToList();
            var gridModel = new DataSourceResult
            {
                Data = paymentMethodsModel,
                Total = paymentMethodsModel.Count
            };

            return Json(gridModel);
        }

        [HttpPost]
        public ActionResult MethodUpdate([Bind(Exclude = "ConfigurationRouteValues")] PaymentMethodModelCustom model)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManagePaymentMethods))
                return AccessDeniedView();

            var pm = _paymentService.LoadPaymentMethodBySystemName(model.SystemName);
            if (pm.IsPaymentMethodActive(_paymentSettings))
            {
                if (!model.IsActive)
                {
                    //mark as disabled
                    _paymentSettings.ActivePaymentMethodSystemNames.Remove(pm.PluginDescriptor.SystemName);
                    _settingService.SaveSetting(_paymentSettings);
                }
            }
            else
            {
                if (model.IsActive)
                {
                    //mark as active
                    _paymentSettings.ActivePaymentMethodSystemNames.Add(pm.PluginDescriptor.SystemName);
                    _settingService.SaveSetting(_paymentSettings);
                }
            }
            // Payment method IsTabletOnly
            if (pm.IsPaymentMethodForTabletOnly(_paymentSettingsCustom))
            {
                if (!model.IsTabletOnly)
                {
                    //mark as disabled
                    _paymentSettingsCustom.TabletPaymentMethodSystemNames.Remove(pm.PluginDescriptor.SystemName);
                    _settingService.SaveSetting(_paymentSettingsCustom);
                }
            }
            else
            {
                if (model.IsTabletOnly)
                {
                    //mark as active
                    _paymentSettingsCustom.TabletPaymentMethodSystemNames.Add(pm.PluginDescriptor.SystemName);
                    _settingService.SaveSetting(_paymentSettingsCustom);
                }
            }
            //----------------------
            var pluginDescriptor = pm.PluginDescriptor;
            pluginDescriptor.FriendlyName = model.FriendlyName;
            pluginDescriptor.DisplayOrder = model.DisplayOrder;
            PluginFileParser.SavePluginDescriptionFile(pluginDescriptor);
            //reset plugin cache
            _pluginFinder.ReloadPlugins();

            return new NullJsonResult();
        }

        #region Additional Methods
        public ActionResult MethodMarkPrimary(PaymentMethodModelCustom model, DataSourceRequest command)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManagePaymentMethods))
                return AccessDeniedView();

            /* mark as primary method (if active) */
            if (!String.IsNullOrEmpty(model.SystemName))
            {
                var paymentMethod = _paymentService.LoadPaymentMethodBySystemName(model.SystemName);
                if (paymentMethod.IsPaymentMethodActive(_paymentSettings))
                {
                    _paymentSettingsCustom.PrimaryPaymentMethodSystemName = paymentMethod.PluginDescriptor.SystemName;
                    _settingService.SaveSetting(_paymentSettingsCustom);
                }
            }

            return Methods(command);
        }
        #endregion
        #endregion

    }
}