﻿using Nop.Admin.Controllers;
using Nop.Data;
using Shopfast.Plugin.Custom.Models.NopAdmin.Orders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Shopfast.Plugin.Custom.Controllers
{
    public class OrderCustomAdminController : BaseAdminController
    {
        private readonly IDbContext _dbContext;

        public OrderCustomAdminController(IDbContext dbContext)
        {            
            _dbContext = dbContext;
        }

        [ChildActionOnly]
        public ActionResult OrderTempIdView(int orderId)
        {
            var model =
                _dbContext.SqlQuery<OrderModelCustom>(
                    "select top 1 OrderTempId from [Order] where id=@p0", orderId)
                    .FirstOrDefault() ?? new OrderModelCustom();
            return View(model);
        }

        [ChildActionOnly]
        public ActionResult SignatureView(int orderId)
        {
            var model =
                _dbContext.SqlQuery<OrderModelCustom>(
                    "select top 1 Signature from [Order] where id=@p0", orderId)
                    .FirstOrDefault() ?? new OrderModelCustom();
            return View(model);
        }
    }
}