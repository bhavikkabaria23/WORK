﻿using System.Collections.Generic;
using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc;

namespace ShopFast.Plugin.Misc.QuickCheckout.Models
{
    public class ConfigurationModel : BaseNopModel
    {
        public bool ShowBothTablesOnMultipleOrders { get; set; }
    }
}
