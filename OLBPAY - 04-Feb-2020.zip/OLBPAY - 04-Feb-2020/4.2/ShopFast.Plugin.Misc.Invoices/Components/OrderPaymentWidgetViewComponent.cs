﻿using System;
using Microsoft.AspNetCore.Mvc;
using Nop.Web.Framework.Components;

namespace ShopFast.Plugin.Misc.Invoices.Components
{
    [ViewComponent(Name = "OrderPaymentWidget")]
    public class OrderPaymentWidgetViewComponent : NopViewComponent
    {       
        public IViewComponentResult Invoke(string widgetZone, object additionalData)
        {
            switch (widgetZone)
            {
                case "account_navigation_before":
                    var model = new ShopFast.Plugin.Misc.Invoices.Models.CustomerNavigationModel();
                    return View("~/Plugins/ShopFast.Misc.Invoices/Views/OrderPayment/PaidUnpaidOrders.cshtml", model);
                case "orderdetails_page_overview":
                    return null;//StoreInfo((int) additionalData);
                default:
                    throw new Exception("Shouldn't get here...");
            }            
        }     
    }
}
