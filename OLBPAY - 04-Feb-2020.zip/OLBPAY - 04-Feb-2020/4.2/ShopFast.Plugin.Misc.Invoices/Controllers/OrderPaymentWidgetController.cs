﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Razor;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Nop.Core;
using Nop.Core.Domain.Common;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Core.Infrastructure;
using Nop.Services.Catalog;
using Nop.Services.Common;
using Nop.Services.Directory;
using Nop.Services.Helpers;
using Nop.Services.Localization;
using Nop.Services.Orders;
using Nop.Services.Payments;
using Nop.Web.Framework.Controllers;
using Nop.Web.Models.Order;
using ShopFast.Plugin.Misc.Core.Extensions;
using ShopFast.Plugin.Misc.Core.Services;
using ShopFast.Plugin.Misc.Invoices.Models;

namespace ShopFast.Plugin.Misc.Invoices.Controllers
{
    public class OrderPaymentWidgetController : BasePluginController
    {
        #region Fields

        private readonly IWorkContext _workContext;
        private readonly IOrderService _orderService;
        private readonly IStoreContext _storeContext;
        private readonly IPaymentService _paymentService;

        private readonly PrepareCheckoutModels _prepareCheckoutModels;
        private readonly AddressSettings _addressSettings;
        private readonly IDateTimeHelper _dateTimeHelper;
        private readonly ILocalizationService _localizationService;
        private readonly IOrderProcessingService _orderProcessingService;
        private readonly ICurrencyService _currencyService;
        private readonly IPriceFormatter _priceFormatter;
        private readonly IGenericAttributeService _genericAttributeService;

        #endregion

        #region Ctor

        public OrderPaymentWidgetController(IWorkContext workContext,
            IOrderService orderService,
            IStoreContext storeContext,
            IPaymentService paymentService,
            PrepareCheckoutModels prepareCheckoutModels,
            AddressSettings addressSettings,
            IDateTimeHelper dateTimeHelper,
            ILocalizationService localizationService,
            ICurrencyService currencyService,
            IOrderProcessingService orderProcessingService,
            IPriceFormatter priceFormatter, IGenericAttributeService genericAttributeService)
        {
            _workContext = workContext;
            _orderService = orderService;
            _storeContext = storeContext;
            _paymentService = paymentService;
            _prepareCheckoutModels = prepareCheckoutModels;
            _addressSettings = addressSettings;
            _dateTimeHelper = dateTimeHelper;
            _localizationService = localizationService;
            _currencyService = currencyService;
            _orderProcessingService = orderProcessingService;
            _priceFormatter = priceFormatter;
            _genericAttributeService = genericAttributeService;
        }

        #endregion

        #region Utilites

        [NonAction]
        protected virtual CustomerOrderListModel PrepareCustomerOrderListModel(PaymentStatus? paymentStatus)
        {
            var model = new CustomerOrderListModel();
            IPagedList<Order> orders;
            if (paymentStatus == null)
            {
                orders = _orderService.SearchOrders(storeId: _storeContext.CurrentStore.Id,
                    customerId: _workContext.CurrentCustomer.Id);
                var ordersToRemove = _orderService.SearchOrders(storeId: _storeContext.CurrentStore.Id,
                    customerId: _workContext.CurrentCustomer.Id, psIds: new List<int>() { (int) PaymentStatus.Paid });
                foreach (var order in ordersToRemove)
                {
                    orders.Remove(order);
                }
            }
            else
            {
                orders = _orderService.SearchOrders(storeId: _storeContext.CurrentStore.Id,
                    customerId: _workContext.CurrentCustomer.Id, psIds: new List<int>() { (int)paymentStatus });
                if (paymentStatus == PaymentStatus.Paid)
                {
                    orders = new PagedList<Order>(orders.Where(o => o.OrderTotal > decimal.Zero).ToList(), 0, int.MaxValue);
                }
            }

            //Remove partial payment orders
            var orderIdsToDelete = new List<int>();
            orders.ToList().ForEach(o =>
            {
                if (_genericAttributeService.GetAttributesForEntity(o.Id, "Order")
                    .Any(ga => ga.Key == SystemCustomerAttributeNames.InvoiceType && ga.Value == "PartialPayment"))
                    orderIdsToDelete.Add(o.Id);
            });
            orderIdsToDelete.ForEach(id => orders.Remove(orders.First(o => o.Id == id)));
            

            foreach (var order in orders)
            {
                var orderModel = new CustomerOrderListModel.OrderDetailsModel
                {
                    Id = order.Id,
                    CreatedOn = _dateTimeHelper.ConvertToUserTime(order.CreatedOnUtc, DateTimeKind.Utc),
                    OrderStatus = _localizationService.GetLocalizedEnum(order.OrderStatus),
                   PaymentStatus = _localizationService.GetLocalizedEnum(order.PaymentStatus),
                    ShippingStatus = _localizationService.GetLocalizedEnum(order.ShippingStatus),
                IsReturnRequestAllowed = _orderProcessingService.IsReturnRequestAllowed(order)
                };
                var orderTotalInCustomerCurrency = _currencyService.ConvertCurrency(order.OrderTotal, order.CurrencyRate);
                orderModel.OrderTotal = _priceFormatter.FormatPrice(orderTotalInCustomerCurrency, true, order.CustomerCurrencyCode, false, _workContext.WorkingLanguage);

                model.Orders.Add(orderModel);
            }

            var recurringPayments = _orderService.SearchRecurringPayments(_storeContext.CurrentStore.Id,
                _workContext.CurrentCustomer.Id, 0, null, 0, int.MaxValue);
            foreach (var recurringPayment in recurringPayments)
            {
                var recurringPaymentModel = new CustomerOrderListModel.RecurringOrderModel
                {
                    Id = recurringPayment.Id,
                    StartDate = _dateTimeHelper.ConvertToUserTime(recurringPayment.StartDateUtc, DateTimeKind.Utc).ToString(),
                    CycleInfo = $"{recurringPayment.CycleLength} {_localizationService.GetLocalizedEnum(recurringPayment.CyclePeriod)}",
                    NextPayment = recurringPayment.NextPaymentDate.HasValue ? _dateTimeHelper.ConvertToUserTime(recurringPayment.NextPaymentDate.Value, DateTimeKind.Utc).ToString() : "",
                    TotalCycles = recurringPayment.TotalCycles,
                    CyclesRemaining = recurringPayment.CyclesRemaining,
                    InitialOrderId = recurringPayment.InitialOrder.Id,
                    CanCancel = _orderProcessingService.CanCancelRecurringPayment(_workContext.CurrentCustomer, recurringPayment),
                };

                model.RecurringOrders.Add(recurringPaymentModel);
            }

            return model;
        }

        protected virtual string RenderPartialViewToString(string viewName, object model)
        {
            //get Razor view engine
            var razorViewEngine = EngineContext.Current.Resolve<IRazorViewEngine>();

            //create action context
            var actionContext = new ActionContext(HttpContext, RouteData, ControllerContext.ActionDescriptor, ModelState);

            //set view name as action name in case if not passed
            if (string.IsNullOrEmpty(viewName))
                viewName = ControllerContext.ActionDescriptor.ActionName;

            //set model
            ViewData.Model = model;

            //try to get a view by the name
            var viewResult = razorViewEngine.FindView(actionContext, viewName, false);
            if (viewResult.View == null)
            {
                //or try to get a view by the path
                viewResult = razorViewEngine.GetView(null, viewName, false);
                if (viewResult.View == null)
                    throw new ArgumentNullException($"{viewName} view was not found");
            }
            using (var stringWriter = new StringWriter())
            {
                var viewContext = new ViewContext(actionContext, viewResult.View, ViewData, TempData, stringWriter, new HtmlHelperOptions());

                var t = viewResult.View.RenderAsync(viewContext);
                t.Wait();
                return stringWriter.GetStringBuilder().ToString();
            }
        }    

        [NonAction]
        private PaymentMethodsModel PreparePaymentMethodModel(IList<ShoppingCartItem> cart, string invoiceType = null)
        {
            var model = new PaymentMethodsModel();

            int filterByCountryId = 0;
            if (_addressSettings.CountryEnabled &&
                _workContext.CurrentCustomer.BillingAddress != null &&
                _workContext.CurrentCustomer.BillingAddress.Country != null)
            {
                filterByCountryId = _workContext.CurrentCustomer.BillingAddress.Country.Id;
            }

            var paymentInfoModel = _prepareCheckoutModels.PreparePaymentMethodModel(cart, filterByCountryId);
            model.IsPaymentWorkflowRequired = true;
            if (invoiceType == "Recurring")
            {
                model.PaymentMethods = paymentInfoModel.PaymentMethods.Where(p =>
                    _paymentService.GetRecurringPaymentType(p.PaymentMethodSystemName) != RecurringPaymentType.NotSupported)
                    .ToList();
            }
            else
            {
                model.PaymentMethods = paymentInfoModel.PaymentMethods;
            }
            model.DisplayRewardPoints = paymentInfoModel.DisplayRewardPoints;
            model.RewardPointsAmount = paymentInfoModel.RewardPointsAmount;
            model.RewardPointsBalance = model.RewardPointsBalance;

            return model;
        }

        #endregion


        [HttpPost]
        public IActionResult AjaxGetOrderPaymentStatus(int orderId)
        {
            var order = _orderService.GetOrderById(orderId);
            if (order != null)
            {
                return Json(new
                {
                    success = true,
                    partial = RenderPartialViewToString("~/Plugins/ShopFast.Misc.Invoices/Views/OrderPayment/_OrderPaymentStatus.cshtml", order)
                });
            }
            else
            {
                return Json(new
                {
                    success = false,
                    partial = ""
                });
            }
        }

        #region Methods              

        public IActionResult StoreInfo(int? orderId)
        {
            if (orderId == null)
            {
                return View();
            }
            var model = PrepareCustomerOrderListModel(PaymentStatus.Paid);

            return View("~/Plugins/ShopFast.Misc.Invoices/Views/OrderPayment/PaidOrders.cshtml", model);
        }

        public IActionResult PaidOrders()
        {
            var model = PrepareCustomerOrderListModel(PaymentStatus.Paid);

            return View("~/Plugins/ShopFast.Misc.Invoices/Views/OrderPayment/PaidOrders.cshtml", model);
        }

        public IActionResult UnpaidOrders()
        {
            var model = PrepareCustomerOrderListModel(null);

            return View("~/Plugins/ShopFast.Misc.Invoices/Views/OrderPayment/UnpaidOrders.cshtml", model);
        }

        #endregion
    }
}