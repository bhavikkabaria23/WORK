﻿using Autofac;
using Autofac.Core;
using Nop.Core.Configuration;
using Nop.Core.Data;
using Nop.Core.Infrastructure;
using Nop.Core.Infrastructure.DependencyManagement;
using Nop.Data;
using Nop.Services.Catalog;
using Nop.Services.Common;
using Nop.Services.Messages;
using Nop.Services.Orders;
using Nop.Services.Payments;
using Nop.Services.Shipping;
using Nop.Web.Framework.Mvc;
using ShopFast.Plugin.Misc.Core.Services;

namespace ShopFast.Plugin.Misc.Core
{
    public class DependencyRegistrar : IDependencyRegistrar
    {
        //nop3.7 upgrade begin
        /// <summary>
        /// Register services and interfaces
        /// </summary>
        /// <param name="builder">Container builder</param>
        /// <param name="typeFinder">Type finder</param>
        /// <param name="config">Config</param>
        public virtual void Register(ContainerBuilder builder, ITypeFinder typeFinder, NopConfig config)
        {
            builder.RegisterType<WeightAttributeParser>().As<WeightAttributeParser>().InstancePerLifetimeScope();
            builder.RegisterType<WeightProductTemplateService>().As<WeightProductTemplateService>().InstancePerLifetimeScope();
            builder.RegisterType<ITPProductService>().As<IProductService>().InstancePerLifetimeScope();
            builder.RegisterType<ITPPriceCalculationService>().As<IPriceCalculationService>().InstancePerLifetimeScope();
            builder.RegisterType<ITPShippingService>().As<IShippingService>().InstancePerLifetimeScope();
            builder.RegisterType<ITPProductAttributeFormatter>().As<IProductAttributeFormatter>().InstancePerLifetimeScope();
            builder.RegisterType<TipsCheckoutAttributeParser>().As<TipsCheckoutAttributeParser>().InstancePerLifetimeScope();
            builder.RegisterType<ITPCheckoutAttributeFormatter>().As<ICheckoutAttributeFormatter>().InstancePerLifetimeScope();
            builder.RegisterType<ITPInvoiceTotalCalculationService>().As<IITPInvoiceTotalCalculationService>().InstancePerLifetimeScope();
            builder.RegisterType<ITPInvoiceTotalCalculationService>().As<IOrderTotalCalculationService>().InstancePerLifetimeScope();
            builder.RegisterType<ITPShoppingCartService>().As<IShoppingCartService>().InstancePerLifetimeScope();
            builder.RegisterType<ITPLocalizationService>().As<ITPLocalizationService>().InstancePerLifetimeScope();
            builder.RegisterType<ITPProductExtService>().As<ITPProductExtService>().InstancePerLifetimeScope();
            builder.RegisterType<PrepareShoppingCartModels>().As<PrepareShoppingCartModels>().InstancePerLifetimeScope();
            builder.RegisterType<PrepareCheckoutModels>().As<PrepareCheckoutModels>().InstancePerLifetimeScope();
            builder.RegisterType<ITPProductTemplateService>().As<ITPProductTemplateService>().InstancePerLifetimeScope();
            builder.RegisterType<ITPOrderService>().As<IOrderService>().InstancePerLifetimeScope();
            builder.RegisterType<ITPOrderService>().As<IITPOrderService>().InstancePerLifetimeScope();
            builder.RegisterType<InvoiceItemAttributeParser>().As<InvoiceItemAttributeParser>().InstancePerLifetimeScope();
            builder.RegisterType<ITPCustomerService>().As<IITPCustomerService>().InstancePerLifetimeScope();
            builder.RegisterType<InvoiceCartService>().As<IInvoiceCartService>().InstancePerLifetimeScope();
            //builder.RegisterType<InvoiceCartService>().As<IShoppingCartService>().InstancePerLifetimeScope();
            builder.RegisterType<ITPMessageTokenProvider>().As<IITPMessageTokenProvider>().InstancePerLifetimeScope();
            builder.RegisterType<ITPPartialPaymentService>().As<IITPPartialPaymentService>().InstancePerLifetimeScope();
            builder.RegisterType<ITPOrderProcessingService>().As<IITPOrderProcessingService>().InstancePerLifetimeScope();
            builder.RegisterType<ITPPaymentService>().As<IPaymentService>().InstancePerLifetimeScope();
            builder.RegisterType<ITPPaymentService>().As<IITPPaymentService>().InstancePerLifetimeScope();
            builder.RegisterType<ITPPdfService>().As<IPdfService>().InstancePerLifetimeScope();
        }
        //nop3.7 upgrade end

        public int Order
        {
            get { return 100500; }
        }

    }
}
