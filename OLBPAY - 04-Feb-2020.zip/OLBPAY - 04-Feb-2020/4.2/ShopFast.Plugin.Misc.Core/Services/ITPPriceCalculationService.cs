﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Nop.Core;
using Nop.Core.Caching;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Directory;
using Nop.Core.Domain.Discounts;
using Nop.Core.Domain.Orders;
using Nop.Services.Catalog;
using Nop.Services.Catalog.Cache;
using Nop.Services.Customers;
using Nop.Services.Directory;
using Nop.Services.Discounts;

namespace ShopFast.Plugin.Misc.Core.Services
{
    public class ITPPriceCalculationService : PriceCalculationService
    {
        private IProductAttributeParser _productAttributeParser2;
        private ShoppingCartSettings _shoppingCartSettings2;
        private IStoreContext _storeContext2;
        private CatalogSettings _catalogSettings2;
        private ICacheManager _cacheManager2;
        private IDiscountService _discountService2;
        private readonly WeightAttributeParser _productWeightAttributeParser;
        private readonly WeightProductTemplateService _productWeightTemplateService;
        private readonly IProductService _productService;
        private readonly CurrencySettings _currencySettings;
        private readonly ICategoryService _categoryService;
        private readonly IStaticCacheManager _cacheManager;


        public ITPPriceCalculationService(IWorkContext workContext, IStoreContext storeContext, IDiscountService discountService, 
            ICategoryService categoryService, IManufacturerService manufacturerService, IProductAttributeParser productAttributeParser, 
            IProductService productService, ICacheManager cacheManager, ShoppingCartSettings shoppingCartSettings, 
            CatalogSettings catalogSettings, WeightAttributeParser productWeightAttributeParser, 
            WeightProductTemplateService productWeightTemplateService,     
            ICurrencyService currencyService,
            CurrencySettings currencySettings,      
            IStaticCacheManager cacheManager2
            )
            //nop3.7 upgrade begin
            : base( catalogSettings,
             currencySettings,
             categoryService,
             currencyService,
             discountService,
             manufacturerService,
             productAttributeParser,
             productService,
             cacheManager2,
             storeContext,
             workContext,
             shoppingCartSettings)
            //nop3.7 upgrade end
        {
            _productAttributeParser2 = productAttributeParser;
            _shoppingCartSettings2 = shoppingCartSettings;
            _storeContext2 = storeContext;
            _catalogSettings2 = catalogSettings;
            _cacheManager2 = cacheManager;
            _discountService2 = discountService;
            _productWeightAttributeParser = productWeightAttributeParser;
            _productWeightTemplateService = productWeightTemplateService;
            _productService = productService;
        }
        /// <summary>
        /// Gets the shopping cart unit price (one item)
        /// </summary>
        /// <param name="product">Product</param>
        /// <param name="customer">Customer</param>
        /// <param name="shoppingCartType">Shopping cart type</param>
        /// <param name="quantity">Quantity</param>
        /// <param name="attributesXml">Product atrributes (XML format)</param>
        /// <param name="customerEnteredPrice">Customer entered price (if specified)</param>
        /// <param name="rentalStartDate">Rental start date (null for not rental products)</param>
        /// <param name="rentalEndDate">Rental end date (null for not rental products)</param>
        /// <param name="includeDiscounts">A value indicating whether include discounts or not for price computation</param>
        /// <param name="discountAmount">Applied discount amount</param>
        /// <param name="appliedDiscount">Applied discount</param>
        /// <returns>Shopping cart unit price (one item)</returns>
        public override decimal GetUnitPrice(Product product,
            Customer customer,
            ShoppingCartType shoppingCartType,
            int quantity,
            string attributesXml,
            decimal customerEnteredPrice,
            DateTime? rentalStartDate, DateTime? rentalEndDate,
            bool includeDiscounts,
            out decimal discountAmount,
            out List<DiscountForCaching> appliedDiscounts)
        {
            if (product == null)
                throw new ArgumentNullException("product");

            if (customer == null)
                throw new ArgumentNullException("customer");

            discountAmount = decimal.Zero;
            appliedDiscounts = new List<DiscountForCaching>();

            decimal finalPrice;

            var combination = _productAttributeParser2.FindProductAttributeCombination(product, attributesXml);
            if (combination != null && combination.OverriddenPrice.HasValue)
            {
                finalPrice = combination.OverriddenPrice.Value;
            }
            else
            {
                //summarize price of all attributes
                decimal attributesTotalPrice = decimal.Zero;
                var attributeValues = _productAttributeParser2.ParseProductAttributeValues(attributesXml);
                if (attributeValues != null)
                {
                    foreach (var attributeValue in attributeValues)
                    {
                        attributesTotalPrice += GetProductAttributeValuePriceAdjustment(attributeValue, customer, product.CustomerEntersPrice ? (decimal?)customerEnteredPrice : null);
                    }
                }

                //summarize price of all ext attributes
                decimal? weight = null;
                if (_productWeightTemplateService.IsWeightProductTemplate(product.ProductTemplateId))
                {
                    var extAttributeValues = _productWeightAttributeParser.ParseProductAttributeValue(attributesXml);
                    if (extAttributeValues != null)
                    {
                        decimal value = 0;
                        decimal.TryParse(extAttributeValues, out value);
                        weight = value;
                    }
                }

                //get price of a product (with previously calculated price of all attributes)
                if (product.CustomerEntersPrice)
                {
                    finalPrice = customerEnteredPrice;
                }
                else
                {
                    int qty;
                    if (_shoppingCartSettings2.GroupTierPricesForDistinctShoppingCartItems)
                    {
                        //the same products with distinct product attributes could be stored as distinct "ShoppingCartItem" records
                        //so let's find how many of the current products are in the cart
                        qty = customer.ShoppingCartItems
                            .Where(x => x.ProductId == product.Id)
                            .Where(x => x.ShoppingCartType == shoppingCartType)
                            .Sum(x => x.Quantity);
                        if (qty == 0)
                        {
                            qty = quantity;
                        }
                    }
                    else
                    {
                        qty = quantity;
                    }
                    finalPrice = GetWeightFinalPrice(product,
                        customer,
                        weight,
                        combination?.OverriddenPrice,
                        attributesTotalPrice,
                        includeDiscounts,
                        qty,
                        product.IsRental ? rentalStartDate : null,
                        product.IsRental ? rentalEndDate : null,
                        out discountAmount, out appliedDiscounts);
                }
            }

            //rounding
            if (_shoppingCartSettings2.RoundPricesDuringCalculation)
                finalPrice = RoundPrice(finalPrice);


            return finalPrice;
        }
        /// <summary>
        /// Gets the final price
        /// </summary>
        /// <param name="product">Product</param>
        /// <param name="customer">The customer</param>
        /// <param name="additionalCharge">Additional charge</param>
        /// <param name="includeDiscounts">A value indicating whether include discounts or not for final price computation</param>
        /// <param name="quantity">Shopping cart item quantity</param>
        /// <param name="rentalStartDate">Rental period start date (for rental products)</param>
        /// <param name="rentalEndDate">Rental period end date (for rental products)</param>
        /// <param name="discountAmount">Applied discount amount</param>
        /// <param name="appliedDiscount">Applied discount</param>
        /// <returns>Final price</returns>
        public virtual decimal GetWeightFinalPrice(Product product,
            Customer customer,
            decimal? weight,
            decimal? overriddenProductPrice,
            decimal additionalCharge,
            bool includeDiscounts,
            int quantity,
            DateTime? rentalStartDate,
            DateTime? rentalEndDate,
            out decimal discountAmount,
            out List<DiscountForCaching> appliedDiscounts)
        {
            if (product == null)
                throw new ArgumentNullException("product");

            discountAmount = decimal.Zero;
            appliedDiscounts = new List<DiscountForCaching>();

            var cacheKey = string.Format(NopCatalogDefaults.ProductPriceModelCacheKey,
    product.Id,
                overriddenProductPrice.HasValue ? overriddenProductPrice.Value.ToString(CultureInfo.InvariantCulture) : null,
                additionalCharge.ToString(CultureInfo.InvariantCulture),
                includeDiscounts,
                quantity,
                string.Join(",", customer.GetCustomerRoleIds()),
                _storeContext2.CurrentStore.Id);
            var cacheTime = _catalogSettings2.CacheProductPrices ? 60 : 0;
            //we do not cache price for rental products
            //otherwise, it can cause memory leaks (to store all possible date period combinations)
            if (product.IsRental || weight.HasValue)
                cacheTime = 0;
            var cachedPrice = _cacheManager2.Get(cacheKey, () =>
            {
                var result = new ProductPriceForCaching();

                //initial price
                decimal price = product.Price;

                ////special price
                //var specialPrice = product.GetSpecialPrice();
                //if (specialPrice.HasValue)
                //    price = specialPrice.Value;

                //tier prices
                if (product.HasTierPrices)
                {
                    var tierPrice = _productService.GetPreferredTierPrice(product, customer, _storeContext2.CurrentStore.Id, quantity);
                    if (tierPrice != null)
                        price = tierPrice.Price;
                }
                if (weight.HasValue && _productWeightTemplateService.IsWeightProductTemplate(product.ProductTemplateId))
                    price = price * weight.Value;
                //additional charge
                price = price + additionalCharge;

                //rental products
                if (product.IsRental)
                    if (rentalStartDate.HasValue && rentalEndDate.HasValue)
                        price = price * _productService.GetRentalPeriods(product, rentalStartDate.Value, rentalEndDate.Value);

                if (includeDiscounts)
                {
                    //discount
                    List<DiscountForCaching> tmpAppliedDiscounts;
                    decimal tmpDiscountAmount = GetDiscountAmount(product, customer, price, out tmpAppliedDiscounts);
                    price = price - tmpDiscountAmount;

                    if (tmpAppliedDiscounts != null && tmpAppliedDiscounts.Any())
                    {
                        result.AppliedDiscounts = tmpAppliedDiscounts;
                        result.AppliedDiscountAmount = tmpDiscountAmount;
                    }
                }

                if (price < decimal.Zero)
                    price = decimal.Zero;

                result.Price = price;
                return result;
            });

            if (includeDiscounts)
            {
                //Discount instance cannnot be cached between requests (when "catalogSettings.CacheProductPrices" is "true)
                //This is limitation of Entity Framework
                //That's why we load it here after working with cache
                appliedDiscounts = cachedPrice.AppliedDiscounts;
                if (appliedDiscounts.Any())
                {
                    discountAmount = cachedPrice.AppliedDiscountAmount;
                }
            }

            return cachedPrice.Price;
        }
    }
}
