﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using Nop.Core;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Common;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Directory;
using Nop.Core.Domain.Discounts;
using Nop.Core.Domain.Localization;
using Nop.Core.Domain.Media;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Core.Domain.Shipping;
using Nop.Core.Plugins;
using Nop.Services.Catalog;
using Nop.Services.Common;
using Nop.Services.Customers;
using Nop.Services.Directory;
using Nop.Services.Discounts;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Media;
using Nop.Services.Messages;
using Nop.Services.Orders;
using Nop.Services.Payments;
using Nop.Services.Security;
using Nop.Services.Shipping;
using Nop.Services.Stores;
using Nop.Services.Tax;
using Nop.Web.Extensions;
using Nop.Web.Factories;
using Nop.Web.Models.Checkout;
using Nop.Web.Models.Common;
using Nop.Web.Models.Order;
using Nop.Web.Models.ShoppingCart;
using ShopFast.Plugin.Misc.Core.Domain;
using ShopFast.Plugin.Misc.Core.Services;
using ShopFast.Plugin.Misc.QuickCheckout.Models;

namespace ShopFast.Plugin.Misc.QuickCheckout.Services
{
    public partial class QuickCheckoutPluginService
    {
        #region Fields

        private readonly IWorkContext _workContext;
        private readonly IStoreContext _storeContext;
        private readonly IStoreMappingService _storeMappingService;
        private readonly IShoppingCartService _shoppingCartService;
        private readonly ILocalizationService _localizationService;
        private readonly ITaxService _taxService;
        private readonly ICurrencyService _currencyService;
        private readonly IPriceFormatter _priceFormatter;
        private readonly IOrderProcessingService _orderProcessingService;
        private readonly ICustomerService _customerService;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly ICountryService _countryService;
        private readonly IStateProvinceService _stateProvinceService;
        private readonly IShippingService _shippingService;
        private readonly IPaymentService _paymentService;
        private readonly IPluginFinder _pluginFinder;
        private readonly IOrderTotalCalculationService _orderTotalCalculationService;
        private readonly ILogger _logger;
        private readonly IOrderService _orderService;
        private readonly IWebHelper _webHelper;
        private readonly HttpContextBase _httpContext;
        private readonly IAddressAttributeParser _addressAttributeParser;
        private readonly IAddressAttributeService _addressAttributeService;
        private readonly IAddressAttributeFormatter _addressAttributeFormatter;

        private readonly OrderSettings _orderSettings;
        private readonly RewardPointsSettings _rewardPointsSettings;
        private readonly PaymentSettings _paymentSettings;
        private readonly ShippingSettings _shippingSettings;
        private readonly AddressSettings _addressSettings;
        private readonly ICheckoutAttributeService _checkoutAttributeService;
        private readonly IPermissionService _permissionService;
        private readonly ICheckoutAttributeParser _checkoutAttributeParser;
        private readonly PrepareCheckoutModels _prepareCheckoutModels;
        private readonly IITPPartialPaymentService _partialPaymentService;
        private readonly TipsCheckoutAttributeParser _tipsCheckoutAttributeParser;
        private readonly IDownloadService _downloadService;
        private readonly IPriceCalculationService _priceCalculationService;
        private readonly ShoppingCartSettings _shoppingCartSettings;
        private readonly PrepareShoppingCartModels _prepareShoppingCartModels;
        private readonly MediaSettings _mediaSettings;
        private readonly InvoiceItemAttributeParser _invoiceItemAttributeParser;
        private readonly IInvoiceCartService _invoiceCartService;

        //nop3.7 upgrade begin
        private readonly IRewardPointService _rewardPointService;
        //nop3.7 upgrade end

        private readonly IAddressModelFactory _addressModelFactory;
        private readonly IDiscountService _discountService;

        #endregion

        #region Constructors

        public QuickCheckoutPluginService(IWorkContext workContext,
            IStoreContext storeContext,
            IStoreMappingService storeMappingService,
            IShoppingCartService shoppingCartService,
            ILocalizationService localizationService,
            ITaxService taxService,
            ICurrencyService currencyService,
            IPriceFormatter priceFormatter,
            IOrderProcessingService orderProcessingService,
            ICustomerService customerService,
            IGenericAttributeService genericAttributeService,
            ICountryService countryService,
            IStateProvinceService stateProvinceService,
            IShippingService shippingService,
            IPaymentService paymentService,
            IPluginFinder pluginFinder,
            IOrderTotalCalculationService orderTotalCalculationService,
            ILogger logger,
            IOrderService orderService,
            IWebHelper webHelper,
            HttpContextBase httpContext,
            IAddressAttributeParser addressAttributeParser,
            IAddressAttributeService addressAttributeService,
            IAddressAttributeFormatter addressAttributeFormatter,
            OrderSettings orderSettings,
            RewardPointsSettings rewardPointsSettings,
            PaymentSettings paymentSettings,
            ShippingSettings shippingSettings,
            AddressSettings addressSettings,
            ICheckoutAttributeService checkoutAttributeService,
            IPermissionService permissionService,
            ICheckoutAttributeParser checkoutAttributeParser,
            PrepareCheckoutModels prepareCheckoutModels,
            IITPPartialPaymentService partialPaymentService,
            TipsCheckoutAttributeParser tipsCheckoutAttributeParser,
            IDownloadService downloadService,
            IPriceCalculationService priceCalculationService,
            ShoppingCartSettings shoppingCartSettings,
            PrepareShoppingCartModels prepareShoppingCartModels,
            MediaSettings mediaSettings,
            InvoiceItemAttributeParser invoiceItemAttributeParser,
            IInvoiceCartService invoiceCartService,
            IRewardPointService rewardPointService,
            IAddressModelFactory addressModelFactory,
            IDiscountService discountService)
        {
            this._workContext = workContext;
            this._storeContext = storeContext;
            this._storeMappingService = storeMappingService;
            this._shoppingCartService = shoppingCartService;
            this._localizationService = localizationService;
            this._taxService = taxService;
            this._currencyService = currencyService;
            this._priceFormatter = priceFormatter;
            this._orderProcessingService = orderProcessingService;
            this._customerService = customerService;
            this._genericAttributeService = genericAttributeService;
            this._countryService = countryService;
            this._stateProvinceService = stateProvinceService;
            this._shippingService = shippingService;
            this._paymentService = paymentService;
            this._pluginFinder = pluginFinder;
            this._orderTotalCalculationService = orderTotalCalculationService;
            this._logger = logger;
            this._orderService = orderService;
            this._webHelper = webHelper;
            this._httpContext = httpContext;
            this._addressAttributeParser = addressAttributeParser;
            this._addressAttributeService = addressAttributeService;
            this._addressAttributeFormatter = addressAttributeFormatter;

            this._orderSettings = orderSettings;
            this._rewardPointsSettings = rewardPointsSettings;
            this._paymentSettings = paymentSettings;
            this._shippingSettings = shippingSettings;
            this._addressSettings = addressSettings;
            this._checkoutAttributeService = checkoutAttributeService;
            this._permissionService = permissionService;
            this._checkoutAttributeParser = checkoutAttributeParser;
            this._prepareCheckoutModels = prepareCheckoutModels;
            this._partialPaymentService = partialPaymentService;
            this._tipsCheckoutAttributeParser = tipsCheckoutAttributeParser;
            this._downloadService = downloadService;
            this._priceCalculationService = priceCalculationService;
            this._shoppingCartSettings = shoppingCartSettings;
            this._prepareShoppingCartModels = prepareShoppingCartModels;
            this._mediaSettings = mediaSettings;
            this._invoiceItemAttributeParser = invoiceItemAttributeParser;
            this._invoiceCartService = invoiceCartService;
            this._rewardPointService = rewardPointService;
            this._addressModelFactory = addressModelFactory;
            this._discountService = discountService;
        }

        #endregion

        #region ShoppingCart Methods

        [NonAction]
        public List<ShoppingCartItem> GetShoppingCartItems(int? orderId = null, Customer customer = null)
        {
            if (orderId == null)
            {
                return _workContext.CurrentCustomer.ShoppingCartItems
                .Where(sci => sci.ShoppingCartType == ShoppingCartType.ShoppingCart)
                .LimitPerStore(_storeContext.CurrentStore.Id)
                .ToList();
            }

            List<ShoppingCartItem> cart;
            var order = _orderService.GetOrderById((int)orderId);

            cart = order.Customer.ShoppingCartItems
                .Where(sci => sci.ShoppingCartType == ShoppingCartType.ShoppingCart &&
                              _invoiceItemAttributeParser.GetInvoiceItemAttributeMapping(sci.AttributesXml) != null &&
                              _invoiceItemAttributeParser.GetInvoiceItemAttributeMapping(sci.AttributesXml)
                                  .InvoiceId == order.Id)
                .LimitPerStore(_storeContext.CurrentStore.Id)
                .ToList();

            /*cart = _workContext.CurrentCustomer.ShoppingCartItems
                .Where(sci => sci.ShoppingCartType == ShoppingCartType.ShoppingCart &&
                    _invoiceItemAttributeParser.GetInvoiceItemAttributeMapping(sci.AttributesXml) != null &&
                    _invoiceItemAttributeParser.GetInvoiceItemAttributeMapping(sci.AttributesXml)
                    .InvoiceId == order.Id)
                .LimitPerStore(_storeContext.CurrentStore.Id)
                .ToList();*/

            return cart;
        }

        [NonAction]
        public void ClearShoppingCart(int? orderId = null, Customer customer = null)
        {
            var cart = GetShoppingCartItems(orderId, customer);
            cart.ToList().ForEach(sci => _invoiceCartService.DeleteShoppingCartItem(sci, false));
        }

        [NonAction]
        public List<ShoppingCartItem> ReOrder(int orderId, Customer customer = null, bool authorizeOnly = false)//;, out List<string> warnings)
        {
            //warnings = new List<string>();

            var order = _orderService.GetOrderById(orderId);
            if (order == null)
            {
                //warnings.Add("Can't find the order");
                return null;
            }
            if (order.Customer != _workContext.CurrentCustomer && authorizeOnly)
            {
                //warnings.Add("Order is assigned to another customer");
                return null;
            }

            try
            {
                ClearShoppingCart(orderId, customer);
                //_orderProcessingService.ReOrder(order);
                _invoiceCartService.ReOrderInvoice(order);

                return GetShoppingCartItems(order.Id, customer);
            }
            catch (Exception exc)
            {
                return null;
            }
        }

        [NonAction]
        public List<ShoppingCartItem> GetShoppingCart(List<int> ids, bool authorizeOnly = false)
        {
            var cart = new List<ShoppingCartItem>();
            if (ids.Any())
            {
                foreach (var id in ids)
                {
                    var shoppingCartItem = GetShoppingCart(id, authorizeOnly);
                    if (shoppingCartItem != null && shoppingCartItem.Count > 0)
                    {
                        cart.AddRange(shoppingCartItem);
                    }
                }
            }
            else
            {
                cart = GetShoppingCart();
            }
            return cart;
        }

        [NonAction]
        public List<ShoppingCartItem> GetShoppingCart(int? orderId = null, bool authorizeOnly = false)
        {
            if (orderId == null || _orderService.GetOrderById((int)orderId) == null)
            {
                return _workContext.CurrentCustomer.ShoppingCartItems
                    .Where(sci => sci.ShoppingCartType == ShoppingCartType.ShoppingCart)
                    .LimitPerStore(_storeContext.CurrentStore.Id)
                    .ToList();
            }
            else
            {
                return ReOrder((int)orderId, authorizeOnly: authorizeOnly);
            }
        }

        #endregion

        #region Multiple Orders Payment

        [NonAction]
        public List<Order> GetOrders(string str, string separator = ",")
        {
            var result = str.Split(separator.ToCharArray()).ToList();
            return result.Where(id => !string.IsNullOrEmpty(id))
                .Select(id => _orderService.GetOrderById(Int32.Parse(id)))
                .Where(order => order != null).ToList();
        }

        [NonAction]
        public List<Order> GetOrders(List<int> orderIds)
        {
            var result = orderIds.Select(id => _orderService.GetOrderById(id))
                .Where(o => o != null).ToList();
            return result;
        }

        [NonAction]
        public List<int> GetOrderIds(string str, string separator = ",")
        {
            if (string.IsNullOrEmpty(str))
                return new List<int>();

            var result = str.Split(separator.ToCharArray()).ToList();
            return result.Where(id => !string.IsNullOrEmpty(id))
                .Select(Int32.Parse)
                .Where(id => id > 0)
                .ToList();
        }

        [NonAction]
        public decimal GetMultipleOrdersTotal(List<int> orderIds)
        {
            return GetMultipleOrdersTotal(GetOrders(orderIds));
        }

        [NonAction]
        public decimal GetMultipleOrdersTotal(List<Order> orders)
        {
            return orders.Sum(order => order.OrderTotal);
        }

        [NonAction]
        protected List<Order> ValidateOrderList(List<Order> orders)
        {
            orders.RemoveAll(order => order.PaymentStatus == PaymentStatus.Paid);
            return orders;
        }

        #endregion

        #region Prepare QuickCheckout Model Methods 

        [NonAction]
        public QuickCheckoutModel PrepareQuickCheckoutModel(IList<ShoppingCartItem> cart,
            IList<string> warnings = null,
            IList<string> warningsPayment = null,
            IList<string> warningsShipping = null,
            int? orderId = null,
            bool showPartialPaymentSelector = false,
            int? customerId = null,
            string area = "Customer")
        {
            List<int> orderIds = new List<int>();
            if (orderId.HasValue)
                orderIds.Add(orderId.GetValueOrDefault());

            return PrepareQuickCheckoutModel(cart, orderIds, warnings, warningsPayment, warningsShipping, showPartialPaymentSelector,
                customerId, area);
        }

        [NonAction]
        public QuickCheckoutModel PrepareQuickCheckoutModel(IList<ShoppingCartItem> cart,
            List<int> orderIds,
            IList<string> warnings = null,
            IList<string> warningsPayment = null,
            IList<string> warningsShipping = null,
            bool showPartialPaymentSelector = false,
            int? customerId = null,
            string area = "Customer")
        {
            var cartModel = new ShoppingCartModel();

            //_prepareShoppingCartModels.PrepareShoppingCartModel(cartModel, cart);
            cartModel = PrepareShoppingCartModel(cart);

            var orders = GetOrders(orderIds);

            //Set customer
            Customer customer = null;
            if (customerId.HasValue)
            {
                customer = _customerService.GetCustomerById(customerId.GetValueOrDefault());
            }

            if (customer == null)
            {
                if (orders.Any())
                {
                    customer = orders.First().Customer;
                }
                else
                {
                    customer = _workContext.CurrentCustomer;
                }
            }

            /*var billingAddressToShow = customer.BillingAddress ?? (orders.Count() == 1
                ? orders.First().BillingAddress
                : null);*/
            var billingAddressToShow = orders.Count() == 1
                ? orders.First().BillingAddress
                : customer.BillingAddress;

            //Prepare addresses
            var billingAddress = new AddressModel();
            _addressModelFactory.PrepareAddressModel(billingAddress,
                address: billingAddressToShow,//customer.BillingAddress,
                excludeProperties: false,
                addressSettings: _addressSettings);
            PrepareAvailableCountriesAndStates(billingAddress, "Billing");

            var shippingAddress = new AddressModel();
            _addressModelFactory.PrepareAddressModel(shippingAddress,
                address: customer.ShippingAddress,
                excludeProperties: false,
                addressSettings: _addressSettings);
            PrepareAvailableCountriesAndStates(shippingAddress, "Shipping");

            var addresses = customer.Addresses.Select(a => PrepareAddressModel(a)).ToList();

            var model = new QuickCheckoutModel
            {
                CustomerId = customer.Id,

                BillingAddress = billingAddress,
                ShippingAddress = shippingAddress,

                ShowProductImages = cartModel.ShowProductImages,
                IsEditable = cartModel.IsEditable,
                UseDifferentAddressForShipping = true,
                IsGuest = customer.IsGuest(),
                IsAllowCustomerToWriteComment = false,
                TermsOfServiceOnOrderConfirmPage = true,//cartModel.TermsOfServiceOnOrderConfirmPage,
                isPaymentWorkflowRequired = _prepareCheckoutModels.IsPaymentWorkflowRequired(cart),
                RequiresShipping = cart.RequiresShipping(),
                AllowToSelectTheAddress = true,

                MinOrderTotalWarning = cartModel.MinOrderSubtotalWarning,

                Items = cartModel.Items.ToList(),

                ShowDiscountAndGiftcard = false, // Disable discounts and gift cards
                //ShowDiscountAndGiftcard = (orderId != null) && (_orderService.GetOrderById((int)orderId) != null),

                CheckoutAttributeInfo = cartModel.CheckoutAttributeInfo,
                RewardPointsAmount = _rewardPointsSettings.PointsForPurchases_Amount.ToString(),
                Shippingoption = SystemCustomerAttributeNames.SelectedShippingOption,
                //DiscountBox = new QuickCheckoutModel.DiscountBoxModel
                //{
                //    CurrentCode = cartModel.DiscountBox.CurrentCode,
                //    Display = cartModel.DiscountBox.Display,
                //    Message = cartModel.DiscountBox.Message
                //},
                GiftCardBox = new QuickCheckoutModel.GiftCardBoxModel
                {
                    CurrentGiftCardCode = null,
                    Display = cartModel.GiftCardBox.Display,
                    Message = cartModel.GiftCardBox.Message
                },
                //nop3.7 upgrade begin
                RewardPointsBalance = _rewardPointService.GetRewardPointsBalance(customer.Id, _storeContext.CurrentStore.Id),
                //nop3.7 upgrade end
                PaymentMethodSystemName = SystemCustomerAttributeNames.SelectedPaymentMethod,
                DisplayRewardPoints = _rewardPointsSettings.Enabled,
                UseRewardPoints = _rewardPointsSettings.Enabled,

                ExistingBillingAddresses = addresses,
                ExistingShippingAddresses = addresses,

                Orders = orders.Select(order => PrepareOrderModel(order)).ToList()
            };


            // discount
            var discounts = cartModel.DiscountBox.AppliedDiscountsWithCodes.ToList();
            foreach (var discount in discounts)
            {
                model.DiscountBox = new QuickCheckoutModel.DiscountBoxModel
                {
                    //CurrentCode = discount.CouponCode,
                    Display = cartModel.DiscountBox.Display
                };
            }

            if (warnings != null)
            {
                model.Warnings = warnings;
            }

            if (warningsPayment != null)
            {
                model.WarningsPayment = warningsPayment;
            }

            if (warningsShipping != null)
            {
                model.WarningsShipping = warningsShipping;
            }

            if (orders.Any())
            {
                if (model.MultipleOrders)
                {
                    model.RemainingBalance = _priceFormatter.FormatPrice(
                        orders.Sum(order => _partialPaymentService.GetRemainingBalance(order)), true, false);
                    PrepareCheckoutAttributes(model, "");
                }
                else
                {
                    var order = orders.First();
                    model.OrderId = order.Id;
                    model.RemainingBalance = _priceFormatter.FormatPrice(
                        _partialPaymentService.GetRemainingBalance(order), true, false);
                    PrepareCheckoutAttributes(model, order.CheckoutAttributesXml);
                }

                model.SetOrderIds();
            }

            //Set Shipping Methods
            ITPPrepareShippingMethodModel(cart, customer.ShippingAddress, model);
            ITPPreparePaymentMethodModel(cart, model);

            model.ShowPartialPaymentSelector = showPartialPaymentSelector;
            if (model.OrderId != null)
            {
                model.ShowCheckoutAttributes = true;
                model.ShowDiscountAndGiftcard = false; // Disable discounts and gift cards
                model.ShowOrderItems = true;
            }

            model.PaymentOperationType = PaymentOperationType.Full;
            model.ShowPaymentOperationTypes = true;
            model.PartialPaymentAmount = decimal.Zero;

            switch (area)
            {
                case "Admin":
                    model.Layout = "~/Administration/Views/Shared/_AdminLayout.cshtml";
                    model.Area = "Admin";
                    break;
                case "Customer":
                default:
                    model.Layout = "~/Views/Shared/_ColumnsOne.cshtml";
                    model.Area = "Customer";
                    break;
            }

            //model.ShoppingCartModel = PrepareShoppingCartModel(cart);

            return model;
        }

        [NonAction]
        public ShoppingCartModel PrepareShoppingCartModel(IList<ShoppingCartItem> cart)
        {
            var model = new ShoppingCartModel();

            foreach (var sci in cart)
            {
                var cartItemModel = new ShoppingCartModel.ShoppingCartItemModel
                {
                    Id = sci.Id,
                    ProductId = sci.Product.Id,
                    ProductName = sci.Product.GetLocalized(x => x.Name),
                    Quantity = sci.Quantity,
                    //AttributeInfo = _productAttributeFormatter.FormatAttributes(sci.Product, sci.AttributesXml),
                };

                cartItemModel.AllowItemEditing = false;

                //allowed quantities
                //nop3.7 upgrade begin
                var allowedQuantities = sci.Product.ParseAllowedQuantities();
                //nop3.7 upgrade end
                foreach (var qty in allowedQuantities)
                {
                    cartItemModel.AllowedQuantities.Add(new SelectListItem
                    {
                        Text = qty.ToString(),
                        Value = qty.ToString(),
                        Selected = sci.Quantity == qty
                    });
                }

                //recurring info
                if (sci.Product.IsRecurring)
                    cartItemModel.RecurringInfo = string.Format(_localizationService.GetResource("ShoppingCart.RecurringPeriod"),
                        sci.Product.RecurringCycleLength, sci.Product.RecurringCyclePeriod.GetLocalizedEnum(_localizationService, _workContext));

                //rental info
                if (sci.Product.IsRental)
                {
                    var rentalStartDate = sci.RentalStartDateUtc.HasValue ? sci.Product.FormatRentalDate(sci.RentalStartDateUtc.Value)
                        : "";
                    var rentalEndDate = sci.RentalEndDateUtc.HasValue ? sci.Product.FormatRentalDate(sci.RentalEndDateUtc.Value) : "";
                    cartItemModel.RentalInfo = string.Format(_localizationService.GetResource("ShoppingCart.Rental.FormattedDate"),
                        rentalStartDate, rentalEndDate);
                }

                //unit prices
                if (sci.Product.CallForPrice)
                {
                    cartItemModel.UnitPrice = _localizationService.GetResource("Products.CallForPrice");
                }
                else
                {
                    decimal taxRate;
                    decimal shoppingCartUnitPriceWithDiscountBase = _taxService.GetProductPrice(sci.Product,
                        _priceCalculationService.GetUnitPrice(sci), out taxRate);
                    decimal shoppingCartUnitPriceWithDiscount = _currencyService.ConvertFromPrimaryStoreCurrency(shoppingCartUnitPriceWithDiscountBase, _workContext.WorkingCurrency);
                    cartItemModel.UnitPrice = _priceFormatter.FormatPrice(shoppingCartUnitPriceWithDiscount);
                }
                //subtotal, discount
                if (sci.Product.CallForPrice)
                {
                    cartItemModel.SubTotal = _localizationService.GetResource("Products.CallForPrice");
                }
                else
                {
                    //sub total
                    List<DiscountForCaching> scDiscounts;
                    int? maximumDiscountQty;
                    decimal shoppingCartItemDiscountBase;
                    decimal taxRate;
                    decimal shoppingCartItemSubTotalWithDiscountBase = _taxService.GetProductPrice(sci.Product, _priceCalculationService.GetSubTotal(sci, true, out shoppingCartItemDiscountBase, out scDiscounts, out maximumDiscountQty), out taxRate);
                    decimal shoppingCartItemSubTotalWithDiscount = _currencyService.ConvertFromPrimaryStoreCurrency(shoppingCartItemSubTotalWithDiscountBase, _workContext.WorkingCurrency);
                    cartItemModel.SubTotal = _priceFormatter.FormatPrice(shoppingCartItemSubTotalWithDiscount);

                    //display an applied discount amount
                    if (scDiscounts != null && scDiscounts.Any())
                    {
                        shoppingCartItemDiscountBase = _taxService.GetProductPrice(sci.Product, shoppingCartItemDiscountBase, out taxRate);
                        if (shoppingCartItemDiscountBase > decimal.Zero)
                        {
                            decimal shoppingCartItemDiscount = _currencyService.ConvertFromPrimaryStoreCurrency(shoppingCartItemDiscountBase, _workContext.WorkingCurrency);
                            cartItemModel.Discount = _priceFormatter.FormatPrice(shoppingCartItemDiscount);
                        }
                    }
                }

                //picture
                if (_shoppingCartSettings.ShowProductImagesOnShoppingCart)
                {
                    cartItemModel.Picture = _prepareShoppingCartModels.PrepareCartItemPictureModel(sci,
                        _mediaSettings.CartThumbPictureSize, true, cartItemModel.ProductName);
                }

                //item warnings
                var itemWarnings = _shoppingCartService.GetShoppingCartItemWarnings(
                    cart.GetCustomer(),
                    sci.ShoppingCartType,
                    sci.Product,
                    sci.StoreId,
                    sci.AttributesXml,
                    sci.CustomerEnteredPrice,
                    sci.RentalStartDateUtc,
                    sci.RentalEndDateUtc,
                    sci.Quantity,
                    false);
                foreach (var warning in itemWarnings)
                    cartItemModel.Warnings.Add(warning);

                var iiam = _invoiceItemAttributeParser.GetInvoiceItemAttributeMapping(sci.AttributesXml);
                if (iiam != null)
                {
                    cartItemModel.ProductName = iiam.Description;
                }

                model.Items.Add(cartItemModel);
            }

            model.ShowProductImages = _shoppingCartSettings.ShowProductImagesOnShoppingCart;
            model.DiscountBox.Display = _shoppingCartSettings.ShowDiscountBox;
            var discountCouponCodes = _workContext.CurrentCustomer.ParseAppliedDiscountCouponCodes();
            foreach (var couponCode in discountCouponCodes)
            {
                var discount = _discountService.GetAllDiscountsForCaching(couponCode: couponCode)
                    .FirstOrDefault(d => d.RequiresCouponCode && _discountService.ValidateDiscount(d, _workContext.CurrentCustomer).IsValid);

                model.DiscountBox.AppliedDiscountsWithCodes.Add(new ShoppingCartModel.DiscountBoxModel.DiscountInfoModel()
                {
                    Id = discount.Id,
                    CouponCode = discount.CouponCode
                });
            }
            model.GiftCardBox.Display = _shoppingCartSettings.ShowGiftCardBox;

            return model;
        }


        public void ITPPrepareShippingMethodModel(IList<ShoppingCartItem> cart, Address shippingAddress, QuickCheckoutModel model)
        {
            if (cart.RequiresShipping())
            {
                var shippingModel = _prepareCheckoutModels.PrepareShippingMethodModel(cart, shippingAddress);

                model.ShippingMethods = shippingModel.ShippingMethods;
                foreach (var warning in shippingModel.Warnings)
                {
                    model.Warnings.Add(warning);
                }
            }
        }

        public void ITPPreparePaymentMethodModel(IList<ShoppingCartItem> cart, QuickCheckoutModel model)
        {
            var orderIds = GetOrderIds(model.OrderIds);
            var orders = GetOrders(orderIds);

            //Set Payment Methods
            //filter by country
            int filterByCountryId = 0;
            if (_addressSettings.CountryEnabled &&
                _workContext.CurrentCustomer.BillingAddress != null &&
                _workContext.CurrentCustomer.BillingAddress.Country != null)
            {
                filterByCountryId = _workContext.CurrentCustomer.BillingAddress.Country.Id;
            }

            var paymentInfoModel = _prepareCheckoutModels.PreparePaymentMethodModel(cart, filterByCountryId);
            model.PaymentMethods = paymentInfoModel.PaymentMethods;
            //Check if one of orders is recurring invoice and remove methods which haven't suppot recurring payment
            /*if (orders.Any(order => order.GetAttribute<InvoiceType>(Core.Extensions.SystemCustomerAttributeNames.InvoiceType) 
                == InvoiceType.RecurringInvoice))
            {
                var paymentMethods = model.PaymentMethods.ToList();
                paymentMethods.RemoveAll(pm => 
                    _paymentService.GetRecurringPaymentType(pm.PaymentMethodSystemName) == RecurringPaymentType.NotSupported);
                model.PaymentMethods = paymentMethods;
            }*/

            model.DisplayRewardPoints = paymentInfoModel.DisplayRewardPoints;
            model.RewardPointsAmount = paymentInfoModel.RewardPointsAmount;
            model.RewardPointsBalance = model.RewardPointsBalance;
        }

        [NonAction]
        public OrderDetailsModel PrepareOrderModel(Order order)
        {
            var result = new OrderDetailsModel
            {
                Id = order.Id,
                BillingAddress = new AddressModel
                {
                    FirstName = order.BillingAddress.FirstName
                        ?? order.Customer.GetAttribute<string>(SystemCustomerAttributeNames.FirstName),
                    LastName = order.BillingAddress.LastName
                        ?? order.Customer.GetAttribute<string>(SystemCustomerAttributeNames.LastName),
                    Company = order.BillingAddress.Company
                        ?? order.Customer.GetAttribute<string>(SystemCustomerAttributeNames.Company)
                },
                CreatedOn = order.CreatedOnUtc,
                OrderTotal = _priceFormatter.FormatPrice(order.OrderTotal, true, false),
                PaymentMethodStatus = order.PaymentStatus.ToString()
            };

            return result;

            /*var result = new OrderDetailsModel
            {
                Id = order.Id,
                BillingAddress = new AddressModel
                {
                    FirstName = order.Customer.BillingAddress.FirstName
                        ?? order.Customer.GetAttribute<string>(SystemCustomerAttributeNames.FirstName),
                    LastName = order.Customer.BillingAddress.LastName
                        ?? order.Customer.GetAttribute<string>(SystemCustomerAttributeNames.LastName),
                    Company = order.Customer.BillingAddress.Company
                        ?? order.Customer.GetAttribute<string>(SystemCustomerAttributeNames.Company)
                },
                CreatedOn = order.CreatedOnUtc,
                OrderTotal = _priceFormatter.FormatPrice(order.OrderTotal, true, false),
                PaymentMethodStatus = order.PaymentStatus.ToString()
            };

            return result;*/
        }

        #endregion

        #region Checkout Attributes Methods

        [NonAction]//Done
        public void PrepareCheckoutAttributes(QuickCheckoutModel model, string attributesXml)
        {
            model.CheckoutAttributes = new List<ShoppingCartModel.CheckoutAttributeModel>();

            var checkoutAttributes = _checkoutAttributeService.GetAllCheckoutAttributes(_storeContext.CurrentStore.Id, true);
            foreach (var attribute in checkoutAttributes)
            {
                var attributeModel = new ShoppingCartModel.CheckoutAttributeModel
                {
                    Id = attribute.Id,
                    Name = attribute.GetLocalized(x => x.Name),
                    TextPrompt = attribute.GetLocalized(x => x.TextPrompt),
                    IsRequired = attribute.IsRequired,
                    AttributeControlType = attribute.AttributeControlType,
                    DefaultValue = attribute.DefaultValue
                };
                if (!String.IsNullOrEmpty(attribute.ValidationFileAllowedExtensions))
                {
                    attributeModel.AllowedFileExtensions = attribute.ValidationFileAllowedExtensions
                        .Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                        .ToList();
                }

                if (attribute.ShouldHaveValues())
                {
                    //values
                    var attributeValues = _checkoutAttributeService.GetCheckoutAttributeValues(attribute.Id);
                    foreach (var attributeValue in attributeValues)
                    {
                        var attributeValueModel = new ShoppingCartModel.CheckoutAttributeValueModel
                        {
                            Id = attributeValue.Id,
                            Name = attributeValue.GetLocalized(x => x.Name),
                            ColorSquaresRgb = attributeValue.ColorSquaresRgb,
                            IsPreSelected = attributeValue.IsPreSelected,
                        };
                        attributeModel.Values.Add(attributeValueModel);

                        //display price if allowed
                        if (_permissionService.Authorize(StandardPermissionProvider.DisplayPrices))
                        {
                            decimal priceAdjustmentBase = _taxService.GetCheckoutAttributePrice(attributeValue);
                            decimal priceAdjustment = _currencyService.ConvertFromPrimaryStoreCurrency(priceAdjustmentBase, _workContext.WorkingCurrency);
                            if (priceAdjustmentBase > decimal.Zero)
                                attributeValueModel.PriceAdjustment = "+" + _priceFormatter.FormatPrice(priceAdjustment);
                            else if (priceAdjustmentBase < decimal.Zero)
                                attributeValueModel.PriceAdjustment = "-" + _priceFormatter.FormatPrice(-priceAdjustment);
                        }
                    }
                }

                //set already selected attributes
                //var selectedCheckoutAttributes = _workContext.CurrentCustomer.GetAttribute<string>(
                //    Nop.Core.Domain.Customers.SystemCustomerAttributeNames.CheckoutAttributes, _genericAttributeService, 
                //    _storeContext.CurrentStore.Id);
                switch (attribute.AttributeControlType)
                {
                    case AttributeControlType.DropdownList:
                    case AttributeControlType.RadioList:
                    case AttributeControlType.Checkboxes:
                    case AttributeControlType.ColorSquares:
                        {
                            if (!String.IsNullOrEmpty(attributesXml))
                            {
                                //clear default selection
                                foreach (var item in attributeModel.Values)
                                    item.IsPreSelected = false;

                                //select new values
                                var selectedValues = _checkoutAttributeParser.ParseCheckoutAttributeValues(attributesXml);
                                foreach (var attributeValue in selectedValues)
                                    foreach (var item in attributeModel.Values)
                                        if (attributeValue.Id == item.Id)
                                            item.IsPreSelected = true;
                            }
                        }
                        break;
                    case AttributeControlType.ReadonlyCheckboxes:
                        {
                            //do nothing
                            //values are already pre-set
                        }
                        break;
                    case AttributeControlType.TextBox:
                    case AttributeControlType.MultilineTextbox:
                        {
                            if (!String.IsNullOrEmpty(attributesXml))
                            {
                                var enteredText = _checkoutAttributeParser.ParseValues(attributesXml, attribute.Id);
                                if (enteredText.Count > 0)
                                    attributeModel.DefaultValue = enteredText[0];
                            }
                        }
                        break;
                    case AttributeControlType.Datepicker:
                        {
                            //keep in mind my that the code below works only in the current culture
                            var selectedDateStr = _checkoutAttributeParser.ParseValues(attributesXml, attribute.Id);
                            if (selectedDateStr.Count > 0)
                            {
                                DateTime selectedDate;
                                if (DateTime.TryParseExact(selectedDateStr[0], "D", CultureInfo.CurrentCulture,
                                                       DateTimeStyles.None, out selectedDate))
                                {
                                    //successfully parsed
                                    attributeModel.SelectedDay = selectedDate.Day;
                                    attributeModel.SelectedMonth = selectedDate.Month;
                                    attributeModel.SelectedYear = selectedDate.Year;
                                }
                            }

                        }
                        break;
                    default:
                        break;
                }

                model.CheckoutAttributes.Add(attributeModel);
            }
        }

        [NonAction]//Done
        public virtual string ParseAndSaveCheckoutAttributesExt(List<ShoppingCartItem> cart, FormCollection form, Customer customer)
        {
            if (cart == null)
                throw new ArgumentNullException("cart");

            if (form == null)
                throw new ArgumentNullException("form");

            string attributesXml = customer.GetAttribute<string>(
                Nop.Core.Domain.Customers.SystemCustomerAttributeNames.CheckoutAttributes,
                _genericAttributeService,
                _storeContext.CurrentStore.Id);
            attributesXml = _tipsCheckoutAttributeParser.ClearCheckoutAttributes(attributesXml);

            var checkoutAttributes = _checkoutAttributeService.GetAllCheckoutAttributes(
                _storeContext.CurrentStore.Id, !cart.RequiresShipping());

            foreach (var attribute in checkoutAttributes)
            {
                //string controlId = string.Format("checkout_attribute_{0}", attribute.Id);
                string controlId = string.Format("checkout_attribute_{0}", attribute.Id);
                switch (attribute.AttributeControlType)
                {
                    case AttributeControlType.DropdownList:
                    case AttributeControlType.RadioList:
                    case AttributeControlType.ColorSquares:
                        {
                            var ctrlAttributes = form[controlId];
                            if (!String.IsNullOrEmpty(ctrlAttributes))
                            {
                                int selectedAttributeId = int.Parse(ctrlAttributes);
                                if (selectedAttributeId > 0)
                                    attributesXml = _checkoutAttributeParser.AddCheckoutAttribute(attributesXml,
                                        attribute, selectedAttributeId.ToString());
                            }
                        }
                        break;
                    case AttributeControlType.Checkboxes:
                        {
                            var cblAttributes = form[controlId];
                            if (!String.IsNullOrEmpty(cblAttributes))
                            {
                                foreach (var item in cblAttributes.Split(new[] { ',' },
                                    StringSplitOptions.RemoveEmptyEntries))
                                {
                                    int selectedAttributeId = int.Parse(item);
                                    if (selectedAttributeId > 0)
                                        attributesXml = _checkoutAttributeParser.AddCheckoutAttribute(
                                            attributesXml,
                                            attribute, selectedAttributeId.ToString());
                                }
                            }
                        }
                        break;
                    case AttributeControlType.ReadonlyCheckboxes:
                        {
                            //load read-only (already server-side selected) values
                            var attributeValues = _checkoutAttributeService.GetCheckoutAttributeValues(
                                attribute.Id);
                            foreach (var selectedAttributeId in attributeValues
                                .Where(v => v.IsPreSelected)
                                .Select(v => v.Id)
                                .ToList())
                            {
                                attributesXml = _checkoutAttributeParser.AddCheckoutAttribute(attributesXml,
                                            attribute, selectedAttributeId.ToString());
                            }
                        }
                        break;
                    case AttributeControlType.TextBox:
                    case AttributeControlType.MultilineTextbox:
                        {
                            var ctrlAttributes = form[controlId];
                            if (!String.IsNullOrEmpty(ctrlAttributes))
                            {
                                string enteredText = ctrlAttributes.Trim();
                                attributesXml = _checkoutAttributeParser.AddCheckoutAttribute(attributesXml,
                                    attribute, enteredText);
                            }
                        }
                        break;
                    case AttributeControlType.Datepicker:
                        {
                            var date = form[controlId + "_day"];
                            var month = form[controlId + "_month"];
                            var year = form[controlId + "_year"];
                            DateTime? selectedDate = null;
                            try
                            {
                                selectedDate = new DateTime(Int32.Parse(year), Int32.Parse(month),
                                    Int32.Parse(date));
                            }
                            catch { }
                            if (selectedDate.HasValue)
                            {
                                attributesXml = _checkoutAttributeParser.AddCheckoutAttribute(attributesXml,
                                    attribute, selectedDate.Value.ToString("D"));
                            }
                        }
                        break;
                    case AttributeControlType.FileUpload:
                        {
                            Guid downloadGuid;
                            Guid.TryParse(form[controlId], out downloadGuid);
                            var download = _downloadService.GetDownloadByGuid(downloadGuid);
                            if (download != null)
                            {
                                attributesXml = _checkoutAttributeParser.AddCheckoutAttribute(attributesXml,
                                           attribute, download.DownloadGuid.ToString());
                            }
                        }
                        break;
                    default:
                        break;
                }
            }

            //save checkout attributes
            //_genericAttributeService.SaveAttribute(_workContext.CurrentCustomer, 
            //    Nop.Core.Domain.Customers.SystemCustomerAttributeNames.CheckoutAttributes, 
            //    attributesXml, _storeContext.CurrentStore.Id);

            return attributesXml;
        }

        #endregion

        #region Address Methods

        [NonAction]
        public void PrepareAvailableCountriesAndStates(AddressModel address, string type)
        {
            if (_addressSettings.CountryEnabled)
            {
                IList<Country> countries = new List<Country>();
                if (_localizationService == null)
                    throw new ArgumentNullException("localizationService");

                switch (type.ToLower())
                {
                    case "billing":
                        countries = _countryService.GetAllCountriesForBilling();
                        break;
                    case "shipping":
                        countries = _countryService.GetAllCountriesForBilling();
                        break;
                }

                address.AvailableCountries.Add(new SelectListItem { Text = _localizationService.GetResource("Address.SelectCountry"), Value = "0" });
                foreach (var country in countries)
                {
                    address.AvailableCountries.Add(new SelectListItem
                    {
                        Text = country.GetLocalized(x => x.Name),
                        Value = country.Id.ToString(),
                        Selected = country.Id == address.CountryId
                    });
                }

                if (_addressSettings.StateProvinceEnabled)
                {
                    //states
                    if (_stateProvinceService == null)
                        throw new ArgumentNullException("stateProvinceService");

                    var states = _stateProvinceService
                        .GetStateProvincesByCountryId(address.CountryId.HasValue ? address.CountryId.Value : 0)
                        .ToList();
                    if (states.Count > 0)
                    {
                        address.AvailableStates.Add(new SelectListItem { Text = _localizationService.GetResource("Address.SelectState"), Value = "0" });

                        foreach (var s in states)
                        {
                            address.AvailableStates.Add(new SelectListItem
                            {
                                Text = s.GetLocalized(x => x.Name),
                                Value = s.Id.ToString(),
                                Selected = (s.Id == address.StateProvinceId)
                            });
                        }
                    }
                    else
                    {
                        bool anyCountrySelected = address.AvailableCountries.Any(x => x.Selected);
                        address.AvailableStates.Add(new SelectListItem
                        {
                            Text = _localizationService.GetResource(anyCountrySelected ? "Address.OtherNonUS" : "Address.SelectState"),
                            Value = "0"
                        });
                    }
                }
            }
        }

        [NonAction]
        public AddressModel PrepareAddressModel(Address address)
        {
            var model = new AddressModel
            {
                Id = address.Id,
                FirstName = address.FirstName ?? "",
                LastName = address.LastName ?? "",
                Company = address.Company ?? "",
                CompanyEnabled = _addressSettings.CityEnabled,
                CompanyRequired = _addressSettings.CompanyRequired,
                StreetAddressEnabled = _addressSettings.StreetAddressEnabled,
                Address1 = address.Address1 ?? "",
                Address2 = address.Address2 ?? "",
                CityEnabled = _addressSettings.CityEnabled,
                City = address.City ?? "",
                StateProvinceId = address.StateProvince != null ? address.StateProvince.Id : 0,
                StateProvinceEnabled = _addressSettings.StateProvinceEnabled,
                StateProvinceName = address.StateProvince != null ? address.StateProvince.Name : null,
                ZipPostalCodeEnabled = _addressSettings.ZipPostalCodeEnabled,
                ZipPostalCode = address.ZipPostalCode ?? "",
                CountryId = address.Country != null ? address.Country.Id : 0,
                CountryEnabled = _addressSettings.CountryEnabled,
                CountryName = address.Country != null ? address.Country.Name : null,
                PhoneNumber = address.PhoneNumber ?? "",
                FaxEnabled = _addressSettings.FaxEnabled,
                FaxRequired = _addressSettings.FaxRequired,
                FaxNumber = address.FaxNumber ?? "",
                Email = address.Email ?? ""
            };

            return model;
        }

        #endregion
    }
}
