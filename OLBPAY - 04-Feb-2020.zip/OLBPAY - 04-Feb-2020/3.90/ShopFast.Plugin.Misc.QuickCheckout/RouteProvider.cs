﻿using System.Web.Mvc;
using System.Web.Routing;
using Nop.Web.Framework.Mvc.Routes;

namespace ShopFast.Plugin.Misc.QuickCheckout
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(RouteCollection routes)
        {
            routes.MapRoute("ShopFast.Plugin.Misc.QuickCheckout.QuickCheckout",
                 "QuickCheckout",
                 new { controller = "QuickCheckout", action = "QuickCheckout" },
                 new[] { "ShopFast.Plugin.Misc.QuickCheckout.Controllers" });

            routes.MapRoute("ShopFast.Plugin.Misc.QuickCheckout.OrderQuickCheckout",
                 "OrderQuickCheckout/{ids}",
                 new { controller = "QuickCheckout", action = "OrderQuickCheckout", ids = UrlParameter.Optional },
                 new[] { "ShopFast.Plugin.Misc.QuickCheckout.Controllers" });
            
            routes.MapRoute("ShopFast.Plugin.Misc.QuickCheckout.AdminOrderQuickCheckout",
                "AdminOrderQuickCheckout/{ids}",
                new { controller = "QuickCheckout", action = "AdminOrderQuickCheckout", ids = UrlParameter.Optional },
                new[] { "ShopFast.Plugin.Misc.QuickCheckout.Controllers" }
            ).DataTokens.Add("area", "admin");

            routes.MapRoute("ShopFast.Plugin.Misc.QuickCheckout.AnonymousOrderSearch",
                 "AnonymousOrderSearch",
                 new { controller = "QuickCheckout", action = "AnonymousOrderSearch" },
                 new[] { "ShopFast.Plugin.Misc.QuickCheckout.Controllers" });

            routes.MapRoute("ShopFast.Plugin.Misc.QuickCheckout.CryptedMakeAPayment",
                 "CryptedMakeAPayment/{cryptedId}",
                 new { controller = "QuickCheckout", action = "CryptedMakeAPayment", cryptedId = UrlParameter.Optional },
                 new[] { "ShopFast.Plugin.Misc.QuickCheckout.Controllers" });

           routes.MapRoute("ShopFast.Plugin.Misc.QuickCheckout.AjaxSetPaymentSection",
                "QuickCheckout/Ajax/AjaxSetPaymentSection",
                new { controller = "QuickCheckout", action = "AjaxSetPaymentSection" },
                new[] { "ShopFast.Plugin.Misc.QuickCheckout.Controllers" }
           );

           /*routes.MapRoute("ShopFast.Plugin.Misc.QuickCheckout.CompleteRedirectionPayment",
               "CompleteRedirectionPayment",
               new { controller = "QuickCheckout", action = "CompleteRedirectionPayment" },
               new[] { "ShopFast.Plugin.Misc.QuickCheckout.Controllers" }
            );*/

           /*routes.MapRoute("ShopFast.Plugin.Misc.QuickCheckout.AjaxProceedPayment",
              "AjaxProceedPayment",
              new { controller = "QuickCheckout", action = "AjaxProceedPayment" },
              new[] { "ShopFast.Plugin.Misc.QuickCheckout.Controllers" }
         );*/

           routes.MapRoute("ShopFast.Plugin.Misc.QuickCheckout.AjaxPaymentMethod",
                "QuickCheckout/Ajax/AjaxPaymentMethod",
                new { controller = "QuickCheckout", action = "AjaxPaymentMethod" },
                new[] {"ShopFast.Plugin.Misc.QuickCheckout.Controllers"});

           routes.MapRoute("ShopFast.Plugin.Misc.QuickCheckout.AjaxShippingMethod",
                "QuickCheckout/Ajax/AjaxShippingMethod",
                new { controller = "QuickCheckout", action = "AjaxShippingMethod" },
                new[] {"ShopFast.Plugin.Misc.QuickCheckout.Controllers"});

           routes.MapRoute("ShopFast.Plugin.Misc.QuickCheckout.AjaxOrderSummary",
               "QuickCheckout/Ajax/AjaxOrderSummary",
               new { controller = "QuickCheckout", action = "AjaxOrderSummary" },
               new[] { "ShopFast.Plugin.Misc.QuickCheckout.Controllers" });

           routes.MapRoute("ShopFast.Plugin.Misc.QuickCheckout.AjaxPaymentInfo",
                "QuickCheckout/Ajax/AjaxPaymentInfo",
                new { controller = "QuickCheckout", action = "AjaxPaymentInfo" },
                new[] { "ShopFast.Plugin.Misc.QuickCheckout.Controllers" });

            //Discounts
            routes.MapRoute("ShopFast.Plugin.Misc.QuickCheckout.AjaxGetAppliedDiscount",
                 "Plugin/QuickCheckout/Ajax/AjaxGetAppliedDiscount",
                 new { controller = "QuickCheckout", action = "AjaxGetAppliedDiscount" },
                 new[] { "ShopFast.Plugin.Misc.QuickCheckout.Controllers" });

            routes.MapRoute("ShopFast.Plugin.Misc.QuickCheckout.AjaxApplyDiscountCoupon",
                 "Plugin/QuickCheckout/Ajax/AjaxApplyDiscountCoupon",
                 new { controller = "QuickCheckout", action = "AjaxApplyDiscountCoupon" },
                 new[] { "ShopFast.Plugin.Misc.QuickCheckout.Controllers" });

            routes.MapRoute("ShopFast.Plugin.Misc.QuickCheckout.AjaxRemoveDiscountCoupon",
                 "Plugin/QuickCheckout/Ajax/AjaxRemoveDiscountCoupon",
                 new { controller = "QuickCheckout", action = "AjaxRemoveDiscountCoupon" },
                 new[] { "ShopFast.Plugin.Misc.QuickCheckout.Controllers" });

            //GiftCards
            routes.MapRoute("ShopFast.Plugin.Misc.QuickCheckout.AjaxApplyGiftCard",
                 "Plugin/QuickCheckout/Ajax/AjaxApplyGiftCard",
                 new { controller = "QuickCheckout", action = "AjaxApplyGiftCard" },
                 new[] { "ShopFast.Plugin.Misc.QuickCheckout.Controllers" });

            routes.MapRoute("ShopFast.Plugin.Misc.QuickCheckout.AjaxRemoveGiftCard",
                 "Plugin/QuickCheckout/Ajax/AjaxRemoveGiftCard",
                 new { controller = "QuickCheckout", action = "AjaxRemoveGiftCard" },
                 new[] { "ShopFast.Plugin.Misc.QuickCheckout.Controllers" });

            
        }
        public int Priority
        {
            get
            {
                return 0;
            }
        }
    }
}
