﻿using System.Collections.Generic;
using System.Web.Routing;
using Nop.Core.Plugins;
using Nop.Services.Cms;
using Nop.Services.Common;
using Nop.Services.Localization;
using Nop.Services.Security;
using ShopFast.Plugin.Misc.Core.Services;

namespace ShopFast.Plugin.Misc.QuickCheckout
{
    public class QuickCheckoutPlugin : BasePlugin, IMiscPlugin, IWidgetPlugin
    {
        #region Fields
        


        #endregion

        #region Ctor

        public QuickCheckoutPlugin()
        {

        }

        #endregion

        #region Methods

        public static void SetDefaultSettings()
        {
            foreach (var localeResource in GetLocaleResources())
            {
                ITPLocalizationService.AddOrUpdateLocaleResource(localeResource.Key, localeResource.Value);
            }
        }

        private static Dictionary<string, string> GetLocaleResources()
        {
            return new Dictionary<string, string>()
            {
                { "ShopFast.Plugins.Misc.QuickCheckout.NewAddress", "Add new address" },
                { "ShopFast.Plugins.Misc.QuickCheckout.ExistingShippingAddresses.Hint","Select an address" },
                { "ShopFast.Plugins.Misc.QuickCheckout.ExistingBillingAddresses.Hint", "Select an address" },
                { "ShopFast.Plugins.Misc.QuickCheckout.CartIsEmpty", "Your cart is empty" },
                { "ShopFast.Plugins.Misc.QuickCheckout.AnonymousNotAllowed", "Anonymous checkout is not allowed" },
                { "ShopFast.Plugins.Misc.QuickCheckout.PaymentMethodNotSelected", "Payment method is not selected" },
                { "ShopFast.Plugins.Misc.QuickCheckout.IncorrectPaymentInfo", "Payment information is not entered correctly" },
                { "ShopFast.Plugins.Misc.QuickCheckout.NotEnteredPaymentInfo", "Payment information is not entered" },
                { "ShopFast.Plugins.Misc.QuickCheckout.ExistingBillingAddresses", "Billing Addresses" },
                { "ShopFast.Plugins.Misc.QuickCheckout.ExistingShippingAddresses", "Shipping Addresses" },
                { "ShopFast.Plugins.Misc.QuickCheckout.UseDifferentAddressForBilling", "Use Different Address for Billing" },
                { "ShopFast.Plugins.Misc.QuickCheckout.UseDifferentAddressForShipping", "Use Different Address for Shipping" },
                { "ShopFast.Plugins.Misc.QuickCheckout.ShippingOption", "Shipping Option" },
                { "ShopFast.Plugins.Misc.QuickCheckout.PaymentMethod", "Payment Method" },
                { "ShopFast.Plugins.Misc.QuickCheckout.CustomerComment", "Comment" },
                { "ShopFast.Plugins.Misc.QuickCheckout.Guest.MessageForLogin", "Authorization" },
                { "ShopFast.Plugins.Misc.QuickCheckout.Order.RequiresCheckout", "Payment is required" },
                { "ShopFast.Plugins.Misc.QuickCheckout.Order.NotRequiresCheckout", "Payment is not required" },
                { "ShopFast.Plugins.Misc.QuickCheckout.ProcessCheckout", "Make a Payment" },
                { "ShopFast.Plugins.Misc.QuickCheckout.MakeMultipleInvoicePayment", "Pay Multiple Invoices" },
                { "ShopFast.Plugins.Misc.QuickCheckout.SubmitPayment", "Submit Payment" },
                { "ShopFast.Plugins.Misc.QuickCheckout.PayNow", "Pay Now" },
                { "ShopFast.Plugins.Misc.QuickCheckout.FullPayment", "Full Payment" },
                { "ShopFast.Plugins.Misc.QuickCheckout.Partial", "Partial Payment"},
                { "ShopFast.Plugins.Misc.QuickCheckout.Amount", "Amount" },
                { "ShopFast.Plugins.Misc.QuickCheckout.RemainingBalance", "Remaining Balance" },
                { "ShopFast.Plugins.Misc.QuickCheckout.Apply", "Apply" },
                { "ShopFast.Plugins.Misc.QuickCheckout.SearchOrder.OrderNotFound", "Invoice not found" },
                { "ShopFast.Plugins.Misc.QuickCheckout.SearchOrder.IncorrectDate", "Incorrect date" },
                { "ShopFast.Plugins.Misc.QuickCheckout.SearchOrder.IncorrectAmount", "Incorrect amount" },
                { "ShopFast.Plugins.Misc.QuickCheckout.SearchOrder.InvoiceNumber", "Invoice Number" },
                { "ShopFast.Plugins.Misc.QuickCheckout.SearchOrder.InvoiceAmount", "Invoice Amount" },
                { "ShopFast.Plugins.Misc.Core.AmountPaid", "Amount Paid" },
                { "ShopFast.Plugins.Misc.Core.AmountToPay", "Amount to Pay"},
                { "Shopfast.Plugins.Misc.QuickCheckout.DefaultSettings", "Default Settings" }
            };
        }

        public override void Install()
        {
            SetDefaultSettings();
            //ITPLocalizationService.AddOrUpdateLocaleResource("ShopFast.Plugins.Misc.QuickCheckout.", "");
            base.Install();
        }

        public override void Uninstall()
        {
            foreach (var localeResource in GetLocaleResources())
            {
                this.DeletePluginLocaleResource(localeResource.Key);
            }

            base.Uninstall();
        }

        /// <summary>
        /// Gets a route for provider configuration
        /// </summary>
        /// <param name="actionName">Action name</param>
        /// <param name="controllerName">Controller name</param>
        /// <param name="routeValues">Route values</param>
        public void GetConfigurationRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "Configure";
            controllerName = "QuickCheckout";
            routeValues = new RouteValueDictionary
            {
                { "Namespaces", "ShopFast.Plugin.Misc.QuickCheckout.Controllers" }, 
                { "area", null } 
            };
        }

        /// <summary>
        /// Gets widget zones where this widget should be rendered
        /// </summary>
        /// <returns>Widget zones</returns>
        public IList<string> GetWidgetZones()
        {
            return new List<string>
            { 
                "orderdetails_page_afterproducts"
            };
        }

        /// <summary>
        /// Gets a route for displaying widget
        /// </summary>
        /// <param name="widgetZone">Widget zone where it's displayed</param>
        /// <param name="actionName">Action name</param>
        /// <param name="controllerName">Controller name</param>
        /// <param name="routeValues">Route values</param>
        public void GetDisplayWidgetRoute(string widgetZone, out string actionName, out string controllerName, 
            out RouteValueDictionary routeValues)
        {
            actionName = "PublicInfo";
            controllerName = "QuickCheckout";
            routeValues = new RouteValueDictionary
            {
                {"Namespaces", "ShopFast.Plugin.Misc.QuickCheckout.Controllers"},
                {"area", null},
                {"widgetZone", widgetZone}
            };
        }

        #endregion
    }
}
