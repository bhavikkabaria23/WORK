using System;
using System.Collections.Generic;
using Nop.Core;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Localization;
using Nop.Core.Domain.Payments;

namespace ShopFast.Plugin.Misc.Core.Domain
{
    /// <summary>
    /// Represents a payment operation type
    /// </summary>
    public enum InvoiceType
    {
        /// <summary>
        /// Invoice
        /// </summary>
        Invoice = 10,
        /// <summary>
        /// Estimate
        /// </summary>
        Estimate = 20,
        /// <summary>
        /// Recurring Invoice
        /// </summary>
        RecurringInvoice = 30,
        /// <summary>
        /// Payment
        /// </summary>
        Payment = 40
    }
}
