﻿using System.Web.Mvc;
using System.Web.Routing;
using Nop.Web.Framework.Mvc.Routes;
using System.Web.Http;

namespace ShopFast.Plugin.Misc.Core
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(RouteCollection routes)
        {
            routes.MapRoute("Shopfast.Plugin.Misc.Core.API.GetRewardPointsBalance",
                           "Plugins/API/GetRewardPointsBalance/{id}",
                           new { controller = "ShopFastApi", action = "GetRewardPointsBalance" },
                           new { id = @"\d+" },
                           new[] { "Shopfast.Plugin.Misc.Core.Controllers" }
                      );



        }

        public int Priority
        {
            get
            {
                return 0;
            }
        }
    }
}
