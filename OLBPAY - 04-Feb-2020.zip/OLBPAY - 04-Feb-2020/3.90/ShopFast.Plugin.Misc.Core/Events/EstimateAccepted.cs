using Nop.Core;
using Nop.Core.Domain.Orders;

namespace ShopFast.Plugin.Misc.Core.Events
{
    /// <summary>
    /// A container for entities that have been inserted.
    /// </summary>
    public class EstimateAccepted : BaseEntity
    {
        public EstimateAccepted(Order invoice)
        {
            this.Entity = invoice;
        }

        public Order Entity { get; set; }
    }
}
