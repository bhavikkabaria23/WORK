using Nop.Core;
using Nop.Core.Domain.Orders;

namespace ShopFast.Plugin.Misc.Core.Events
{
    /// <summary>
    /// A container for entities that have been inserted.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class ITPEntityImported<T> where T : BaseEntity
    {
        public ITPEntityImported(T entity)
        {
            this.Entity = entity;
        }

        public T Entity { get; private set; }
    }
}
