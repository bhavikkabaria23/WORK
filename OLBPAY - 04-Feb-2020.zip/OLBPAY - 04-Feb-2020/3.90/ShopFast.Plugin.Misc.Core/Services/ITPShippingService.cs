﻿using System;
using Nop.Core;
using Nop.Core.Caching;
using Nop.Core.Data;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Shipping;
using Nop.Core.Plugins;
using Nop.Services.Catalog;
using Nop.Services.Common;
using Nop.Services.Events;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Orders;
using Nop.Services.Shipping;

namespace ShopFast.Plugin.Misc.Core.Services
{
    public class ITPShippingService : ShippingService
    {
        private readonly WeightAttributeParser _productWeightAttributeParser;
        private readonly WeightProductTemplateService _productWeightTemplateService;
        public ITPShippingService(IRepository<ShippingMethod> shippingMethodRepository, IRepository<Warehouse> warehouseRepository, 
            ILogger logger, IProductService productService, IProductAttributeParser productAttributeParser, ICheckoutAttributeParser checkoutAttributeParser, 
            IGenericAttributeService genericAttributeService, ILocalizationService localizationService, IAddressService addressService, ShippingSettings shippingSettings, 
            IPluginFinder pluginFinder, IStoreContext storeContext, IEventPublisher eventPublisher, ShoppingCartSettings shoppingCartSettings, ICacheManager cacheManager,
            WeightAttributeParser productWeightAttributeParser, WeightProductTemplateService productWeightTemplateService)
            : base(shippingMethodRepository, warehouseRepository, logger, productService, productAttributeParser, checkoutAttributeParser, genericAttributeService, localizationService, addressService, shippingSettings, pluginFinder, storeContext, eventPublisher, shoppingCartSettings, cacheManager)
        {
            _productWeightAttributeParser = productWeightAttributeParser;
            _productWeightTemplateService = productWeightTemplateService;
        }

        /// <summary>
        /// Gets shopping cart item weight (of one item)
        /// </summary>
        /// <param name="shoppingCartItem">Shopping cart item</param>
        /// <returns>Shopping cart item weight</returns>
        public override decimal GetShoppingCartItemWeight(ShoppingCartItem shoppingCartItem)
        {
            if (shoppingCartItem == null)
                throw new ArgumentNullException("shoppingCartItem");

            if (shoppingCartItem.Product == null)
                return decimal.Zero;
            if (_productWeightTemplateService.IsWeightProductTemplate(shoppingCartItem.Product.ProductTemplateId))
            {
                //validate required weight product attribute (whether they're entered)
                var value = _productWeightAttributeParser.ParseProductAttributeValue(shoppingCartItem.AttributesXml);
                decimal decimalValue;
                if (!decimal.TryParse(value, out decimalValue) || decimalValue <= 0)
                {
                    return base.GetShoppingCartItemWeight(shoppingCartItem);
                }

                return decimalValue;
            }
            return base.GetShoppingCartItemWeight(shoppingCartItem);
        }
    }
}
