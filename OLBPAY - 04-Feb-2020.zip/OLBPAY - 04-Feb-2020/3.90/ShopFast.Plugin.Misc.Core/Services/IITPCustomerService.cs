﻿using System;
using System.Collections.Generic;
using Nop.Core;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Localization;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Core.Domain.Shipping;
using Nop.Core.Infrastructure;
using Nop.Services.Customers;
using Nop.Services.Localization;
using Nop.Services.Orders;

namespace ShopFast.Plugin.Misc.Core.Services
{
    public interface IITPCustomerService : ICustomerService
    {
        IPagedList<Customer> GetFilteredCustomers(string filter = null,
            bool filterByEmail = false,
            bool filterByUsername = false,
            bool filterByFirstName = false,
            bool filterByLastName = false,
            //bool filterByDayOfBirth = false, 
            //bool filterByMonthOfBirth = false,
            bool filterByCompany = false,
            bool filterByPhone = false,
            bool filterByZipPostalCode = false,
            //bool loadOnlyWithShoppingCart = false,
            //ShoppingCartType? sct = null,
            int[] customerRoleIds = null,
            int pageIndex = 0, int pageSize = 2147483647);
    }
}
