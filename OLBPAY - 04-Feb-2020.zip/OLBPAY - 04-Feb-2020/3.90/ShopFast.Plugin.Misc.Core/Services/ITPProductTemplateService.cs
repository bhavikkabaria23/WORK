﻿using System;
using System.Collections.Generic;
using System.Linq;
using Nop.Core.Data;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Common;
using Nop.Services.Catalog;
using Nop.Services.Events;

namespace ShopFast.Plugin.Misc.Core.Services
{
    public class ITPProductTemplateService : ProductTemplateService
    {
        private readonly IRepository<ProductTemplate> _productTemplateRepository2;
        private readonly IRepository<GenericAttribute> _genericAttributeRepository;


        /// <summary>
        /// Ctor
        /// </summary>
        /// <param name="productTemplateRepository">Product template repository</param>
        public ITPProductTemplateService(IRepository<ProductTemplate> productTemplateRepository, IRepository<GenericAttribute> genericAttributeRepository, IEventPublisher eventPublisher)
            : base(productTemplateRepository, eventPublisher)
        {
            _productTemplateRepository2 = productTemplateRepository;
            _genericAttributeRepository = genericAttributeRepository;
        }


        /// <summary>
        /// Gets all product weight templates
        /// </summary>
        /// <returns>Product templates</returns>
        //public virtual IList<ProductTemplate> GetAllTemplatesByTypeId(string typeId)
        //{
        //    var query = from pt in _productTemplateRepository.Table
        //                join gar in _genericAttributeRepository.Table on pt.Id equals gar.EntityId 
        //                where gar.Value=typeId
        //                orderby pt.DisplayOrder
        //                select pt;

        //    //var weight = product.GetAttribute<decimal>(SystemCustomerAttributeNames.Weight);
        //    //weight -= decimalValue;
        //    //_genericAttributeService.SaveAttribute(product, SystemCustomerAttributeNames.Weight, weight);

        //    var templates = query.ToList();
        //    return templates;
        //}

        public virtual IList<ProductTemplate> GetAllTemplatesByViewPath(string viewPath)
        {
            var query = from pt in _productTemplateRepository2.Table
                        where pt.ViewPath.Contains(viewPath)
                        orderby pt.DisplayOrder
                        select pt;

            var templates = query.ToList();
            return templates;
        }

        /// <summary>
        /// check if it is product weight templates
        /// </summary>
        /// <returns>Product templates</returns>
        public virtual bool IsContainsViewPath(int productTemplateId, string viewPath)
        {
            IList<ProductTemplate> allWeightProductTemplates = GetAllTemplatesByViewPath(viewPath);
            if (allWeightProductTemplates != null)
            {
                var template = allWeightProductTemplates.FirstOrDefault(x => x.Id == productTemplateId);
                if (template != null)
                    return true;
            }
            return false;
        }
    }
}
