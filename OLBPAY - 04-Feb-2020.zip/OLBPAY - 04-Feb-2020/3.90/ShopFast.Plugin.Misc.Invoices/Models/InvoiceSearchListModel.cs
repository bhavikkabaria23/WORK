﻿using System.ComponentModel;
using System.Web.Mvc;
using Nop.Admin.Models.Orders;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;
using ShopFast.Plugin.Misc.Core.Domain;

namespace ShopFast.Plugin.Misc.Invoices.Models
{
    public class InvoiceSearchListModel : OrderListModel
    {
        public int InvoiceTypeId { get; set; }
        
        [DisplayName("First name")]
        [AllowHtml]
        public string CustomerFirstName { get; set; }

        [DisplayName("Last name")]
        [AllowHtml]
        public string CustomerLastName { get; set; }

        [DisplayName("Company")]
        [AllowHtml]
        public string Company { get; set; }

        //[NopResourceDisplayName("Admin.Orders.List.CustomerEmail")]
        [DisplayName("Phone number")]
        [AllowHtml]
        public string Phone { get; set; }

        public string InvoiceIds { get; set; }
        public int OrderStatusId { get; set; }
        public int PaymentStatusId { get; set; }


        public InvoiceType? InvoiceType
        {
            get { return InvoiceTypeId != 0 ? (InvoiceType?) InvoiceTypeId : null; }
            set { InvoiceTypeId = (int) value; }
        }

        protected string GetListRouteName()
        {
            return string.Format("ShopFast.Plugin.Misc.Invoices.{0}s", InvoiceType.ToString());
        }
    }
}
