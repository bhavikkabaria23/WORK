﻿using System.Security.Policy;
using Autofac;
using Nop.Core.Configuration;
using Nop.Core.Infrastructure;
using Nop.Core.Infrastructure.DependencyManagement;

namespace ShopFast.Plugin.Misc.Invoices
{
    public class DependencyRegistrar : IDependencyRegistrar
    {
        public void Register(ContainerBuilder builder, ITypeFinder typeFinder, NopConfig config)
        {
            //FilterProviders.Providers.Add(new FilterProvider());
        }
        public int Order => 1;
    }
}
