﻿using Nop.Services.Events;
using System;
using System.Collections.Generic;
using System.Text;
using Nop.Web.Framework.Events;
using Nop.Web.Framework.Models;
using Nop.Web.Models.Customer;
using Nop.Core.Infrastructure;
using Nop.Core.Data;

namespace Shopfast.Plugin.Custom.Events
{
    class CustomNavigationEvent : IConsumer<ModelPreparedEvent<BaseNopModel>>
    {
        public CustomNavigationEvent() { }
        public void HandleEvent(ModelPreparedEvent<BaseNopModel> eventMessage)
        {
            if (MultisiteHelper.IsAdminSite)
            {
                var _localizationService = EngineContext.Current.Resolve<Nop.Services.Localization.ILocalizationService>();
                if (eventMessage?.Model is CustomerNavigationModel customerNavigationModel)
                {
                    customerNavigationModel.CustomerNavigationItems.Add(new CustomerNavigationItemModel
                    {
                        RouteName = "PackageOrders",
                        Title = _localizationService.GetResource("Account.MyPlan"),
                        Tab = CustomerNavigationEnum.Orders,
                        ItemClass = "customer-plan"
                    });

                    customerNavigationModel.CustomerNavigationItems.Add(new CustomerNavigationItemModel
                    {
                        RouteName = "MerchantCards",
                        Title = _localizationService.GetResource("Account.MerchantCards"),
                        Tab = CustomerNavigationEnum.Info,
                        ItemClass = "customer-merchantcards"
                    });

                    customerNavigationModel.CustomerNavigationItems.Add(new CustomerNavigationItemModel
                    {
                        RouteName = "ResumeStore",
                        Title = _localizationService.GetResource("Account.ResumeStore"),
                        Tab = CustomerNavigationEnum.Info,
                        ItemClass = "customer-resumestore"
                    });
                }
            }
        }
    }
}
