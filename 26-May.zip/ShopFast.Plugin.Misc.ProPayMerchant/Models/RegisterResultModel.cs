﻿namespace ShopFast.Plugin.Misc.ProPayMerchant.Models
{
    public class RegisterResultModel
    {
        public string Result { get; set; }
    }
}
