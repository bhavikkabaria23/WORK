﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.Rendering;
using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;

namespace ShopFast.Plugin.Misc.ProPayMerchant.Models
{
    public class ConfigurationModel : BaseNopModel
    {
        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.CertString")]
        public string CertString { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.TermId")]
        public string TermId { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.DefaultAccountTier")]
        public string DefaultAccountTier { get; set; }
        public IList<SelectListItem> AvailableAccountTiers { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.AuthenticationToken")]
        public string AuthenticationToken { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.BillerAccountId")]
        public string BillerAccountId { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.JumioApiToken")]
        public string JumioApiToken { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.JumioApiSecret")]
        public string JumioApiSecret { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.PlaidClientId")]
        public string PlaidClientId { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.PlaidSecret")]
        public string PlaidSecret { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.PlaidPublicKey")]
        public string PlaidPublicKey { get; set; }

        public ConfigurationModel()
        {
            AvailableAccountTiers = new List<SelectListItem>();
        }
    }
}