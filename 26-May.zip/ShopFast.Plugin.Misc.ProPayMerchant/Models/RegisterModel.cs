﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;
using ShopFast.Plugin.Misc.ProPayMerchant.Dto.Crm;

namespace ShopFast.Plugin.Misc.ProPayMerchant.Models
{
    public partial class RegisterModel : BaseNopModel
    {
        // plaid config
        public string Environment { get; set; }
        public string PublicKey { get; set; }
        public string PlaidPublicToken { get; set; }
        public string PlaidInstitutionName { get; set; }

        // this gets set when a successful CRM record is created so that if propay fails
        // we know if we need to ignore creating a CRM record on the next request
        public string CrmMerchantBoardingId { get; set; }

        public CrmPricingData PricingTemplate { get; set; }


        ////////////////////
        // personal data
        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.PersonalFirstName")]
        public string FirstName { get; set; }

        //[NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.MiddleInitial")]
        //public string MiddleInitial { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.PersonalLastName")]
        public string LastName { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.PersonalDateOfBirth")]
        public DateTime? DateOfBirth { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.SocialSecurityNumber")]
        public string SocialSecurityNumber { get; set; }



        //[NopResourceDisplayName("Account.Fields.DateOfBirth")]
        //public int? DateOfBirthDay { get; set; }
        //[NopResourceDisplayName("Account.Fields.DateOfBirth")]
        //public int? DateOfBirthMonth { get; set; }
        //[NopResourceDisplayName("Account.Fields.DateOfBirth")]
        //public int? DateOfBirthYear { get; set; }

        // source email
        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.PersonalEmail")]
        public string Email { get; set; }

        [DataType(DataType.Password)]
        [NoTrim]
        [NopResourceDisplayName("Account.Fields.Password")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [NoTrim]
        [NopResourceDisplayName("Account.Fields.ConfirmPassword")]
        public string ConfirmPassword { get; set; }

        [DataType(DataType.PhoneNumber)]
        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.DaytimePhone")]
        public string DaytimePhone { get; set; }

        [DataType(DataType.PhoneNumber)]
        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.MobilePhone")]
        public string MobilePhone { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.PersonalStreetAddress")]
        public string StreetAddress { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.PersonalStreetAddress2")]
        public string StreetAddress2 { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.PersonalCity")]
        public string City { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.PersonalStateProvince")]
        public int StateProvinceId { get; set; }

        public IList<SelectListItem> AvailableStates { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.PersonalZipPostalCode")]
        public string ZipPostalCode { get; set; }

        // this field is used when the user is an owner/partner with 25% or more ownership
        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.HasSignificantOwnership")]
        public bool HasSignificantOwnership { get; set; }


        public IList<SelectListItem> AvailableCountries { get; set; }

        /////////////////////
        // business data
        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.BusinessLegalName")]
        public string BusinessLegalName { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.BusinessName")]
        public string BusinessName { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.EIN")]
        public string EIN { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.WebsiteUrl")]
        public string WebsiteUrl { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.BusinessDescription")]
        public string BusinessDescription { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.MonthlyBankCardVolume")]
        public long MonthlyBankCardVolume { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.AverageTicket")]
        public long AverageTicket { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.HighestTicket")]
        public long HighestTicket { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.BusinessNumberOfYears")]
        public int NumberOfYearsInBusiness { get; set; }

        // processing method percentages
        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.BusinessSwipedCardPresentPercent")]
        public decimal SwipedCardPresentPercent { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.BusinessKeyedCardPercent")]
        public decimal KeyedCardPercent { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.BusinessOnlineTransactionPercent")]
        public decimal OnlineTransactionPercent { get; set; }

        // MCCCode
        //[NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.BusinessCategory")]
        //public int BusinessCategory { get; set; }

        //public IList<SelectListItem> AvailableBusinessCategories { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.IsLegalAddressDifferentThanBusinessAddress")]
        public bool IsLegalAddressDifferentThanBusinessAddress { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.LegalEntityStreetAddress")]
        public string LegalEntityStreetAddress { get; set; }
        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.LegalEntityCity")]
        public string LegalEntityCity { get; set; }
        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.LegalEntityStateProvinceId")]
        public int LegalEntityStateProvinceId { get; set; }
        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.LegalEntityZip")]
        public string LegalEntityZip { get; set; }


        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.BusinessStreetAddress")]
        public string BusinessStreetAddress { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.BusinessStreetAddress2")]
        public string BusinessStreetAddress2 { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.BusinessCity")]
        public string BusinessCity { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.BusinessStateProvince")]
        public int BusinessStateProvinceId { get; set; }

        public IList<SelectListItem> BusinessAvailableStates { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.BusinessZipPostalCode")]
        public string BusinessZipPostalCode { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.BusinessEntityType")]
        public string BusinessEntityType { get; set; }
        public IList<SelectListItem> BusinessEntityTypes { get; set; }

        [DataType(DataType.PhoneNumber)]
        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.BusinessPhone")]
        public string BusinessPhone { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.UseFulfillmentHouse")]
        public bool UseFulfillmentHouse { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.FulfillmentCompanyName")]
        public string FulfillmentCompanyName { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.FulfillmentContactPhoneNumber")]
        public string FulfillmentContactPhoneNumber { get; set; }


        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.PercentageSoldToBusiness")]
        public decimal PercentageSoldToBusiness { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.PercentageSoldToPublic")]
        public decimal PercentageSoldToPublic { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.OwnProductInventory")]
        public bool OwnProductInventory { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.SoldAtLocations")]
        public IList<SelectListItem> SoldAtLocations { get; set; }

        //public bool SellLocally { get; set; }
        //public bool SellNationally { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.NumberOfChargebacksInLast12Months")]
        public int NumberOfChargebacksInLast12Months { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.AmountOfChargeBacksInLast12Months")]
        public decimal AmountOfChargeBacksInLast12Months { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.TimeCustomerIsCharged")]
        public string TimeCustomerIsCharged { get; set; }
        public IList<SelectListItem> TimeCustomerIsChargedItems { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.DaysToDeliverToCustomer")]
        public string DaysToDeliverToCustomer { get; set; }
        public IList<SelectListItem> DaysToDeliverToCustomerItems { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.RefundPolicy")]
        public string RefundPolicy { get; set; }



        ////////////////////
        // bank account data
        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.BankAccountId")]
        public string BankAccountId { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.AccountType")]
        public string BankAccountType { get; set; }
        public IList<SelectListItem> BankAccountTypes { get; set; }

        //public string AccountType { get; set; }
        //public IList<SelectListItem> AccountTypes { get; set; }

        //[NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.BankName")]
        //public string BankName { get; set; }

        //[NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.RoutingNumber")]
        //public string RoutingNumber { get; set; }

        //[NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.AccountNumber")]
        //public string AccountNumber { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.NameOnAccount")]
        public string NameOnAccount { get; set; }



        public bool AddSecondBeneficialOwner { get; set; }

        public IList<Owner> BeneficialOwners { get; set; }

        public IList<SelectListItem> AvailableTitles { get; set; }

        [NopResourceDisplayName("Plugins.Misc.ProPayMerchant.Fields.TermsAndConditionsAccepted")]
        public bool TermsAndConditionsAccepted { get; set; }

        public string JumioRedirectUrl { get; set; }

        // these have to be on the top level model not on the owner class
        // otherwise fluent validation throws errors
        public IFormFile BeneficialOwner1DriversLicense { get; set; }

        public IFormFile BeneficialOwner2DriversLicense { get; set; }

        public IFormFile BusinessProcessingStatement { get; set; }

        public bool JumioSuccess { get; set; }
        public string JumioTransactionReference { get; set; }



        public RegisterModel()
        {
            //AvailableBusinessCategories = new List<SelectListItem>();
            AvailableStates = new List<SelectListItem>();
            AvailableCountries = new List<SelectListItem>();
            BankAccountTypes = new List<SelectListItem>();
            //AccountTypes = new List<SelectListItem>();
            BeneficialOwners = new List<Owner>();
        }

        public class Owner
        {
            public string Title { get; set; }

            [NopResourceDisplayName("Account.Fields.FirstName")]
            public string FirstName { get; set; }

            [NopResourceDisplayName("Account.Fields.LastName")]
            public string LastName { get; set; }

            [NopResourceDisplayName("Account.Fields.Email")]
            public string Email { get; set; }

            [NopResourceDisplayName("Account.Fields.DateOfBirth")]
            public DateTime? OwnerDateOfBirth { get; set; }

            [NopResourceDisplayName("Account.Fields.StreetAddress")]
            public string Address { get; set; }

            public int? Percentage { get; set; }

            public string SSN { get; set; }

            [NopResourceDisplayName("Account.Fields.City")]
            public string City { get; set; }

            [NopResourceDisplayName("Account.Fields.StateProvince")]
            public int StateProvinceId { get; set; }

            public IList<SelectListItem> AvailableStates { get; set; }

            [NopResourceDisplayName("Account.Fields.ZipPostalCode")]
            public string ZipPostalCode { get; set; }

            [NopResourceDisplayName("Account.Fields.Country")]
            public int CountryId { get; set; }

            public IList<SelectListItem> AvailableCountries { get; set; }


        }
    }
}