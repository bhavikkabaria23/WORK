﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace ShopFast.Plugin.Misc.ProPayMerchant.Dto.Plaid
{
    public partial class Account
    {
        [JsonProperty("account_id")]
        public string AccountId { get; set; }

        [JsonProperty("balances")]
        public Balances Balances { get; set; }

        [JsonProperty("mask")]
        public string Mask { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("official_name")]
        public string OfficialName { get; set; }

        [JsonProperty("owners")]
        public List<Owner> Owners { get; set; }

        [JsonProperty("subtype")]
        public string Subtype { get; set; }

        [JsonProperty("type")]
        public string Type { get; set; }
    }
}