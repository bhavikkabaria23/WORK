﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace ShopFast.Plugin.Misc.ProPayMerchant.Dto.Plaid
{

    public partial class PlaidAuthResponse
    {
        [JsonProperty("accounts")]
        public List<Account> Accounts { get; set; }

        [JsonProperty("numbers")]
        public Numbers Numbers { get; set; }

        [JsonProperty("item")]
        public Item Item { get; set; }

        [JsonProperty("request_id")]
        public string RequestId { get; set; }
    }

    public partial class Item
    {
    }

    public partial class Numbers
    {
        [JsonProperty("ach")]
        public List<Ach> Ach { get; set; }

        [JsonProperty("eft")]
        public List<Eft> Eft { get; set; }

        [JsonProperty("international")]
        public List<International> International { get; set; }

        [JsonProperty("bacs")]
        public List<Bac> Bacs { get; set; }
    }

    public partial class Ach
    {
        [JsonProperty("account")]
        public string Account { get; set; }

        [JsonProperty("account_id")]
        public string AccountId { get; set; }

        [JsonProperty("routing")]
        public string Routing { get; set; }

        [JsonProperty("wire_routing")]
        public string WireRouting { get; set; }
    }

    public partial class Bac
    {
        [JsonProperty("account")]
        public long Account { get; set; }

        [JsonProperty("account_id")]
        public string AccountId { get; set; }

        [JsonProperty("sort_code")]
        public long SortCode { get; set; }
    }

    public partial class Eft
    {
        [JsonProperty("account")]
        public string Account { get; set; }

        [JsonProperty("account_id")]
        public string AccountId { get; set; }

        [JsonProperty("institution")]
        public string Institution { get; set; }

        [JsonProperty("branch")]
        public string Branch { get; set; }
    }

    public partial class International
    {
        [JsonProperty("account_id")]
        public string AccountId { get; set; }

        [JsonProperty("bic")]
        public string Bic { get; set; }

        [JsonProperty("iban")]
        public string Iban { get; set; }
    }
}
