﻿using Newtonsoft.Json;

namespace ShopFast.Plugin.Misc.ProPayMerchant.Dto.Plaid
{
    public partial class Balances
    {
        [JsonProperty("available")]
        public long? Available { get; set; }

        [JsonProperty("current")]
        public double Current { get; set; }

        [JsonProperty("iso_currency_code")]
        public string IsoCurrencyCode { get; set; }

        [JsonProperty("limit")]
        public long? Limit { get; set; }

        [JsonProperty("unofficial_currency_code")]
        public object UnofficialCurrencyCode { get; set; }
    }
}