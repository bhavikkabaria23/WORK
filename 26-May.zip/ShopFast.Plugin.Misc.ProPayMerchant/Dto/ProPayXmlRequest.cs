﻿using System.Xml.Serialization;

namespace ShopFast.Plugin.Misc.ProPayMerchant.Dto
{
    [XmlRoot(ElementName = "XMLTrans")]
    public class XmlTrans
    {
        [XmlElement(ElementName = "transType")]
        public string TransType { get; set; }
        [XmlElement(ElementName = "tier")]
        public string Tier { get; set; }
        [XmlElement(ElementName = "userId")]
        public string UserId { get; set; }
        [XmlElement(ElementName = "phonePin")]
        public string PhonePin { get; set; }
        [XmlElement(ElementName = "externalId")]
        public string ExternalId { get; set; }
        [XmlElement(ElementName = "firstName")]
        public string FirstName { get; set; }
        [XmlElement(ElementName = "mInitial")]
        public string MInitial { get; set; }
        [XmlElement(ElementName = "lastName")]
        public string LastName { get; set; }
        [XmlElement(ElementName = "dob")]
        public string Dob { get; set; }
        [XmlElement(ElementName = "ssn")]
        public string Ssn { get; set; }
        [XmlElement(ElementName = "sourceEmail")]
        public string SourceEmail { get; set; }
        [XmlElement(ElementName = "dayPhone")]
        public string DayPhone { get; set; }
        [XmlElement(ElementName = "evenPhone")]
        public string EvenPhone { get; set; }
        [XmlElement(ElementName = "NotificationEmail")]
        public string NotificationEmail { get; set; }
        [XmlElement(ElementName = "currencyCode")]
        public string CurrencyCode { get; set; }
        [XmlElement(ElementName = "addr")]
        public string Addr { get; set; }
        [XmlElement(ElementName = "aptNum")]
        public string AptNum { get; set; }
        [XmlElement(ElementName = "city")]
        public string City { get; set; }
        [XmlElement(ElementName = "state")]
        public string State { get; set; }
        [XmlElement(ElementName = "zip")]
        public string Zip { get; set; }
        [XmlElement(ElementName = "country")]
        public string Country { get; set; }
        [XmlElement(ElementName = "AccountOwnershipType")]
        public string AccountOwnershipType { get; set; }
        [XmlElement(ElementName = "accountType")]
        public string AccountType { get; set; }
        [XmlElement(ElementName = "BankName")]
        public string BankName { get; set; }
        [XmlElement(ElementName = "RoutingNumber")]
        public string RoutingNumber { get; set; }
        [XmlElement(ElementName = "AccountNumber")]
        public string AccountNumber { get; set; }
        [XmlElement(ElementName = "accountName")]
        public string AccountName { get; set; }
        [XmlElement(ElementName = "BusinessLegalName")]
        public string BusinessLegalName { get; set; }
        [XmlElement(ElementName = "DoingBusinessAs")]
        public string DoingBusinessAs { get; set; }
        [XmlElement(ElementName = "EIN")]
        public string EIN { get; set; }
        [XmlElement(ElementName = "MCCCode")]
        public string MCCCode { get; set; }
        [XmlElement(ElementName = "WebsiteURL")]
        public string WebsiteURL { get; set; }
        [XmlElement(ElementName = "BusinessDesc")]
        public string BusinessDesc { get; set; }
        [XmlElement(ElementName = "MonthlyBankCardVolume")]
        public string MonthlyBankCardVolume { get; set; }
        [XmlElement(ElementName = "AverageTicket")]
        public string AverageTicket { get; set; }
        [XmlElement(ElementName = "HighestTicket")]
        public string HighestTicket { get; set; }
        [XmlElement(ElementName = "BusinessAddress")]
        public string BusinessAddress { get; set; }
        [XmlElement(ElementName = "BusinessAddress2")]
        public string BusinessAddress2 { get; set; }
        [XmlElement(ElementName = "BusinessCity")]
        public string BusinessCity { get; set; }
        [XmlElement(ElementName = "BusinessCountry")]
        public string BusinessCountry { get; set; }
        [XmlElement(ElementName = "BusinessState")]
        public string BusinessState { get; set; }
        [XmlElement(ElementName = "BusinessZip")]
        public string BusinessZip { get; set; }
        [XmlElement(ElementName = "BeneficialOwnerData")]
        public BeneficialOwnerData BeneficialOwnerData { get; set; }
    }

    [XmlRoot(ElementName = "Owner")]
    public class Owner
    {
        [XmlElement(ElementName = "FirstName")]
        public string FirstName { get; set; }
        [XmlElement(ElementName = "LastName")]
        public string LastName { get; set; }
        [XmlElement(ElementName = "Title")]
        public string Title { get; set; }
        [XmlElement(ElementName = "Address")]
        public string Address { get; set; }
        [XmlElement(ElementName = "Percentage")]
        public string Percentage { get; set; }
        [XmlElement(ElementName = "SSN")]
        public string SSN { get; set; }
        [XmlElement(ElementName = "Country")]
        public string Country { get; set; }
        [XmlElement(ElementName = "State")]
        public string State { get; set; }
        [XmlElement(ElementName = "City")]
        public string City { get; set; }
        [XmlElement(ElementName = "Zip")]
        public string Zip { get; set; }
        [XmlElement(ElementName = "Email")]
        public string Email { get; set; }
        [XmlElement(ElementName = "DateOfBirth")]
        public string DateOfBirth { get; set; }
    }

    [XmlRoot(ElementName = "Owners")]
    public class Owners
    {
        [XmlElement(ElementName = "Owner")]
        public Owner Owner { get; set; }
    }

    [XmlRoot(ElementName = "BeneficialOwnerData")]
    public class BeneficialOwnerData
    {
        [XmlElement(ElementName = "OwnerCount")]
        public string OwnerCount { get; set; }
        [XmlElement(ElementName = "Owners")]
        public Owners Owners { get; set; }
    }

    [XmlRoot(ElementName = "XMLRequest")]
    public class ProPayXmlRequest
    {
        [XmlElement(ElementName = "certStr")]
        public string CertStr { get; set; }
        [XmlElement(ElementName = "termid")]
        public string Termid { get; set; }
        [XmlElement(ElementName = "class")]
        public string Class { get; set; }
        [XmlElement(ElementName = "XMLTrans")]
        public XmlTrans XMLTrans { get; set; }
    }
}
