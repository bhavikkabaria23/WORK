﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace ShopFast.Plugin.Misc.ProPayMerchant.Dto.Crm
{
    public partial class CrmPricingResponse
    {
        [JsonProperty("@odata.context")]
        public Uri OdataContext { get; set; }

        [JsonProperty("value")]
        public List<CrmPricingData> CrmPricingData { get; set; }
    }

    public partial class CrmPricingData
    {
        [JsonProperty("@odata.etag")]
        public string OdataEtag { get; set; }

        [JsonProperty("new_merlinkchargebackbool")]
        public bool NewMerlinkchargebackbool { get; set; }

        [JsonProperty("new_achmonthlyfees_base")]
        public long NewAchmonthlyfeesBase { get; set; }

        [JsonProperty("new_visamcdistiered2")]
        public double NewVisamcdistiered2 { get; set; }

        [JsonProperty("_owningbusinessunit_value")]
        public Guid OwningbusinessunitValue { get; set; }

        [JsonProperty("new_achdiscountrate")]
        public double NewAchdiscountrate { get; set; }

        [JsonProperty("new_achperitem")]
        public double NewAchperitem { get; set; }

        [JsonProperty("new_visamcdisaxpmidqual")]
        public long NewVisamcdisaxpmidqual { get; set; }

        [JsonProperty("new_continuingpersonalguarantyprovision")]
        public string NewContinuingpersonalguarantyprovision { get; set; }

        [JsonProperty("new_name")]
        public string NewName { get; set; }

        [JsonProperty("new_certificationofbeneficialowners")]
        public string NewCertificationofbeneficialowners { get; set; }

        [JsonProperty("createdon")]
        public DateTimeOffset Createdon { get; set; }

        [JsonProperty("new_monthlyminimum_base")]
        public long NewMonthlyminimumBase { get; set; }

        [JsonProperty("new_achstoppaymentcustomercancelationfee_base")]
        public long NewAchstoppaymentcustomercancelationfeeBase { get; set; }

        [JsonProperty("new_authfee_base")]
        public double NewAuthfeeBase { get; set; }

        [JsonProperty("new_chargebackperchargeback_base")]
        public long NewChargebackperchargebackBase { get; set; }

        [JsonProperty("statecode")]
        public long Statecode { get; set; }

        [JsonProperty("new_achreturnfees")]
        public long NewAchreturnfees { get; set; }

        [JsonProperty("overriddencreatedon")]
        public DateTimeOffset Overriddencreatedon { get; set; }

        [JsonProperty("new_merchantapplicationandagreementacceptance")]
        public string NewMerchantapplicationandagreementacceptance { get; set; }

        [JsonProperty("new_monthlyminimum")]
        public long NewMonthlyminimum { get; set; }

        [JsonProperty("_transactioncurrencyid_value")]
        public Guid TransactioncurrencyidValue { get; set; }

        [JsonProperty("new_batchsettlementfee_base")]
        public long NewBatchsettlementfeeBase { get; set; }

        [JsonProperty("_ownerid_value")]
        public Guid OwneridValue { get; set; }

        [JsonProperty("new_axppassthruicplus")]
        public double NewAxppassthruicplus { get; set; }

        [JsonProperty("modifiedon")]
        public DateTimeOffset Modifiedon { get; set; }

        [JsonProperty("new_transfee_base")]
        public long NewTransfeeBase { get; set; }

        [JsonProperty("new_bankformattemplate")]
        public string NewBankformattemplate { get; set; }

        [JsonProperty("new_monthlymanagfee_base")]
        public long NewMonthlymanagfeeBase { get; set; }

        [JsonProperty("new_avsfeeaddressverificationservice_base")]
        public double NewAvsfeeaddressverificationserviceBase { get; set; }

        [JsonProperty("new_achsetupfees")]
        public long NewAchsetupfees { get; set; }

        [JsonProperty("versionnumber")]
        public long Versionnumber { get; set; }

        [JsonProperty("new_avsfeeaddressverificationservice")]
        public double NewAvsfeeaddressverificationservice { get; set; }

        [JsonProperty("new_perachrejectfee")]
        public long NewPerachrejectfee { get; set; }

        [JsonProperty("new_achsetupfees_base")]
        public long NewAchsetupfeesBase { get; set; }

        [JsonProperty("exchangerate")]
        public long Exchangerate { get; set; }

        [JsonProperty("new_monthlywirelessmobilefee")]
        public long NewMonthlywirelessmobilefee { get; set; }

        [JsonProperty("new_transfee")]
        public long NewTransfee { get; set; }

        [JsonProperty("_modifiedby_value")]
        public Guid ModifiedbyValue { get; set; }

        [JsonProperty("new_achmonthlyfees")]
        public long NewAchmonthlyfees { get; set; }

        [JsonProperty("new_monthlymanagfee")]
        public long NewMonthlymanagfee { get; set; }

        [JsonProperty("new_achstoppaymentcustomercancelationfee")]
        public long NewAchstoppaymentcustomercancelationfee { get; set; }

        [JsonProperty("statuscode")]
        public long Statuscode { get; set; }

        [JsonProperty("new_authfee")]
        public double NewAuthfee { get; set; }

        [JsonProperty("new_visamcdistiered1")]
        public double NewVisamcdistiered1 { get; set; }

        [JsonProperty("new_visamcdisaxpnonqual")]
        public long NewVisamcdisaxpnonqual { get; set; }

        [JsonProperty("new_perachrejectfee_base")]
        public long NewPerachrejectfeeBase { get; set; }

        [JsonProperty("new_batchsettlementfee")]
        public long NewBatchsettlementfee { get; set; }

        [JsonProperty("_createdby_value")]
        public Guid CreatedbyValue { get; set; }

        [JsonProperty("new_chargebackperchargeback")]
        public long NewChargebackperchargeback { get; set; }

        [JsonProperty("_owninguser_value")]
        public Guid OwninguserValue { get; set; }

        [JsonProperty("new_achperitem_base")]
        public double NewAchperitemBase { get; set; }

        [JsonProperty("new_achreturnfees_base")]
        public long NewAchreturnfeesBase { get; set; }

        [JsonProperty("new_banktemplateid")]
        public Guid NewBanktemplateid { get; set; }

        [JsonProperty("new_feedisclosures")]
        public string NewFeedisclosures { get; set; }

        [JsonProperty("new_monthlywirelessmobilefee_base")]
        public long NewMonthlywirelessmobilefeeBase { get; set; }

        [JsonProperty("new_gatewaysetupfee")]
        public object NewGatewaysetupfee { get; set; }

        [JsonProperty("new_government_compliance_fee_base")]
        public object NewGovernmentComplianceFeeBase { get; set; }

        [JsonProperty("new_monthlypcifee")]
        public object NewMonthlypcifee { get; set; }

        [JsonProperty("new_applicationfee")]
        public object NewApplicationfee { get; set; }

        [JsonProperty("new_wirelessmobilepertransfee")]
        public object NewWirelessmobilepertransfee { get; set; }

        [JsonProperty("new_excessivehelpdeskcalls_base")]
        public object NewExcessivehelpdeskcallsBase { get; set; }

        [JsonProperty("new_chargebackreversalsperreversal")]
        public object NewChargebackreversalsperreversal { get; set; }

        [JsonProperty("_owningteam_value")]
        public object OwningteamValue { get; set; }

        [JsonProperty("new_ebttransfee")]
        public object NewEbttransfee { get; set; }

        [JsonProperty("new_irsregulatoryfee")]
        public object NewIrsregulatoryfee { get; set; }

        [JsonProperty("new_chargebackretrievalperretrieval")]
        public object NewChargebackretrievalperretrieval { get; set; }

        [JsonProperty("new_wirelessmobilesetupfee")]
        public object NewWirelessmobilesetupfee { get; set; }

        [JsonProperty("new_ebtstatementfee_base")]
        public object NewEbtstatementfeeBase { get; set; }

        [JsonProperty("new_achservicefees")]
        public object NewAchservicefees { get; set; }

        [JsonProperty("new_pindebittransactionfee_base")]
        public object NewPindebittransactionfeeBase { get; set; }

        [JsonProperty("new_opvoiceperauthfee_base")]
        public object NewOpvoiceperauthfeeBase { get; set; }

        [JsonProperty("new_chargebackretrievalperretrievaltype_base")]
        public object NewChargebackretrievalperretrievaltypeBase { get; set; }

        [JsonProperty("new_ensurebillsetupfee_base")]
        public object NewEnsurebillsetupfeeBase { get; set; }

        [JsonProperty("new_nonpcicompliancefee")]
        public object NewNonpcicompliancefee { get; set; }

        [JsonProperty("new_voiceperauthfee")]
        public object NewVoiceperauthfee { get; set; }

        [JsonProperty("new_ensurebillsetupfee")]
        public object NewEnsurebillsetupfee { get; set; }

        [JsonProperty("new_chargebackprearbitrationprearbitration_base")]
        public object NewChargebackprearbitrationprearbitrationBase { get; set; }

        [JsonProperty("new_nonpcicompliancefee_base")]
        public object NewNonpcicompliancefeeBase { get; set; }

        [JsonProperty("new_chargebackprearbitrationprearbitration")]
        public object NewChargebackprearbitrationprearbitration { get; set; }

        [JsonProperty("timezoneruleversionnumber")]
        public object Timezoneruleversionnumber { get; set; }

        [JsonProperty("new_amextransactionfee")]
        public object NewAmextransactionfee { get; set; }

        [JsonProperty("new_gatewaypertransfee")]
        public object NewGatewaypertransfee { get; set; }

        [JsonProperty("new_monthlycustomersvsfee_base")]
        public object NewMonthlycustomersvsfeeBase { get; set; }

        [JsonProperty("new_emvresidencyfee_base")]
        public object NewEmvresidencyfeeBase { get; set; }

        [JsonProperty("new_visafixedacquirernetworkfeefanf")]
        public object NewVisafixedacquirernetworkfeefanf { get; set; }

        [JsonProperty("new_tinmismatchfee_base")]
        public object NewTinmismatchfeeBase { get; set; }

        [JsonProperty("new_otherfee")]
        public object NewOtherfee { get; set; }

        [JsonProperty("new_irsregulatoryfee_base")]
        public object NewIrsregulatoryfeeBase { get; set; }

        [JsonProperty("new_ensurebillmonthlyfee_base")]
        public object NewEnsurebillmonthlyfeeBase { get; set; }

        [JsonProperty("new_onlineservicefee_base")]
        public object NewOnlineservicefeeBase { get; set; }

        [JsonProperty("new_gatewaymonthlyfee")]
        public object NewGatewaymonthlyfee { get; set; }

        [JsonProperty("new_emvresidencyfee")]
        public object NewEmvresidencyfee { get; set; }

        [JsonProperty("new_gatewaypertransfee_base")]
        public object NewGatewaypertransfeeBase { get; set; }

        [JsonProperty("new_merchantonlineportalreporting")]
        public object NewMerchantonlineportalreporting { get; set; }

        [JsonProperty("new_amextransactionfee_base")]
        public object NewAmextransactionfeeBase { get; set; }

        [JsonProperty("new_tinmismatchfee")]
        public object NewTinmismatchfee { get; set; }

        [JsonProperty("_createdonbehalfby_value")]
        public object CreatedonbehalfbyValue { get; set; }

        [JsonProperty("new_multipasspertransfee_base")]
        public object NewMultipasspertransfeeBase { get; set; }

        [JsonProperty("new_chargebackretrievalperretrieval_base")]
        public object NewChargebackretrievalperretrievalBase { get; set; }

        [JsonProperty("new_passthrufee")]
        public object NewPassthrufee { get; set; }

        [JsonProperty("new_visamcdispassthru1")]
        public object NewVisamcdispassthru1 { get; set; }

        [JsonProperty("importsequencenumber")]
        public object Importsequencenumber { get; set; }

        [JsonProperty("new_merchantonlineportalreporting_base")]
        public object NewMerchantonlineportalreportingBase { get; set; }

        [JsonProperty("new_ensurebillmonthlyfee")]
        public object NewEnsurebillmonthlyfee { get; set; }

        [JsonProperty("new_visafixedacquirernetworkfeefanf_base")]
        public object NewVisafixedacquirernetworkfeefanfBase { get; set; }

        [JsonProperty("new_achservicefees_base")]
        public object NewAchservicefeesBase { get; set; }

        [JsonProperty("new_annualfee")]
        public object NewAnnualfee { get; set; }

        [JsonProperty("new_visamcdiscovertransactionfee_base")]
        public object NewVisamcdiscovertransactionfeeBase { get; set; }

        [JsonProperty("new_ebtstatementfee")]
        public object NewEbtstatementfee { get; set; }

        [JsonProperty("_modifiedonbehalfby_value")]
        public object ModifiedonbehalfbyValue { get; set; }

        [JsonProperty("new_otherfee_base")]
        public object NewOtherfeeBase { get; set; }

        [JsonProperty("new_annualfee_base")]
        public object NewAnnualfeeBase { get; set; }

        [JsonProperty("new_earlyterminationfee")]
        public object NewEarlyterminationfee { get; set; }

        [JsonProperty("new_onlineservicefee")]
        public object NewOnlineservicefee { get; set; }

        [JsonProperty("new_emvtransactionperdevice_base")]
        public object NewEmvtransactionperdeviceBase { get; set; }

        [JsonProperty("new_gatewaymonthlyfee_base")]
        public object NewGatewaymonthlyfeeBase { get; set; }

        [JsonProperty("new_ensurebillupdateperitemfee")]
        public object NewEnsurebillupdateperitemfee { get; set; }

        [JsonProperty("new_pindebittransactionfee")]
        public object NewPindebittransactionfee { get; set; }

        [JsonProperty("new_government_compliance_fee")]
        public object NewGovernmentComplianceFee { get; set; }

        [JsonProperty("new_chargebackretrievalperretrievaltype")]
        public object NewChargebackretrievalperretrievaltype { get; set; }

        [JsonProperty("new_emvtransactionperdevice")]
        public object NewEmvtransactionperdevice { get; set; }

        [JsonProperty("new_nonemvcompliance_base")]
        public object NewNonemvcomplianceBase { get; set; }

        [JsonProperty("new_applicationfee_base")]
        public object NewApplicationfeeBase { get; set; }

        [JsonProperty("new_multipasspertransfee")]
        public object NewMultipasspertransfee { get; set; }

        [JsonProperty("new_g2monitoring_base")]
        public object NewG2MonitoringBase { get; set; }

        [JsonProperty("new_merlinkchargeback")]
        public object NewMerlinkchargeback { get; set; }

        [JsonProperty("new_passthrufee_base")]
        public object NewPassthrufeeBase { get; set; }

        [JsonProperty("utcconversiontimezonecode")]
        public object Utcconversiontimezonecode { get; set; }

        [JsonProperty("new_earlyterminationfee_base")]
        public object NewEarlyterminationfeeBase { get; set; }

        [JsonProperty("new_multipassgatewaymonthlyfee")]
        public object NewMultipassgatewaymonthlyfee { get; set; }

        [JsonProperty("new_visamcdiscovertransactionfee")]
        public object NewVisamcdiscovertransactionfee { get; set; }

        [JsonProperty("new_chargebackreversalsperreversal_base")]
        public object NewChargebackreversalsperreversalBase { get; set; }

        [JsonProperty("new_ebttransfee_base")]
        public object NewEbttransfeeBase { get; set; }

        [JsonProperty("new_wirelessmobilesetupfee_base")]
        public object NewWirelessmobilesetupfeeBase { get; set; }

        [JsonProperty("new_wirelessmobilepertransfee_base")]
        public object NewWirelessmobilepertransfeeBase { get; set; }

        [JsonProperty("new_gatewaysetupfee_base")]
        public object NewGatewaysetupfeeBase { get; set; }

        [JsonProperty("new_multipasssetupfee_base")]
        public object NewMultipasssetupfeeBase { get; set; }

        [JsonProperty("new_nonemvcompliance")]
        public object NewNonemvcompliance { get; set; }

        [JsonProperty("new_multipassgatewaymonthlyfee_base")]
        public object NewMultipassgatewaymonthlyfeeBase { get; set; }

        [JsonProperty("new_multipasssetupfee")]
        public object NewMultipasssetupfee { get; set; }

        [JsonProperty("new_ensurebillupdateperitemfee_base")]
        public object NewEnsurebillupdateperitemfeeBase { get; set; }

        [JsonProperty("new_voiceperauthfee_base")]
        public object NewVoiceperauthfeeBase { get; set; }

        [JsonProperty("new_monthlycustomersvsfee")]
        public object NewMonthlycustomersvsfee { get; set; }

        [JsonProperty("new_excessivehelpdeskcalls")]
        public object NewExcessivehelpdeskcalls { get; set; }

        [JsonProperty("new_monthlypcifee_base")]
        public object NewMonthlypcifeeBase { get; set; }

        [JsonProperty("new_g2monitoring")]
        public object NewG2Monitoring { get; set; }

        [JsonProperty("new_opvoiceperauthfee")]
        public object NewOpvoiceperauthfee { get; set; }

        [JsonProperty("new_visamcdispassthru2")]
        public object NewVisamcdispassthru2 { get; set; }

        [JsonProperty("new_merlinkchargeback_base")]
        public object NewMerlinkchargebackBase { get; set; }
    }
}
