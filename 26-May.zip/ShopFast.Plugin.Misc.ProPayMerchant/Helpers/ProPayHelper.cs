﻿using Nop.Services.Directory;
using ShopFast.Plugin.Misc.ProPayMerchant.Dto.Plaid;
using ShopFast.Plugin.Misc.ProPayMerchant.Models;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Security;
using System.Text;

namespace ShopFast.Plugin.Misc.ProPayMerchant.Helpers
{
    public class ProPayHelper
    {
        /// <summary>
        /// Sends a request to perform function at ProPay.
        /// </summary>
        /// <param name="requestUrl">Url of ProPay test/production api.</param>
        /// <param name="requestXml">Request xml.</param>
        /// <returns>Response xml.</returns>
        public static string SendRequest(string requestUrl, string requestXml)
        {
            string responseXml = string.Empty;

            //creates a web request using service URL
            var webRequest = WebRequest.Create(requestUrl);
            //sets a HTTP Method property of web request to POST data
            webRequest.Method = "POST";


            //converts a request xml to byte array
            byte[] byteArray = Encoding.UTF8.GetBytes(requestXml);
            //sets a ContentType property of web request for xml data
            webRequest.ContentType = "application/xml";
            //sets a ContentLength property of web request
            webRequest.ContentLength = byteArray.Length;

            //gets a request stream to write data
            var dataStream = webRequest.GetRequestStream();
            //writes a request xml byte array to request stream
            dataStream.Write(byteArray, 0, byteArray.Length);
            //closes a request stream object
            dataStream.Close();


            //gets a response from server
            var webResponse = webRequest.GetResponse();
            //gets a response stream containing response xml returned by ProPay
            dataStream = webResponse.GetResponseStream();
            //opens a response stream using StreamReader for easy access
            var streamReader = new StreamReader(dataStream);
            //gets a response xml string
            responseXml = streamReader.ReadToEnd();

            //cleaning up stream objects
            streamReader.Close();
            dataStream.Close();
            webResponse.Close();

            //returns response
            return responseXml;
        }

        public static string CreateProPayRequest(RegisterModel model, ProPayMerchantSettings proPayMerchantSettings, Account plaidAccount, Ach plaidNumber,
            IStateProvinceService stateProvinceService, ICountryService countryService)
        {
            var requestXml = new StringBuilder();
            requestXml.Append("<?xml version=\"1.0\"?>");
            requestXml.Append("<!DOCTYPE Request.dtd>");
            requestXml.Append("<XMLRequest>");
            requestXml.Append($"<certStr>{proPayMerchantSettings.CertString}</certStr>");
            requestXml.Append($"<termid>{proPayMerchantSettings.TermId}</termid>");
            requestXml.Append("<class>partner</class>");
            requestXml.Append("<XMLTrans>");
            requestXml.Append("<transType>01</transType>");

            //account information
            var phonePin = new Random().Next(9999);
            var accountExternalId = Guid.NewGuid();
            requestXml.Append($"<tier>{proPayMerchantSettings.DefaultAccountTier}</tier>");
            requestXml.Append($"<userId>{model.Email}</userId>");
            requestXml.Append($"<phonePin>{phonePin}</phonePin>");
            requestXml.Append($"<externalId>{accountExternalId.ToString().Split('-')[4]}</externalId>");

            //account identification information
            requestXml.Append($"<firstName>{model.FirstName}</firstName>");
            requestXml.Append($"<lastName>{model.LastName}</lastName>");
            requestXml.Append($"<dob>{model.DateOfBirth.Value:MM-dd-yyyy}</dob>");
            requestXml.Append($"<ssn>{model.SocialSecurityNumber.Replace("-", "")}</ssn>");
            requestXml.Append($"<sourceEmail>{model.Email}</sourceEmail>");
            requestXml.Append($"<dayPhone>{model.DaytimePhone}</dayPhone>");
            requestXml.Append($"<evenPhone>{model.MobilePhone}</evenPhone>");
            requestXml.Append($"<NotificationEmail>{model.Email}</NotificationEmail>");

            requestXml.Append($"<addr>{model.StreetAddress}</addr>");
            requestXml.Append($"<aptNum>{model.StreetAddress2}</aptNum>");
            requestXml.Append($"<city>{model.City}</city>");
            requestXml.Append($"<state>{stateProvinceService.GetStateProvinceById(model.StateProvinceId).Abbreviation}</state>");
            requestXml.Append($"<zip>{model.ZipPostalCode}</zip>");

            // always USA for now
            requestXml.Append("<country>USA</country>");

            //primary bank account information
            var accountType = plaidAccount.Subtype == "savings" ? "S" : "C";

            requestXml.Append($"<AccountOwnershipType>{model.BankAccountType}</AccountOwnershipType>");
            requestXml.Append($"<accountType>{accountType}</accountType>");
            requestXml.Append($"<BankName>{SecurityElement.Escape(model.PlaidInstitutionName)}</BankName>");
            requestXml.Append($"<RoutingNumber>{plaidNumber.Routing}</RoutingNumber>");
            requestXml.Append($"<AccountNumber>{plaidNumber.Account}</AccountNumber>");
            requestXml.Append($"<accountName>{model.NameOnAccount}</accountName>");

            // business data
            requestXml.Append($"<BusinessLegalName>{model.BusinessLegalName}</BusinessLegalName>");
            requestXml.Append($"<DoingBusinessAs>{model.BusinessLegalName}</DoingBusinessAs>");
            requestXml.Append($"<EIN>{model.EIN}</EIN>");

            // this is going to be set by the back office
            //requestXml.Append($"<MCCCode>{model.BusinessCategory}</MCCCode>");
            requestXml.Append($"<WebsiteURL>{model.WebsiteUrl}</WebsiteURL>");
            requestXml.Append($"<BusinessDesc>{model.BusinessDescription}</BusinessDesc>");
            requestXml.Append($"<MonthlyBankCardVolume>{model.MonthlyBankCardVolume}</MonthlyBankCardVolume>");
            requestXml.Append($"<AverageTicket>{model.AverageTicket}</AverageTicket>");
            requestXml.Append($"<HighestTicket>{model.HighestTicket}</HighestTicket>");

            requestXml.Append($"<BusinessAddress>{model.BusinessStreetAddress}</BusinessAddress>");
            requestXml.Append($"<BusinessAddress2>{model.BusinessStreetAddress2}</BusinessAddress2>");
            requestXml.Append($"<BusinessCity>{model.BusinessCity}</BusinessCity>");
            requestXml.Append("<BusinessCountry>USA</BusinessCountry>");
            requestXml.Append($"<BusinessState>{stateProvinceService.GetStateProvinceById(model.BusinessStateProvinceId).Abbreviation}</BusinessState>");
            requestXml.Append($"<BusinessZip>{model.BusinessZipPostalCode}</BusinessZip>");

            requestXml.Append("<BeneficialOwnerData>");

            requestXml.Append($"<OwnerCount>{model.BeneficialOwners.Count}</OwnerCount>");

            requestXml.Append("<Owners>");
            var beneficialOwner = model.BeneficialOwners.FirstOrDefault();
            requestXml.Append("<Owner>");
            requestXml.Append($"<FirstName>{beneficialOwner.FirstName}</FirstName>");
            requestXml.Append($"<LastName>{beneficialOwner.LastName}</LastName>");
            requestXml.Append($"<Title>{beneficialOwner.Title}</Title>");
            requestXml.Append($"<Address>{beneficialOwner.Address}</Address>");
            requestXml.Append($"<Percentage>{beneficialOwner.Percentage}</Percentage>");
            requestXml.Append($"<SSN>{beneficialOwner.SSN.Replace("-", "")}</SSN>");
            requestXml.Append($"<Country>{countryService.GetCountryById(beneficialOwner.CountryId).ThreeLetterIsoCode}</Country>");
            requestXml.Append($"<State>{stateProvinceService.GetStateProvinceById(beneficialOwner.StateProvinceId).Abbreviation}</State>");
            requestXml.Append($"<City>{beneficialOwner.City}</City>");
            requestXml.Append($"<Zip>{beneficialOwner.ZipPostalCode}</Zip>");
            requestXml.Append($"<Email>{beneficialOwner.Email}</Email>");
            requestXml.Append($"<DateOfBirth>{beneficialOwner.OwnerDateOfBirth.Value:MM-dd-yyyy}</DateOfBirth>");
            requestXml.Append("</Owner>");

            if (model.AddSecondBeneficialOwner)
            {
                var secondBeneficialOwner = model.BeneficialOwners[1];
                requestXml.Append("<Owner>");
                requestXml.Append($"<FirstName>{secondBeneficialOwner.FirstName}</FirstName>");
                requestXml.Append($"<LastName>{secondBeneficialOwner.LastName}</LastName>");
                requestXml.Append($"<Title>{secondBeneficialOwner.Title}</Title>");
                requestXml.Append($"<Address>{secondBeneficialOwner.Address}</Address>");
                requestXml.Append($"<Percentage>{secondBeneficialOwner.Percentage}</Percentage>");
                requestXml.Append($"<SSN>{secondBeneficialOwner.SSN.Replace("-", "")}</SSN>");
                requestXml.Append($"<Country>{countryService.GetCountryById(secondBeneficialOwner.CountryId).ThreeLetterIsoCode}</Country>");
                requestXml.Append($"<State>{stateProvinceService.GetStateProvinceById(secondBeneficialOwner.StateProvinceId).Abbreviation}</State>");
                requestXml.Append($"<City>{secondBeneficialOwner.City}</City>");
                requestXml.Append($"<Zip>{secondBeneficialOwner.ZipPostalCode}</Zip>");
                requestXml.Append($"<Email>{secondBeneficialOwner.Email}</Email>");
                requestXml.Append($"<DateOfBirth>{secondBeneficialOwner.OwnerDateOfBirth.Value:MM-dd-yyyy}</DateOfBirth>");
                requestXml.Append("</Owner>");
            }
            requestXml.Append("</Owners>");

            requestXml.Append("</BeneficialOwnerData>");

            requestXml.Append("</XMLTrans>");
            requestXml.Append("</XMLRequest>");

            return requestXml.ToString();
        }
    }
}
