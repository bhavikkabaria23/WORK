﻿using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Newtonsoft.Json;
using Nop.Core;
using ShopFast.Plugin.Misc.ProPayMerchant.Dto.Crm;
using System;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace ShopFast.Plugin.Misc.ProPayMerchant.Infrastructure.Crm
{
    public class CrmApiClient
    {
        public HttpClient HttpClient = new HttpClient();

        public CrmApiClient(string tenantId, string clientId, string clientSecret)
        {
            GetHttpClient(tenantId, clientId, clientSecret);
        }

        private HttpClient GetHttpClient(string tenantId, string clientId, string clientSecret)
        {
            string resource = "https://securepay.crm.dynamics.com/";

            try
            {
                var context = new AuthenticationContext($"https://login.microsoftonline.com/{tenantId}", false);

                var cred = new ClientCredential(clientId, clientSecret);
                var result = context.AcquireTokenAsync(resource, cred).Result;

                HttpClient.DefaultRequestHeaders.Add("OData-MaxVersion", "4.0");
                HttpClient.DefaultRequestHeaders.Add("OData-Version", "4.0");
                HttpClient.DefaultRequestHeaders.Add("Prefer", "return=representation");
                HttpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", result.AccessToken);

                return HttpClient;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public async Task<CrmPricingData> GetPricingTemplateByTemplateId(string templateId)
        {
            try
            {
                var response = await HttpClient.GetAsync($"https://securepay.crm.dynamics.com/api/data/v9.1/new_banktemplates?$filter=new_banktemplateid eq {templateId}");
                if (!response.IsSuccessStatusCode)
                {
                    throw new NopException("Could not retrieve pricing template");
                }

                var content = await response.Content.ReadAsStringAsync();
                var parsed = JsonConvert.DeserializeObject<CrmPricingResponse>(content);
                return parsed.CrmPricingData.FirstOrDefault();

            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
