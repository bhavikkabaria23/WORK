﻿using System.Collections.Generic;

namespace ShopFast.Plugin.Misc.ProPayMerchant.Infrastructure
{
    public static class LocalizationHelper
    {
        public static IDictionary<string, string> GetLocaleResources()
        {
            return new Dictionary<string, string>
            {
                // plaid
                { "Plugins.Misc.ProPayMerchant.Fields.PlaidClientId", "Plaid Client ID" },
                { "Plugins.Misc.ProPayMerchant.Fields.PlaidClientId.Hint", "Specify your Plaid Client ID" },
                { "Plugins.Misc.ProPayMerchant.Fields.PlaidSecret", "Plaid Secret" },
                { "Plugins.Misc.ProPayMerchant.Fields.PlaidSecret.Hint", "Specify your Plaid Secret" },
                { "Plugins.Misc.ProPayMerchant.Fields.PlaidPublicKey", "Plaid Public Key" },
                { "Plugins.Misc.ProPayMerchant.Fields.PlaidPublicKey.Hint", "Specify your Plaid Public Key" },

                { "Plugins.Misc.ProPayMerchant.Fields.CertString", "Certification String" },
                { "Plugins.Misc.ProPayMerchant.Fields.CertString.Hint", "Specify a certification string, which will be used to authenticate the incoming data at ProPay is from the correct source." },
                { "Plugins.Misc.ProPayMerchant.Fields.TermId", "Term ID" },
                { "Plugins.Misc.ProPayMerchant.Fields.TermId.Hint", "Specify a term identifier, which will be used as a second form of authentication at ProPay." },
                { "Plugins.Misc.ProPayMerchant.Fields.DefaultAccountTier", "Default Account Tier" },
                { "Plugins.Misc.ProPayMerchant.Fields.DefaultAccountTier.Hint", "Specify a default account tier, which will be used to set an account type while creating a ProPay merchant account." },
                { "Plugins.Misc.ProPayMerchant.Fields.AuthenticationToken", "Authentication Token" },
                { "Plugins.Misc.ProPayMerchant.Fields.AuthenticationToken.Hint", "Specify an authentication token, which will be used to authenticate every incoming request at ProtectPay." },
                { "Plugins.Misc.ProPayMerchant.Fields.BillerAccountId", "Biller Account ID" },
                { "Plugins.Misc.ProPayMerchant.Fields.BillerAccountId.Hint", "Specify a biller account identifier, which will be used to identify the correct collection of tokens in ProtectPay." },
                { "Plugins.Misc.ProPayMerchant.Fields.JumioApiToken", "Jumio API Token" },
                { "Plugins.Misc.ProPayMerchant.Fields.JumioApiToken.Hint", "Your Jumio API Token from the customer portal" },
                { "Plugins.Misc.ProPayMerchant.Fields.JumioApiSecret", "Jumio API Secret" },
                { "Plugins.Misc.ProPayMerchant.Fields.JumioApiSecret.Hint", "Your Jumio API Secret from the customer portal" },
                { "Plugins.Misc.ProPayMerchant.PageTitle.MerchantRegister", "Merchant Signup" },
                { "Plugins.Misc.ProPayMerchant.Signup", "Merchant Signup" },

                { "Plugins.Misc.ProPayMerchant.Fields.PersonalFirstName", "Applicant's First Name" },
                { "Plugins.Misc.ProPayMerchant.Fields.PersonalLastName", "Applicant's Last Name" },
                { "Plugins.Misc.ProPayMerchant.Fields.PersonalDateOfBirth", "Applicant's Date of birth" },
                { "Plugins.Misc.ProPayMerchant.Fields.PersonalEmail", "Applicant's Email" },
                { "Plugins.Misc.ProPayMerchant.Fields.PersonalStreetAddress", "Applicant's Street Address" },
                { "Plugins.Misc.ProPayMerchant.Fields.PersonalStreetAddress2", "Applicant's Street Address 2" },
                { "Plugins.Misc.ProPayMerchant.Fields.PersonalCity", "Applicant's City" },
                { "Plugins.Misc.ProPayMerchant.Fields.PersonalStateProvince", "Applicant's State / Province" },
                { "Plugins.Misc.ProPayMerchant.Fields.PersonalZipPostalCode", "Applicant's Zip / Postal Code" },
                { "Plugins.Misc.ProPayMerchant.Fields.DaytimePhone", "Applicant's Daytime Phone" },
                { "Plugins.Misc.ProPayMerchant.Fields.DaytimePhone.Required", "Daytime Phone is required." },
                { "Plugins.Misc.ProPayMerchant.Fields.MobilePhone", "Applicant's Mobile Phone" },
                { "Plugins.Misc.ProPayMerchant.Fields.MobilePhone.Required", "Mobile Phone is required." },


                { "Plugins.Misc.ProPayMerchant.Fields.SocialSecurityNumber", "Applicant's SSN" },
                { "Plugins.Misc.ProPayMerchant.Fields.SocialSecurityNumber.Required", "SSN is required." },
                { "Plugins.Misc.ProPayMerchant.Fields.SocialSecurityNumber.Wrong", "Wrong SSN. Must be in format XXX-XX-XXXX" },


                { "Plugins.Misc.ProPayMerchant.Fields.BusinessName", "Business Name" },
                { "Plugins.Misc.ProPayMerchant.Fields.BusinessName.Required", "Business name is required." },
                { "Plugins.Misc.ProPayMerchant.Fields.BusinessLegalName", "Business Legal Name (Must match IRS Tax filings)" },
                { "Plugins.Misc.ProPayMerchant.Fields.BusinessLegalName.Required", "Business Lgeal Name is required." },
                { "Plugins.Misc.ProPayMerchant.Fields.BusinessCategory", "Business category" },
                { "Plugins.Misc.ProPayMerchant.Fields.BusinessCategory.Required", "Business category is required." },
                { "Plugins.Misc.ProPayMerchant.Fields.BusinessCategory.Select", "Select business category" },
                { "Plugins.Misc.ProPayMerchant.Fields.AccountType", "Account type" },
                { "Plugins.Misc.ProPayMerchant.Fields.AccountType.Required", "Account type is required." },
                { "Plugins.Misc.ProPayMerchant.Fields.BankName", "Bank name" },
                { "Plugins.Misc.ProPayMerchant.Fields.BankName.Required", "Bank name is required." },
                { "Plugins.Misc.ProPayMerchant.Fields.RoutingNumber", "Routing number" },
                { "Plugins.Misc.ProPayMerchant.Fields.RoutingNumber.Required", "Routing number is required." },
                { "Plugins.Misc.ProPayMerchant.Fields.RoutingNumber.Wrong", "Wrong routing number" },
                { "Plugins.Misc.ProPayMerchant.Fields.AccountNumber", "Account number" },
                { "Plugins.Misc.ProPayMerchant.Fields.AccountNumber.Required", "Account number is required." },
                { "Plugins.Misc.ProPayMerchant.Fields.AccountNumber.Wrong", "Wrong account number" },
                { "Plugins.Misc.ProPayMerchant.Fields.NameOnAccount", "Name on account" },
                { "Plugins.Misc.ProPayMerchant.Fields.NameOnAccount.Required", "Name on account is required." },
                { "Plugins.Misc.ProPayMerchant.Button.Signup", "Sign up" },
                { "Plugins.Misc.ProPayMerchant.Signup.Result", "Your merchant account has been successfully created. You have just been sent an email containing merchant account information and account activation instructions." },
                { "Plugins.Misc.ProPayMerchant.TechnicalError", "We're sorry, an error occurred while processing the request: {0}" },

                { "Plugins.Misc.ProPayMerchant.Fields.WebsiteUrl", "Website URL" },
                { "Plugins.Misc.ProPayMerchant.Fields.WebsiteUrl.Required", "Website URL is required." },
                { "Plugins.Misc.ProPayMerchant.Fields.BusinessDescription", "Business Description" },
                { "Plugins.Misc.ProPayMerchant.Fields.MonthlyBankCardVolume", "Monthly Bank Card Volume" },
                { "Plugins.Misc.ProPayMerchant.Fields.MonthlyBankCardVolume.Required", "Monthly Bank Card Volume is required." },
                { "Plugins.Misc.ProPayMerchant.Fields.AverageTicket", "Average Ticket" },
                { "Plugins.Misc.ProPayMerchant.Fields.AverageTicket.Required", "Average Ticket is required." },
                { "Plugins.Misc.ProPayMerchant.Fields.HighestTicket", "Highest Ticket" },
                { "Plugins.Misc.ProPayMerchant.Fields.HighestTicket.Required", "Highest Ticket is required." },

                { "Plugins.Misc.ProPayMerchant.Fields.WebsiteUrl.Format", "The website URL must be in the format example.com or www.example.com" },

                { "Plugins.Misc.ProPayMerchant.Fields.HasSignificantOwnership", "Check if you are an owner and/or partner with 25% or more ownership?" },

                { "Plugins.Misc.ProPayMerchant.Fields.BusinessEntityType", "Entity Type" },
                { "Plugins.Misc.ProPayMerchant.Fields.BusinessEntityType.Required", "Business Entity Type is required" },
                { "Plugins.Misc.ProPayMerchant.Fields.BusinessStreetAddress", "Business Street Address" },
                { "Plugins.Misc.ProPayMerchant.Fields.BusinessStreetAddress2", "Business Street Address2" },
                { "Plugins.Misc.ProPayMerchant.Fields.BusinessCity", "Business City" },
                { "Plugins.Misc.ProPayMerchant.Fields.BusinessStateProvince", "Business State / Province" },
                { "Plugins.Misc.ProPayMerchant.Fields.BusinessZipPostalCode", "Business Zip / Postal Code" },
                { "Plugins.Misc.ProPayMerchant.Fields.BusinessPhone", "Business Phone Number" },
                { "Plugins.Misc.ProPayMerchant.Fields.BusinessNumberOfYears", "Number of Years in Business" },
                { "Plugins.Misc.ProPayMerchant.Fields.BusinessSwipedCardPresentPercent", "Swiped - Card Present" },
                { "Plugins.Misc.ProPayMerchant.Fields.BusinessKeyedCardPercent", "Card Keyed Manually" },
                { "Plugins.Misc.ProPayMerchant.Fields.BusinessOnlineTransactionPercent", "Internet Transactions" },
                { "Plugins.Misc.ProPayMerchant.ProcessingMethodsTotalPercent", "The total percentage of transactions must equal 100%" },

                // mail order section
                { "Plugins.Misc.ProPayMerchant.Fields.PercentageSoldToBusiness", "What percentage do you sell to business?" },
                { "Plugins.Misc.ProPayMerchant.Fields.PercentageSoldToPublic", "What percentage do you sell to public?" },
                { "Plugins.Misc.ProPayMerchant.Fields.OwnProductInventory", "Check if you own the product/inventory?" },
                { "Plugins.Misc.ProPayMerchant.Fields.SoldAtLocations", "Where do you sell? (check all that apply)" },
                { "Plugins.Misc.ProPayMerchant.Fields.NumberOfChargebacksInLast12Months", "How many chargebacks did you do in the last 12 months?" },
                { "Plugins.Misc.ProPayMerchant.Fields.AmountOfChargeBacksInLast12Months", "What is the total dollar amount of chargebacks you had in the last 12 months?" },
                { "Plugins.Misc.ProPayMerchant.Fields.TimeCustomerIsCharged", "When are the customers charged?" },
                { "Plugins.Misc.ProPayMerchant.Fields.DaysToDeliverToCustomer", "How many days from the time of the order does it take to deliver merchandise to the customer?" },
                { "Plugins.Misc.ProPayMerchant.Fields.RefundPolicy", "Please describe your refund policy" },

                { "Plugins.Misc.ProPayMerchant.Fields.IsLegalAddressDifferentThanBusinessAddress", "Check if your legal address different than your business address?" },
                { "Plugins.Misc.ProPayMerchant.Fields.LegalEntityStreetAddress", "Street Address" },
                { "Plugins.Misc.ProPayMerchant.Fields.LegalEntityCity", "City" },
                { "Plugins.Misc.ProPayMerchant.Fields.LegalEntityStateProvinceId", "State / Province" },
                { "Plugins.Misc.ProPayMerchant.Fields.LegalEntityZip", "Zip / Postal Code" },

                { "Plugins.Misc.ProPayMerchant.Fields.UseFulfillmentHouse", "Check if you use a fulfillment house to fulfill products?" },
                { "Plugins.Misc.ProPayMerchant.Fields.FulfillmentCompanyName", "Fulfillment Company Name" },
                { "Plugins.Misc.ProPayMerchant.Fields.FulfillmentContactPhoneNumber", "Fulfillment Company Phone Number" },

                { "Plugins.Misc.ProPayMerchant.Fields.EIN", "EIN (Must match IRS Tax filings)" },
                { "Plugins.Misc.ProPayMerchant.Fields.EIN.Format", "EIN must be in the format XX-XXXXXXX." },
                { "Plugins.Misc.ProPayMerchant.BankInformationMessage", "Please enter your bank account for deposits of merchant credits" },

                { "Plugins.Misc.ProPayMerchant.BankNameNotFound", "We could not find a bank by that routing number.  Please try a different routing number or manually enter the name of your bank." },

                { "Plugins.Misc.ProPayMerchant.Fields.TermsAndConditionsAccepted.Required", "You must accept the ProPay terms and conditions." }
            };
        }
    }
}
