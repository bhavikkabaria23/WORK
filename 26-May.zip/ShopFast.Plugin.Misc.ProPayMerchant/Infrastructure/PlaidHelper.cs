﻿using System;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using ShopFast.Plugin.Misc.ProPayMerchant.Dto.Plaid;

namespace ShopFast.Plugin.Misc.ProPayMerchant.Infrastructure
{
    public class PlaidHelper
    {
        public static async Task<(Account, Ach)> GetAchAccountInformation(string baseUrl, ProPayMerchantSettings settings, string publicToken, string accountId)
        {
            try
            {
                var httpClient = new HttpClient
                {
                    BaseAddress = new Uri(baseUrl)
                };

                // exchange public token for an access token
                var accessTokenResponse = await httpClient.PostAsJsonAsync(
                    @"/item/public_token/exchange",
                    new
                    {
                        client_id = settings.PlaidClientId,
                        secret = settings.PlaidSecret,
                        public_token = publicToken
                    });

                var accessTokenResult = await accessTokenResponse.Content.ReadAsStringAsync();
                var jObject = JObject.Parse(accessTokenResult);
                var accessToken = jObject["access_token"].ToString();

                // get bank information
                var data = new
                {
                    client_id = settings.PlaidClientId,
                    secret = settings.PlaidSecret,
                    access_token = accessToken
                };

                var response = await httpClient.PostAsJsonAsync(@"/auth/get", data);
                var result = await response.Content.ReadAsStringAsync();

                var authResponse = JsonConvert.DeserializeObject<PlaidAuthResponse>(result);

                var plaidNumber = authResponse?.Numbers?.Ach.FirstOrDefault(x => x.AccountId == accountId);
                var plaidAccount = authResponse?.Accounts.FirstOrDefault(x => x.AccountId == accountId);

                return (plaidAccount, plaidNumber);
            }
            catch (Exception ex)
            {
                return (null, null);
            }
        }
    }
}
