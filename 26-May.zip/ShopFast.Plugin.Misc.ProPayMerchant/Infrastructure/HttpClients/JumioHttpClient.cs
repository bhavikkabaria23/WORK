﻿using Newtonsoft.Json.Linq;
using Nop.Core;
using System;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace ShopFast.Plugin.Misc.ProPayMerchant.Infrastructure.HttpClients
{
    public class JumioHttpClient
    {
        private readonly HttpClient _httpClient;
        private readonly ProPayMerchantSettings _propaySettings;
        private readonly IWorkContext _workContext;
        private readonly IWebHelper _webHelper;

        public JumioHttpClient(HttpClient httpClient, ProPayMerchantSettings propaySettings, IWorkContext workContext,
            IWebHelper webHelper)
        {
            _httpClient = httpClient;
            _propaySettings = propaySettings;
            _workContext = workContext;
            _webHelper = webHelper;

            httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("OLB ProPayMerchantSignup");

            var auth = $"{propaySettings.JumioApiToken}:{propaySettings.JumioApiSecret}";
            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(Encoding.UTF8.GetBytes(auth)));
        }

        public async Task<string> GetJumioRequestUrl()
        {
            var request = new JObject
                {
                    { "customerInternalReference",_workContext.CurrentCustomer.CustomerGuid.ToString() },
                    { "userReference", _workContext.CurrentCustomer.Id },
                    { "successUrl", $"{_webHelper.GetStoreLocation(true)}jumio-success" }
                };

            var result = await _httpClient.PostAsJsonAsync("https://netverify.com/api/v4/initiate", request);

            var response = await result.Content.ReadAsStringAsync();

            if (!result.IsSuccessStatusCode)
            {
                throw new NopException("Jumio initiate API call failed");
            }

            var parsed = JObject.Parse(response);

            return parsed["redirectUrl"].ToString();
        }

        public async Task<JObject> GetDocumentData(string transactionReference)
        {
            var result = await _httpClient.GetAsync($"https://netverify.com/api/netverify/v2/scans/{transactionReference}/data/document");

            var response = await result.Content.ReadAsStringAsync();

            if (!result.IsSuccessStatusCode)
            {
                return null;
            }

            return JObject.Parse(response);
        }

        public async Task<JObject> GetImages(string transactionReference)
        {
            var result = await _httpClient.GetAsync($"https://netverify.com/api/netverify/v2/scans/{transactionReference}/images");

            var response = await result.Content.ReadAsStringAsync();

            if (!result.IsSuccessStatusCode)
            {
                return null;
            }

            return JObject.Parse(response);
        }

        public async Task<MemoryStream> GetImage(string imageHref)
        {
            var result = await _httpClient.GetAsync(imageHref);

            if (!result.IsSuccessStatusCode)
            {
                return null;
            }

            var ms = new MemoryStream();
            var stream = await result.Content.ReadAsStreamAsync();
            await stream.CopyToAsync(ms);
            
            return ms;
        }
    }
}
