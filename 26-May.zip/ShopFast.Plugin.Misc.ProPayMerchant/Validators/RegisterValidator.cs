﻿using System;
using System.Linq;
using FluentValidation;
using Microsoft.AspNetCore.Http;
using Nop.Core;
using Nop.Core.Domain.Customers;
using Nop.Services.Directory;
using Nop.Services.Localization;
using Nop.Web.Framework.Validators;
using ShopFast.Plugin.Misc.ProPayMerchant.Models;

namespace ShopFast.Plugin.Misc.ProPayMerchant.Validators
{
    public partial class RegisterValidator : BaseNopValidator<RegisterModel>
    {
        public RegisterValidator(ILocalizationService localizationService, CustomerSettings customerSettings, ICountryService countryService, IStateProvinceService stateProvinceService)
        {
            RuleFor(x => x.TermsAndConditionsAccepted).Must(x => x.Equals(true)).WithMessage(localizationService.GetResource("Plugins.Misc.ProPayMerchant.Fields.TermsAndConditionsAccepted.Required"));

            //////////////////
            // personal data
            RuleFor(x => x.FirstName).MaximumLength(20).NotEmpty().WithMessage(localizationService.GetResource("Account.Fields.FirstName.Required"));
            RuleFor(x => x.LastName).MaximumLength(25).NotEmpty().WithMessage(localizationService.GetResource("Account.Fields.LastName.Required"));
            RuleFor(x => x.SocialSecurityNumber).NotEmpty().WithMessage(localizationService.GetResource("Plugins.Misc.ProPayMerchant.Fields.SocialSecurityNumber.Required"));
            RuleFor(x => x.SocialSecurityNumber).Matches(@"^(\d{3}-?\d{2}-?\d{4})$").WithMessage(localizationService.GetResource("Plugins.Misc.ProPayMerchant.Fields.SocialSecurityNumber.Wrong"));

            // entered?
            RuleFor(x => x.DateOfBirth)
                .Must((x, context) =>
                {
                    var dateOfBirth = x.DateOfBirth;
                    //entered?
                    return dateOfBirth.HasValue;
                })
                .WithMessage(localizationService.GetResource("Account.Fields.DateOfBirth.Required"))
                .Must((x, context) =>
                {
                    var dateOfBirth = x.DateOfBirth;

                    //minimum age
                    if (customerSettings.DateOfBirthMinimumAge.HasValue &&
                        CommonHelper.GetDifferenceInYears(dateOfBirth.Value, DateTime.Today) < customerSettings.DateOfBirthMinimumAge.Value)
                    {
                        return false;
                    }

                    return true;
                }).WithMessage(string.Format(localizationService.GetResource("Account.Fields.DateOfBirth.MinimumAge"), customerSettings.DateOfBirthMinimumAge ?? 0));

            // source email
            RuleFor(x => x.Email).NotEmpty().WithMessage(localizationService.GetResource("Account.Fields.Email.Required"));
            RuleFor(x => x.Email).EmailAddress().WithMessage(localizationService.GetResource("Common.WrongEmail"));

            //Password rule
            RuleFor(x => x.Password).IsPassword(localizationService, customerSettings);

            RuleFor(x => x.ConfirmPassword).NotEmpty().WithMessage(localizationService.GetResource("Account.Fields.ConfirmPassword.Required"));
            RuleFor(x => x.ConfirmPassword).Equal(x => x.Password).WithMessage(localizationService.GetResource("Account.Fields.Password.EnteredPasswordsDoNotMatch"));

            RuleFor(x => x.StreetAddress).NotEmpty().WithMessage(localizationService.GetResource("Account.Fields.StreetAddress.Required"));
            RuleFor(x => x.City).NotEmpty().WithMessage(localizationService.GetResource("Account.Fields.City.Required"));
            RuleFor(x => x.StateProvinceId).Must((x, context) => x.StateProvinceId != 0).WithMessage(localizationService.GetResource("Account.Fields.StateProvince.Required"));
            RuleFor(x => x.ZipPostalCode).NotEmpty().WithMessage(localizationService.GetResource("Account.Fields.ZipPostalCode.Required"));

            RuleFor(x => x.DaytimePhone).NotEmpty().WithMessage(localizationService.GetResource("Account.Fields.Phone.Required"));
            RuleFor(x => x.MobilePhone).NotEmpty().WithMessage(localizationService.GetResource("Account.Fields.Phone.Required"));

            ///////////////////
            // business data
            RuleFor(x => x.BusinessLegalName)
                .NotEmpty().WithMessage(localizationService.GetResource("Plugins.Misc.ProPayMerchant.Fields.BusinessName.Required"))
                .MaximumLength(255);

            RuleFor(x => x.NumberOfYearsInBusiness).NotEmpty();
            RuleFor(x => x.BusinessEntityType).Must(x => !x.Equals("0")).WithMessage(localizationService.GetResource("Plugins.Misc.ProPayMerchant.Fields.BusinessEntityType.Required"));

            RuleFor(x => x.SwipedCardPresentPercent).NotNull();
            RuleFor(x => x.KeyedCardPercent).NotNull();
            RuleFor(x => x.OnlineTransactionPercent).NotNull();

            RuleFor(x => (decimal)100).Equal(x => x.SwipedCardPresentPercent + x.KeyedCardPercent + x.OnlineTransactionPercent)
                .WithMessage(localizationService.GetResource("Plugins.Misc.ProPayMerchant.ProcessingMethodsTotalPercent"));

            //RuleFor(x => x.BusinessCategory).Must((x, context) => x.BusinessCategory != 0).WithMessage(localizationService.GetResource("Plugins.Misc.ProPayMerchant.Fields.BusinessCategory.Required"));

            RuleFor(x => x.EIN)
                .NotEmpty()
                .Matches(@"^[1-9]\d?-\d{7}$").WithMessage(localizationService.GetResource("Plugins.Misc.ProPayMerchant.Fields.EIN.Format"));

            RuleFor(x => x.BusinessStreetAddress)
                .NotEmpty().WithMessage(localizationService.GetResource("Account.Fields.StreetAddress.Required"))
                .MaximumLength(100);
            RuleFor(x => x.BusinessCity)
                .NotEmpty().WithMessage(localizationService.GetResource("Account.Fields.City.Required"))
                .MaximumLength(30);
            RuleFor(x => x.BusinessZipPostalCode).NotEmpty().WithMessage(localizationService.GetResource("Account.Fields.ZipPostalCode.Required"));

            RuleFor(x => x.BusinessStateProvinceId).Must((x, context) =>
            {
                var country = countryService.GetCountryByThreeLetterIsoCode("USA");
                if (country == null)
                {
                    return false;
                }

                //does selected country have states?
                var hasStates = stateProvinceService.GetStateProvincesByCountryId(country.Id).Any();
                if (hasStates)
                {
                    //if yes, then ensure that a state is selected
                    if (x.BusinessStateProvinceId == 0)
                        return false;
                }

                return true;
            }).WithMessage(localizationService.GetResource("Account.Fields.StateProvince.Required"));

            // legal entity address
            When(x => x.IsLegalAddressDifferentThanBusinessAddress, () =>
            {
                RuleFor(x => x.LegalEntityStreetAddress).NotEmpty().WithMessage(localizationService.GetResource("Account.Fields.StreetAddress.Required"));
                RuleFor(x => x.LegalEntityCity).NotEmpty().WithMessage(localizationService.GetResource("Account.Fields.City.Required"));
                RuleFor(x => x.LegalEntityZip).NotEmpty().WithMessage(localizationService.GetResource("Account.Fields.ZipPostalCode.Required"));

                RuleFor(x => x.LegalEntityStateProvinceId).Must((x, context) =>
                {
                    var country = countryService.GetCountryByThreeLetterIsoCode("USA");
                    if (country == null)
                    {
                        return false;
                    }

                    //does selected country have states?
                    var hasStates = stateProvinceService.GetStateProvincesByCountryId(country.Id).Any();
                    if (hasStates)
                    {
                        //if yes, then ensure that a state is selected
                        if (x.LegalEntityStateProvinceId == 0)
                            return false;
                    }

                    return true;
                }).WithMessage(localizationService.GetResource("Account.Fields.StateProvince.Required"));
            });

            // mail order section
            When(x => x.SwipedCardPresentPercent <= 74, () =>
            {
                RuleFor(x => x.PercentageSoldToBusiness).NotEmpty();
                RuleFor(x => x.PercentageSoldToPublic).NotEmpty();
                RuleFor(x => x.OwnProductInventory).NotEmpty();
                RuleFor(x => x.SoldAtLocations.Any(y => y.Selected)).Must(x => x.Equals(true));
                RuleFor(x => x.NumberOfChargebacksInLast12Months).NotEmpty();
                RuleFor(x => x.AmountOfChargeBacksInLast12Months).NotEmpty();
                RuleFor(x => x.TimeCustomerIsCharged).NotEmpty();
                RuleFor(x => x.DaysToDeliverToCustomer).NotEmpty();
                RuleFor(x => x.RefundPolicy).NotEmpty();
            });

            // fulfillment section
            When(x => x.UseFulfillmentHouse, () =>
            {
                RuleFor(x => x.FulfillmentCompanyName).NotEmpty();
                RuleFor(x => x.FulfillmentContactPhoneNumber).NotEmpty();
            });

            RuleFor(x => x.WebsiteUrl)
                .NotEmpty().WithMessage(localizationService.GetResource("Plugins.Misc.ProPayMerchant.Fields.WebsiteUrl.Required"))
                .MaximumLength(255)
                .Matches(@"^\s*(http\:\/\/)?([a-z\d\-]{1,63}\.)*[a-z\d\-]{1,255}\.[a-z]{2,6}\s*$")
                .WithMessage(localizationService.GetResource("Plugins.Misc.ProPayMerchant.Fields.WebsiteUrl.Format"));
            RuleFor(x => x.MonthlyBankCardVolume).GreaterThan(0).WithMessage(localizationService.GetResource("Plugins.Misc.ProPayMerchant.Fields.MonthlyBankCardVolume.Required"));
            RuleFor(x => x.AverageTicket).GreaterThan(0).WithMessage(localizationService.GetResource("Plugins.Misc.ProPayMerchant.Fields.AverageTicket.Required"));
            RuleFor(x => x.HighestTicket).GreaterThan(0).WithMessage(localizationService.GetResource("Plugins.Misc.ProPayMerchant.Fields.HighestTicket.Required"));

            //////////////////////
            // bank account data
            RuleFor(x => x.BankAccountType).Must((x, context) => !string.IsNullOrEmpty(x.BankAccountType)).WithMessage(localizationService.GetResource("Plugins.Misc.ProPayMerchant.Fields.AccountType.Required"));
            RuleFor(x => x.BankAccountId).NotEmpty().Must((x, c) => x.BankAccountId != "0");
            RuleFor(x => x.NameOnAccount).NotEmpty().WithMessage(localizationService.GetResource("Plugins.Misc.ProPayMerchant.Fields.NameOnAccount.Required"));
            RuleFor(x => x.PlaidInstitutionName).NotEmpty();
            RuleFor(x => x.PlaidPublicToken).NotEmpty();

            // uploads
            RuleFor(x => x.BeneficialOwner1DriversLicense).SetValidator(new FileValidator());
            RuleFor(x => x.BusinessProcessingStatement).SetValidator(new FileValidator());

            //RuleFor(x => x.AccountType).Must((x, context) => !string.IsNullOrEmpty(x.AccountType)).WithMessage(localizationService.GetResource("Plugins.Misc.ProPayMerchant.Fields.AccountType.Required"));
            //RuleFor(x => x.RoutingNumber).NotEmpty().WithMessage(localizationService.GetResource("Plugins.Misc.ProPayMerchant.Fields.RoutingNumber.Required"));
            //RuleFor(x => x.RoutingNumber).Matches("^[0-9]{9}$").WithMessage(localizationService.GetResource("Plugins.Misc.ProPayMerchant.Fields.RoutingNumber.Wrong"));
            //RuleFor(x => x.AccountNumber).NotEmpty().WithMessage(localizationService.GetResource("Plugins.Misc.ProPayMerchant.Fields.AccountNumber.Required"));
            //RuleFor(x => x.AccountNumber).Matches("^[0-9]{4,25}$").WithMessage(localizationService.GetResource("Plugins.Misc.ProPayMerchant.Fields.AccountNumber.Wrong"));


            RuleFor(x => x.BeneficialOwners[0]).SetValidator(new BeneficialOwnerValidator(localizationService, customerSettings));

            When(x => x.AddSecondBeneficialOwner,
                () =>
                {
                    RuleFor(x => x.BeneficialOwners[1])
                        .SetValidator(new BeneficialOwnerValidator(localizationService, customerSettings));

                    // 2nd beneficial owner drivers license is optional
                    //RuleFor(x => x.BeneficialOwner2DriversLicense).SetValidator(new FileValidator());
                });
        }
    }

    public class BeneficialOwnerValidator : BaseNopValidator<RegisterModel.Owner>
    {
        public BeneficialOwnerValidator(ILocalizationService localizationService, CustomerSettings customerSettings)
        {
            RuleFor(x => x.Title).NotEmpty().NotEqual("0");
            RuleFor(x => x.FirstName).NotEmpty();
            RuleFor(x => x.LastName).NotEmpty();
            RuleFor(x => x.Email).NotEmpty();
            RuleFor(x => x.Percentage).NotNull();
            RuleFor(x => x.Address).NotEmpty();
            RuleFor(x => x.SSN).NotEmpty();
            RuleFor(x => x.City).NotEmpty();
            RuleFor(x => x.ZipPostalCode).NotEmpty();

            RuleFor(x => x.StateProvinceId).Must((x, context) => x.StateProvinceId != 0).WithMessage(localizationService.GetResource("Account.Fields.StateProvince.Required"));
            RuleFor(x => x.CountryId).Must((x, context) => x.CountryId != 0).WithMessage(localizationService.GetResource("Account.Fields.Country.Required"));

            RuleFor(x => x.OwnerDateOfBirth)
                .Must((x, context) =>
                {
                    var dateOfBirth = x.OwnerDateOfBirth;
                    //entered?
                    return dateOfBirth.HasValue;
                })
                .WithMessage(localizationService.GetResource("Account.Fields.DateOfBirth.Required"))
                .Must((x, context) =>
                {
                    var dateOfBirth = x.OwnerDateOfBirth;

                    //minimum age
                    if (customerSettings.DateOfBirthMinimumAge.HasValue &&
                        CommonHelper.GetDifferenceInYears(dateOfBirth.Value, DateTime.Today) < customerSettings.DateOfBirthMinimumAge.Value)
                    {
                        return false;
                    }

                    return true;
                }).WithMessage(string.Format(localizationService.GetResource("Account.Fields.DateOfBirth.MinimumAge"), customerSettings.DateOfBirthMinimumAge ?? 0));
        }
    }

    public class FileValidator : BaseNopValidator<IFormFile>
    {
        public FileValidator()
        {
            RuleFor(x => x).NotNull();
            RuleFor(x => x.Length).NotNull();
            RuleFor(x => x.ContentType)
                .NotNull()
                .Must(x => x.Equals("image/jpeg") || x.Equals("image/jpg") || x.Equals("image/png") || x.Equals("application/pdf"))
                .WithMessage("File type must be a jpeg/jpg/png/PDF");
        }
    }
}