﻿using Nop.Core;
using Nop.Services.Common;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Plugins;
using ShopFast.Plugin.Misc.ProPayMerchant.Infrastructure;

namespace ShopFast.Plugin.Misc.ProPayMerchant
{
    public class ProPayMerchantPlugin : BasePlugin, IMiscPlugin
    {
        #region Fields

        private readonly ISettingService _settingService;
        private readonly IWebHelper _webHelper;
        private readonly ILocalizationService _localizationService;

        #endregion

        #region Constructors

        public ProPayMerchantPlugin(ISettingService settingService, IWebHelper webHelper, ILocalizationService localizationService)
        {
            _settingService = settingService;
            _webHelper = webHelper;
            _localizationService = localizationService;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Gets a configuration page URL
        /// </summary>
        public override string GetConfigurationPageUrl()
        {
            return _webHelper.GetStoreLocation() + "Admin/MiscProPayMerchant/Configure";
        }

        /// <summary>
        /// Installs plugin.
        /// </summary>
        public override void Install()
        {
            //settings
            var settings = new ProPayMerchantSettings
            {
                UseSandbox = true,
                AvailableAccountTiers = "Premium",
                DefaultAccountTier = "Premium"
            };
            _settingService.SaveSetting(settings);

            //locales
            foreach (var localeResource in LocalizationHelper.GetLocaleResources())
            {
                _localizationService.AddOrUpdatePluginLocaleResource(localeResource.Key, localeResource.Value);
            }

            base.Install();
        }

        /// <summary>
        /// Uninstalls plugin.
        /// </summary>
        public override void Uninstall()
        {
            //settings
            _settingService.DeleteSetting<ProPayMerchantSettings>();

            //locales
            foreach (var localeResource in LocalizationHelper.GetLocaleResources())
            {
                _localizationService.DeletePluginLocaleResource(localeResource.Key);
            }

            base.Uninstall();
        }

        #endregion

        public bool HideInWidgetList => false;
    }
}
