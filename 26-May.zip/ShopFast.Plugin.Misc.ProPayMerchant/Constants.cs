﻿namespace ShopFast.Plugin.Misc.ProPayMerchant
{
    public static class Constants
    {
        public static string ProPayMerchantProfileId = "ProPayMerchantProfileId";
    }
}
