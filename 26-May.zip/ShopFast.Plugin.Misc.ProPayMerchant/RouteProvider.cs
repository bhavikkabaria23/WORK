﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Nop.Web.Framework.Mvc.Routing;

namespace ShopFast.Plugin.Misc.ProPayMerchant
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(IEndpointRouteBuilder endpointRouteBuilder)
        {
            // register launch page
            endpointRouteBuilder.MapControllerRoute(
                "Plugin.Misc.ProPayMerchant.RegisterLaunch",
                "merchant-signup/",
                new { controller = "MiscProPayMerchant", action = "RegisterLaunch" }
            );

            // sign up
            endpointRouteBuilder.MapControllerRoute(
                "Plugin.Misc.ProPayMerchant.Register",
                "propay-register/",
                new { controller = "MiscProPayMerchant", action = "Register" }
            );

            // jumio success callback
            endpointRouteBuilder.MapControllerRoute(
                "Plugin.Misc.ProPayMerchant.JumioSuccess",
                "jumio-success/",
                new { controller = "MiscProPayMerchant", action = "JumioSuccess" }
            );

            // jumio register callback
            endpointRouteBuilder.MapControllerRoute(
                "Plugin.Misc.ProPayMerchant.JumioRegister",
                "jumio-register/",
                new { controller = "MiscProPayMerchant", action = "JumioRegister" }
            );

            // jumio register popup
            endpointRouteBuilder.MapControllerRoute(
                "Plugin.Misc.ProPayMerchant.JumioRegisterPopup",
                "jumio-popup/",
                new { controller = "MiscProPayMerchant", action = "JumioRegisterPopup" }
            );

            // propay terms of service view
            endpointRouteBuilder.MapControllerRoute(
                "Plugin.Misc.ProPayMerchant.PropayTermsOfService",
                "propay-terms/",
                new { controller = "MiscProPayMerchant", action = "PropayTermsOfService" }
            );
        }

        public int Priority => 0;
    }
}
