﻿using FluentValidation;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Nop.Core.Infrastructure;
using Nop.Web.Framework.Infrastructure.Extensions;
using ShopFast.Plugin.Misc.ProPayMerchant.Infrastructure.HttpClients;
using ShopFast.Plugin.Misc.ProPayMerchant.Models;
using ShopFast.Plugin.Misc.ProPayMerchant.Validators;

namespace ShopFast.Plugin.Misc.ProPayMerchant
{
    /// <summary>
    /// Represents object for the configuring services on application startup
    /// </summary>
    public class Startup : INopStartup
    {
        /// <summary>
        /// Add and configure any of the middleware
        /// </summary>
        /// <param name="services">Collection of service descriptors</param>
        /// <param name="configuration">Configuration of the application</param>
        public void ConfigureServices(IServiceCollection services, IConfiguration configuration)
        {
            // must register validator because by default nop only registers assemblies that start with "Nop"
            services.AddTransient<IValidator<RegisterModel>, RegisterValidator>();

            // register http clients for external apis
            services.AddHttpClient<JumioHttpClient>().WithProxy();
        }

        /// <summary>
        /// Configure the using of added middleware
        /// </summary>
        /// <param name="application">Builder for configuring an application's request pipeline</param>
        public void Configure(IApplicationBuilder application)
        {
        }

        /// <summary>
        /// Gets order of this startup configuration implementation
        /// </summary>
        public int Order => 100;
    }
}
