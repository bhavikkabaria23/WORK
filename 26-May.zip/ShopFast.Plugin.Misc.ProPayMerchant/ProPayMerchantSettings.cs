﻿using Nop.Core.Configuration;

namespace ShopFast.Plugin.Misc.ProPayMerchant
{
    public class ProPayMerchantSettings : ISettings
    {
        // plaid
        public string PlaidClientId { get; set; }
        public string PlaidSecret { get; set; }
        public string PlaidPublicKey { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether to use ProPay test or production environment.
        /// </summary>
        public bool UseSandbox { get; set; }

        /// <summary>
        /// Gets or sets a unique certification string. It is used to authenticate the incoming data at ProPay is from the correct source.
        /// </summary>
        public string CertString { get; set; }

        /// <summary>
        /// Gets or sets a unique term identifier provided by ProPay. It is used as a second form of authentication.
        /// </summary>
        public string TermId { get; set; }

        /// <summary>
        /// Gets or sets available account types of ProPay affiliation.
        /// </summary>
        public string AvailableAccountTiers { get; set; }

        /// <summary>
        /// Gets or sets a default account type. It is used to set an account type while creating a ProPay merchant account.
        /// </summary>
        public string DefaultAccountTier { get; set; }

        /// <summary>
        /// Gets or sets a unique authentication token provided by ProPay. It is used to authenticate every incoming request at ProtectPay.
        /// </summary>
        public string AuthenticationToken { get; set; }

        /// <summary>
        /// Gets or sets a unique biller account identifier. It is used to identify the correct collection of tokens in ProtectPay.
        /// </summary>
        public string BillerAccountId { get; set; }

        public string CrmTenantId { get; set; }
        public string CrmClientId { get; set; }
        public string CrmClientSecret { get; set; }

        public string JumioApiToken { get; set; }
        public string JumioApiSecret { get; set; }
    }
}
