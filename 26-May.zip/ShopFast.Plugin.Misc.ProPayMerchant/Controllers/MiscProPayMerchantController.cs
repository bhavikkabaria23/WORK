﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Nop.Core;
using Nop.Core.Domain.Common;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Localization;
using Nop.Core.Http.Extensions;
using Nop.Services.Authentication;
using Nop.Services.Common;
using Nop.Services.Configuration;
using Nop.Services.Customers;
using Nop.Services.Directory;
using Nop.Services.Events;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Messages;
using Nop.Services.Vendors;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Mvc.Filters;
using ShopFast.Plugin.Misc.ProPayMerchant.Domain;
using ShopFast.Plugin.Misc.ProPayMerchant.Helpers;
using ShopFast.Plugin.Misc.ProPayMerchant.Infrastructure;
using ShopFast.Plugin.Misc.ProPayMerchant.Infrastructure.Crm;
using ShopFast.Plugin.Misc.ProPayMerchant.Models;
using ShopFast.Plugin.Misc.ProPayMerchant.Validators;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace ShopFast.Plugin.Misc.ProPayMerchant.Controllers
{
    public class MiscProPayMerchantController : BasePluginController
    {
        private const string PROPAY_MERCHANT_FORM_ID = "PropayMerchantFormId";

        #region Fields

        private readonly IWorkContext _workContext;
        private readonly IStoreContext _storeContext;
        private readonly ISettingService _settingService;
        private readonly ICountryService _countryService;
        private readonly IStateProvinceService _stateProvinceService;
        private readonly ILocalizationService _localizationService;
        private readonly ILogger _logger;
        private readonly INotificationService _notificationService;
        private readonly CustomerSettings _customerSettings;
        private readonly ICustomerRegistrationService _customerRegistrationService;
        private readonly IAuthenticationService _authenticationService;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly IAddressService _addressService;
        private readonly ICustomerService _customerService;
        private readonly IEventPublisher _eventPublisher;
        private readonly IWorkflowMessageService _workflowMessageService;
        private readonly ProPayMerchantSettings _proPaySettings;
        private readonly IWebHelper _webHelper;
        private readonly IVendorService _vendorService;
        private readonly LocalizationSettings _localizationSettings;

        #endregion

        #region Constructors

        public MiscProPayMerchantController(IWorkContext workContext, IStoreContext storeContext, ISettingService settingService, ICountryService countryService,
            IStateProvinceService stateProvinceService, ILocalizationService localizationService,
            ILogger logger, INotificationService notificationService, CustomerSettings customerSettings, ICustomerRegistrationService customerRegistrationService,
            IAuthenticationService authenticationService, IGenericAttributeService genericAttributeService, IAddressService addressService,
            ICustomerService customerService, IEventPublisher eventPublisher, IWorkflowMessageService workflowMessageService, ProPayMerchantSettings proPaySettings, IWebHelper webHelper,
            IVendorService vendorService, LocalizationSettings localizationSettings)
        {
            _workContext = workContext;
            _storeContext = storeContext;
            _settingService = settingService;
            _countryService = countryService;
            _stateProvinceService = stateProvinceService;
            _localizationService = localizationService;
            _logger = logger;
            _notificationService = notificationService;
            _customerSettings = customerSettings;
            _customerRegistrationService = customerRegistrationService;
            _authenticationService = authenticationService;
            _genericAttributeService = genericAttributeService;
            _addressService = addressService;
            _customerService = customerService;
            _eventPublisher = eventPublisher;
            _workflowMessageService = workflowMessageService;
            _proPaySettings = proPaySettings;
            _webHelper = webHelper;
            _vendorService = vendorService;
            _localizationSettings = localizationSettings;
        }

        #endregion

        #region Utilities

        [NonAction]
        protected virtual void PrepareMerchantRegisterModel(RegisterModel model)
        {
            if (model == null)
                throw new ArgumentNullException(nameof(model));


            var pricingTemplate = new CrmApiClient(_proPaySettings.CrmTenantId, _proPaySettings.CrmClientId, _proPaySettings.CrmClientSecret)
                .GetPricingTemplateByTemplateId("957fc400-7119-e911-a818-000d3a1617d5").Result;

            if (pricingTemplate == null)
            {
                _logger.Error("Could not retrieve pricing template");
                throw new NopException("Could not retrieve pricing template");
            }

            model.PricingTemplate = pricingTemplate;

            //business categories
            //model.AvailableBusinessCategories = new List<SelectListItem>
            //{
            //    new SelectListItem
            //    {
            //        Text = _localizationService.GetResource(
            //            "Plugins.Misc.ProPayMerchant.Fields.BusinessCategory.Select"),
            //        Value = "0"
            //    },
            //    new SelectListItem {Text = "General Merchandise", Value = "5399"}
            //};

            // plaid
            model.PublicKey = _proPaySettings.PlaidPublicKey;
            model.Environment = _proPaySettings.UseSandbox ? "sandbox" : "production";

            //states
            model.AvailableStates = new List<SelectListItem>();
            var country = _countryService.GetCountryByThreeLetterIsoCode("USA");
            var states = _stateProvinceService.GetStateProvincesByCountryId(country?.Id ?? 0, _workContext.WorkingLanguage.Id).ToList();
            if (states.Count > 0)
            {
                model.AvailableStates.Add(new SelectListItem { Text = _localizationService.GetResource("Address.SelectState"), Value = "0" });
                foreach (var s in states)
                {
                    model.AvailableStates.Add(new SelectListItem { Text = _localizationService.GetLocalized(s, x => x.Name), Value = s.Id.ToString(), Selected = (s.Id == model.StateProvinceId) });
                }
            }

            model.BusinessAvailableStates = model.AvailableStates;

            // countries
            model.AvailableCountries.Add(new SelectListItem { Text = _localizationService.GetResource("Address.SelectCountry"), Value = "0" });

            foreach (var c in _countryService.GetAllCountries(_workContext.WorkingLanguage.Id))
            {
                model.AvailableCountries.Add(new SelectListItem
                {
                    Text = _localizationService.GetLocalized(c, x => x.Name),
                    Value = c.Id.ToString(),
                    Selected = c.ThreeLetterIsoCode == "USA"
                });
            }

            //bank account types
            model.BankAccountTypes = new List<SelectListItem>
            {
                new SelectListItem {Value = "Business", Text = "Business", Selected = true},
                new SelectListItem {Value = "Personal", Text = "Personal"}
            };

            if (string.IsNullOrEmpty(model.BankAccountType))
            {
                model.BankAccountType = "Business";
            }

            if (model.BeneficialOwners.Count != 2 || model.BeneficialOwners.Any(x => x == null))
            {
                model.BeneficialOwners = new List<RegisterModel.Owner>
                {
                    new RegisterModel.Owner(),
                    new RegisterModel.Owner()
                };
            }

            model.BusinessEntityTypes = new List<SelectListItem>
            {
                new SelectListItem { Value = "0", Text = "Select an Entity Type", Selected = true },
                new SelectListItem{ Value = "Soleprop", Text = "Sole Proprietorship" },
                new SelectListItem{ Value = "Corporation", Text = "Corporation" },
                new SelectListItem{ Value = "LLC", Text = "LLC" },
                new SelectListItem{ Value = "Government", Text = "Government" },
                new SelectListItem{ Value = "501CNonProfit", Text = "501C Non-Profit" },
                new SelectListItem{ Value = "Partnership", Text = "Partnership" }
            };

            model.AvailableTitles = new List<SelectListItem>
            {
                new SelectListItem{ Value = "0", Text = "Select a Title" },
                new SelectListItem{ Value = "CEO", Text = "CEO" },
                new SelectListItem{ Value = "CFO", Text = "CFO" },
                new SelectListItem{ Value = "Executive", Text = "Executive" }
            };

            model.SoldAtLocations = new List<SelectListItem>
            {
                new SelectListItem {Value = "Locally", Text = "Locally"},
                new SelectListItem {Value = "Nationally", Text = "Nationally"}
            };

            model.TimeCustomerIsChargedItems = new List<SelectListItem>
            {
                new SelectListItem { Value = "0", Text = "Time of Order"},
                new SelectListItem { Value = "1", Text = "Upon Shipment"}
            };

            model.DaysToDeliverToCustomerItems = new List<SelectListItem>
            {
                new SelectListItem { Value = "0", Text = "1-7 Days"},
                new SelectListItem { Value = "1", Text = "8-14 Days"},
                new SelectListItem { Value = "2", Text = "14+ Days"},
            };
        }

        #endregion

        #region Methods

        #region - Configuration -

        [AuthorizeAdmin]
        [Area(AreaNames.Admin)]
        public IActionResult Configure()
        {
            //load settings for a chosen store scope
            var storeScope = _storeContext.ActiveStoreScopeConfiguration;
            var proPayMerchantSettings = _settingService.LoadSetting<ProPayMerchantSettings>(storeScope);

            var model = new ConfigurationModel
            {
                CertString = proPayMerchantSettings.CertString,
                TermId = proPayMerchantSettings.TermId,
                DefaultAccountTier = proPayMerchantSettings.DefaultAccountTier,
                AuthenticationToken = proPayMerchantSettings.AuthenticationToken,
                BillerAccountId = proPayMerchantSettings.BillerAccountId,
                JumioApiToken = proPayMerchantSettings.JumioApiToken,
                JumioApiSecret = proPayMerchantSettings.JumioApiSecret,
                PlaidClientId = proPayMerchantSettings.PlaidClientId,
                PlaidSecret = proPayMerchantSettings.PlaidSecret,
                PlaidPublicKey = proPayMerchantSettings.PlaidPublicKey
            };

            if (!string.IsNullOrEmpty(proPayMerchantSettings.AvailableAccountTiers))
            {
                proPayMerchantSettings.AvailableAccountTiers.Split(',')
                    .ToList()
                    .ForEach(x =>
                    {
                        model.AvailableAccountTiers.Add(new SelectListItem { Value = x, Text = x, Selected = x == model.DefaultAccountTier });
                    });
            }

            model.AvailableAccountTiers.Insert(0, new SelectListItem { Value = "Value", Text = "Text" });

            return View("~/Plugins/ShopFast.Misc.ProPayMerchant/Views/Configure.cshtml", model);
        }

        [HttpPost]
        [AuthorizeAdmin]
        [Area(AreaNames.Admin)]
        public IActionResult Configure(ConfigurationModel model)
        {
            if (!ModelState.IsValid)
                return Configure();

            //load settings for a chosen store scope
            var storeScope = _storeContext.ActiveStoreScopeConfiguration;
            var proPayMerchantSettings = _settingService.LoadSetting<ProPayMerchantSettings>(storeScope);

            //save settings
            proPayMerchantSettings.CertString = model.CertString;
            proPayMerchantSettings.TermId = model.TermId;
            proPayMerchantSettings.DefaultAccountTier = model.DefaultAccountTier;
            proPayMerchantSettings.AuthenticationToken = model.AuthenticationToken;
            proPayMerchantSettings.BillerAccountId = model.BillerAccountId;
            proPayMerchantSettings.JumioApiToken = model.JumioApiToken;
            proPayMerchantSettings.JumioApiSecret = model.JumioApiSecret;
            proPayMerchantSettings.PlaidClientId = model.PlaidClientId;
            proPayMerchantSettings.PlaidSecret = model.PlaidSecret;
            proPayMerchantSettings.PlaidPublicKey = model.PlaidPublicKey;

            _settingService.SaveSetting(proPayMerchantSettings, storeScope);

            //now clear settings cache
            _settingService.ClearCache();

            _notificationService.SuccessNotification(_localizationService.GetResource("Admin.Configuration.Updated"));

            return Configure();
        }

        #endregion

        #region - Register -

        public IActionResult PropayTermsOfService()
        {
            var model = new RegisterModel();
            PrepareMerchantRegisterModel(model);

            return View("~/Plugins/ShopFast.Misc.ProPayMerchant/Views/PropayTermsOfService.cshtml", model);
        }

        public IActionResult RegisterLaunch()
        {
            return View("~/Plugins/ShopFast.Misc.ProPayMerchant/Views/RegisterLaunch.cshtml");
        }

        public IActionResult JumioRegisterPopup()
        {
            return View("~/Plugins/ShopFast.Misc.ProPayMerchant/Views/JumioRegisterPopup.cshtml");
        }

        public ActionResult JumioRegister(RegisterModel model)
        {
            HttpContext.Session.Set(PROPAY_MERCHANT_FORM_ID, model);

            try
            {
                var httpClient = new HttpClient();

                var request = new JObject
                {
                    { "customerInternalReference",_workContext.CurrentCustomer.CustomerGuid.ToString() },
                    { "userReference", _workContext.CurrentCustomer.Id },
                    { "successUrl", $"{_webHelper.GetStoreLocation(true)}jumio-success" }
                };

                var auth = $"{_proPaySettings.JumioApiToken}:{_proPaySettings.JumioApiSecret}";
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(Encoding.UTF8.GetBytes(auth)));
                httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("OLB ProPayMerchantSignup");

                var result = httpClient.PostAsJsonAsync("https://netverify.com/api/v4/initiate", request).Result;

                var response = result.Content.ReadAsStringAsync().Result;
                if (result.IsSuccessStatusCode)
                {
                    var parsed = JObject.Parse(response);

                    //return Redirect(parsed["redirectUrl"].ToString());
                    return Json(new { url = parsed["redirectUrl"].ToString() });
                }

                _logger.Error($"Jumio API was not successful calling jumio api - Status Code: {result.StatusCode}, Error: {response}");
            }
            catch (Exception ex)
            {
                _logger.Error("Unexpected exception calling jumio api", ex);
            }

            return Json(new { url = "/" });
        }

        public ActionResult JumioError()
        {
            _logger.Error($"JumioError::Error validating identity through jumio. Error Code: {Request.Query["errorCode"]}");
            return View("~/Plugins/ShopFast.Misc.ProPayMerchant/Views/RegisterResult.cshtml", new RegisterResultModel { Result = "A Jumio error occurred" });
        }

        public ActionResult JumioSuccess()
        {
            var status = Request.Query["transactionStatus"].ToString();
            if (status != "SUCCESS")
            {
                _logger.Error($"JumioSuccess::Error validating identity through jumio. Error Code: {Request.Query["errorCode"]}");
                return View("~/Plugins/ShopFast.Misc.ProPayMerchant/Views/RegisterResult.cshtml", new RegisterResultModel { Result = "A Jumio error occurred" });
            }

            var model = HttpContext.Session.Get<RegisterModel>(PROPAY_MERCHANT_FORM_ID) ?? new RegisterModel();
            PrepareMerchantRegisterModel(model);

            try
            {
                var httpClient = new HttpClient();

                var auth = $"{_proPaySettings.JumioApiToken}:{_proPaySettings.JumioApiSecret}";
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(Encoding.UTF8.GetBytes(auth)));
                httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("OLB ProPayMerchantSignup");

                var referenceNumber = Request.Query["transactionReference"].ToString();
                var result = httpClient.GetAsync($"https://netverify.com/api/netverify/v2/scans/{referenceNumber}/data/document").Result;

                var response = result.Content.ReadAsStringAsync().Result;

                model.JumioTransactionReference = referenceNumber;

                if (result.IsSuccessStatusCode)
                {
                    model.JumioSuccess = true;
                    var parsed = JObject.Parse(response);

                    model.FirstName = model.FirstName ?? parsed["firstName"].ToString();
                    model.LastName = model.LastName ?? parsed["lastName"].ToString();
                    model.DateOfBirth = model.DateOfBirth ?? DateTime.Parse(parsed["dob"].ToString());

                    var state = _stateProvinceService.GetStateProvinceByAbbreviation(parsed["usState"].ToString());
                    if (state != null)
                    {
                        model.StateProvinceId = model.StateProvinceId != 0 ? model.StateProvinceId : state.Id;
                    }

                    var address = parsed["address"];
                    if (address != null)
                    {
                        model.StreetAddress = model.StreetAddress ?? $"{address["streetNumber"]} {address["streetName"]}";
                        model.City = model.City ?? address["city"].ToString();
                        model.ZipPostalCode ??= address["zip"].ToString();

                        var country = _countryService.GetCountryByThreeLetterIsoCode(address["country"].ToString());
                        if (country != null)
                        {
                            model.BeneficialOwners[0].CountryId = model.BeneficialOwners[0].CountryId != 0 ? model.BeneficialOwners[0].CountryId : country.Id;
                        }
                    }
                }

                _logger.Error($"Jumio API was not successful calling jumio api - Status Code: {result.StatusCode}, Response: {response}");
            }
            catch (Exception ex)
            {
                _logger.Error("Unexpected exception calling jumio api", ex);
            }

            return View("~/Plugins/ShopFast.Misc.ProPayMerchant/Views/Register.cshtml", model);
        }

        public IActionResult Register()
        {
            var model = new RegisterModel();
            PrepareMerchantRegisterModel(model);

            return View("~/Plugins/ShopFast.Misc.ProPayMerchant/Views/Register.cshtml", model);
        }

        [HttpPost]
        [AutoValidateAntiforgeryToken]
        [DisableRequestSizeLimit]
        public async Task<IActionResult> Register(RegisterModel model)
        {
            // run validation
            var validator = new RegisterValidator(_localizationService, _customerSettings, _countryService, _stateProvinceService);
            var validationResult = validator.Validate(model);
            if (!validationResult.IsValid)
            {
                foreach (var error in validationResult.Errors)
                {
                    ModelState.AddModelError(error.PropertyName, error.ErrorMessage);
                }
            }

            // manually validate uploaded files since it doesn't seems like fluentvalidation is doing it

            // we get drivers license from jumio
            //if (model.BeneficialOwner1DriversLicense == null)
            //{
            //    ModelState.AddModelError(nameof(model.BeneficialOwner1DriversLicense), "You must upload the first beneficial owner's drivers' license file");
            //}

            if (model.BusinessProcessingStatement == null)
            {
                ModelState.AddModelError(nameof(model.BusinessProcessingStatement), "You must upload the business processing statement");
            }

            //if (model.AddSecondBeneficialOwner && model.BeneficialOwner2DriversLicense == null)
            //{
            //    ModelState.AddModelError(nameof(model.BeneficialOwner2DriversLicense), "You must the drivers license file for the second beneficiary owner");
            //}

            // get bank account information from plaid
            var (plaidAccount, plaidNumber) = PlaidHelper.GetAchAccountInformation(GetPlaidUrl(), _proPaySettings, model.PlaidPublicToken, model.BankAccountId).Result;

            if (plaidAccount == null || plaidNumber == null)
            {
                ModelState.AddModelError("", "Could not retrieve the selected bank account information");
            }

            if (ModelState.IsValid)
            {
                try
                {
                    //
                    // Send merchant information to CRM first because if propay fails we can avoid creating another
                    // CRM record because we will have the merchant boarding ID from CRM
                    //
                    #region CRM - Insert Merchant Boarding Record
                    if (string.IsNullOrEmpty(model.CrmMerchantBoardingId))
                    {
                        // insert record into crm
                        var crmClient = new CrmApiClient(_proPaySettings.CrmTenantId, _proPaySettings.CrmClientId, _proPaySettings.CrmClientSecret);

                        var registerForm = new JObject();

                        // hidden fields required for underwriting
                        // propay project
                        registerForm.Add("new_selectproject", 2);

                        // primary owner
                        var owner = model.BeneficialOwners.FirstOrDefault();

                        registerForm.Add("new_name", $"{model.FirstName} {model.LastName}");
                        registerForm.Add("new_firstname1", owner.FirstName);
                        registerForm.Add("new_lastname1", owner.LastName);
                        registerForm.Add("new_title", owner.Title);
                        registerForm.Add("new_ssn", owner.SSN);
                        registerForm.Add("new_ownership", owner.Percentage);

                        if (owner.OwnerDateOfBirth.HasValue)
                            registerForm.Add("new_dateofbirth", owner.OwnerDateOfBirth);

                        registerForm.Add("new_homeaddress", owner.Address);
                        registerForm.Add("new_city9", owner.City);
                        registerForm.Add("new_zipcode9", owner.ZipPostalCode);
                        registerForm.Add("new_homephone9", model.DaytimePhone);
                        registerForm.Add("new_emailaddress9", owner.Email);

                        // controlling owner fields
                        registerForm.Add("new_firstname3", owner.FirstName);
                        registerForm.Add("new_lastname3", owner.LastName);
                        registerForm.Add("new_title2", owner.Title);
                        registerForm.Add("new_ownseship2", owner.Percentage);
                        registerForm.Add("new_homeaddress3", owner.Address);
                        registerForm.Add("new_city11", owner.City);
                        registerForm.Add("new_zipcode11", owner.ZipPostalCode);
                        registerForm.Add("new_homephone11", model.DaytimePhone);
                        registerForm.Add("new_emailaddress11", owner.Email);

                        var state = _stateProvinceService.GetStateProvinceById(owner.StateProvinceId);
                        if (state != null)
                        {
                            // TODO: states need to be converted to an int32 somehow
                            //registerForm.Add("new_state9", state.Abbreviation);

                            //// controlling owner fields
                            //registerForm.Add("new_state11", state.Abbreviation);
                        }

                        // default second owner values
                        registerForm.Add("new_firstname2", "");
                        registerForm.Add("new_middleint1", "");
                        registerForm.Add("new_lastname2", "");
                        registerForm.Add("new_title1", "");
                        registerForm.Add("new_ssn1", "");
                        registerForm.Add("new_ownership1", null);
                        registerForm.Add("new_dateofbirth1", null);
                        registerForm.Add("new_homeaddress1", "");
                        registerForm.Add("new_city10", "");
                        registerForm.Add("new_zipcode10", "");
                        registerForm.Add("new_homephone10", "");
                        registerForm.Add("new_emailaddress10", "");
                        registerForm.Add("new_state10", null);
                        registerForm.Add("new_dlstate10", null);
                        registerForm.Add("new_drivinglicensenumber2", "");
                        registerForm.Add("new_drivinglicenseexpdate2", null);

                        if (model.AddSecondBeneficialOwner && model.BeneficialOwners.Count == 2)
                        {
                            var secondOwner = model.BeneficialOwners[1];

                            registerForm["new_firstname2"] = secondOwner.FirstName;
                            registerForm["new_lastname2"] = secondOwner.LastName;
                            registerForm["new_title1"] = secondOwner.Title;
                            registerForm["new_ssn1"] = secondOwner.SSN;
                            registerForm["new_ownership1"] = secondOwner.Percentage;
                            registerForm["new_dateofbirth1"] = secondOwner.OwnerDateOfBirth;
                            registerForm["new_homeaddress1"] = secondOwner.Address;
                            registerForm["new_city10"] = secondOwner.City;
                            registerForm["new_zipcode10"] = secondOwner.ZipPostalCode;
                            registerForm["new_emailaddress10"] = secondOwner.Email;
                            //registerForm["new_state10"] = null;
                            //registerForm["new_dlstate10"] = null;
                            //registerForm["new_drivinglicensenumber2"] = "";
                            //registerForm["new_drivinglicenseexpdate2"] = null;
                        }

                        // business info
                        registerForm.Add("new_corporateinfo", model.IsLegalAddressDifferentThanBusinessAddress);
                        if (model.IsLegalAddressDifferentThanBusinessAddress)
                        {
                            registerForm.Add("new_corporateaddress", model.LegalEntityStreetAddress);
                            registerForm.Add("new_city3", model.LegalEntityCity);
                            registerForm.Add("new_zipcode3", model.LegalEntityZip);
                        }

                        registerForm.Add("new_businessemailaddress", owner.Email);
                        registerForm.Add("new_businessphonenumber", model.BusinessPhone);

                        registerForm.Add("new_locationaddress1", model.BusinessStreetAddress);

                        registerForm.Add("new_companyname", model.BusinessLegalName);
                        //registerForm.Add("new_dbaname", model.BusinessName);
                        registerForm.Add("new_federaltaxid", model.EIN);
                        //registerForm.Add("new_corporationtype", model.BusinessEntityType); // this is on new_merchantpartner
                        registerForm.Add("new_lengthoftimeinbusinessyears", model.NumberOfYearsInBusiness.ToString());
                        registerForm.Add("new_natureofbusinesscsv", model.BusinessDescription);

                        registerForm.Add("new_merchantuse", model.UseFulfillmentHouse);
                        if (model.UseFulfillmentHouse)
                        {
                            registerForm.Add("new_name3", model.FulfillmentCompanyName);
                            registerForm.Add("new_contactnumber3", model.FulfillmentContactPhoneNumber);
                        }

                        registerForm.Add("new_internetordersvaluein", model.OnlineTransactionPercent);
                        registerForm.Add("new_telephoneordersvaluein", model.KeyedCardPercent);

                        registerForm.Add("new_doyouowntheproductinventory1", model.OwnProductInventory);

                        registerForm.Add("new_delivermerchandisetothecustomer", model.DaysToDeliverToCustomer);
                        registerForm.Add("new_whenisthecustomerscharged", model.TimeCustomerIsCharged);

                        registerForm.Add("new_howmanychargebacksdidyouhaveforthisprevio", model.NumberOfChargebacksInLast12Months);
                        registerForm.Add("new_whatwasthetotaldollaramountofthosechargeb", model.AmountOfChargeBacksInLast12Months);

                        registerForm.Add("new_whatpercentagedoyouselltobusinessconsumer", model.PercentageSoldToBusiness);
                        registerForm.Add("new_whatpercentagedoyouselltopublic", model.PercentageSoldToPublic);

                        // new_merchantpartner entity
                        registerForm.Add("new_whatisthephysicaladdressofyourbusiness", model.BusinessStreetAddress);
                        //registerForm.Add("new_address", model.BusinessStreetAddress);
                        //registerForm.Add("new_city", model.BusinessCity);
                        //registerForm.Add("new_zipcode", model.BusinessZipPostalCode);

                        var businessState = _stateProvinceService.GetStateProvinceById(model.BusinessStateProvinceId);
                        if (businessState != null)
                        {
                            // TODO: states need to be converted to an int32 somehow
                            //registerForm.Add("new_state", businessState.Abbreviation);
                        }

                        registerForm.Add("new_monthlypaymentcardvolume", Convert.ToDecimal(model.MonthlyBankCardVolume));
                        registerForm.Add("new_averageticket", Convert.ToDecimal(model.AverageTicket));
                        registerForm.Add("new_highestticket", Convert.ToDecimal(model.HighestTicket));

                        registerForm.Add("new_websiteaddress", model.WebsiteUrl);

                        registerForm.Add("new_bankname", plaidAccount.Name);

                        registerForm.Add("new_pleasedescribeyourrefundpolicy", model.RefundPolicy);

                        // insert record and return new entity so that we can retrieve the merchant boarding ID that is generated
                        var crmInsertResponse = await crmClient.HttpClient.PostAsync("https://securepay.crm.dynamics.com/api/data/v9.1/new_merchantboardings?$select=new_merchantboardingid", new StringContent(registerForm.ToString(), Encoding.UTF8, "application/json"));
                        var crmInsertResponseContent = await crmInsertResponse.Content.ReadAsStringAsync();

                        if (!crmInsertResponse.IsSuccessStatusCode)
                        {
                            _logger.Error($"Erroring inserting new merchant record into CRM, Status Code: {crmInsertResponse.StatusCode}, Response: {crmInsertResponseContent}");
                            throw new NopException("Erroring inserting merchant record");
                        }

                        // extract merchant ID so we can upload attachments
                        var crmInsertEntity = JObject.Parse(crmInsertResponseContent);
                        var merchantId = crmInsertEntity["new_merchantboardingid"].ToString();

                        // set model merchant boarding ID
                        model.CrmMerchantBoardingId = merchantId;

                        //
                        // create merchantpartner entity for business information????
                        //

                        var updateForm = new JObject();

                        // upload business processing document
                        var note = new NoteEntity
                        {
                            Text = "Business Processing Statement",
                            Subject = "cardprocessingstatement",
                            LookupEntity = "new_merchantboarding",
                            EntityId = merchantId
                        };

                        bool noteResult = await UploadFileInNote(note, model.BusinessProcessingStatement);
                        if (noteResult)
                            updateForm.Add("new_cardprocessingstatement", true);

                        // retrieve drivers license images from jumio and add to CRM
                        var httpClient = new HttpClient();

                        var auth = $"{_proPaySettings.JumioApiToken}:{_proPaySettings.JumioApiSecret}";
                        httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(Encoding.UTF8.GetBytes(auth)));
                        httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("OLB ProPayMerchantSignup");

                        var referenceNumber = model.JumioTransactionReference;
                        var jumioImageResult = httpClient.GetAsync($"https://netverify.com/api/netverify/v2/scans/{referenceNumber}/images").Result;
                        var jumioImageContent = jumioImageResult.Content.ReadAsStringAsync().Result;

                        if (!jumioImageResult.IsSuccessStatusCode)
                        {
                            _logger.Error($"Erroring retrieving jumio images, Status Code: {jumioImageResult.StatusCode}, Response: {jumioImageContent}");
                            throw new NopException("Erroring retrieving Jumio images");
                        }

                        updateForm.Add("new_pbo1_drivinglicense", true);

                        var jsonContent = JObject.Parse(jumioImageContent);
                        foreach (var image in jsonContent["images"])
                        {
                            var imageResult = httpClient.GetAsync(image["href"].ToString()).Result;
                            if (imageResult.IsSuccessStatusCode)
                            {
                                var ms = new MemoryStream();
                                var stream = imageResult.Content.ReadAsStreamAsync().Result;
                                stream.CopyTo(ms);

                                var classifier = image["classifier"];

                                var license = new NoteEntity
                                {
                                    Text = $"Owner 1 Drivers License - {classifier}",
                                    Subject = $"PBO1_DrivingLicense-{classifier}",
                                    LookupEntity = "new_merchantboarding",
                                    EntityId = merchantId
                                };


                                bool licenseResult = await UploadFileInNote(license, ms);
                            }
                        }
                        //var owner1DriversLicense = new NoteEntity
                        //{
                        //    Text = "Owner 1 Drivers License",
                        //    Subject = "PBO1_DrivingLicense",
                        //    LookupEntity = "new_merchantboarding",
                        //    EntityId = merchantId
                        //};

                        //bool owner1DriversLicenseResult = await UploadFileInNote(owner1DriversLicense, model.BeneficialOwner1DriversLicense);
                        //if (owner1DriversLicenseResult)
                        //    updateForm.Add("new_pbo1_drivinglicense", true);

                        // upload owner 2 drivers license
                        if (model.AddSecondBeneficialOwner && model.BeneficialOwner2DriversLicense != null)
                        {
                            var owner2DriversLicense = new NoteEntity
                            {
                                Text = "Owner 2 Drivers License",
                                Subject = "PBO2_DrivingLicense",
                                LookupEntity = "new_merchantboarding",
                                EntityId = merchantId
                            };

                            bool owner2DriversLicenseResult = await UploadFileInNote(owner2DriversLicense, model.BeneficialOwner2DriversLicense);
                            if (owner2DriversLicenseResult)
                                updateForm.Add("new_pbo2_drivinglicense", true);
                        }

                        var crmUpdateResult = await crmClient.HttpClient.PatchAsync($"https://securepay.crm.dynamics.com/api/data/v9.1/new_merchantboardings({merchantId})", new StringContent(updateForm.ToString(), Encoding.UTF8, "application/json"));
                        if (!crmUpdateResult.IsSuccessStatusCode)
                        {
                            var content = await crmUpdateResult.Content.ReadAsStringAsync();

                            _logger.Warning($"Error adding attachments to CRM.  Manual action needs to be taken to upload these documents, Response: {content}");
                        }
                    }
                    #endregion

                    //
                    // Send merchant information to Propay 
                    //
                    var proPayMerchantSettings = _settingService.LoadSetting<ProPayMerchantSettings>(_storeContext.CurrentStore.Id);

                    //prepares a request xml to create ProPay merchant account
                    var propayRequest = ProPayHelper.CreateProPayRequest(model, proPayMerchantSettings, plaidAccount, plaidNumber, _stateProvinceService, _countryService);

                    //sends a request to ProPay for creating new merchant account
                    var responseXml = ProPayHelper.SendRequest(GetProPayUrl(), propayRequest);

                    //_logger.Information("Merchant Response Xml: " + responseXml.ToString());
                    var xmlDocument = new XmlDocument();
                    xmlDocument.LoadXml(responseXml);
                    var responseStatus = xmlDocument.SelectSingleNode("XMLResponse/XMLTrans/status").InnerText;

                    // 00 = successful
                    // 66 = account created but identity was not able to be verified (requires additional validation)
                    // form must be submitted for manual identity validation to activate the account
                    if (responseStatus == "00" || responseStatus == "66")
                    {
                        // create new user in nopcommerce
                        var customer = _workContext.CurrentCustomer;
                        customer.RegisteredInStoreId = _storeContext.CurrentStore.Id;

                        var isApproved = _customerSettings.UserRegistrationType == UserRegistrationType.Standard;
                        var registrationRequest = new CustomerRegistrationRequest(customer,
                            model.Email,
                            model.Email,
                            model.Password,
                            _customerSettings.DefaultPasswordFormat,
                            _storeContext.CurrentStore.Id,
                            isApproved);

                        var registrationResult = _customerRegistrationService.RegisterCustomer(registrationRequest);

                        if (registrationResult.Success)
                        {
                            // create vendor
                            // associate vendor with customer
                            // add vendor role to customer
                            var vendor = new Nop.Core.Domain.Vendors.Vendor
                            {
                                Active = true,
                                Name = model.BusinessLegalName,
                                Email = model.Email
                            };

                            _vendorService.InsertVendor(vendor);

                            customer.VendorId = vendor.Id;

                            var vendorRole = _customerService.GetCustomerRoleBySystemName(NopCustomerDefaults.VendorsRoleName);


                            _customerService.AddCustomerRoleMapping(new CustomerCustomerRoleMapping { CustomerId = customer.Id, CustomerRoleId = vendorRole.Id });

                            _customerService.UpdateCustomer(customer);

                            //form fields
                            _genericAttributeService.SaveAttribute(customer, NopCustomerDefaults.FirstNameAttribute,
                                model.FirstName);
                            _genericAttributeService.SaveAttribute(customer, NopCustomerDefaults.LastNameAttribute,
                                model.LastName);

                            if (_customerSettings.DateOfBirthEnabled)
                            {
                                _genericAttributeService.SaveAttribute(customer,
                                    NopCustomerDefaults.DateOfBirthAttribute, model.DateOfBirth);
                            }

                            if (_customerSettings.StreetAddressEnabled)
                                _genericAttributeService.SaveAttribute(customer,
                                    NopCustomerDefaults.StreetAddressAttribute, model.StreetAddress);
                            if (_customerSettings.StreetAddress2Enabled)
                                _genericAttributeService.SaveAttribute(customer,
                                    NopCustomerDefaults.StreetAddress2Attribute, model.StreetAddress2);
                            if (_customerSettings.ZipPostalCodeEnabled)
                                _genericAttributeService.SaveAttribute(customer,
                                    NopCustomerDefaults.ZipPostalCodeAttribute, model.ZipPostalCode);
                            if (_customerSettings.CityEnabled)
                                _genericAttributeService.SaveAttribute(customer, NopCustomerDefaults.CityAttribute,
                                    model.City);
                            if (_customerSettings.CountryEnabled)
                            {
                                var country = _countryService.GetCountryByThreeLetterIsoCode("USA");
                                _genericAttributeService.SaveAttribute(customer, NopCustomerDefaults.CountryIdAttribute,
                                    country.Id);
                            }

                            if (_customerSettings.CountryEnabled && _customerSettings.StateProvinceEnabled)
                                _genericAttributeService.SaveAttribute(customer,
                                    NopCustomerDefaults.StateProvinceIdAttribute,
                                    model.StateProvinceId);
                            if (_customerSettings.PhoneEnabled)
                                _genericAttributeService.SaveAttribute(customer, NopCustomerDefaults.PhoneAttribute,
                                    model.DaytimePhone);

                            //login customer now
                            if (isApproved)
                                _authenticationService.SignIn(customer, true);

                            //insert default address (if possible)
                            var defaultAddress = new Address
                            {
                                FirstName = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.FirstNameAttribute),
                                LastName = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.LastNameAttribute),
                                Email = customer.Email,
                                Company = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.CompanyAttribute),
                                CountryId = _genericAttributeService.GetAttribute<int>(customer, NopCustomerDefaults.CountryIdAttribute) > 0
                                    ? (int?)_genericAttributeService.GetAttribute<int>(customer, NopCustomerDefaults.CountryIdAttribute)
                                    : null,
                                StateProvinceId = _genericAttributeService.GetAttribute<int>(customer, NopCustomerDefaults.StateProvinceIdAttribute) > 0
                                    ? (int?)_genericAttributeService.GetAttribute<int>(customer, NopCustomerDefaults.StateProvinceIdAttribute)
                                    : null,
                                County = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.CountyAttribute),
                                City = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.CityAttribute),
                                Address1 = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.StreetAddressAttribute),
                                Address2 = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.StreetAddress2Attribute),
                                ZipPostalCode = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.ZipPostalCodeAttribute),
                                PhoneNumber = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.PhoneAttribute),
                                FaxNumber = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.FaxAttribute),
                                CreatedOnUtc = customer.CreatedOnUtc
                            };
                            if (_addressService.IsAddressValid(defaultAddress))
                            {
                                //some validation
                                if (defaultAddress.CountryId == 0)
                                    defaultAddress.CountryId = null;
                                if (defaultAddress.StateProvinceId == 0)
                                    defaultAddress.StateProvinceId = null;
                                //set default address
                                //customer.Addresses.Add(defaultAddress);

                                _addressService.InsertAddress(defaultAddress);

                                _customerService.InsertCustomerAddress(customer, defaultAddress);

                                customer.BillingAddressId = defaultAddress.Id;
                                customer.ShippingAddressId = defaultAddress.Id;

                                _customerService.UpdateCustomer(customer);
                            }

                            //notifications
                            if (_customerSettings.NotifyNewCustomerRegistration)
                                _workflowMessageService.SendCustomerRegisteredNotificationMessage(customer, _localizationSettings.DefaultAdminLanguageId);

                            //raise event       
                            _eventPublisher.Publish(new CustomerRegisteredEvent(customer));

                            //send customer welcome message
                            _workflowMessageService.SendCustomerWelcomeMessage(customer, _workContext.WorkingLanguage.Id);

                            // clear session data
                            HttpContext.Session.Remove(PROPAY_MERCHANT_FORM_ID);

                            if (responseStatus == "66")
                            {
                                return View("~/Plugins/ShopFast.Misc.ProPayMerchant/Views/RegisterResult.cshtml",
                                    new RegisterResultModel
                                    {
                                        Result =
                                            "Your account was created successfully but your identity could not be verified.  Additional action is required.  Please contact support to finish your application"
                                    });
                            }

                            return View("~/Plugins/ShopFast.Misc.ProPayMerchant/Views/RegisterResult.cshtml",
                                new RegisterResultModel
                                {
                                    Result = _localizationService.GetResource("Plugins.Misc.ProPayMerchant.Signup.Result")
                                });

                            #region Create Merchant Profile - only needed if we are storing CC info on the propay side

                            ////sets a merchant account identifier
                            //var merchantAccountId = xmlDocument.SelectSingleNode("XMLResponse/XMLTrans/accntNum").InnerText;

                            ////prepares a request xml to create merchant profile in ProtectPay
                            //requestXml.Clear();
                            //requestXml.Append("<con:CreateMerchantProfile>");
                            ////identification information
                            //requestXml.Append("<con:identification>");
                            //requestXml.Append(
                            //    $"<typ:AuthenticationToken>{proPayMerchantSettings.AuthenticationToken}</typ:AuthenticationToken>");
                            //requestXml.Append(
                            //    $"<typ:BillerAccountId>{proPayMerchantSettings.BillerAccountId}</typ:BillerAccountId>");
                            //requestXml.Append("</con:identification>");
                            ////payment processor information
                            //requestXml.Append("<con:merchantProfile>");
                            //requestXml.Append("<prop:PaymentProcessor>LegacyProPay</prop:PaymentProcessor>");
                            //requestXml.Append("<prop:ProcessorData>");
                            ////certification string
                            //requestXml.Append("<prop:ProcessorDatum>");
                            //requestXml.Append("<prop:ProcessorField>certStr</prop:ProcessorField>");
                            //requestXml.Append($"<prop:Value>{proPayMerchantSettings.CertString}</prop:Value>");
                            //requestXml.Append("</prop:ProcessorDatum>");
                            ////term identifier
                            //requestXml.Append("<prop:ProcessorDatum>");
                            //requestXml.Append("<prop:ProcessorField>termId</prop:ProcessorField>");
                            //requestXml.Append($"<prop:Value>{proPayMerchantSettings.TermId}</prop:Value>");
                            //requestXml.Append("</prop:ProcessorDatum>");
                            ////merchant account identifier
                            //requestXml.Append("<prop:ProcessorDatum>");
                            //requestXml.Append("<prop:ProcessorField>accountNum</prop:ProcessorField>");
                            //requestXml.Append($"<prop:Value>{merchantAccountId}</prop:Value>");
                            //requestXml.Append("</prop:ProcessorDatum>");
                            //requestXml.Append("</prop:ProcessorData>");
                            ////profile name
                            //requestXml.Append($"<prop:ProfileName>{accountExternalId}</prop:ProfileName>");
                            //requestXml.Append("</con:merchantProfile>");
                            //requestXml.Append("</con:CreateMerchantProfile>");

                            ////sends a request to ProtectPay for creating merchant profile
                            //var responseXml1 = ProtectPayHelper.SendRequest((proPayMerchantSettings.UseSandbox ?
                            //        "https://protectpaytest.propay.com/api/sps.svc" : "https://api.propay.com/api/sps.svc"),
                            //    "CreateMerchantProfile", requestXml.ToString());

                            //var xmlDocument1 = new XmlDocument();
                            //xmlDocument1.LoadXml(responseXml1);
                            ////sets xml namespaces to read values from response
                            //var xmlnsManager = new XmlNamespaceManager(xmlDocument1.NameTable);
                            //xmlnsManager.AddNamespace("s", "http://schemas.xmlsoap.org/soap/envelope/");
                            //xmlnsManager.AddNamespace("c", "http://propay.com/SPS/contracts");
                            //xmlnsManager.AddNamespace("a", "http://schemas.datacontract.org/2004/07/ProPay.Contracts.SPS.External");
                            //xmlnsManager.AddNamespace("b", "http://propay.com/SPS/types");
                            ////checks a result value from response xml
                            //string resultXmlPath = "/s:Envelope/s:Body/c:CreateMerchantProfileResponse/c:CreateMerchantProfileResult/";
                            //var resultValue = xmlDocument1.GetElementsByTagName("b:ResultValue")[0].InnerText;

                            //switch (resultValue)
                            //{
                            //    case "SUCCESS":
                            //        {
                            //            //sets a merchant profile identifierdd
                            //            //var merchantProfileId = xmlDocument1.SelectSingleNode(string.Concat(resultXmlPath, "a:ProfileId"), xmlnsManager).InnerText;
                            //            var merchantProfileId = xmlDocument1.GetElementsByTagName("a:ProfileId")[0].InnerText;

                            //            // create new user in nopcommerce
                            //            var customer = _workContext.CurrentCustomer;
                            //            customer.RegisteredInStoreId = _storeContext.CurrentStore.Id;

                            //            var isApproved = _customerSettings.UserRegistrationType == UserRegistrationType.Standard;
                            //            var registrationRequest = new CustomerRegistrationRequest(customer,
                            //                model.Email,
                            //                model.Email,
                            //                model.Password,
                            //                _customerSettings.DefaultPasswordFormat,
                            //                _storeContext.CurrentStore.Id,
                            //                isApproved);

                            //            var registrationResult = _customerRegistrationService.RegisterCustomer(registrationRequest);

                            //            if (registrationResult.Success)
                            //            {
                            //                // save merchant profile ID to the customer
                            //                _genericAttributeService.SaveAttribute(customer, Constants.ProPayMerchantProfileId, merchantProfileId);

                            //                //form fields
                            //                _genericAttributeService.SaveAttribute(customer, NopCustomerDefaults.FirstNameAttribute, model.FirstName);
                            //                _genericAttributeService.SaveAttribute(customer, NopCustomerDefaults.LastNameAttribute, model.LastName);

                            //                if (_customerSettings.DateOfBirthEnabled)
                            //                {
                            //                    _genericAttributeService.SaveAttribute(customer, NopCustomerDefaults.DateOfBirthAttribute, model.DateOfBirth);
                            //                }

                            //                if (_customerSettings.StreetAddressEnabled)
                            //                    _genericAttributeService.SaveAttribute(customer, NopCustomerDefaults.StreetAddressAttribute, model.StreetAddress);
                            //                if (_customerSettings.StreetAddress2Enabled)
                            //                    _genericAttributeService.SaveAttribute(customer, NopCustomerDefaults.StreetAddress2Attribute, model.StreetAddress2);
                            //                if (_customerSettings.ZipPostalCodeEnabled)
                            //                    _genericAttributeService.SaveAttribute(customer, NopCustomerDefaults.ZipPostalCodeAttribute, model.ZipPostalCode);
                            //                if (_customerSettings.CityEnabled)
                            //                    _genericAttributeService.SaveAttribute(customer, NopCustomerDefaults.CityAttribute, model.City);
                            //                if (_customerSettings.CountryEnabled)
                            //                {
                            //                    var country = _countryService.GetCountryByThreeLetterIsoCode("USA");
                            //                    _genericAttributeService.SaveAttribute(customer, NopCustomerDefaults.CountryIdAttribute, country.Id);
                            //                }

                            //                if (_customerSettings.CountryEnabled && _customerSettings.StateProvinceEnabled)
                            //                    _genericAttributeService.SaveAttribute(customer, NopCustomerDefaults.StateProvinceIdAttribute,
                            //                        model.StateProvinceId);
                            //                if (_customerSettings.PhoneEnabled)
                            //                    _genericAttributeService.SaveAttribute(customer, NopCustomerDefaults.PhoneAttribute, model.DaytimePhone);

                            //                //login customer now
                            //                if (isApproved)
                            //                    _authenticationService.SignIn(customer, true);

                            //                //insert default address (if possible)
                            //                var defaultAddress = new Address
                            //                {
                            //                    FirstName = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.FirstNameAttribute),
                            //                    LastName = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.LastNameAttribute),
                            //                    Email = customer.Email,
                            //                    Company = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.CompanyAttribute),
                            //                    CountryId = _genericAttributeService.GetAttribute<int>(customer, NopCustomerDefaults.CountryIdAttribute) > 0
                            //                        ? (int?)_genericAttributeService.GetAttribute<int>(customer, NopCustomerDefaults.CountryIdAttribute)
                            //                        : null,
                            //                    StateProvinceId = _genericAttributeService.GetAttribute<int>(customer, NopCustomerDefaults.StateProvinceIdAttribute) > 0
                            //                        ? (int?)_genericAttributeService.GetAttribute<int>(customer, NopCustomerDefaults.StateProvinceIdAttribute)
                            //                        : null,
                            //                    County = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.CountyAttribute),
                            //                    City = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.CityAttribute),
                            //                    Address1 = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.StreetAddressAttribute),
                            //                    Address2 = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.StreetAddress2Attribute),
                            //                    ZipPostalCode = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.ZipPostalCodeAttribute),
                            //                    PhoneNumber = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.PhoneAttribute),
                            //                    FaxNumber = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.FaxAttribute),
                            //                    CreatedOnUtc = customer.CreatedOnUtc
                            //                };

                            //                if (_addressService.IsAddressValid(defaultAddress))
                            //                {
                            //                    //some validation
                            //                    if (defaultAddress.CountryId == 0)
                            //                        defaultAddress.CountryId = null;
                            //                    if (defaultAddress.StateProvinceId == 0)
                            //                        defaultAddress.StateProvinceId = null;
                            //                    //set default address
                            //                    //customer.Addresses.Add(defaultAddress);
                            //                    customer.CustomerAddressMappings.Add(new CustomerAddressMapping { Address = defaultAddress });
                            //                    customer.BillingAddress = defaultAddress;
                            //                    customer.ShippingAddress = defaultAddress;
                            //                    _customerService.UpdateCustomer(customer);
                            //                }
                            //            }

                            //            //raise event       
                            //            _eventPublisher.Publish(new CustomerRegisteredEvent(customer));

                            //            switch (_customerSettings.UserRegistrationType)
                            //            {
                            //                case UserRegistrationType.EmailValidation:
                            //                    {
                            //                        //email validation message
                            //                        _genericAttributeService.SaveAttribute(customer, NopCustomerDefaults.AccountActivationTokenAttribute, Guid.NewGuid().ToString());
                            //                        _workflowMessageService.SendCustomerEmailValidationMessage(customer, _workContext.WorkingLanguage.Id);

                            //                        //result
                            //                        return RedirectToRoute("RegisterResult",
                            //                            new { resultId = (int)UserRegistrationType.EmailValidation });
                            //                    }
                            //                case UserRegistrationType.AdminApproval:
                            //                    {
                            //                        return RedirectToRoute("RegisterResult",
                            //                            new { resultId = (int)UserRegistrationType.AdminApproval });
                            //                    }
                            //                case UserRegistrationType.Standard:
                            //                    {
                            //                        //send customer welcome message
                            //                        _workflowMessageService.SendCustomerWelcomeMessage(customer, _workContext.WorkingLanguage.Id);

                            //                        return View("~/Plugins/ShopFast.Misc.ProPayMerchant/Views/RegisterResult.cshtml",
                            //                            new RegisterResultModel { Result = _localizationService.GetResource("Plugins.Misc.ProPayMerchant.Signup.Result") });
                            //                    }
                            //                default:
                            //                    {
                            //                        return RedirectToRoute("Homepage");
                            //                    }
                            //            }
                            //        }
                            //    case "FAILURE":
                            //        {
                            //            ModelState.AddModelError("", xmlDocument1.ChildNodes[0].FirstChild.ChildNodes[0].FirstChild.ChildNodes[1].FirstChild.NextSibling.InnerText);
                            //            break;
                            //        }
                            //}

                            #endregion
                        }

                        return View("~/Plugins/ShopFast.Misc.ProPayMerchant/Views/RegisterResult.cshtml",
                            new RegisterResultModel
                            {
                                Result = "Your Propay account was created successfully but your Retailer Cloud account could you be created for the following reason:" + registrationResult.Errors[0]
                            });
                    }
                    else
                    {
                        _logger.Error($"Error occurred when calling propay API, Response Status: {responseStatus}");
                        ModelState.AddModelError("", $"Error has occured.  Response status code: {responseStatus}");
                    }
                }
                catch (Exception ex)
                {
                    _logger.Error($"Error occurred when processing the merchant on boarding form", ex);
                    ModelState.AddModelError("", string.Format(_localizationService.GetResource("Plugins.Misc.ProPayMerchant.TechnicalError"), ex.Message));
                }
            }

            //If we got this far, something failed, redisplay form
            PrepareMerchantRegisterModel(model);
            return View("~/Plugins/ShopFast.Misc.ProPayMerchant/Views/Register.cshtml", model);
        }

        private string GetPlaidUrl()
        {
            return _proPaySettings.UseSandbox ? "https://sandbox.plaid.com" : "https://production.plaid.com";
        }

        private string GetProPayUrl()
        {
            return _proPaySettings.UseSandbox ? "https://xmltest.propay.com/api/propayapi.aspx" : "https://epay.propay.com/api/propayapi.aspx";
        }

        private async Task<bool> UploadFileInNote(NoteEntity model, MemoryStream memoryStream)
        {
            try
            {
                var crmHttpClient = new CrmApiClient(_proPaySettings.CrmTenantId, _proPaySettings.CrmClientId, _proPaySettings.CrmClientSecret);

                // check if any file exists based on subject. if it does then just update the documentbody
                // else add record in note
                var queryOptions = "?$select=annotationid&$filter=subject eq '" + model.Subject + "' and _objectid_value eq " + model.EntityId;

                var noteResponse = await crmHttpClient.HttpClient.GetAsync("https://securepay.crm.dynamics.com/api/data/v9.1/annotations" + queryOptions);

                var retrievedData = new JObject();
                var note = new JObject();

                if (noteResponse.StatusCode == HttpStatusCode.OK)
                {
                    retrievedData = JsonConvert.DeserializeObject<JObject>(await noteResponse.Content.ReadAsStringAsync());
                }

                if (retrievedData != null)
                {
                    var jvalue = retrievedData.GetValue("value");

                    var fileData = Convert.ToBase64String(memoryStream.ToArray());

                    if (jvalue != null && jvalue.Count() > 0)
                    {
                        // update note
                        string annotationId = jvalue[0].SelectToken("annotationid").ToString();
                        string annotationUri = "https://securepay.crm.dynamics.com/api/data/v9.1/annotations(" + annotationId + ")";

                        note.Add("filename", model.Text);
                        note.Add("documentbody", fileData);

                        HttpRequestMessage updateRequestNote = new HttpRequestMessage(new HttpMethod("PATCH"), annotationUri);
                        updateRequestNote.Content = new StringContent(note.ToString(), Encoding.UTF8, "application/json");

                        HttpResponseMessage updateNoteResponse = await crmHttpClient.HttpClient.SendAsync(updateRequestNote);

                        if (updateNoteResponse.IsSuccessStatusCode)
                        {
                            return true;
                        }

                        throw new NopException("Error updating attachment");
                    }
                    else
                    {
                        // make a new entry in note
                        note.Add("notetext", model.Text);
                        note.Add("subject", model.Subject);
                        note.Add("filename", model.Text);
                        note.Add($"objectid_{model.LookupEntity}@odata.bind", $"/{model.LookupEntity}s({model.EntityId})");
                        note.Add("documentbody", fileData);

                        var createRequestNote = new HttpRequestMessage(HttpMethod.Post, "https://securepay.crm.dynamics.com/api/data/v9.1/annotations")
                        {
                            Content = new StringContent(note.ToString(), Encoding.UTF8, "application/json")
                        };

                        var createNoteResponse = await crmHttpClient.HttpClient.SendAsync(createRequestNote);

                        if (createNoteResponse.IsSuccessStatusCode)
                        {
                            return true;
                        }

                        throw new NopException("Error creating new attachment");
                    }
                }

                return false;
            }
            catch (Exception ex)
            {
                _logger.Error($"UploadFileInNote - subject :- {model.Subject}, fileName :- {model.Text}, Error :- {ex.Message} -- {ex.InnerException} -- {ex.StackTrace}");
                return false;
            }
        }

        private async Task<bool> UploadFileInNote(NoteEntity model, IFormFile file)
        {
            var memoryStream = new MemoryStream();

            await file.CopyToAsync(memoryStream);

            return await UploadFileInNote(model, memoryStream);
        }

        #endregion

        #endregion
    }
}
