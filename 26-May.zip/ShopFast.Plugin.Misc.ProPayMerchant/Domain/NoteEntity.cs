﻿namespace ShopFast.Plugin.Misc.ProPayMerchant.Domain
{
    public class NoteEntity
    {
        public string Text { get; internal set; }
        public string Subject { get; internal set; }
        public string LookupEntity { get; internal set; }
        public string EntityId { get; internal set; }
    }
}
