using ShopFast.Plugin.BD.CrowdPay.Domain;
using System.Collections.Generic;

namespace ShopFast.Plugin.BD.CrowdPay.Services.Interfaces
{
    public partial interface IInvestorDocumentService
    {
        /// <summary>
        /// Inserts an InvestorDocument Details
        /// </summary>
        /// <param name="investorDocument">InvestorDocument</param>
        void InsertInvestorDocument(InvestorDocument investorDocument);

        /// <summary>
        /// Updates an InvestorDocument Details
        /// </summary>
        /// <param name="investorDocument">InvestorDocument</param>
        void UpdateInvestorDocument(InvestorDocument investorDocument);


        /// <summary>
        /// Deletes an InvestorDocument Details
        /// </summary>
        /// <param name="investorDocument">InvestorDocument</param>
        void DeleteInvestorDocument(InvestorDocument investorDocument);

        /// <summary>
        /// Gets an InvestorDocument by customer identifier
        /// </summary>
        /// <param name="customerId">customer identifier</param>
        /// <returns>investor documents by customer identifier</returns>
        InvestorDocument GetInvestorDocumentByCustomerId(int customerId);

        /// <summary>
        /// Gets an InvestorDocuments by customer identifier
        /// </summary>
        /// <param name="customerId"></param>
        /// <returns></returns>
        IList<InvestorDocument> GetDocumentsByCustomerId(int customerId);
    }
}
