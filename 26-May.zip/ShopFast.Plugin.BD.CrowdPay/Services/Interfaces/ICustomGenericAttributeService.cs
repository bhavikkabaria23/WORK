﻿using System.Collections.Generic;
using Nop.Core.Domain.Common;

namespace ShopFast.Plugin.BD.CrowdPay.Services.Interfaces
{
   public interface ICustomGenericAttributeService
    {
        void DeleteAttriutes(params string[] attributes);

        GenericAttribute GetAttributeByNameForCurrentCustomer(string attributeName);

       IList<GenericAttribute> GetAttributesByName(string attributeName);

        void SaveGenericAttirubteValue(string attributeName, string value);
    }
}
