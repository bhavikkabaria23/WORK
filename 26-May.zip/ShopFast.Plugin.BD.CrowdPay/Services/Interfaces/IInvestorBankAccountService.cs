using ShopFast.Plugin.BD.CrowdPay.Domain;

namespace ShopFast.Plugin.BD.CrowdPay.Services.Interfaces
{
    public partial interface IInvestorBankAccountService
    {
        /// <summary>
        /// Inserts an InvestorBankAccount Details
        /// </summary>
        /// <param name="investorbankAccount">InvestorBankAccount</param>
        void InsertInvestorBankAccount(InvestorBankAccount investorbankAccount);

        /// <summary>
        /// Updates an InvestorBankAccount Details
        /// </summary>
        /// <param name="investorbankAccount">InvestorBankAccount</param>
        void UpdateInvestorBankAccount(InvestorBankAccount investorbankAccount);

        /// <summary>
        /// Deletes an InvestorBankAccount Details
        /// </summary>
        /// <param name="investorbankAccount">InvestorBankAccount</param>
        void DeleteInvestorBankAccount(InvestorBankAccount investorbankAccount);

        /// <summary>
        /// Gets an InvestorBankAccount by customer identifier
        /// </summary>
        /// <param name="customerId">customer identifier</param>
        InvestorBankAccount GetInvestorBankAccountById(int customerId);
    }
}
