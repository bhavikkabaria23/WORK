﻿using Nop.Core.Domain.Common;
using Nop.Services.Common;

namespace ShopFast.Plugin.BD.CrowdPay.Services.Interfaces
{
    public interface ICustomAddressAttributeParser : IAddressAttributeParser
    {
        string UpdateAddressAttribute(string attributesXml, AddressAttribute attribute, string value);

        string UpdateCustomAddressAttributes(string attributesXml, string attrName, string value);

        string ParseCustomAddressAttributesValues(string attributesXml, string attrName);
    }
}
