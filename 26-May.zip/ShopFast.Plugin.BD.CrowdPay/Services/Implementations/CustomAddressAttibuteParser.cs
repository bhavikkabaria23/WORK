﻿using System;
using System.Diagnostics;
using System.Xml;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Common;
using Nop.Services.Common;
using Nop.Services.Localization;
using ShopFast.Plugin.BD.CrowdPay.Services.Interfaces;

namespace ShopFast.Plugin.BD.CrowdPay.Services.Implementations
{
    public class CustomAddressAttibuteParser : AddressAttributeParser, ICustomAddressAttributeParser
    {
        private readonly IAddressAttributeService _addressAttributeService;
        public CustomAddressAttibuteParser(IAddressAttributeService addressAttributeService, ILocalizationService localizationService) : base(addressAttributeService, localizationService)
        {
            _addressAttributeService = addressAttributeService;
        }

        /// <summary>
        /// Update custom address attirubite
        /// </summary>
        /// <param name="attributesXml">Existing attributes in xml format</param>
        /// <param name="attribute">Updated attribute</param>
        /// <param name="value">Settable value</param>
        /// <returns>Address attributes in xml format</returns>
        public string UpdateAddressAttribute(string attributesXml, AddressAttribute attribute, string value)
        {
            string result = string.Empty;
            try
            {
                var xmlDoc = new XmlDocument();
                if (String.IsNullOrEmpty(attributesXml))
                {
                    var element1 = xmlDoc.CreateElement("Attributes");
                    xmlDoc.AppendChild(element1);
                }
                else
                {
                    xmlDoc.LoadXml(attributesXml);
                }
                var rootElement = (XmlElement)xmlDoc.SelectSingleNode(@"//Attributes");

                XmlElement attributeElement = null;
                //find existing
                var nodeList1 = xmlDoc.SelectNodes(@"//Attributes/AddressAttribute");
                foreach (XmlNode node1 in nodeList1)
                {
                    if (node1.Attributes != null && node1.Attributes["ID"] != null)
                    {
                        string str1 = node1.Attributes["ID"].InnerText.Trim();
                        int id;
                        if (int.TryParse(str1, out id))
                        {
                            if (id == attribute.Id)
                            {
                                attributeElement = (XmlElement)node1;
                                break;
                            }
                        }
                    }
                }

                //create new one if not found
                if (attributeElement == null)
                {
                    attributeElement = xmlDoc.CreateElement("AddressAttribute");
                    attributeElement.SetAttribute("ID", attribute.Id.ToString());
                    rootElement.AppendChild(attributeElement);

                    var attributeValueElement = xmlDoc.CreateElement("AddressAttributeValue");
                    attributeElement.AppendChild(attributeValueElement);

                    var attributeValueValueElement = xmlDoc.CreateElement("Value");
                    attributeValueValueElement.InnerText = value;
                    attributeValueElement.AppendChild(attributeValueValueElement);
                }
                else
                {
                    attributeElement.InnerText = value;
                    attributeElement.InnerXml = String.Format("<AddressAttributeValue><Value>{0}</Value></AddressAttributeValue>", value);
                }

                result = xmlDoc.OuterXml;
            }
            catch (Exception exc)
            {
                Debug.Write(exc.ToString());
            }

            return result;
        }

        /// <summary>
        /// Same as method above
        /// </summary>
        /// <param name="attributesXml">Existing attributes in xml format</param>
        /// <param name="attrName">Updated attribute name</param>
        /// <param name="value">Settable value</param>
        /// <returns>Address attributes in xml format</returns>
        public string UpdateCustomAddressAttributes(string attributesXml, string attrName, string value)
        {
            var attributes = _addressAttributeService.GetAllAddressAttributes();
            foreach (var attribute in attributes)
            {
                if (attribute.Name == attrName)
                {
                    attributesXml = UpdateAddressAttribute(attributesXml,
                                attribute, value);
                }
            }

            return attributesXml;
        }

        /// <summary>
        /// Parse custom address attributes by attribute name
        /// </summary>
        /// <param name="attributesXml">Address attributes in xml format</param>
        /// <param name="attrName">Attribute name</param>
        /// <returns>Attribute value</returns>
        public string ParseCustomAddressAttributesValues(string attributesXml, string attrName)
        {
            string returnedValue = String.Empty;
            var attributes = _addressAttributeService.GetAllAddressAttributes();
            foreach (var attribute in attributes)
            {
                if (attribute.Name == attrName)
                {
                    var enteredText = ParseValues(attributesXml, attribute.Id);
                    switch (attribute.AttributeControlType)
                    {
                        case AttributeControlType.TextBox:
                            {
                                if (enteredText.Count > 0)
                                    returnedValue = enteredText[0];
                                break;
                            }
                    }

                }
            }

            return returnedValue;
        }
    }
}
