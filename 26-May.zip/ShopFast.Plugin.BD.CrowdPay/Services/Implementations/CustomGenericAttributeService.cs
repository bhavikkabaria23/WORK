﻿using System.Collections.Generic;
using System.Linq;
using Nop.Core;
using Nop.Core.Data;
using Nop.Core.Domain.Common;
using Nop.Services.Common;
using ShopFast.Plugin.BD.CrowdPay.Common;
using ShopFast.Plugin.BD.CrowdPay.Services.Interfaces;

namespace ShopFast.Plugin.BD.CrowdPay.Services.Implementations
{
    /// <summary>
    /// This class is a wrapper. Standard generic service doesn't provide functions like saving or deleting attributes by attributes names
    /// </summary>
    public class CustomGenericAttributeService : ICustomGenericAttributeService
    {
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly IWorkContext _workContext;
        private readonly IRepository<GenericAttribute> _genericRepository;

        public CustomGenericAttributeService(IGenericAttributeService genericAttributeService, IWorkContext workContext, IRepository<GenericAttribute> genericRepository)
        {
            _genericAttributeService = genericAttributeService;
            _workContext = workContext;
            _genericRepository = genericRepository;
        }

        /// <summary>
        /// Delete generic attributes
        /// </summary>
        /// <param name="attributes">List of attributes names</param>
        public void DeleteAttriutes(params string[] attributes)
        {
            foreach (var attributeItem in attributes)
            {
                var genericAttributes = _genericAttributeService.GetAttributesForEntity(_workContext.CurrentCustomer.Id,
           ClientConstants.GerenicAttributeKeyGroup.CustomerGroup)
           .Where(
               x =>
                   x.Key.Contains(attributeItem)).ToList();

                foreach (var attribute in genericAttributes)
                {
                    _genericAttributeService.DeleteAttribute(attribute);
                }
            }
        }

        /// <summary>
        /// Get attribute by name
        /// </summary>
        /// <param name="attributeName">Attribute name</param>
        /// <returns></returns>
        public GenericAttribute GetAttributeByNameForCurrentCustomer(string attributeName)
        {
            return _genericAttributeService.GetAttributesForEntity(_workContext.CurrentCustomer.Id,
                ClientConstants.GerenicAttributeKeyGroup.CustomerGroup).SingleOrDefault(x => x.Key == attributeName);
        }

        /// <summary>
        /// Get all generic attributes by name
        /// </summary>
        /// <param name="attributeName">Attribute name</param>
        /// <returns></returns>
        public IList<GenericAttribute> GetAttributesByName(string attributeName)
        {
            return
                _genericRepository.Table.Where(
                    x => x.KeyGroup == ClientConstants.GerenicAttributeKeyGroup.CustomerGroup && x.Key == attributeName)
                    .ToList();
        }

        /// <summary>
        /// Save attribute value
        /// </summary>
        /// <param name="attributeName">Attribute name</param>
        /// <param name="value">Settable value</param>
        public void SaveGenericAttirubteValue(string attributeName, string value)
        {
            var genericAttribute =
              GetAttributeByNameForCurrentCustomer(attributeName);
            if (genericAttribute == null)
            {
                genericAttribute = new GenericAttribute()
                {
                    EntityId = _workContext.CurrentCustomer.Id,
                    KeyGroup = ClientConstants.GerenicAttributeKeyGroup.CustomerGroup,
                    Key = attributeName,
                    Value = value
                };
                _genericAttributeService.InsertAttribute(genericAttribute);
            }
            else
            {
                genericAttribute.Value = value;
                _genericAttributeService.UpdateAttribute(genericAttribute);
            }
        }
    }
}
