﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Xml;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Customers;
using Nop.Services.Customers;
using Nop.Services.Localization;
using ShopFast.Plugin.BD.CrowdPay.Services.Interfaces;

namespace ShopFast.Plugin.BD.CrowdPay.Services.Implementations
{
    public class CustomCustomerAttributeParser : CustomerAttributeParser, ICustomCustomerAttributeParser
    {
        private readonly ICustomerAttributeService _customerAttributeService;
        public CustomCustomerAttributeParser(ICustomerAttributeService customerAttributeService, 
            ILocalizationService localizationService) : base(customerAttributeService, localizationService)
        {
            _customerAttributeService = customerAttributeService;
        }

        /// <summary>
        /// Update customer attirubite
        /// </summary>
        /// <param name="attributesXml">Existing attributes in xml format</param>
        /// <param name="ca">Updated customer attribute</param>
        /// <param name="value">Settable value</param>
        /// <returns>Address attributes in xml format</returns>
        public string UpdateCustomerAttribute(string attributesXml, CustomerAttribute ca, string value)
        {
            string result = string.Empty;
            try
            {
                var xmlDoc = new XmlDocument();
                if (String.IsNullOrEmpty(attributesXml))
                {
                    var element1 = xmlDoc.CreateElement("Attributes");
                    xmlDoc.AppendChild(element1);
                }
                else
                {
                    xmlDoc.LoadXml(attributesXml);
                }
                var rootElement = (XmlElement)xmlDoc.SelectSingleNode(@"//Attributes");

                XmlElement attributeElement = null;
                //find existing
                var nodeList1 = xmlDoc.SelectNodes(@"//Attributes/CustomerAttribute");
                foreach (XmlNode node1 in nodeList1)
                {
                    if (node1.Attributes != null && node1.Attributes["ID"] != null)
                    {
                        string str1 = node1.Attributes["ID"].InnerText.Trim();
                        int id;
                        if (int.TryParse(str1, out id))
                        {
                            if (id == ca.Id)
                            {
                                attributeElement = (XmlElement)node1;
                                break;
                            }
                        }
                    }
                }

                //create new one if not found
                if (attributeElement == null)
                {
                    attributeElement = xmlDoc.CreateElement("CustomerAttribute");
                    attributeElement.SetAttribute("ID", ca.Id.ToString());
                    rootElement.AppendChild(attributeElement);

                    var attributeValueElement = xmlDoc.CreateElement("CustomerAttributeValue");
                    attributeElement.AppendChild(attributeValueElement);

                    var attributeValueValueElement = xmlDoc.CreateElement("Value");
                    attributeValueValueElement.InnerText = value;
                    attributeValueElement.AppendChild(attributeValueValueElement);
                }
                else
                {
                    attributeElement.InnerText = value;
                    attributeElement.InnerXml = String.Format("<CustomerAttributeValue><Value>{0}</Value></CustomerAttributeValue>", value);
                }



                result = xmlDoc.OuterXml;
            }
            catch (Exception exc)
            {
                Debug.Write(exc.ToString());
            }
            return result;
        }

        /// <summary>
        /// Same as method above
        /// </summary>
        /// <param name="attributesXml">Address attributes in xml format</param>
        /// <param name="attrName">Attribute name</param>
        /// <param name="value">Settable value</param>
        /// <returns>Attribute value</returns>
        public string ParseCustomCustomerAttributes(string attributesXml, string attrName, string value)
        {
            var attributes = _customerAttributeService.GetAllCustomerAttributes();
            foreach (var attribute in attributes)
            {
                if (attribute.Name == attrName)
                {
                    switch (attribute.AttributeControlType)
                    {
                        case AttributeControlType.RadioList:
                            {

                                if (attribute.CustomerAttributeValues.Any())
                                {
                                    foreach (var attrValue in attribute.CustomerAttributeValues)
                                    {
                                        if (attrValue.Name == value)
                                        {
                                            attributesXml = UpdateCustomerAttribute(attributesXml,
                              attribute, attrValue.Id.ToString());
                                        }
                                    }
                                }
                                break;
                            }
                        default:
                            {

                                attributesXml = UpdateCustomerAttribute(attributesXml,
                                    attribute, value);

                                break;
                            }
                    }
                }
            }

            return attributesXml;
        }

        /// <summary>
        /// Parse customer attributes by attribute name
        /// </summary>
        /// <param name="attributesXml">Customer attributes in xml format</param>
        /// <param name="attrName">Attribute name</param>
        /// <returns>Attribute value</returns>
        public string ParseCustomCustomerAttributesValues(string attributesXml, string attrName)
        {
            string returnedValue = String.Empty;
            var attributes = _customerAttributeService.GetAllCustomerAttributes();
            foreach (var attribute in attributes)
            {
                if (attribute.Name == attrName)
                {
                    var enteredText = ParseValues(attributesXml, attribute.Id);
                    switch (attribute.AttributeControlType)
                    {
                        case AttributeControlType.TextBox:
                            {

                                if (enteredText.Count > 0)
                                    returnedValue = enteredText[0];
                                break;
                            }
                        case AttributeControlType.RadioList:
                            {
                                if (enteredText.Count > 0)
                                {
                                    foreach (var attrValue in attribute.CustomerAttributeValues)
                                    {
                                        if (attrValue.Id == int.Parse(enteredText[0]))
                                        {
                                            returnedValue = attrValue.Name;
                                            break;;
                                        }
                                    }
                                }

                                break;
                            }
                    }
                }
            }

            return returnedValue;
        }
    }
}
