﻿using Nop.Core.Domain.Customers;
using Nop.Services.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Nop.Services.Customers;
using Nop.Core.Domain.Tax;
using Nop.Services.Common;
using Nop.Services.Stores;
using Nop.Services.Events;
using Nop.Core;
using ShopFast.Plugin.BD.CrowdPay.Models;
using Nop.Services.Directory;
using Nop.Services.Catalog;

namespace Shopfast.Plugin.Custom.Services.Messages
{
    public class MessageTokenProviderBD : IMessageTokenProviderBD
    {

        #region Fields
        private readonly IStoreService _storeService;
        private readonly IStoreContext _storeContext;
        private readonly IEventPublisher _eventPublisher;
        private readonly ICountryService _countryService;
        private readonly IStateProvinceService _stateProvinceService;
        private readonly IProductService _productService;

        #endregion

        #region Ctor

        public MessageTokenProviderBD(
            IStoreService storeService,
            IStoreContext storeContext,
            IEventPublisher eventPublisher,
            ICountryService countryService,
            IProductService productService,
            IStateProvinceService stateProvinceService)
        {
            this._storeService = storeService;
            this._eventPublisher = eventPublisher;
            this._storeContext = storeContext;
            this._countryService = countryService;
            this._productService = productService;
            this._stateProvinceService = stateProvinceService;
        }

        #endregion

        #region Methods
        public virtual void AddInvestorFormTokens(IList<Token> tokens, InvestorFormModel investorForm)
        {
            tokens.Add(new Token("InvestorForm.Email", investorForm.Email));
            tokens.Add(new Token("InvestorForm.FullName", investorForm.FirstName + " " + investorForm.LastName));
            tokens.Add(new Token("InvestorForm.FirstName", investorForm.FirstName));
            tokens.Add(new Token("InvestorForm.LastName", investorForm.LastName));
            tokens.Add(new Token("InvestorForm.Phone", investorForm.Phone));
            tokens.Add(new Token("InvestorForm.Country", _countryService.GetCountryById(investorForm.CountryId).Name));
            tokens.Add(new Token("InvestorForm.State", _stateProvinceService.GetStateProvinceById(investorForm.StateId).Name));
            tokens.Add(new Token("InvestorForm.LookingToInvest", investorForm.LookingToInvestList.FirstOrDefault(i => i.Value == investorForm.LookingToInvest.ToString()).Text));
            tokens.Add(new Token("InvestorForm.PreferedContacts", investorForm.PreferedContacts));
            tokens.Add(new Token("InvestorForm.TimeToCall", investorForm.TimeToCall));
            tokens.Add(new Token("InvestorForm.Product", _productService.GetProductById(investorForm.productId).Name));          
        }

        public virtual void AddAccreditationTokens(IList<Token> tokens, AccreditationEmailModel emailModel)
        {
            tokens.Add(new Token("Accreditation.InvestorType", emailModel.InvestorType));
            tokens.Add(new Token("Accreditation.AnnualIncome", emailModel.AnnualIncome));
            tokens.Add(new Token("Accreditation.NetWorth", emailModel.NetWorth));
            tokens.Add(new Token("Accreditation.VerificationPdfPath", emailModel.VerificationPdfPath));
            tokens.Add(new Token("Accreditation.CustomerEmail", emailModel.CustomerEmail));
            tokens.Add(new Token("Accreditation.CustomerFullName", emailModel.CustomerFullName));
        }

        #endregion
    }
}