﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using RazorEngine;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ShopFast.Plugin.BD.CrowdPay.Helper
{
    public class PdfBuilder<T>
    {
        private readonly T _model;

        private readonly string _file;

        public PdfBuilder(T model, string file)
        {
            _model = model;
            _file = file;
        }

        //public FileContentResult GetPdf()

        public byte[] GetPdf2()
        {
            byte[] b = null;
            return b;
        }
        public byte[] GetPdf()
        {
            var html = GetHtml();
            Byte[] bytes;
            using (var ms = new MemoryStream())
            {
                using (var doc = new Document())
                {
                    using (var writer = PdfWriter.GetInstance(doc, ms))
                    {
                        doc.Open();
                        try
                        {
                            using (var msHtml = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(html)))
                            {
                                iTextSharp.tool.xml.XMLWorkerHelper.GetInstance()
                                    .ParseXHtml(writer, doc, msHtml, System.Text.Encoding.UTF8);
                            }
                        }
                        finally
                        {
                            doc.Close();
                        }
                    }
                }

                bytes = ms.ToArray();
            }
            return bytes;
            //return new FileContentResult(bytes, "application/pdf");
        }

        private string GetHtml()
        {
            var html = File.ReadAllText(_file);
            return Razor.Parse(html, _model);
        }
    }
}
