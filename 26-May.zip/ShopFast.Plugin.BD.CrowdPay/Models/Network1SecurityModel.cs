﻿using System.ComponentModel.DataAnnotations;
using FluentValidation.Attributes;
using Nop.Web.Framework;
using ShopFast.Plugin.BD.CrowdPay.Validation;

namespace ShopFast.Plugin.BD.CrowdPay.Models
{
    [Validator(typeof(Network1SecurityValidation))]
    public class Network1SecurityModel
    {
        public int Network1SecurityId { get; set; }
        public int customerId { get; set; }

        [NopResourceDisplayName("BD.Network1Security.IsNetwork1Security")]
        public bool? IsNetwork1Security { get; set; }
        [NopResourceDisplayName("BD.Network1Security.AccountNumber")]
        public string AccountNumber { get; set; }
        [NopResourceDisplayName("BD.Network1Security.AssociatedBroker")]
        public string AssociatedBroker { get; set; }
    }
}
