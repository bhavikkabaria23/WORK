﻿using Newtonsoft.Json;

namespace ShopFast.Plugin.BD.CrowdPay.Models.BlockScore
{
    public class CompanyModel
    {
        [JsonProperty(PropertyName = "id")]
        public string CompanyId { get; set; }

        [JsonProperty(PropertyName = "entity_name")]
        public string CompanyName { get; set; }

        [JsonProperty(PropertyName = "tax_id")]
        public string TaxId { get; set; }

        [JsonProperty(PropertyName = "incorporation_country_code")]
        public string CorporationCountryCode { get; set; }

        [JsonProperty(PropertyName = "incorporation_type")]
        public string CorporationType { get; set; }

        [JsonProperty(PropertyName = "address_street1")]
        public string StreetAddress { get; set; }

        [JsonProperty(PropertyName = "address_street2")]
        public string StreetAddress2 { get; set; }

        [JsonProperty(PropertyName = "address_city")]
        public string City { get; set; }

        [JsonProperty(PropertyName = "address_subdivision")]
        public string State { get; set; }

        [JsonProperty(PropertyName = "address_postal_code")]
        public string ZipPostalCode { get; set; }

        [JsonProperty(PropertyName = "address_country_code")]
        public string CountryCode { get; set; }

        [JsonProperty(PropertyName = "phone_number")]
        public string Phone { get; set; }//optional

    }
}
