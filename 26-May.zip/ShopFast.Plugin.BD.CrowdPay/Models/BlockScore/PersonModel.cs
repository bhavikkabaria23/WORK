﻿using Newtonsoft.Json;

namespace ShopFast.Plugin.BD.CrowdPay.Models.BlockScore
{
    public class PersonModel
    {
        [JsonProperty(PropertyName = "id")]
        public string CustomerId { get; set; }

        [JsonProperty(PropertyName = "name_first")]
        public string FirstName { get; set; }


        [JsonProperty(PropertyName = "name_last")]
        public string LastName { get; set; }


        [JsonProperty(PropertyName = "birth_day")]
        public string BirthDay { get; set; }


        [JsonProperty(PropertyName = "birth_month")]
        public string BirthMonth { get; set; }


        [JsonProperty(PropertyName = "birth_year")]
        public string BirthYear { get; set; }


        [JsonProperty(PropertyName = "document_type")]
        public string DocumentType { get; set; }


        [JsonProperty(PropertyName = "document_value")]
        public string DocumentValue { get; set; }


        [JsonProperty(PropertyName = "address_street1")]
        public string StreetAddress { get; set; }


        [JsonProperty(PropertyName = "address_street2")]
        public string StreetAddress2 { get; set; } //optional 


        [JsonProperty(PropertyName = "address_city")]
        public string City { get; set; }


        [JsonProperty(PropertyName = "address_subdivision")]
        public string State { get; set; }


        [JsonProperty(PropertyName = "address_postal_code")]
        public string ZipPostalCode { get; set; }


        [JsonProperty(PropertyName = "address_country_code")]
        public string CountryCode { get; set; }


        [JsonProperty(PropertyName = "phone_number")]
        public string Phone { get; set; }//optional

    }
}
