﻿using Nop.Web.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopFast.Plugin.BD.CrowdPay.Models
{
    public class InvestmentAttributes
    {
        [NopResourceDisplayName("ShopFast.BD.InvestmentAttributes.ShowTotalInvestment")]
        public bool ShowTotalInvestment { get; set; }
        [NopResourceDisplayName("ShopFast.BD.InvestmentAttributes.ShowMaxInvestment")]
        public bool ShowMaxInvestment { get; set; }
        [NopResourceDisplayName("ShopFast.BD.InvestmentAttributes.ShowMinInvestment")]
        public bool ShowMinInvestment { get; set; }
        [NopResourceDisplayName("ShopFast.BD.InvestmentAttributes.ShowPrice")]
        public bool ShowPrice { get; set; }
        [NopResourceDisplayName("ShopFast.BD.InvestmentAttributes.ShowDaysLeft")]
        public bool ShowDaysLeft { get; set; }
        [NopResourceDisplayName("ShopFast.BD.InvestmentAttributes.ShowInvestors")]
        public bool ShowInvestors { get; set; }
        [NopResourceDisplayName("ShopFast.BD.InvestmentAttributes.ShowRaised")]
        public bool ShowRaised { get; set; }

        // DisplayOrder of InvestmentAttributes
        [NopResourceDisplayName("ShopFast.BD.InvestmentAttributes.ShowTotalInvestment")]
        public int TotalInvestmentOrder { get; set; }
        [NopResourceDisplayName("ShopFast.BD.InvestmentAttributes.ShowMaxInvestment")]
        public int MaxInvestmentOrder { get; set; }
        [NopResourceDisplayName("ShopFast.BD.InvestmentAttributes.ShowMinInvestment")]
        public int MinInvestmentOrder { get; set; }
        [NopResourceDisplayName("ShopFast.BD.InvestmentAttributes.ShowPrice")]
        public int PriceOrder { get; set; }
        [NopResourceDisplayName("ShopFast.BD.InvestmentAttributes.ShowDaysLeft")]
        public int DaysLeftOrder { get; set; }
        [NopResourceDisplayName("ShopFast.BD.InvestmentAttributes.ShowInvestors")]
        public int InvestorsOrder { get; set; }
        [NopResourceDisplayName("ShopFast.BD.InvestmentAttributes.ShowRaised")]
        public int RaisedOrder { get; set; }        


        // CUstom Attributes
        [NopResourceDisplayName("ShopFast.BD.InvestmentAttributes.CustomFieldLabel")]
        public string CustomField1Label { get; set; }
        [NopResourceDisplayName("ShopFast.BD.InvestmentAttributes.CustomFieldValue")]
        public string CustomField1Value { get; set; }
        [NopResourceDisplayName("Admin.Catalog.Categories.Fields.DisplayOrder")]
        public int CustomField1Order { get; set; }
        public bool ShowCustomField1InSummary { get; set; }
        public bool ShowCustomField1InDetail { get; set; }
        public bool ShowCustomField1InCheckout { get; set; }

        public string CustomField2Label { get; set; }
        public string CustomField2Value { get; set; }
        public int CustomField2Order { get; set; }
        public bool ShowCustomField2InSummary { get; set; }
        public bool ShowCustomField2InDetail { get; set; }
        public bool ShowCustomField2InCheckout { get; set; }

        public string CustomField3Label { get; set; }
        public string CustomField3Value { get; set; }
        public int CustomField3Order { get; set; }
        public bool ShowCustomField3InSummary { get; set; }
        public bool ShowCustomField3InDetail { get; set; }
        public bool ShowCustomField3InCheckout { get; set; }

        public string CustomField4Label { get; set; }
        public string CustomField4Value { get; set; }
        public int CustomField4Order { get; set; }
        public bool ShowCustomField4InSummary { get; set; }
        public bool ShowCustomField4InDetail { get; set; }
        public bool ShowCustomField4InCheckout { get; set; }

        public string CustomField5Label { get; set; }
        public string CustomField5Value { get; set; }
        public int CustomField5Order { get; set; }
        public bool ShowCustomField5InSummary { get; set; }
        public bool ShowCustomField5InDetail { get; set; }
        public bool ShowCustomField5InCheckout { get; set; }
    }

    public class InvestmentAttributesParser
    {
        public InvestmentAttributesParser()
        {
            ShowAttribute = new InvestmentAttributes();
            DisplayOrder = new InvestmentAttributes();
            CustomField = new InvestmentAttributes();
        }
        public InvestmentAttributes ShowAttribute { get; set; }
        public InvestmentAttributes DisplayOrder { get; set; }
        public InvestmentAttributes CustomField { get; set; }
    }
}
