﻿using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;
using System.Web.Mvc;

namespace ShopFast.Plugin.BD.CrowdPay.Models
{
    public class ConfigurationModel : BaseNopModel
    {
        [NopResourceDisplayName("ShopFast.Admin.Settings.DocuSignUserName")]
        public string DocuSignUserName { get; set; }

        [NopResourceDisplayName("ShopFast.Admin.Settings.DocuSignPassword")]
        public string DocuSignPassword { get; set; }

        [NopResourceDisplayName("ShopFast.Admin.Settings.DocuSignIntegratorKey")]
        public string DocuSignIntegratorKey { get; set; }

        [NopResourceDisplayName("ShopFast.Admin.Settings.BlockScoreKey")]
        public string BlockScoreKey { get; set; }

        [NopResourceDisplayName("ShopFast.Admin.Settings.ViSettingsEnabled")]
        public bool VerifyInvestorValidationEnabled { get; set; }
        [NopResourceDisplayName("ShopFast.Admin.Settings.SelfAccredited")]
        public bool SelfAccredited { get; set; }
        [NopResourceDisplayName("ShopFast.Admin.Settings.InternalAccreditation")]
        public bool InternalAccreditation { get; set; }

        [NopResourceDisplayName("ShopFast.Admin.Settings.ViAPiKey")]
        public string VerifyInvestorApiKey { get; set; }

        [NopResourceDisplayName("ShopFast.Admin.Settings.ViUserKey")]
        public string VerifyInvestorUserKey { get; set; }

        public int VerifyInvestorModeId { get; set; }

        [NopResourceDisplayName("ShopFast.Admin.Settings.ViModeValues")]
        public SelectList VerifyInvestorModeValues { get; set; }

        [NopResourceDisplayName("ShopFast.Admin.Settings.OfferingType")]
        public string OfferingType { get; set; }

        [NopResourceDisplayName("ShopFast.Admin.Settings.SingleOfferProductId")]
        public int SingleOfferProductId { get; set; }

        // Post to net1 CRM - http://net1crm.crowdpay.us
        [NopResourceDisplayName("BD.Network1Security.Net1CRM.Settings.Net1CrmApiUrl")]
        public string Net1CrmApiUrl { get; set; }
        [NopResourceDisplayName("BD.Network1Security.Net1CRM.Settings.Net1CrmUsername")]
        public string Net1CrmUsername { get; set; }
        [NopResourceDisplayName("BD.Network1Security.Net1CRM.Settings.Net1AccessKey")]
        public string Net1AccessKey { get; set; }
        [NopResourceDisplayName("BD.Network1Security.Net1CRM.Settings.Net1AssignedUserId")]
        public string Net1AssignedUserId { get; set; }

    }
}