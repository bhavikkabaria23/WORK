﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopFast.Plugin.BD.CrowdPay.Models
{
    public class Net1CrmResponse
    {
        public bool success { get; set; }
        public Net1CrmResult result { get; set; }
    }

    public class Net1CrmResult
    {
        public string token { get; set; }
        public string sessionName { get; set; }
        public string userId { get; set; }
    }

    public class Net1CrmLoginPost
    {
        public string operation { get; set; }
        public string username { get; set; }
        public string accessKey { get; set; }
    }

}
