﻿namespace ShopFast.Plugin.BD.CrowdPay.Models
{
    public class InvestorVerificationPendingResponse
    {
        public string error { get; set; }

        public PendingVerificationResponse pending_verification_request { get; set; }
    }

    public class PendingVerificationResponse
    {
        public int id { get; set; }

        public string redirect_url { get; set; }

        public string investor_url { get; set; }

        public string waiting_for_info { get; set; }
    }


    public class UserVerificationStatus
    {
        public string id { get; set; }

        public string verification_status { get; set; }

        public string verification_request_step { get; set; }

        public string verified_on { get; set; }

        public string first_name { get; set; }

        public string last_name { get; set; }

        public string email { get; set; }
    }

    public class VerificationRequestStatus
    {
        public Investor investor { get; set; }
    }

    public class Investor
    {
        public string id { get; set; }
    }
}
