﻿using System.Collections.Generic;
using Nop.Web.Models.Catalog;
using Nop.Web.Models.Checkout;

namespace ShopFast.Plugin.BD.CrowdPay.Models
{
    public class ConfirmOrderModel : CheckoutConfirmModel
    {
        public ConfirmOrderModel()
        {
        Warnings = new List<string>();    
        }

        public int ProductId { get; set; }

        public int DeliveredQuantity { get; set; }

        public string CurrencySymbol { get; set; }

        public ProductDetailsModel DeliveredProduct { get; set; }

    }
}
