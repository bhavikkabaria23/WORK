﻿using Nop.Web.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopFast.Plugin.BD.CrowdPay.Models
{
    public class UploadDocumentModel
    {
        public int DocumentId { get; set; }
        public int CustomerId { get; set; }
        public int DocumentUploadId { get; set; }
        public string DocumentUrl { get; set; }
        [NopResourceDisplayName("ShopFast.Fields.UploadDocuments.Filename")]
        public string Filename { get; set; }
        [NopResourceDisplayName("ShopFast.Fields.UploadDocuments.Description")]
        public string Description { get; set; }
        [NopResourceDisplayName("ShopFast.Fields.UploadDocuments.IsApproved")]
        public bool IsApproved { get; set; }
        public int? ApprovedById { get; set; } //ID of approved by which customer
        [NopResourceDisplayName("ShopFast.Fields.UploadDocuments.ApprovedByName")]
        public string ApprovedByName { get; set; } // Name of customer
        [NopResourceDisplayName("ShopFast.Fields.UploadDocuments.ApprovedByEmail")]
        public string ApprovedByEmail { get; set; } // Customer email
        [NopResourceDisplayName("ShopFast.Fields.UploadDocuments.ApproveDate")]
        public DateTime? ApproveDate { get; set; }
        [NopResourceDisplayName("ShopFast.Fields.UploadDocuments.Comment")]
        public string Comment { get; set; }
        [NopResourceDisplayName("ShopFast.Fields.UploadDocuments.InvestorComment")]
        public string InvestorComment { get; set; }
    }
}
