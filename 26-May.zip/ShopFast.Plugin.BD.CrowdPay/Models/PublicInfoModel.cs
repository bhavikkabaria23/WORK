﻿using Nop.Web.Framework.Mvc;

namespace ShopFast.Plugin.BD.CrowdPay.Models
{
     public class PublicInfoModel : BaseNopModel
    {
        public int ProductId { get; set; }

        public bool ShippingRequired { get; set; }

        public bool InvestorInformationExists { get; set; }

        public bool SubscriptionAgreementExists { get; set; }

        public bool GoToInformationGatheringSection { get; set; }

        public bool Network1SecurityExists { get; set; }
    }
}
