﻿using System;

namespace ShopFast.Plugin.BD.CrowdPay.Models
{
   public class VerifyInvestorAdminModel
    {
        public string Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Company { get; set; }
        public string VerifiedStatus { get; set; }
        public DateTime VerifiedOn { get; set; }
        public string CssClass { get; set; }
        public string VerifiedDocumentUrl { get; set; }

        public bool UserExists { get; set; }

       public VerifyInvestorAdminModel()
       {
            VerifiedOn = DateTime.MinValue;
       }
    }
}
