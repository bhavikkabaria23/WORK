﻿using System.Collections.Generic;
using FluentValidation.Attributes;
using Nop.Web.Models.Checkout;
using ShopFast.Plugin.BD.CrowdPay.Validation;
using System.Web.Mvc;
using System;
using Nop.Core.Infrastructure;
using Nop.Services.Localization;

namespace ShopFast.Plugin.BD.CrowdPay.Models
{
    [Validator(typeof(PurchaseValidation))]
    public class PurchaseModel
    {
        public int ProductId { get; set; }
        public int MinimumSharesCount { get; set; }

        public int MaximumSharesCount { get; set; }

        [Remote("CheckAllowToInvestOnPurchaseAmount", "CrowdPayInvestment", HttpMethod = "POST", AdditionalFields = "PerShare", ErrorMessageResourceType = typeof(PurchaseModel), ErrorMessageResourceName = "NotAllowToInvestMessage")]
        //[Remote("CheckAllowToInvestOnPurchaseAmount", "CrowdPayInvestment", HttpMethod="POST", ErrorMessage = "You can not invest.")]
        public int OrderedSharesCount { get; set; }

        public string CurrencySymbol { get; set; }

        public decimal PerShare { get; set; }

        public decimal MinimumInvest { get; set; }

        public decimal MaximumInvest { get; set; }

        public IList<CheckoutPaymentMethodModel.PaymentMethodModel> PaymentMethods { get; set; }

        public decimal MaxShareAmount { get; set; }

        public string SelectedInvestorType { get; set; }

        public string SignatureName { get; set; }        

        public decimal OldPrice { get; set; }

        public static string NotAllowToInvestMessage
        {
            get
            {
                return EngineContext.Current.Resolve<ILocalizationService>().GetResource("shopfast.fields.NotAllowToInvest");
            }
        }

        public PurchaseModel()
        {
            PaymentMethods = new List<CheckoutPaymentMethodModel.PaymentMethodModel>();
        }
    }

    public static class PurchaseExtension
    {
        public static DateTime ChangeYear(this DateTime dt, int newYear)
        {
            return dt.AddYears(newYear - dt.Year);
        }
    }
}
