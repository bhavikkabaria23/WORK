﻿namespace ShopFast.Plugin.BD.CrowdPay.Models
{
    public class SigningResult
    {
        public string Status { get; set; }

        public bool Complete { get; set; }

        public string StepName { get; set; }
    }
}
