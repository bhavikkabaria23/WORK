﻿using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace ShopFast.Plugin.BD.CrowdPay.Models
{
    public class SubscriptionTemplateModel
    {
        public SubscriptionTemplateModel()
        {
            ShowInCheckoutPage = new InvestmentAttributes();
            ShowInDeatilPage = new InvestmentAttributes();
            ShowInSummaryPage = new InvestmentAttributes();
            CustomFields = new InvestmentAttributes();
            InvestmentAttributesDisplayOrder = new InvestmentAttributes();
        }
        public int SubscriptionTemplateId { get; set; }
        public int productId { get; set; }
        [NopResourceDisplayName("Admin.Catalog.Products.Fields.TokenList")]
        public string TokenList { get; set; }
        [NopResourceDisplayName("Admin.Catalog.Products.Fields.HTMLTemplate")]
        [AllowHtml]
        public string HTMLTemplate { get; set; }
        [NopResourceDisplayName("Admin.Catalog.Products.Fields.PDFUploadId")]
        [UIHint("Download")]
        public int PDFUploadId { get; set; }
        [NopResourceDisplayName("Admin.Catalog.Products.Fields.HTMLTemplateForProductAgreement")]
        [AllowHtml]
        public string HTMLTemplateForProductAgreement { get; set; }
        [NopResourceDisplayName("Admin.Catalog.Products.Fields.PDFUploadIdForProductAgreement")]
        [UIHint("Download")]
        public int PDFUploadIdForProductAgreement { get; set; }
        [NopResourceDisplayName("Admin.Catalog.Products.Fields.IsDocusign")]
        public bool IsDocusign { get; set; }

        [NopResourceDisplayName("Admin.Catalog.Products.Fields.HtmlSubscriptionTemplate")]
        public bool HtmlSubscriptionTemplate { get; set; }

        [NopResourceDisplayName("ShopFast.Admin.Settings.DocuSignUserName")]
        public string DocusignUsername { get; set; }
        [NopResourceDisplayName("ShopFast.Admin.Settings.DocuSignPassword")]
        public string DocusignPassword { get; set; }
        [NopResourceDisplayName("ShopFast.Admin.Settings.DocuSignIntegratorKey")]
        public string DocuSignIntegratorKey { get; set; }
        public int DocuSignModeId { get; set; }

        [NopResourceDisplayName("ShopFast.Admin.Settings.DocuSignModeValues")]
        public IList<SelectListItem> DocuSignModeValues { get; set; }

        [NopResourceDisplayName("ShopFast.Admin.Settings.OfferingType")]
        public int? OfferingType { get; set; }

        [NopResourceDisplayName("ShopFast.Admin.Settings.AllowInvestment")]
        public bool AllowInvestment { get; set; }
        [NopResourceDisplayName("ShopFast.Admin.Settings.ShowLookingToInvest")]
        public bool ShowLookingToInvest { get; set; }

        [NopResourceDisplayName("ShopFast.BD.NDA.Admin.Settings.AllowNDA")]
        public bool AllowNDA { get; set; }
        
        [NopResourceDisplayName("ShopFast.BD.NDA.Admin.Settings.NDAHTMLTemplate")]
        public string NDAHTMLTemplate { get; set; }
        [NopResourceDisplayName("ShopFast.BD.NDA.Admin.Settings.NDAPDFUploadId")]
        [UIHint("Download")]    
        public int NDAPDFUploadId { get; set; }
        [NopResourceDisplayName("ShopFast.BD.NDA.Admin.Settings.PPMPDFUploadId")]
        [UIHint("Download")]
        public int PPMPDFUploadId { get; set; }

        [NopResourceDisplayName("ShopFast.BD.Admin.Settings.ShowInSummaryPage")]
        public InvestmentAttributes ShowInSummaryPage { get; set; }
        [NopResourceDisplayName("ShopFast.BD.Admin.Settings.ShowInDeatilPage")]
        public InvestmentAttributes ShowInDeatilPage { get; set; }
        [NopResourceDisplayName("ShopFast.BD.Admin.Settings.ShowInCheckoutPage")]
        public InvestmentAttributes ShowInCheckoutPage { get; set; }
        [NopResourceDisplayName("Admin.Catalog.Categories.Fields.DisplayOrder")]
        public InvestmentAttributes InvestmentAttributesDisplayOrder { get; set; }

        [NopResourceDisplayName("ShopFast.BD.InvestmentAttributes.CustomFields")]
        public InvestmentAttributes CustomFields { get; set; }

        [NopResourceDisplayName("ShopFast.BD.Admin.Settings.AuthorizeOffering")]
        public bool AuthorizeOffering { get; set; }

        // ReInvestmentPerShare is used to set limit for the second or more times investment.
        //[NopResourceDisplayName("ShopFast.BD.Admin.Settings.ReInvestmentPerShareLimit")]
        //public int ReInvestmentPerShareLimit { get; set; }


    }
}
