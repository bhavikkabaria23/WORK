﻿using System.Collections.Generic;

namespace ShopFast.Plugin.BD.CrowdPay.Models
{
    public class BlockScoreAdminModel
    {
        public bool Valid { get; set; }

        public string ItemType { get; set; }

        public IList<BlockScoreItem> Details { get; set; }

        public BlockScoreAdminModel()
        {
            Details = new List<BlockScoreItem>();
        }

    }
    public class BlockScoreItem
    {
        public string Title { get; set; }
        public string Value { get; set; }
        public string CssClass { get; set; }
    }
}
