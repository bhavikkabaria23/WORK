﻿using FluentValidation.Attributes;
using Nop.Web.Framework;
using ShopFast.Plugin.Other.CrowdPay.Validation;

namespace ShopFast.Plugin.Other.CrowdPay.Models
{
    [Validator(typeof(InvestorInfoValidation))]
    public class InvestorInformationModel
    {
        public string InvestorInformationFilePath { get; set; }

        [NopResourceDisplayName("shopfast.crowdpay.fields.terms")]
        public bool TermsAndConditions { get; set; }

        [NopResourceDisplayName("shopfast.crowdpay.fields.signaturelabel")]
        public string CustomerSignature { get; set; }

        public bool PdfFileExists { get; set; }

        public bool SubscriptionExists { get; set; }

        public int ProductId { get; set; }
    }
}