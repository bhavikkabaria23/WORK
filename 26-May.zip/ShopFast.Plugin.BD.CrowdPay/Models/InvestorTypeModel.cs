﻿using System.Collections.Generic;
using System.Web.Mvc;

namespace ShopFast.Plugin.BD.CrowdPay.Models
{
    public class InvestorTypeModel
    {
        public IList<SelectListItem> InvestorTypeList { get; set; }

        public string SelectedInvestorType { get; set; }
    }
}
