﻿namespace ShopFast.Plugin.Other.CrowdPay.Models
{
   public class SubscriptionAgreementModel : InvestorInformationModel
   {
        public int ProductId { get; set; }

        public int DeliveredQuantity { get; set; }

        public bool SubscriptionAgreementExists { get; set; }

        public string SubscriptionAgreementFile { get; set; }
    }
}
