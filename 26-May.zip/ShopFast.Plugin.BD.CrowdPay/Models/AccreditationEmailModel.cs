﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopFast.Plugin.BD.CrowdPay.Models
{
    public class AccreditationEmailModel
    {
        public string InvestorType { get; set; }
        public string AnnualIncome { get; set; }
        public string NetWorth { get; set; }
        public string VerificationPdfPath { get; set; }
        public string CustomerEmail { get; set; }
        public string CustomerFullName { get; set; }
    }
}
