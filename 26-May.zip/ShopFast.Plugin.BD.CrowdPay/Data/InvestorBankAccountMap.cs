using Nop.Data.Mapping;
using ShopFast.Plugin.BD.CrowdPay.Domain;

namespace ShopFast.Plugin.BD.CrowdPay.Data
{
    public partial class InvestorBankAccountMap : NopEntityTypeConfiguration<InvestorBankAccount>
    {
        public InvestorBankAccountMap()
        {
            this.ToTable("InvestorBankAccount");
            this.HasKey(x => x.Id);
        }
    }
}
