using Nop.Data.Mapping;
using ShopFast.Plugin.BD.CrowdPay.Domain;

namespace ShopFast.Plugin.BD.CrowdPay.Data
{
    public partial class BD_IndividualBasicInfoMap : NopEntityTypeConfiguration<BD_IndividualBasicInfo>
    {
        public BD_IndividualBasicInfoMap()
        {
            this.ToTable("BD_IndividualBasicInfo");
            this.HasKey(tr => tr.Id);            
        }
    }
}