﻿using Nop.Data.Mapping;
using ShopFast.Plugin.BD.CrowdPay.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopFast.Plugin.BD.CrowdPay.Data
{
    public class BD_DocumentsMap : NopEntityTypeConfiguration<BD_Documents>
    {
        public BD_DocumentsMap()
        {
            this.ToTable("BD_Documents");
            this.HasKey(tr => tr.Id);            
        }
    }
}
