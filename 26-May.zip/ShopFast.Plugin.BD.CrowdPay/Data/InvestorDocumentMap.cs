using Nop.Data.Mapping;
using ShopFast.Plugin.BD.CrowdPay.Domain;

namespace ShopFast.Plugin.BD.CrowdPay.Data
{
    public partial class InvestorDocumentMap : NopEntityTypeConfiguration<InvestorDocument>
    {
        public InvestorDocumentMap()
        {
            this.ToTable("InvestorRevenueDocument");
            this.HasKey(x => x.Id);
        }
    }
}
