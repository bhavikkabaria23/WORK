﻿using System.Web.Mvc;
using Nop.Core.Infrastructure;
using Nop.Services.Configuration;
using Nop.Web.Models.Customer;
using Nop.Services.Common;
using ShopFast.Plugin.BD.CrowdPay;
using ShopFast.Plugin.BD.CrowdPay.Services.Interfaces;
using ShopFast.Plugin.BD.CrowdPay.Common;
using Nop.Services.Localization;

namespace Shopfast.Plugin.Custom.Filters.Web
{
    public class CustomerNavigationFilterAttribute : ActionFilterAttribute
    {
        #region Fields

        private readonly IGenericAttributeService _genericAttributeService;
        private readonly ICustomGenericAttributeService _customGenericAttributeService;
        private readonly ILocalizationService _localizationService;

        #endregion

        #region Ctor

        public CustomerNavigationFilterAttribute()
        {
            this._genericAttributeService = EngineContext.Current.Resolve<IGenericAttributeService>();
            this._customGenericAttributeService = EngineContext.Current.Resolve<ICustomGenericAttributeService>();
            this._localizationService = EngineContext.Current.Resolve<ILocalizationService>();
        }

        #endregion

        #region Methods
        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            var model = filterContext.Controller.ViewData.Model as CustomerNavigationModel;
            var vi_user_id = _customGenericAttributeService.GetAttributesByName(ClientConstants.TempCheckOutGenericAttirubutes.VerifyInvestorViUserId);
            if (model != null)
            {
                var showAccreditation = true;

                var _settingsService = EngineContext.Current.Resolve<ISettingService>();
                var settings = _settingsService.LoadSetting<CrowdPaySettings>();
                if (settings.SingleOfferProductId > 0)
                {
                    var _bDAddressService = EngineContext.Current.Resolve<IBDAddressService>();
                    var offeringDetails = _bDAddressService.GetSubscriptionTemplateByProduct(settings.SingleOfferProductId);
                    if (offeringDetails != null && offeringDetails.OfferingType.HasValue &&
                        offeringDetails.OfferingType.Value == ClientConstants.OfferingType.type_S_1_IPO)
                    {
                        //showAccreditation = false;
                    }
                }

                if (showAccreditation)
                {
                    model.CustomerNavigationItems.Insert(0, new CustomerNavigationItemModel
                    {
                        RouteName = "Plugin.CrowdPay.Accreditation",
                        Title = "Investor Account",
                        Tab = CustomerNavigationEnum.VendorInfo,
                        ItemClass = "customer-accreditation"
                    });
                }

                //model.CustomerNavigationItems.Add(new CustomerNavigationItemModel
                //{
                //    RouteName = "HomePage",
                //    Title = _localizationService.GetResource("Account.Investment"),
                //    Tab = CustomerNavigationEnum.VendorInfo,
                //    ItemClass = "make-investment"
                //});

                //model.CustomerNavigationItems.Add(new CustomerNavigationItemModel
                //{
                //    RouteName = "Plugin.CrowdPay.BankAccount",
                //    Title = "Bank Account",
                //    Tab = CustomerNavigationEnum.VendorInfo,
                //    ItemClass = "investor-bankaccount"
                //});
                //model.CustomerNavigationItems.Add(new CustomerNavigationItemModel
                //{
                //    RouteName = "Plugin.Esquire.BankAccountInfo",
                //    Title = "Bank Account",
                //    Tab = CustomerNavigationEnum.VendorInfo,
                //    ItemClass = "investor-bankaccount"
                //});

                model.CustomerNavigationItems.Add(new CustomerNavigationItemModel
                {
                    RouteName = "Plugin.CrowdPay.InvestorDocument",
                    Title = "W-8/W-9 Blurb",
                    Tab = CustomerNavigationEnum.VendorInfo,
                    ItemClass = "investor-document"
                });

                model.CustomerNavigationItems.Add(new CustomerNavigationItemModel
                {
                    RouteName = "Plugin.CrowdPay.VerificationPdfList",
                    Title = _localizationService.GetResource("Account.VerificationPdfs"),
                    Tab = CustomerNavigationEnum.Info,
                    ItemClass = "investor-verification"
                });
            }
        }
        #endregion
    }
}