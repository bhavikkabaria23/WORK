﻿using Nop.Web.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace ShopFast.Plugin.BD.CrowdPay.Filters
{
    public class ProductDetailFilterProvider : IFilterProvider
    {
        public IEnumerable<Filter> GetFilters(ControllerContext controllerContext, ActionDescriptor actionDescriptor)
        {
            if ((actionDescriptor.ControllerDescriptor.ControllerType == typeof(ProductController)) &&
                (actionDescriptor.ActionName.ToLower().Equals("productdetails")) &&
                 controllerContext.HttpContext.Request.HttpMethod == "GET")
            {
                return new[]
                    {
                        new Filter(new ProductDetailFilterAttribute(), FilterScope.Action, null)
                    };
            }

            return new Filter[] { };
        }
    }
}
