﻿using Nop.Core.Infrastructure;
using ShopFast.Plugin.BD.CrowdPay.Common;
using ShopFast.Plugin.BD.CrowdPay.Domain;
using ShopFast.Plugin.BD.CrowdPay.Models;
using ShopFast.Plugin.BD.CrowdPay.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Nop.Admin.Controllers;
using System.Web.Routing;
using Nop.Services.Localization;
using Nop.Web.Framework.UI;
using RestSharp;
using System.Collections.Specialized;

namespace ShopFast.Plugin.BD.CrowdPay.Filters
{
    public class ProductDetailFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            int productId = 0;
            foreach (var parameter in filterContext.ActionParameters)
            {
                if (parameter.Key == "productId")
                {
                    productId = Convert.ToInt32(parameter.Value);
                }                
            }
            
            if(productId > 0)
            {
                //var subscriptionTemplate = EngineContext.Current.Resolve<IBDAddressService>().GetSubscriptionTemplateByProduct(productId);
                //if(subscriptionTemplate != null && !subscriptionTemplate.AuthorizeOffering)
                //{
                //    // redirect to home page
                //    filterContext.Result = new RedirectResult("/");
                //}
                if(!EngineContext.Current.Resolve<IBDAddressService>().IsOfferingAuthorize(productId))
                {
                    // redirect to home page
                    filterContext.Result = new RedirectResult("/");
                }
            }
        }     
    }
}
