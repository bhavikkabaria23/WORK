﻿using Nop.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopFast.Plugin.BD.CrowdPay.Domain
{
    public class BD_InvestorOrder : BaseEntity
    {
        //public int OrderId { get; set; }
        public int CustomerId { get; set; }
        public int ProductId { get; set; }
        public int OfferingType { get; set; } //CustomAttributes.OfferingType
        public string InvestorType { get; set; } // Accredited / Non-Accredited     
       public int StoreId { get; set; }
       //public decimal OrderTotal { get; set; }
       public DateTime CreatedOnUtc { get; set; }       
    }
}
