﻿using Nop.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopFast.Plugin.BD.CrowdPay.Domain
{
    public class BD_VerificationTemplate : BaseEntity
    {
        public int customerId { get; set; }
        public string HTMLTemplateIndividual { get; set; }
        public string HTMLTemplateCompany { get; set; }
        public int PDFIndividualUploadId { get; set; }
        public int PDFCompanyUploadId { get; set; }        
        public bool IsDocusign { get; set; }
        public string DocusignUsername { get; set; }        
        public string DocusignPassword { get; set; }
        public string DocuSignIntegratorKey { get; set; }
        public bool? IsNetwork1Security { get; set; }
        public string AccountNumber { get; set; }
        public string AssociatedBroker { get; set; }
        public bool? IsNDASigned { get; set; }
        public string AuthorizeOfferingsJson { get; set; }

    }
}
