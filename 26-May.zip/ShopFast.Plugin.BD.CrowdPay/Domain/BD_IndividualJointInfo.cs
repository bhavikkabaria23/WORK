﻿using Nop.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopFast.Plugin.BD.CrowdPay.Domain
{
    // This will save joint account external data of Investor / Customer in BD_IndividualBasicInfo Table
    // The other basic customer information will be store in built in nop commerse tables.
    // Both basic and external data can be combine by "CustomerId"
    public partial class BD_IndividualJointInfo : BaseEntity
    {
        public int CustomerId { get; set; }
        // TITLE OF ACCOUNT & MAILING ADDRESS        
        public string FirstName { get; set; }        
        public string LastName { get; set; }
        public string Street { get; set; }
        public string City { get; set; }
        public int Country { get; set; }
        public int State { get; set; }
        public string Zip { get; set; }
        // It will be drop down for number of year (1 to 20+)
        public string Address_Years { get; set; }
        public string SSN { get; set; }

        // HOME ADDRESS:
        public string Home_Street { get; set; }
        public string DateOfBirth { get; set; }
        public string Home_Phone { get; set; }
        public string Home_Email { get; set; }
        public string Home_City { get; set; }
        public int Home_Country { get; set; }
        public int Home_State { get; set; }
        public string Home_Zip { get; set; }        
        public string Driver_License { get; set; }
        public int Driver_Country { get; set; }
        public int Driver_State { get; set; }
        public bool? USA_Citizen { get; set; }
        public int USA_Citizen_Country { get; set; }
        public string Cell_Phone { get; set; }

        // EMPLOYER NAME & ADDRESS: 
        public string Employer_Name { get; set; }
        public string Employer_Street { get; set; }
        public string Employer_City { get; set; }
        public int Employer_Country { get; set; }
        public int Employer_State { get; set; }
        public string Employer_Zip { get; set; }
        public string Employer_Business_Type { get; set; }
        public string Employer_Position { get; set; }
        // It will be drop down for number of year (1 to 20+)
        public string Employer_YRS { get; set; }
        public string Employer_Phone { get; set; }
        public string Employer_Email { get; set; }
        public bool Income1 { get; set; }
        public bool Income2 { get; set; }
        public bool Income3 { get; set; }
        public bool IsBasicSaved { get; set; }
        public bool IsHomeSaved { get; set; }
        public bool IsEmployerSaved { get; set; }
    }
}
