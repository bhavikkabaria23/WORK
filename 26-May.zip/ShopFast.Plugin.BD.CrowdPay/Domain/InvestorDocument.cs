using Nop.Core;

namespace ShopFast.Plugin.BD.CrowdPay.Domain
{
    public class InvestorDocument : BaseEntity
    {
        public int CustomerId { get; set; }

        public int DocumentId { get; set; }

        public string DocumentTitle { get; set; }
    }
}
