﻿using FluentValidation;
using FluentValidation.Results;
using Nop.Services.Localization;
using Nop.Web.Framework.Validators;
using ShopFast.Plugin.BD.CrowdPay.Common;
using ShopFast.Plugin.BD.CrowdPay.Models;

namespace ShopFast.Plugin.BD.CrowdPay.Validation
{

    public class CustomPaymentInfoValidation : BaseNopValidator<CustomPaymentInfoModel>
    {
        public CustomPaymentInfoValidation(ILocalizationService localizationService)
        {
            RuleFor(x => x.TermsTest)
               .NotEmpty()
               .WithMessage(localizationService.GetResource("Shopfast.Errors.PurchaseTermsCheckbox"));
            //RuleFor(x => x.TermOptionTemp)
            //       .NotEmpty()
            //       .WithMessage(localizationService.GetResource("Shopfast.Errors.PurchaseTermsConditions"));
            RuleFor(x => x.TermOptionTemp1)
                   .NotEmpty()
                   .WithMessage(localizationService.GetResource("BD.ConfirmationOption.Required"));
            RuleFor(x => x.TermOptionTemp2)
                   .NotEmpty()
                   .WithMessage(localizationService.GetResource("BD.ConfirmationOption.Required"));
            RuleFor(x => x.TermOptionTemp3)
                   .NotEmpty()
                   .WithMessage(localizationService.GetResource("BD.ConfirmationOption.Required"));
            RuleFor(x => x.TermOptionTemp4)
                   .NotEmpty()
                   .WithMessage(localizationService.GetResource("BD.ConfirmationOption.Required"));
            RuleFor(x => x.Sugnature)
                   .NotEmpty()
            	   .WithMessage(localizationService.GetResource("BD.ConfirmationSignature.Required"));
            //RuleFor(x => x.TermOption1Temp)
            //       .NotEmpty()
            //       .WithMessage(localizationService.GetResource("Shopfast.Errors.PurchaseTermsConditions"));
            //RuleFor(x => x.TermOption2Temp)
            //       .NotEmpty()
            //       .WithMessage(localizationService.GetResource("Shopfast.Errors.PurchaseTermsConditions"));
            //RuleFor(x => x.TermOption3Temp)
            //       .NotEmpty()
            //       .WithMessage(localizationService.GetResource("Shopfast.Errors.PurchaseTermsConditions"));
            //RuleFor(x => x.TermOption4Temp)
            //       .NotEmpty()
            //       .WithMessage(localizationService.GetResource("Shopfast.Errors.PurchaseTermsConditions"));
            //RuleFor(x => x.Sugnature)
            //   .NotEmpty()
            //   .WithMessage(localizationService.GetResource("Shopfast.Errors.PurchaseTermsConditions"));
        }
    }
}
