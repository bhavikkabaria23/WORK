﻿using FluentValidation.Results;
using Nop.Services.Localization;
using Nop.Web.Framework.Validators;
using ShopFast.Plugin.BD.CrowdPay.Common;
using ShopFast.Plugin.BD.CrowdPay.Models;

namespace ShopFast.Plugin.BD.CrowdPay.Validation
{
    public class PurchaseValidation : BaseNopValidator<PurchaseModel>
    {
        public PurchaseValidation(ILocalizationService localizationService)
        {
            Custom(x =>
            {
                if (x.OrderedSharesCount > x.MaximumSharesCount)
                {
                    return new ValidationFailure("OrderedSharesCount",
                               localizationService.GetResource("ShopFast.Fields.OrderedSharesCount.Greater"));
                }
                if (x.OrderedSharesCount < x.MinimumSharesCount)
                {
                    return new ValidationFailure("OrderedSharesCount",
                              localizationService.GetResource("ShopFast.Fields.OrderedSharesCount.Less"));
                }
                //if (x.SelectedInvestorType == ClientConstants.InvestorType.NonAccreditted)
                //{
                //    if ((x.OrderedSharesCount * x.PerShare) > x.MaxShareAmount)
                //    {
                //        return new ValidationFailure("OrderedSharesCount",
                //                localizationService.GetResource("ShopFast.Fields.OrderedSharesCount.Greater"));
                //    }
                //}
                return null;
            });
        }
    }
}
