﻿using FluentValidation;
using FluentValidation.Results;
using Nop.Services.Directory;
using Nop.Services.Localization;
using Nop.Web.Framework.Validators;
using ShopFast.Plugin.BD.CrowdPay.Models;

namespace ShopFast.Plugin.BD.CrowdPay.Validation
{
    public class InvestorFormValidation : BaseNopValidator<InvestorFormModel>
    {
        public InvestorFormValidation(ILocalizationService localizationService,
            IStateProvinceService stateProvinceService)
        {
            RuleFor(x => x.FirstName)
                .NotEmpty()
                .WithMessage(localizationService.GetResource("Account.Fields.FirstName.Required"));
            RuleFor(x => x.LastName)
                .NotEmpty()
                .WithMessage(localizationService.GetResource("Account.Fields.LastName.Required"));
            RuleFor(x => x.Email)
               .NotEmpty()
               .WithMessage(localizationService.GetResource("Account.Fields.Email.Required"));
            RuleFor(x => x.Email).EmailAddress().WithMessage(localizationService.GetResource("Common.WrongEmail"));
            RuleFor(x => x.Phone)
              .NotEmpty()
              .WithMessage(localizationService.GetResource("Account.Fields.Phone.Required"));
            RuleFor(x => x.CountryId)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Account.Fields.Country.Required"));
            RuleFor(x => x.StateId)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("Account.Fields.StateProvince.Required"));          
            RuleFor(x => x.LookingToInvest)
                    .NotEmpty()
                    .WithMessage(localizationService.GetResource("ShopFast.Fields.LookingToInvest.Required"));
            //Custom(x =>
            //{
            //    //does selected country have states?
            //    if (!x.IsEmail && !x.IsPhone)
            //    {
            //        return new ValidationFailure("PreferedContacts",
            //            localizationService.GetResource("ShopFast.Fields.PreferedContacts.Required"));
            //    }
            //    return null;
            //});
            //Custom(x =>
            //{
            //    //does selected country have states?
            //    if (x.IsPhone && string.IsNullOrEmpty(x.TimeToCall))
            //    {
            //        return new ValidationFailure("TimeToCall",
            //            localizationService.GetResource("ShopFast.Fields.TimeToCall.Required"));
            //    }
            //    return null;
            //});
        }
    }
}
