﻿using System.Web.Mvc;
using System.Web.Routing;
using Nop.Web.Framework.Mvc.Routes;
using ShopFast.Plugin.BD.CrowdPay.Infrastructure;

namespace ShopFast.Plugin.BD.CrowdPay
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(RouteCollection routes)
        {

            ViewEngines.Engines.Insert(0, new PluginViewEngine());

            routes.MapRoute("Plugin.CrowdPay.Page",
             "CrowdPayPage",
             new
             {
                 controller = "CrowdPayCheckOut",
                 action = "PublicInfo"
             },
             new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
            );

            routes.MapRoute("Plugin.CrowdPay.Accreditation",
                //"Accreditation/{productId}",
           "Accreditation",
           new
           {
               controller = "CrowdPayCheckOut",
               action = "Accreditation",
               productId = UrlParameter.Optional
           },
           new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
          );

            ////CrowdpayInvestor > BankAccount
            //routes.MapRoute("Plugin.CrowdPay.BankAccount", "customer/bankaccount",
            //                new { controller = "CrowdpayInvestor", action = "BankAccount" },
            //                new[] { "ShopFast.Plugin.BD.CrowdPay.Controllers" });

            //CrowdpayInvestor > W-8/W-9 Blurb
            routes.MapRoute("Plugin.CrowdPay.InvestorDocument", "customer/document",
                            new { controller = "CrowdpayInvestor", action = "InvestorDocument" },
                            new[] { "ShopFast.Plugin.BD.CrowdPay.Controllers" });

            var routeID = routes.MapRoute("Plugin.CrowdPay.Admin.InvestorDocuments",
       "Admin/Customer/InvestorDocuments/{customerId}",
       new
       {
           controller = "CrowdpayInvestor",
           action = "InvestorDocuments",
           customerId = UrlParameter.Optional
       },
       new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
           }
      );

            routeID.DataTokens.Add("area", "admin");
            routes.Remove(routeID);
            routes.Insert(0, routeID);


            routes.MapRoute("Plugin.CrowdPay.InvestorInfoTypeChange",
             "crowdpay/InvestorInfoTypeChange",
             new
             {
                 controller = "CrowdPayCheckOut",
                 action = "InvestorInfoTypeChange"
             },
             new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             });

            routes.MapRoute("Plugin.CrowdPay.SaveInvestorInformation",
             "crowdpay/SaveInvestorInformation",
             new
             {
                 controller = "CrowdPayCheckOut",
                 action = "SaveInvestorInformation"
             },
             new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
            );

            routes.MapRoute("Plugin.CrowdPay.SavePersonalInformation",
             "crowdpay/SavePersonalInformation",
             new
             {
                 controller = "CrowdPayCheckOut",
                 action = "SavePersonalInformation"
             },
             new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
            );


            routes.MapRoute("Plugin.CrowdPay.SaveInvestorType",
             "crowdpay/SaveInvestorType",
             new
             {
                 controller = "CrowdPayCheckOut",
                 action = "SaveInvestorType"
             },
             new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
            );

            routes.MapRoute("Plugin.CrowdPay.SaveInfoGathering",
             "crowdpay/SaveInfoGathering",
             new
             {
                 controller = "CrowdPayCheckOut",
                 action = "SaveInfoGathering"
             },
             new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
            );

            routes.MapRoute("Plugin.CrowdPay.SaveIndividualCompanyVerification",
           "crowdpay/SaveIndividualCompanyVerification",
           new
           {
               controller = "CrowdPayCheckOut",
               action = "SaveIndividualCompanyVerification"
           },
           new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
          );

            routes.MapRoute("Plugin.CrowdPay.SaveNetwork1Security",
         "crowdpay/SaveNetwork1Security",
         new
         {
             controller = "CrowdPayCheckOut",
             action = "SaveNetwork1Security"
         },
         new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
        );
            routes.MapRoute("Plugin.CrowdPay.UploadDocuments", "crowdpay/UploadDocuments",
                new { controller = "CrowdPayCheckOut", action = "UploadDocuments" },
                new[] { "ShopFast.Plugin.BD.CrowdPay.Controllers" });

            routes.MapRoute("Plugin.CrowdPay.AsyncUpload", "crowdpay/AsyncUpload",
                new { controller = "CrowdPayCheckOut", action = "AsyncUpload" },
                new[] { "ShopFast.Plugin.BD.CrowdPay.Controllers" });

            routes.MapRoute("Plugin.CrowdPay.DownloadDocument", "crowdpay/DownloadDocument",
                new { controller = "CrowdPayCheckOut", action = "DownloadDocument" },
                new[] { "ShopFast.Plugin.BD.CrowdPay.Controllers" });

            routes.MapRoute("Plugin.CrowdPay.SavePurchase",
             "crowdpay/SavePurchase",
             new
             {
                 controller = "CrowdPayCheckOut",
                 action = "SavePurchase"
             },
             new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
            );

            routes.MapRoute("Plugin.CrowdPay.SavePaymentInfo",
             "crowdpay/SavePaymentInfo",
             new
             {
                 controller = "CrowdPayCheckOut",
                 action = "SavePaymentInfo"
             },
             new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
            );

            routes.MapRoute("Plugin.CrowdPay.LoadPaymentInfoForm",
           "crowdpay/LoadPaymentInfoForm",
           new
           {
               controller = "CrowdPayCheckOut",
               action = "LoadPaymentInfoForm"
           },
           new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
          );

            routes.MapRoute("Plugin.CrowdPay.Confirm",
             "crowdpay/Confirm",
             new
             {
                 controller = "CrowdPayCheckOut",
                 action = "ConfirmOrder"
             },
             new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
            );

            routes.MapRoute("Plugin.CrowdPay.SuccesfulInvestment",
             "crowdpay/SuccesfulInvestment/{orderId}",
             new
             {
                 controller = "CrowdPayCheckOut",
                 action = "CrowdPayCompleted",
                 orderId = UrlParameter.Optional
             },
             new
             {
                 orderId = @"\d+"
             },
             new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             });

            routes.MapRoute("Plugin.CrowdPay.DownloadFile",
             "crowdpay/DownloadFile",
             new
             {
                 controller = "CrowdPayCheckOut",
                 action = "DownloadFile"
             },
             new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
            );


            routes.MapRoute("Plugin.CrowdPay.SaveSubscriptionAgreement",
             "crowdpay/SaveSubscriptionAgreement",
             new
             {
                 controller = "CrowdPayCheckOut",
                 action = "SaveSubscriptionAgreement"
             },
             new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
            );

            routes.MapRoute("Plugin.CrowdPay.SaveBilling",
             "crowdpay/SaveBilling",
             new
             {
                 controller = "CrowdPayCheckOut",
                 action = "SaveBilling"
             },
             new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
            );

            routes.MapRoute("Plugin.CrowdPay.SaveShipping",
             "crowdpay/SaveShipping",
             new
             {
                 controller = "CrowdPayCheckOut",
                 action = "SaveShipping"
             },
             new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
            );

            routes.MapRoute("Plugin.CrowdPay.SaveShippingMethod",
             "crowdpay/SaveShippingMethod",
             new
             {
                 controller = "CrowdPayCheckOut",
                 action = "SaveShippingMethod"
             },
             new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
            );


            routes.MapRoute("Plugin.CrowdPay.SigningResult",
             "crowdpay/SigningResult",
             new
             {
                 controller = "CrowdPayCheckOut",
                 action = "SigningResult"
             },
             new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
            );


            var route = routes.MapRoute("Plugin.CrowdPay.BlockScoreValidationDetails",
             "Admin/Customer/BlockScoreValidationDetails/{CustomerId}",
             new
             {
                 controller = "CrowdPayAdmin",
                 action = "BlockScoreValidationDetails"
             },
             new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
            );

            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);


            //verify investor api
            routes.MapRoute("Plugin.CrowdPay.VerifyInvestor",
"verivyInvestorApi/VerifyInvestor",
new
{
    controller = "CrowdPayInvestorVerifyApi",
    action = "VerifyInvestor"
},
new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
}
);

            routes.MapRoute("Plugin.CrowdPay.InvestorStatusUpdate",
"verivyInvestorApi/InvestorStatusUpdate",
new
{
    controller = "CrowdPayInvestorVerifyApi",
    action = "InvestorStatusUpdate"
},
new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
}
);

            routes.MapRoute("Plugin.CrowdPay.TestWebhook",
"verivyInvestorApi/TestWebhook",
new
{
    controller = "CrowdPayInvestorVerifyApi",
    action = "TestHook"
},
new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
}
);

            var routeVI = routes.MapRoute("Plugin.CrowdPay.VerifyInvestorDetails",
           "Admin/Customer/VerifyInvestorDetails/{CustomerId}",
           new
           {
               controller = "CrowdPayAdmin",
               action = "VerifyInvestorDetails"
           },
           new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
           }
          );

            routeVI.DataTokens.Add("area", "admin");
            routes.Remove(routeVI);
            routes.Insert(0, routeVI);


            var routeVIDownloadFile = routes.MapRoute("Plugin.CrowdPay.VerifyInvestorDownloadFile",
          "Admin/Customer/DownloadFile/{vi_UserId}",
          new
          {
              controller = "CrowdPayAdmin",
              action = "DownloadFile"
          },
          new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
          }
         );

            routeVIDownloadFile.DataTokens.Add("area", "admin");
            routes.Remove(routeVIDownloadFile);
            routes.Insert(0, routeVIDownloadFile);

            #region Admin > Customers

            var routeCustomerList = routes.MapRoute("Plugin.CrowdPay.CustomerList", "Admin/Customer/CustomerList",
                new { controller = "CrowdPayAdmin", action = "CustomerList" }, new[] { "ShopFast.Plugin.BD.CrowdPay.Controllers" });
            routeCustomerList.DataTokens.Add("area", "admin");
            routes.Remove(routeCustomerList);
            routes.Insert(0, routeCustomerList);

            var routeReportBestCustomersByOrderTotalList = routes.MapRoute("Plugin.CrowdPay.ReportBestCustomersByOrderTotalList", "Admin/Customer/ReportBestCustomersByOrderTotalList",
               new { controller = "CrowdPayAdmin", action = "ReportBestCustomersByOrderTotalList" }, new[] { "ShopFast.Plugin.BD.CrowdPay.Controllers" });
            routeReportBestCustomersByOrderTotalList.DataTokens.Add("area", "admin");
            routes.Remove(routeReportBestCustomersByOrderTotalList);
            routes.Insert(0, routeReportBestCustomersByOrderTotalList);

            var routeReportBestCustomersByNumberOfOrdersList = routes.MapRoute("Plugin.CrowdPay.ReportBestCustomersByNumberOfOrdersList", "Admin/Customer/ReportBestCustomersByNumberOfOrdersList",
               new { controller = "CrowdPayAdmin", action = "ReportBestCustomersByNumberOfOrdersList" }, new[] { "ShopFast.Plugin.BD.CrowdPay.Controllers" });
            routeReportBestCustomersByNumberOfOrdersList.DataTokens.Add("area", "admin");
            routes.Remove(routeReportBestCustomersByNumberOfOrdersList);
            routes.Insert(0, routeReportBestCustomersByNumberOfOrdersList);

            var routeReportRegisteredCustomersList = routes.MapRoute("Plugin.CrowdPay.ReportRegisteredCustomersList", "Admin/Customer/ReportRegisteredCustomersList",
               new { controller = "CrowdPayAdmin", action = "ReportRegisteredCustomersList" }, new[] { "ShopFast.Plugin.BD.CrowdPay.Controllers" });
            routeReportRegisteredCustomersList.DataTokens.Add("area", "admin");
            routes.Remove(routeReportRegisteredCustomersList);
            routes.Insert(0, routeReportRegisteredCustomersList);

            #endregion

            routes.MapRoute("Plugin.CrowdPay.LoadNDAForm",
          "ndaform",
          new
          {
              controller = "CrowdPayCheckOut",
              action = "LoadNDAForm",
              productId = UrlParameter.Optional
          },
          new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
         );

            routes.MapRoute("Plugin.CrowdPay.ShowNDAPdfs",
         "ShowNDAPdfs",
         new
         {
             controller = "CrowdPayCheckOut",
             action = "ShowNDAPdfs",
             productId = UrlParameter.Optional
         },
         new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
        );

            routes.MapRoute("Plugin.CrowdPay.VerificationPdfList",
        "VerificationPdfs",
        new
        {
            controller = "CrowdPayCheckOut",
            action = "VerificationPdfList",
            productId = UrlParameter.Optional
        },
        new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
            }
       );

            // New design and controller map route CrowdPayInvestmentController.
            #region CrowdPayInvestmentController map routes

            routes.MapRoute("Plugin.CrowdPay.Investment",
           "investment/{productId}",
           new
           {
               controller = "CrowdPayInvestment",
               action = "PublicInfo",
               productId = UrlParameter.Optional
           },
           new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
          );

            routes.MapRoute("Plugin.CrowdPay.LoadPurchase",
             "crowdpay/LoadPurchase",
             new
             {
                 controller = "CrowdPayInvestment",
                 action = "LoadPurchase"
             },
             new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
            );
            routes.MapRoute("Plugin.CrowdPay.LoadPaymentInfoDetail",
           "crowdpay/LoadPaymentInfoDetail",
           new
           {
               controller = "CrowdPayInvestment",
               action = "LoadPaymentInfoDetail"
           },
           new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
          );

            routes.MapRoute("Plugin.CrowdPay.LoadBillingInfo",
       "crowdpay/LoadBillingInfo",
       new
       {
           controller = "CrowdPayInvestment",
           action = "LoadBillingInfo"
       },
       new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
      );

            routes.MapRoute("Plugin.CrowdPay.LoadShippingInfo",
      "crowdpay/LoadShippingInfo",
      new
      {
          controller = "CrowdPayInvestment",
          action = "LoadShippingInfo"
      },
      new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
     );
            routes.MapRoute("Plugin.CrowdPay.LoadInvestorForm",
      "crowdpay/LoadInvestorForm",
      new
      {
          controller = "CrowdPayInvestment",
          action = "LoadInvestorForm"
      },
      new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
     );
            routes.MapRoute("Plugin.CrowdPay.InvestorFormDetail",
      "InvestorFormDetail/{Id}",
      new
      {
          controller = "CrowdPayInvestment",
          action = "InvestorFormDetail",
          Id = UrlParameter.Optional
      },
      new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
     );
            var routeIF = routes.MapRoute("Plugin.CrowdPay.InvestorFormsList",
         "Admin/Product/InvestorFormsList/{productId}",
         new
         {
             controller = "CrowdPayInvestment",
             action = "InvestorFormsList",
             ProductId = UrlParameter.Optional
         },
         new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
           }
        );

            routeIF.DataTokens.Add("area", "admin");
            routes.Remove(routeIF);
            routes.Insert(0, routeIF);

            var routeIFAll = routes.MapRoute("Plugin.InvestorForms",
       "Plugin/InvestorForms",
       new
       {
           controller = "CrowdPayInvestment",
           action = "InvestorFormsListForAllProducts"
       },
       new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
           }
      );

            routeIFAll.DataTokens.Add("area", "admin");
            routes.Remove(routeIFAll);
            routes.Insert(0, routeIFAll);

            var routeST = routes.MapRoute("Plugin.CrowdPay.SubscriptionTemplate",
        "Admin/Product/SubscriptionTemplate/{productId}",
        new
        {
            controller = "CrowdPayInvestment",
            action = "SubscriptionTemplate",
            ProductId = UrlParameter.Optional
        },
        new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
           }
       );

            routeST.DataTokens.Add("area", "admin");
            routes.Remove(routeST);
            routes.Insert(0, routeST);

            var routeVT = routes.MapRoute("Plugin.CrowdPay.VerificationTemplate",
      "Admin/Product/VerificationTemplate/{customerId}",
      new
      {
          controller = "CrowdPayCheckOut",
          action = "VerificationTemplate",
          customerId = UrlParameter.Optional
      },
      new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
           }
     );

            routeVT.DataTokens.Add("area", "admin");
            routes.Remove(routeVT);
            routes.Insert(0, routeVT);

            routes.MapRoute("Plugin.CrowdPay.CheckAllowToInvestOnPurchaseAmount",
      "crowdpay/CheckAllowToInvestOnPurchaseAmount",
      new
      {
          controller = "CrowdPayInvestment",
          action = "CheckAllowToInvestOnPurchaseAmount",
          OrderedSharesCount = UrlParameter.Optional,
          PerShare = UrlParameter.Optional
      },
      new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
     );

            routes.MapRoute("Plugin.CrowdPay.UploadDocumentDetail",
    "UploadDocumentDetail/{Id}",
    new
    {
        controller = "CrowdPayCheckOut",
        action = "UploadDocumentDetail",
        Id = UrlParameter.Optional
    },
    new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
   );
            var routeUD = routes.MapRoute("Plugin.CrowdPay.UploadDocumentsList",
         "Admin/Customer/UploadDocumentsList/{customerId}",
         new
         {
             controller = "CrowdPayCheckOut",
             action = "UploadDocumentsList",
             customerId = UrlParameter.Optional
         },
         new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
           }
        );

            routeUD.DataTokens.Add("area", "admin");
            routes.Remove(routeUD);
            routes.Insert(0, routeUD);

            var routeUDD = routes.MapRoute("Plugin.CrowdPay.DeleteDocument",
         "Admin/Customer/DeleteDocument/{id}",
         new
         {
             controller = "CrowdPayCheckOut",
             action = "DeleteDocument",
             id = UrlParameter.Optional
         },
         new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
           }
        );

            routeUDD.DataTokens.Add("area", "admin");
            routes.Remove(routeUDD);
            routes.Insert(0, routeUDD);

            routes.MapRoute("Plugin.CrowdPay.SubscriptionAgreementExternal",
      "crowdpay/subscription/{perShare}/{OrderedSharesCount}/{AgreementType}/{SignatureName}",
      new
      {
          controller = "CrowdPayInvestment",
          action = "SubscriptionAgreementExternal",
          perShare = UrlParameter.Optional,
          OrderedSharesCount = UrlParameter.Optional,
          SignatureName = UrlParameter.Optional,
          AgreementType = UrlParameter.Optional,
      },
      new[] {
     "DevPartner.Plugin.BD.CrowdPay.Controllers"
             }
     );

            #region Download SubscriptionAgreement

            routes.MapRoute("CrowdPayInvestment",
                            "subscription-agreement/{orderShareCount}/{signatureText}",
                            new { controller = "CrowdPayInvestment", action = "SubscriptionAgreement", orderShareCount = UrlParameter.Optional, signatureText = UrlParameter.Optional },
                            new[] { "ShopFast.Plugin.BD.CrowdPay.Controllers" });

            #endregion

             #region InvestorInquiryForm

            routes.MapRoute("Plugin.CrowdPay.LoadInvestorInquiryForm",
                                "crowdpay/LoadInvestorInquiryForm",
                                new { controller = "CrowdPayInvestment", action = "LoadInvestorInquiryForm" },
                                new[] { "ShopFast.Plugin.BD.CrowdPay.Controllers" });

            #endregion

            #endregion
        }
        public int Priority
        {
            get
            {
                return 0;
            }
        }
    }
}