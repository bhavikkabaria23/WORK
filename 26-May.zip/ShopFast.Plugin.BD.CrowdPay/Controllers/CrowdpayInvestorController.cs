﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using Nop.Core;
using Nop.Core.Domain.Customers;
using Nop.Services.Media;
using Nop.Services.Localization;
using Nop.Services.Customers;
using Nop.Services.Orders;
using Nop.Services.Authentication;
using Nop.Services.Events;
using Nop.Services.Logging;
using Nop.Web.Controllers;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Kendoui;
using Nop.Web.Framework.Security.Captcha;
using Nop.Web.Framework;
using Nop.Web.Models.Customer;
using ShopFast.Plugin.BD.CrowdPay.Domain;
using ShopFast.Plugin.BD.CrowdPay.Models;
using ShopFast.Plugin.BD.CrowdPay.Services.Interfaces;
using ShopFast.Plugin.BD.CrowdPay.Common;
using Nop.Services.Common;
using Nop.Services.Media;

namespace ShopFast.Plugin.BD.CrowdPay.Controllers
{
    public class CrowdpayInvestorController : BasePublicController
    {
        #region Fields

        private readonly IWorkContext _workContext;
        private readonly IInvestorBankAccountService _investorBankAccountService;
        private readonly IDownloadService _downloadService;
        private readonly IInvestorDocumentService _investorDocumentService;
        private readonly ILocalizationService _localizationService;
        private readonly ICustomerRegistrationService _customerRegistrationService;
        private readonly IShoppingCartService _shoppingCartService;
        private readonly IAuthenticationService _authenticationService;
        private readonly IEventPublisher _eventPublisher;
        private readonly ICustomerActivityService _customerActivityService;
        private readonly ICustomerService _customerService;
        private readonly IBDAddressService _bDAddressService;
        private readonly ICustomGenericAttributeService _customGenericAttributeService;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly CaptchaSettings _captchaSettings;
        private readonly CustomerSettings _customerSettings;
        private readonly ILogger _logger;

        #endregion

        #region Constructors

        public CrowdpayInvestorController(IWorkContext workContext,
            IInvestorBankAccountService investorBankAccountService,
            IDownloadService downloadService,
            IInvestorDocumentService investorDocumentService,
            ILocalizationService localizationService,
            ICustomerRegistrationService customerRegistrationService,
            IShoppingCartService shoppingCartService,
            IAuthenticationService authenticationService,
            IEventPublisher eventPublisher,
            ICustomerActivityService customerActivityService,
            ICustomerService customerService,
            IBDAddressService bDAddressService,
            ICustomGenericAttributeService customGenericAttributeService,
            IGenericAttributeService genericAttributeService,
            CaptchaSettings captchaSettings,
            CustomerSettings customerSettings,
            ILogger logger)
        {
            this._workContext = workContext;
            this._investorBankAccountService = investorBankAccountService;
            this._downloadService = downloadService;
            this._investorDocumentService = investorDocumentService;
            this._localizationService = localizationService;
            this._customerRegistrationService = customerRegistrationService;
            this._shoppingCartService = shoppingCartService;
            this._authenticationService = authenticationService;
            this._eventPublisher = eventPublisher;
            this._customerActivityService = customerActivityService;
            this._customerService = customerService;
            this._bDAddressService = bDAddressService;
            this._customGenericAttributeService = customGenericAttributeService;
            this._genericAttributeService = genericAttributeService;
            this._captchaSettings = captchaSettings;
            this._customerSettings = customerSettings;
            this._logger = logger;
        }

        #endregion

        #region Utilities

        protected void PrepareInvestorDocumentDetailModel(InvestorDocumentModel model)
        {
            var investorDocument = _investorDocumentService.GetInvestorDocumentByCustomerId(_workContext.CurrentCustomer.Id);
            if (investorDocument != null)
            {
                var document = _downloadService.GetDownloadById(investorDocument.DocumentId);
                if (document != null)
                {
                    model.DocumentId = investorDocument.DocumentId;
                    model.DocumentTitle = investorDocument.DocumentTitle;
                }
            }
        }

        protected void PrepareBankAccountInfoModel(BankAccountInfoModel model)
        {
            var investorBankAccountDetail = _investorBankAccountService.GetInvestorBankAccountById(_workContext.CurrentCustomer.Id);
            if (investorBankAccountDetail != null)
            {
                model.BankAccountType = investorBankAccountDetail.BankAccountType;
                model.AccountType = investorBankAccountDetail.AccountType;
                model.NameOnAccount = investorBankAccountDetail.NameOnAccount;
                model.RoutingNumber = investorBankAccountDetail.RoutingNumber;
                model.AccountNumber = investorBankAccountDetail.AccountNumber;
                model.BankName = investorBankAccountDetail.BankName;
                model.BankSwiftCode = investorBankAccountDetail.BankSwiftCode;
                model.AccountName1 = investorBankAccountDetail.AccountName1;
                model.AccountNumber1 = investorBankAccountDetail.AccountNumber1;
                model.ContactName = investorBankAccountDetail.ContactName;
                model.ReferenceText = investorBankAccountDetail.ReferenceText;
                model.PhoneNumber = investorBankAccountDetail.PhoneNumber;
            }
            model.AvailabelBankAccountTypes = new List<SelectListItem>
            {
                new SelectListItem { Value = "Personal", Text = "Personal", Selected = (!string.IsNullOrEmpty(model.BankAccountType) ? model.BankAccountType.Split(',').Contains("Personal") : false)},
                new SelectListItem { Value = "Business" , Text = "Business", Selected = (!string.IsNullOrEmpty(model.BankAccountType) ? model.BankAccountType.Split(',').Contains("Business") : false)}
            };
            model.AccountTypes = new List<SelectListItem>
            {
                new SelectListItem { Value = "Saving", Text = "Saving", Selected = (!string.IsNullOrEmpty(model.AccountType) ? model.AccountType.Split(',').Contains("Saving") : false)},
                new SelectListItem { Value = "Currrent" , Text = "Currrent", Selected = (!string.IsNullOrEmpty(model.AccountType) ? model.AccountType.Split(',').Contains("Currrent") : false)}
            };
        }

        #endregion

        #region Methods

        #region My Account > Document

        public ActionResult InvestorDocument()
        {
            var model = new InvestorDocumentModel();
            PrepareInvestorDocumentDetailModel(model);

            return View("~/Plugins/BD.CrowdPay/Views/CrowdPay/InvestorDocument.cshtml", model);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult InvestorDocument(InvestorDocumentModel model)
        {
            var investorDocument = _investorDocumentService.GetInvestorDocumentByCustomerId(_workContext.CurrentCustomer.Id);
            if (investorDocument == null)
            {
                _investorDocumentService.InsertInvestorDocument(new InvestorDocument
                {
                    CustomerId = _workContext.CurrentCustomer.Id,
                    DocumentId = model.DocumentId,
                    DocumentTitle = model.DocumentTitle
                });
            }
            else
            {
                investorDocument.DocumentId = model.DocumentId;
                investorDocument.DocumentTitle = model.DocumentTitle;

                _investorDocumentService.UpdateInvestorDocument(investorDocument);
            }

            return InvestorDocument();
        }

        #endregion
        
        #region My Account > Bank

        public ActionResult BankAccount()
        {
            var model = new BankAccountInfoModel();
            PrepareBankAccountInfoModel(model);
            return View("~/Plugins/BD.CrowdPay/Views/CrowdPay/BankAccount.cshtml", model);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult BankAccount(BankAccountInfoModel model)
        {
            var investorBankAccountDetail = _investorBankAccountService.GetInvestorBankAccountById(_workContext.CurrentCustomer.Id);

            if (investorBankAccountDetail == null)
            {
                _investorBankAccountService.InsertInvestorBankAccount(new InvestorBankAccount
                {
                    CustomerId = _workContext.CurrentCustomer.Id,
                    BankAccountType = model.BankAccountType,
                    AccountType = model.AccountType,
                    NameOnAccount = model.NameOnAccount,
                    RoutingNumber = model.RoutingNumber,
                    AccountNumber = model.AccountNumber,
                    BankName = model.BankName,
                    BankSwiftCode = model.BankSwiftCode,
                    AccountName1 = model.AccountName1,
                    AccountNumber1 = model.AccountNumber1,
                    ReferenceText = model.ReferenceText,
                    ContactName = model.ContactName,
                    PhoneNumber = model.PhoneNumber
                });
            }
            else
            {
                investorBankAccountDetail.BankAccountType = model.BankAccountType;
                investorBankAccountDetail.AccountType = model.AccountType;
                investorBankAccountDetail.NameOnAccount = model.NameOnAccount;
                investorBankAccountDetail.RoutingNumber = model.RoutingNumber;
                investorBankAccountDetail.AccountNumber = model.AccountNumber;
                investorBankAccountDetail.BankName = model.BankName;
                investorBankAccountDetail.BankSwiftCode = model.BankSwiftCode;
                investorBankAccountDetail.AccountName1 = model.AccountName1;
                investorBankAccountDetail.AccountNumber1 = model.AccountNumber1;
                investorBankAccountDetail.ReferenceText = model.ReferenceText;
                investorBankAccountDetail.ContactName = model.ContactName;
                investorBankAccountDetail.PhoneNumber = model.PhoneNumber;

                _investorBankAccountService.UpdateInvestorBankAccount(investorBankAccountDetail);
            }

            return BankAccount();
        }

        #endregion

        #region Admin > Customer detail > Documents

        [AdminAuthorize]
        [ChildActionOnly]
        public ActionResult InvestorDocuments(int customerId)
        {
            ViewBag.CustomerId = customerId;
            return View("~/Plugins/BD.CrowdPay/Views/CrowdPay/Administration/InvestorDocumentList.cshtml");
        }

        [HttpPost]
        public ActionResult InvestorDocumentList(DataSourceRequest command, int customerId)
        {
            var investorDocuments = _investorDocumentService.GetDocumentsByCustomerId(customerId);
            var investorDcoumentModel = investorDocuments
                .Select(x =>
                {
                    var download = _downloadService.GetDownloadById(x.DocumentId);
                    if (download == null)
                        throw new Exception("Document cannot be loaded");
                    var model = new InvestorDocumentModel
                    {
                        DocumentId = x.DocumentId,
                        DocumentTitle = x.DocumentTitle,
                    };
                    return model;
                })
                .ToList();

            var gridModel = new DataSourceResult()
            {
                Data = investorDcoumentModel,
                Total = investorDcoumentModel.Count
            };

            return Json(gridModel);
        }

        #endregion

        #region Login

        [HttpPost]
        [CaptchaValidator]
        //available even when a store is closed
        [StoreClosed(true)]
        //available even when navigation is not allowed
        [PublicStoreAllowNavigation(true)]
        public ActionResult Login(LoginModel model, string returnUrl, bool captchaValid)
        {
            //validate CAPTCHA
            if (_captchaSettings.Enabled && _captchaSettings.ShowOnLoginPage && !captchaValid)
            {
                ModelState.AddModelError("", _captchaSettings.GetWrongCaptchaMessage(_localizationService));
            }

            if (ModelState.IsValid)
            {
                if (_customerSettings.UsernamesEnabled && model.Username != null)
                {
                    model.Username = model.Username.Trim();
                }
                var loginResult = _customerRegistrationService.ValidateCustomer(_customerSettings.UsernamesEnabled ? model.Username : model.Email, model.Password);
                switch (loginResult)
                {
                    case CustomerLoginResults.Successful:
                        {
                            var customer = _customerSettings.UsernamesEnabled ? _customerService.GetCustomerByUsername(model.Username) : _customerService.GetCustomerByEmail(model.Email);

                            //migrate shopping cart
                            _shoppingCartService.MigrateShoppingCart(_workContext.CurrentCustomer, customer, true);

                            //sign in new customer
                            _authenticationService.SignIn(customer, model.RememberMe);

                            //raise event       
                            _eventPublisher.Publish(new CustomerLoggedinEvent(customer));

                            //activity log
                            _customerActivityService.InsertActivity("PublicStore.Login", _localizationService.GetResource("ActivityLog.PublicStore.Login"), customer);

                            //return to accrediation page
                            var individualBasicInfo = _bDAddressService.GetIndividualBasicInfo(customer.Id);
                            var vi_user_id = _genericAttributeService.GetAttributesForEntity(customer.Id, ClientConstants.GerenicAttributeKeyGroup.CustomerGroup)
                                .FirstOrDefault(x => x.Key == ClientConstants.TempCheckOutGenericAttirubutes.VerifyInvestorViUserId);
                            if (individualBasicInfo == null | vi_user_id == null)
                            {
                                return RedirectToRoute("Plugin.CrowdPay.Accreditation");
                            }
                            
                            if (String.IsNullOrEmpty(returnUrl) || !Url.IsLocalUrl(returnUrl))
                                return RedirectToRoute("HomePage");

                            return Redirect(returnUrl);
                        }
                    case CustomerLoginResults.CustomerNotExist:
                        ModelState.AddModelError("", _localizationService.GetResource("Account.Login.WrongCredentials.CustomerNotExist"));
                        break;
                    case CustomerLoginResults.Deleted:
                        ModelState.AddModelError("", _localizationService.GetResource("Account.Login.WrongCredentials.Deleted"));
                        break;
                    case CustomerLoginResults.NotActive:
                        ModelState.AddModelError("", _localizationService.GetResource("Account.Login.WrongCredentials.NotActive"));
                        break;
                    case CustomerLoginResults.NotRegistered:
                        ModelState.AddModelError("", _localizationService.GetResource("Account.Login.WrongCredentials.NotRegistered"));
                        break;
                    case CustomerLoginResults.WrongPassword:
                    default:
                        ModelState.AddModelError("", _localizationService.GetResource("Account.Login.WrongCredentials"));
                        break;
                }
            }

            //If we got this far, something failed, redisplay form
            model.UsernamesEnabled = _customerSettings.UsernamesEnabled;
            model.DisplayCaptcha = _captchaSettings.Enabled && _captchaSettings.ShowOnLoginPage;
            return View("~/Themes/OmnisoftCrowd/Views/Customer/Login.cshtml", model);
        }
        #endregion

        #endregion
    }
}
