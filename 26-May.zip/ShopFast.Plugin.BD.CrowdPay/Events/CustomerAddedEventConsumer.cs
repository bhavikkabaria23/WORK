﻿using Nop.Core.Domain.Customers;
using Nop.Core.Events;
using Nop.Services.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Events
{
    public class CustomerAddedEventConsumer : IConsumer<EntityInserted<Customer>>
    {
        public void HandleEvent(EntityInserted<Customer> eventMessage)
        {
            var id = eventMessage.Entity.Id;
            System.Web.HttpContext.Current.Session["BD_Admin_CustomerController_Create_Customer_Id"] = id;
        }
    }
}