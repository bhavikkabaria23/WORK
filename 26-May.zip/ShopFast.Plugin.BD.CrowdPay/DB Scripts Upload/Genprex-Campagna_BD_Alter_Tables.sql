use [test-genprex]
alter table BD_IndividualBasicInfo
add Home_Address nvarchar(max) not null default 'Home Address'

alter table BD_SubscriptionTemplate
add HTMLTemplateForProductAgreement nvarchar(max) null

alter table BD_SubscriptionTemplate
add PDFUploadIdForProductAgreement int null

alter table BD_SubscriptionTemplate
add DocuSignMode int not null default 5

alter table BD_investorForm
add ZipPostalCode nvarchar(max) null

alter table BD_investorForm
add FormType nvarchar(max) not null default 'Reserve Share'

alter table BD_investorForm
add CreatedOn datetime not null default GETDATE()

alter table BD_investorForm
add LanguageId int null 

alter table BD_SubscriptionTemplate
add ShowInSummaryPage nvarchar(max) not null default '{"ShowTotalInvestment":"false","ShowMaxInvestment":"false","ShowMinInvestment":"false","ShowPrice":"false","ShowDaysLeft":"true","ShowInvestors":"true","ShowRaised":"true"}'
alter table BD_SubscriptionTemplate
add ShowInDeatilPage nvarchar(max) not null default '{"ShowTotalInvestment":"false","ShowMaxInvestment":"false","ShowMinInvestment":"false","ShowPrice":"false","ShowDaysLeft":"true","ShowInvestors":"true","ShowRaised":"true"}'
alter table BD_SubscriptionTemplate
add ShowInCheckoutPage nvarchar(max) not null default '{"ShowTotalInvestment":"true","ShowMaxInvestment":"true","ShowMinInvestment":"true","ShowPrice":"true","ShowDaysLeft":"false","ShowInvestors":"false","ShowRaised":"false"}'

-- for custom plugin
alter table Product
add CustomFullDescription nvarchar(max) null

alter table Product
add VideoUrl nvarchar(max) null

CREATE TABLE [dbo].[InvestorBankAccount](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[CustomerId] [int] NOT NULL,
	[BankName] [nvarchar](30) NULL,
	[BankSwiftCode] [nvarchar](30) NULL,
	[BankAccountType] [nvarchar](30) NULL,
	[AccountType] [nvarchar](30) NULL,
	[RoutingNumber] [nvarchar](50) NULL,
	[NameOnAccount] [nvarchar](30) NULL,
	[AccountNumber] [nvarchar](50) NULL,
	[AccountName1] [nvarchar](50) NULL,
	[AccountNumber1] [nvarchar](50) NULL,
	[ReferenceText] [nvarchar](50) NULL,
	[ContactName] [nvarchar](50) NULL,
	[PhoneNumber] [nvarchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[InvestorRevenueDocument](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[CustomerId] [int] NOT NULL,
	[DocumentId] [int] NULL,
	[DocumentTitle] [nvarchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

INSERT INTO [dbo].[LocaleStringResource] ([LanguageId],[ResourceName],[ResourceValue]) VALUES (1
           ,'BD.ConfirmationOption.Required','Please confirm')
		   INSERT INTO [dbo].[LocaleStringResource] ([LanguageId],[ResourceName],[ResourceValue]) VALUES (1
           ,'BD.ConfirmationSignature.Required','Signature is required')

INSERT INTO [dbo].[LocaleStringResource] ([LanguageId],[ResourceName],[ResourceValue]) VALUES (1
           ,'ShopFast.BD.Admin.Settings.ShowInSummaryPage','Summary Page')
INSERT INTO [dbo].[LocaleStringResource] ([LanguageId],[ResourceName],[ResourceValue]) VALUES (1
           ,'ShopFast.BD.Admin.Settings.ShowInDeatilPage','Detail Page')
INSERT INTO [dbo].[LocaleStringResource] ([LanguageId],[ResourceName],[ResourceValue]) VALUES (1
           ,'ShopFast.BD.Admin.Settings.ShowInCheckoutPage','Checkout Page')
INSERT INTO [dbo].[LocaleStringResource] ([LanguageId],[ResourceName],[ResourceValue]) VALUES (1
           ,'ShopFast.BD.InvestmentAttributes.ShowTotalInvestment','Total Investment')
INSERT INTO [dbo].[LocaleStringResource] ([LanguageId],[ResourceName],[ResourceValue]) VALUES (1
           ,'ShopFast.BD.InvestmentAttributes.ShowMaxInvestment','Maximum Investment')
INSERT INTO [dbo].[LocaleStringResource] ([LanguageId],[ResourceName],[ResourceValue]) VALUES (1
           ,'ShopFast.BD.InvestmentAttributes.ShowMinInvestment','Minimum Investment')
INSERT INTO [dbo].[LocaleStringResource] ([LanguageId],[ResourceName],[ResourceValue]) VALUES (1
           ,'ShopFast.BD.InvestmentAttributes.ShowPrice','Price')
INSERT INTO [dbo].[LocaleStringResource] ([LanguageId],[ResourceName],[ResourceValue]) VALUES (1
           ,'ShopFast.BD.InvestmentAttributes.ShowDaysLeft','Days Left')
INSERT INTO [dbo].[LocaleStringResource] ([LanguageId],[ResourceName],[ResourceValue]) VALUES (1
           ,'ShopFast.BD.InvestmentAttributes.ShowInvestors','Investors')
INSERT INTO [dbo].[LocaleStringResource] ([LanguageId],[ResourceName],[ResourceValue]) VALUES (1
           ,'ShopFast.BD.InvestmentAttributes.ShowRaised','Raised')

		   
-----------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------

alter table BD_SubscriptionTemplate
add HtmlSubscriptionTemplate bit not null default 0

INSERT INTO [dbo].[LocaleStringResource] ([LanguageId],[ResourceName],[ResourceValue]) VALUES (1
           ,'Admin.Catalog.Products.Fields.HtmlSubscriptionTemplate','Word Subscription Template')		   

alter table BD_SubscriptionTemplate
add InvestmentAttributesDisplayOrder nvarchar(max) not null default ''

alter table BD_SubscriptionTemplate
add CustomFields nvarchar(max) not null default ''

INSERT INTO [dbo].[LocaleStringResource] ([LanguageId],[ResourceName],[ResourceValue]) VALUES (1
           ,'ShopFast.BD.InvestmentAttributes.CustomFields','Custom Fields')
		   INSERT INTO [dbo].[LocaleStringResource] ([LanguageId],[ResourceName],[ResourceValue]) VALUES (1
           ,'ShopFast.BD.InvestmentAttributes.CustomFieldLabel','Title')
		   INSERT INTO [dbo].[LocaleStringResource] ([LanguageId],[ResourceName],[ResourceValue]) VALUES (1
           ,'ShopFast.BD.InvestmentAttributes.CustomFieldValue','Value')		

		   ---------------New not uploaded -----------------------------------------
-- #################################
-- Vendor additional fields
-- ##################################

alter table Vendor
add OfferingSize nvarchar(max) null

alter table Vendor
add IndustryType nvarchar(max) null

alter table Vendor
add AcceptingInvestment int null

-- #################################
-- AuthorizeOffering for offering allow to access or not
-- ##################################

alter table BD_SubscriptionTemplate
add AuthorizeOffering bit not null default 1
INSERT INTO [dbo].[LocaleStringResource] ([LanguageId],[ResourceName],[ResourceValue]) VALUES (1
           ,'ShopFast.BD.Admin.Settings.AuthorizeOffering','Authorize Offering')

 -- #################################
-- Investor Form message templates - Not in use now
-- ##################################

--		   insert into messagetemplate
--(Name, BccEmailAddresses, [Subject], Body, IsActive, AttachedDownloadId, EmailAccountId, LimitedToStores,DelayBeforeSend,DelayPeriodId)
--values
--('InvestorForm.CustomerNotification',
--	NULL,
--		'Investor Inquiry',
--		'',
--		1,0,0,0,null,0)
--		insert into messagetemplate
--(Name, BccEmailAddresses, [Subject], Body, IsActive, AttachedDownloadId, EmailAccountId, LimitedToStores,DelayBeforeSend,DelayPeriodId)
--values
--('InvestorForm.StoreOwnerNotification',
--	NULL,
--		'Owner - Investor Inquiry',
--		'',
--		1,0,0,0,null,0)
--select * from MessageTemplate

-- #################################
-- Accreditation message templates
-- ##################################

		   insert into messagetemplate
(Name, BccEmailAddresses, [Subject], Body, IsActive, AttachedDownloadId, EmailAccountId, LimitedToStores,DelayBeforeSend,DelayPeriodId)
values
('Accreditation.CustomerNotification',
	NULL,
		'Investor Account',
		'',
		1,0,0,0,null,0)
		insert into messagetemplate
(Name, BccEmailAddresses, [Subject], Body, IsActive, AttachedDownloadId, EmailAccountId, LimitedToStores,DelayBeforeSend,DelayPeriodId)
values
('Accreditation.StoreOwnerNotification',
	NULL,
		'Owner - Investor Account',
		'',
		1,0,0,0,null,0)
select * from MessageTemplate

