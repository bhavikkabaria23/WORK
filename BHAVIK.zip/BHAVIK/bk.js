﻿SelfAssessment.controller("SelfAssessmentCtrl", ['$scope', '$location', '$cookieStore', '$anchorScroll', function ($scope, $location, $cookieStore, $anchorScroll) {
    $scope.isLastStep = false;
    $scope.isFirstStep = true;

    $scope.SetAnswerInCookie = function (key, value, Isga) {        
        var stateJason = {};
        if ($cookieStore.get("SAStateJson") !== undefined) {
            stateJason = JSON.parse($cookieStore.get("SAStateJson"));
        }
        stateJason[key] = value;
        var stateJasonString = JSON.stringify(stateJason);
        $cookieStore.put("SAStateJson", stateJasonString);

        if (Isga) {
            var initial = parseInt(stateJason.SAque1Ans);
            var final = parseInt(stateJason.SAque5Ans);
            var diff = final - initial;
            ga('send', 'event', "self-assessment form", "submission", "Initial - " + initial);
            ga('send', 'event', "self-assessment form", "submission", "Final - " + final);
            ga('send', 'event', "self-assessment form", "submission", "Diff - " + diff);
        }
    };

    // Set Begin Step Start ***
    $scope.SaveBegin = function () {
        $scope.SetAnswerInCookie("SABegin", true);
    };
    // Set Begin Step End ***

    // Set Que1 Step Start ***
    $scope.SaveQue1 = function () {
        if ($scope.que1ScoreValue) {
            $scope.SetAnswerInCookie("SAque1Ans", $scope.que1ScoreValue);
        }
    };

    $scope.Que1Click = function () {
        $location.hash('ptag');
        $anchorScroll();

        $scope.ValidateStep();
    };
    // Set Que1 Step End ***

    // Set Que2 Step Start ***
    $scope.SaveQue2 = function () {
        if ($scope.que2CauseOfHypoparaValue) {
            $scope.SetAnswerInCookie("SAque2Ans", $scope.que2CauseOfHypoparaValue);
        }
    };
    $scope.SetHypoparaCause = function (type) {
        $location.hash('myTabContent');
        // call $anchorScroll()
        $anchorScroll();

        $scope.que2CauseOfHypoparaValue = type;
        $scope.ValidateStep();
    };
    // Set Que2 Step End ***

    // Set Que3 Step Start ***
    $scope.SaveQue3 = function () {        
        if ($scope.que3ComplicationsValue) {
            $scope.SetAnswerInCookie("SAque3Ans", $scope.que3ComplicationsValue);
        }
    };
    $scope.ShowComplications = function (compvalue) {
        $scope.que3ComplicationsValue = compvalue;
        $("#YesComplications").removeClass("active");
        $("#NoComplications").removeClass("active");
        if (compvalue == "Complications_Yes") {
            $("#YesComplications").addClass("active");
        }
        else {
            $("#NoComplications").addClass("active");
        }
        $scope.ValidateStep();
    };
    // Set Que3 Step End ***

    // Set Que4 Step Start ***
    $scope.SetQue4Step = function () {        
        $scope.setQue4SliderDiv = function (currentvalue) {            
            if (currentvalue >= 45 && currentvalue <= 50) {
                $scope.stronglyAgree = false;
                $scope.stronglyDisagree = false;
                $scope.IsStepValidate = false;
                $(".next-arrow-button").css("cursor", "not-allowed");
                $scope.SAque4Ans = undefined;
            }
            else if (currentvalue > 50) {
                $scope.stronglyAgree = true;
                $scope.stronglyDisagree = false;
                $scope.SAque4Agreestatus = "Agree";
                $scope.ValidateStep();
                $scope.SAque4Ans = $scope.SAque4Agreestatus + "_" + currentvalue;
            }
            else {
                $scope.stronglyAgree = false;
                $scope.stronglyDisagree = true;
                $scope.SAque4Agreestatus = "Disagree";
                $scope.ValidateStep();
                $scope.SAque4Ans = $scope.SAque4Agreestatus + "_" + currentvalue;
            }            
            $scope.$apply();            
        };

        /*Slider code start*/
        var handle = $(".custom-handle");
        $("#sliderQuestion4").slider({
            max: 100,
            step:0.5,
            create: function () {
                $scope.stronglyAgree = false;
                $scope.stronglyDisagree = false;
                $(this).slider('value', 48);                
            },
            slide: function (event, ui) {
                //handle.text(ui.value);
                $scope.setQue4SliderDiv(parseInt(ui.value));
                $scope.$apply();                
            }
        });
        /*Slider code end*/
    };

    $scope.SaveQue4 = function () {
        if ($scope.SAque4Ans) {
            $scope.SetAnswerInCookie("SAque4Ans", $scope.SAque4Ans);
        }
    };

    // Set Que4 Step End ***

    // Set Que5 Step Start ***
    $scope.SaveQue5 = function () {
        if ($scope.que5ScoreValue) {
            $scope.SetAnswerInCookie("SAque5Ans", $scope.que5ScoreValue,true);
        }
    };

    $scope.Que5Click = function () {
        $location.hash('ptag5');
        $anchorScroll();

        $scope.ValidateStep();
    };
    // Set Que5 Step End ***

    $scope.ValidateStep = function () {
        $scope.IsStepValidate = true;
    };
    $scope.IsSetStepValidate = function () {        
        if ($scope.IsStepValidate) {            
            $(".next-arrow-button").css("cursor", "pointer");
        }        
        return $scope.IsStepValidate;
    };


    $scope.changeSteps = function (_stepNumber) {       
        $cookieStore.put("stepNumber", _stepNumber);
        switch (_stepNumber) {
            case 1: // Test your knowledge of hypoparathyroidism
                $scope.IsStepValidate = true;
                $(".next-arrow-button").css("cursor", "pointer");
                $scope.isFirstStep = true;                
                //$scope.step = "/Templates/Step1.html";
                break;
            case 2: // How would you assess your current understanding of hypopara?
                if (!$scope.que1ScoreValue) {
                    $scope.IsStepValidate = false;
                    $(".next-arrow-button").css("cursor", "not-allowed");
                }
                $scope.isFirstStep = false;                
                $scope.SaveBegin();
                //$scope.step = "/Templates/Step2.html";
                break;
            case 3: // Do you know the most common cause of hypopara ?                
                if (!$scope.que2CauseOfHypoparaValue) {
                    $scope.IsStepValidate = false;
                    $(".next-arrow-button").css("cursor", "not-allowed");
                }
                $scope.isFirstStep = false;                                
                $scope.SaveQue1();
                //$scope.step = "/Templates/Step3.html";
                break;
            case 4: // Do you know any of the long-term complications of hypopara?
                if (!$scope.que3ComplicationsValue) {
                    $scope.IsStepValidate = false;
                    $(".next-arrow-button").css("cursor", "not-allowed");
                }
                $scope.isFirstStep = false;                        
                $scope.SaveQue2();
                //$scope.step = "/Templates/Step3.html";
                break;
            case 5: // “I understand how hypopara can affect quality of life.”
                if (!$scope.SAque4Ans) {
                    $scope.IsStepValidate = false;
                    $(".next-arrow-button").css("cursor", "not-allowed");
                }
                $scope.isFirstStep = false;                                
                $scope.SaveQue3();
                $scope.SetQue4Step();
                //$scope.step = "/Templates/Step3.html";
                break;
            case 6: // Having completed this tool, how would you assess your knowledge of hypopara now?
                if (!$scope.que5ScoreValue) {
                    $scope.IsStepValidate = false;
                    $(".next-arrow-button").css("cursor", "not-allowed");
                }
                $scope.isFirstStep = false;                                
                $scope.SaveQue4();
                //$scope.step = "/Templates/Step3.html";
                break;
            case 7: // Thank you for taking the self-assessment tool and learning more about hypopara!
                $scope.IsStepValidate = true;
                $(".next-arrow-button").css("cursor", "pointer");
                $scope.isFirstStep = true;
                //$scope.step = "/Templates/Step4.html";
                $scope.isLastStep = true;
                                
                $scope.SaveQue5();
                break;
        }
    };
    $scope.changePreviousSteps = function (_stepNumber) {        
        $cookieStore.put("stepNumber", _stepNumber);
        $scope.IsStepValidate = true;
        $(".next-arrow-button").css("cursor", "pointer");
        switch (_stepNumber) {
            case 1: // Test your knowledge of hypoparathyroidism                
                $scope.isFirstStep = true;                
                break;
            case 2: // How would you assess your current understanding of hypopara?              
                $scope.isFirstStep = false;                
                break;
            case 3: // Do you know the most common cause of hypopara ?                
                $scope.isFirstStep = false;                                
                break;
            case 4: // Do you know any of the long-term complications of hypopara?                
                $scope.isFirstStep = false;                
                break;
            case 5: // “I understand how hypopara can affect quality of life.”                
                $scope.isFirstStep = false;                                
                break;
            case 6: // Having completed this tool, how would you assess your knowledge of hypopara now?
                $scope.isFirstStep = false;                                
                break;
            case 7: // Thank you for taking the self-assessment tool and learning more about hypopara!                
                $scope.isFirstStep = true;                
                $scope.isLastStep = true;
                break;
        }
    };
    $scope.nextStep = function () {        
        if ($scope.IsStepValidate) {
            $scope.changeSteps(++$scope.stepNumber);
        }
    };
    $scope.previousStep = function () {        
        $scope.changePreviousSteps(--$scope.stepNumber);
    };
    $scope.prevStep = function () {
        $scope.changeSteps(--$scope.stepNumber);
    };
    $scope.ShowCurrentStep = function (stepno) {
        if ($scope.stepNumber === stepno) {
            return true;
        }
        else {
            return false;
        }
    };
    $scope.ShowDialogPopup = function () {
        $("#ShowAssessmentPopup").trigger("click");
    };
   
    if ($cookieStore.get("stepNumber") !== undefined) {        
        $scope.stepNumber = $cookieStore.get("stepNumber");
        $scope.changeSteps($scope.stepNumber);
    }

    $("#ConfirmAssessment").click(function () {
        $("#SelfAssessmentConfirmModal").show();
    });
    $(".ConfirmClose").click(function () {
        $("#SelfAssessmentConfirmModal").hide();
    });

    $scope.SetPopupCookie = function () {        
        if ($cookieStore.get("stepNumber") === undefined) {
            $scope.stepNumber = 1;
            $scope.changeSteps($scope.stepNumber);
        }
        else {
            $scope.stepNumber = $cookieStore.get("stepNumber");
            $scope.changeSteps($scope.stepNumber);
        }        
    };    

    $(".minimizePopup").click(function () {
        $("#SelfAssessmentModal").modal("hide");
    });

    $("#hide").click(function () {
        $("#dvPassport").hide();
    });
    $("#nothankyou").click(function () {
        $("#dvPassport").hide();        
    });    
    $("#ShowAssessmentPopup").click(function () {
        $("#dvPassport").hide();
    });
    $("#show").click(function () {        
        if ($scope.SAYesNo === "no") {
            $('.white-modal ul li').removeClass("active");
            $('#nothankyou').addClass("active");
        }
        else {
            $('.white-modal ul li').removeClass("active");
            $('#ShowAssessmentPopup').addClass("active");
        }

        if ($cookieStore.get("stepNumber") === undefined) {
            $("#dvPassport").show();
        }
        else {
            $scope.ShowDialogPopup();
        }
    });   

    $('.white-modal ul li').click(function () {
        $('.white-modal ul li').removeClass("active");
        $(this).addClass("active");        
        $scope.SAYesNo = $(this).data("sayesno");        
    });
    $('.white-modal ul li').mouseover(function () {
        $('.white-modal ul li').removeClass("active");
        $(this).addClass("active");
    });
    $('.white-modal ul li').mouseleave(function () {
        $('.white-modal ul li').addClass("active");
        $(this).removeClass("active");
    });
    
    $(document).keyup(function (e) {        
        if (e.keyCode === 27) {            
            if ($("#SelfAssessmentModal").length > 0) {
                $("#SelfAssessmentModal").modal("hide");
            }
        }
    });
    $(".closecookie").click(function () {
        $(".cookies-div").hide();
    });

    $scope.SetSAIconPosition = function () {
        if ($('.nav-links-next-prev').length > 0) {
            $(".hypopara-popup .self-assessment .popup").css("bottom", "50px");
            $(".hypopara-popup .white-modal").css("bottom", "170px");
        }
    };
    $scope.SetSAIconPosition();

    $scope.ClearAllAnswer = function () {
        $(".setansclear").removeClass("active");

        // que 1
        $scope.que1ScoreValue = undefined;

        // que 2
        $scope.que2CauseOfHypoparaValue = undefined;        

        // que 3
        $scope.que3ComplicationsValue = undefined;
        $scope.que3ComplicationsValue = undefined;
        $("#YesComplications").removeClass("active");
        $("#NoComplications").removeClass("active");

        // que 4
        $scope.stronglyAgree = false;
        $scope.stronglyDisagree = false;                
        $scope.SAque4Ans = undefined;
        $("#sliderQuestion4").slider('value', 48);                

        // que 5
        $scope.que5ScoreValue = undefined;
    };
    $scope.ClearCookie = function () {        
        $scope.stepNumber = 1;
        $scope.changeSteps(1);        
        $cookieStore.remove("SAStateJson");
        $scope.ClearAllAnswer();
    };
}]);

