
	
--truncate table BinderPdfTable

--delete from MigrationReferedPolicy
--delete from MinimumDepositOverride
--delete from ProposalDocument
--delete from ReferedManualExceptionRule
--delete from ProspectClientReminderDetail

--drop table MigrationReferedPolicy
--drop table  MinimumDepositOverride
--drop table  ProposalDocument
--drop table  ReferedManualExceptionRule
--drop table  ProspectClientReminderDetail
--drop table ProposalFormReference

--delete from ProposalFormReference

--drop table DocumentReminderDetail
--drop table PaymentReminderDetail
--drop table ProspectClientReminderDetail
--drop table EmailNotificationsReport

--truncate table ProposalFormReference
--truncate table RenewPolicies
--truncate table ApplicationExceptionLogs
--truncate table EmailNotificationsReport

--select count(*) from BinderPdfTable


--select 'delete from ProposalFormReference where ProposalFormReferenceId = '+cast(ProposalFormReferenceId as nvarchar)+char(10)+'go'+CHAR(10) from ProposalFormReference
