

delete from BinderPdfTable
delete from MigrationReferedPolicy
delete from MinimumDepositOverride
delete from ProposalDocument
delete from ReferedManualExceptionRule
delete from ProspectClientReminderDetail
delete from ProposalFormReference
delete from RenewPolicies
