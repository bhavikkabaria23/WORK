
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
USE [MarathonInsuranceBroker_V2]
ALTER DATABASE [MarathonInsuranceBroker_V2]
SET RECOVERY SIMPLE
Go
DBCC SHRINKFILE (N'MarathonInsuranceBroker',1)
Go
ALTER DATABASE [MarathonInsuranceBroker_V2]
SET RECOVERY FULL

USE [MarathonInsuranceBroker_V2]
ALTER DATABASE [MarathonInsuranceBroker_V2]
SET RECOVERY SIMPLE
Go
DBCC SHRINKFILE (N'MarathonInsuranceBroker_log',1)
Go
ALTER DATABASE [MarathonInsuranceBroker_V2]
SET RECOVERY FULL




