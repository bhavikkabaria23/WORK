$('.phone,.fax,.cellphone').attr("placeholder", "(###) ###-####");
$('.phone,.fax,.cellphone').inputmask("(999) 999-9999");
$(".percent").inputmask("integer", {
    autoGroup: true,
    suffix: " %",
    removeMaskOnSubmit: true,
    rightAlign: false
});
$(".money").inputmask("decimal", {
    radixPoint: ".",
    groupSeparator: ",",
    autoGroup: true,
    prefix: "$ ",
    removeMaskOnSubmit: true,
    rightAlign: false
});
$('.partner-taxid').attr("placeholder", "XX-XXXXXXX");
$('.partner-taxid').unmask().maskFeild('99-9999999', { maskedChar: 'X', maskedCharsLength: 5 });
$('.partner-ssn').attr("placeholder", "XXX-XX-XXXX");
$('.partner-ssn').unmask().maskFeild('999-99-9999', { maskedChar: 'X', maskedCharsLength: 5 });


//$('.phone').mask('(000) 000-0000', { placeholder: "(###) ###-####" });
//$('.percent').mask('000%', { reverse: true });
//$('.money').mask('$ 000.000.000.000.000,00');
//$('.ssn').mask('000-00-0000', { placeholder: "XXX-XX-XXXX" });
//$('.fax').mask('(000) 000-0000', { placeholder: "(###) ###-####" });
//$('.cellphone').mask('000000000000');

// Signature------------------
$('.clearsign').click(function () {
    $('.signBox').signature('clear');
    $(this).siblings('input[type=text]').val('');
});

//$('.signBox').signature();
$('.signBox').signature({
    color: '#000000',
    change: function (event, ui) {
        var cnt = $(this).data('signcount');
        $('#hdnSignJSON' + cnt).val($(this).signature('toDataURL', 'images/png'));
    }
});
//------------------------

$("#mailingaddresssameno").click(function () {
    $("#mailingaddresssameDiv").slideDown();
});
$("#mailingaddresssameyes").click(function () {
    $("#mailingaddresssameDiv").slideUp();
});


$("#PaymentCardsyes").click(function () {
    $("#cacceptingcard").slideDown();
});
$("#PaymentCardsno").click(function () {
    $("#cacceptingcard").slideUp();
});


$("#merchantPaymentCardsyes").click(function () {
    $("#macceptingcard").slideDown();
});
$("#merchantPaymentCardsno").click(function () {
    $("#macceptingcard").slideUp();
});


$("#Breachyes").click(function () {
    $("#securitybreach").slideDown();
});
$("#Breachno").click(function () {
    $("#securitybreach").slideUp();
});

$("#LLC").click(function () {
    if ($(this).prop('checked') == true) {
        $("#llcstate").slideDown();
    }
    else {
        $("#llcstate").slideUp();
    }
});

$("#CardSwipes").click(function () {
    if ($(this).prop('checked') == true) {
        $("#cardswipe").slideDown();
    }
    else {
        $("#cardswipe").slideUp();
    }
});

$("#KeyEntered").click(function () {
    if ($(this).prop('checked') == true) {
        $("#keyentered").slideDown();
    }
    else {
        $("#keyentered").slideUp();
    }
});

$("#Motos").click(function () {
    if ($(this).prop('checked') == true) {
        $("#moto").slideDown();
    }
    else {
        $("#moto").slideUp();
    }
});

function CheckRequiredForWebsite() {
    if ($("#Internets").prop('checked') == true) {        
        $("#new_websiteaddress").rules("add", { required: true });
        $('#new_websiteaddress').prev("label").find('span').css("display", "inline");
    }
    else {        
        $('#new_websiteaddress').rules('remove', "required");
        $('#new_websiteaddress').prev("label").find('span').hide();
    }
}
$("#Internets").click(function () {    
    CheckRequiredForWebsite();
    if ($(this).prop('checked') == true) {
        $("#internet").slideDown();        
    }
    else {
        $("#internet").slideUp();
    }
});


$(".NatureOfBusiness input[type=radio]").click(function () {
    //if ($(this).attr('id') == "Internet") {
    //    $("#InternetUrlDiv").show();        
    //}
    //else {
    //    $("#InternetUrlDiv").hide();        
    //}
    if ($(this).attr('id') == "BusinessOther") {
        $("#NatureofBusiness").show();
    }
    else {
        $("#NatureofBusiness").hide();
    }
});

$("#URL").click(function () {
    $("#url").toggle();
});


$("#MailPercent").click(function () {
    if ($(this).prop('checked') == true) {
        $("#mailpercent").slideDown();
    }
    else {
        $("#mailpercent").slideUp();
    }
});
$("#InternetPercent").click(function () {
    if ($(this).prop('checked') == true) {
        $("#internetpercent").slideDown();
    }
    else {
        $("#internetpercent").slideUp();
    }
});
$("#TelephonePercent").click(function () {
    if ($(this).prop('checked') == true) {
        $("#telephonepercent").slideDown();
    }
    else {
        $("#telephonepercent").slideUp();
    }
});
$("#CardPresent").click(function () {
    if ($(this).prop('checked') == true) {
        $("#cardpresent").slideDown();
    }
    else {
        $("#cardpresent").slideUp();
    }
});

$("#MailfaxPercent").click(function () {
    if ($(this).prop('checked') == true) {
        $("#mailpercentdiv").slideDown();
    }
    else {
        $("#mailpercentdiv").slideUp();
    }
});
$("#InternetPercentorders").click(function () {
    if ($(this).prop('checked') == true) {
        $("#internetpercentdiv").slideDown();
    }
    else {
        $("#internetpercentdiv").slideUp();
    }
});
$("#TelephonePercentorders").click(function () {
    if ($(this).prop('checked') == true) {
        $("#telephonepercentdiv").slideDown();
    }
    else {
        $("#telephonepercentdiv").slideUp();
    }
});
$("#OtherPercentorders").click(function () {
    if ($(this).prop('checked') == true) {
        $("#otherpercentdiv").slideDown();
    }
    else {
        $("#otherpercentdiv").slideUp();
    }
});



$("#merchantServicersyes").click(function () {
    $("#merchantServicerdiv").slideDown();
});
$("#merchantServicersno").click(function () {
    $("#merchantServicerdiv").slideUp();
});


$("#FulfillServicersyes").click(function () {
    $("#FulfillServicerdiv").slideDown();
});
$("#FulfillServicersno").click(function () {
    $("#FulfillServicerdiv").slideUp();
});


$("#BusinessBankruptcy,#PersonalBankruptcy").click(function () {
    if ($("#NeverFiled").prop('checked') == true) {
        $("#NeverFiled").trigger("click");
    }    
    $("#personalServicerdiv").slideDown();
});
$("#NeverFiled").click(function () {
    if ($("#BusinessBankruptcy").prop('checked') == true) {
        $("#BusinessBankruptcy").trigger("click");
    }
    if ($("#PersonalBankruptcy").prop('checked') == true) {
        $("#PersonalBankruptcy").trigger("click");
    }
    $("#personalServicerdiv").slideUp();    
});

$("#productstoreyes").click(function () {
    $("#productstorediv").slideUp();
});
$("#productstoreno").click(function () {
    $("#productstorediv").slideDown();

});

//$("#retailLocationyes").click(function () {
//    $("#retailLocationdiv").slideDown();
//});
//$("#retailLocationno").click(function () {
//    $("#retailLocationdiv").slideUp();
//});

$("#othercompanyyes").click(function () {
    $("#othercompanydiv").slideDown();
});
$("#othercompanyno").click(function () {
    $("#othercompanydiv").slideUp();
});

$("#seasonalmerchantyes").click(function () {
    $("#seasonalmerchantdiv").slideDown();
});
$("#seasonalmerchantno").click(function () {
    $("#seasonalmerchantdiv").slideUp();
});

$("#LLC").click(function () {
    $("#llcstate").slideDown();
});
$("#IndividualSole").click(function () {
    $("#llcstate").slideUp();
});
$("#Partnership").click(function () {
    $("#llcstate").slideUp();
});
$("#Corporation").click(function () {
    $("#llcstate").slideUp();
});
$("#NonProfit").click(function () {
    $("#llcstate").slideUp();
});
$("#Goverment").click(function () {
    $("#llcstate").slideUp();
});
$("#Private").click(function () {
    $("#llcstate").slideUp();
});
$("Publiclyt").click(function () {
    $("#llcstate").slideUp();
});

$("#LLC").click(function () {
    $("#nonprofitdiv").slideUp();
});
$("#IndividualSole").click(function () {
    $("#nonprofitdiv").slideUp();
});
$("#Partnership").click(function () {
    $("#nonprofitdiv").slideUp();
});
$("#Corporation").click(function () {
    $("#nonprofitdiv").slideUp();
});
$("#NonProfit").click(function () {
    $("#nonprofitdiv").slideDown();
});
$("#Goverment").click(function () {
    $("#nonprofitdiv").slideUp();
});
$("#Private").click(function () {
    $("#nonprofitdiv").slideUp();
});
$("#Publiclyt").click(function () {
    $("#nonprofitdiv").slideUp();
});

// SSN and Tax ID format
if ($('#SsnId').is(':checked')) {
    //$('.ssn').mask('000-00-0000', { placeholder: "XXX-XX-XXXX" });
    $('.ssn').attr("placeholder", "XXX-XX-XXXX");
    $('.ssn').unmask().maskFeild('999-99-9999', { maskedChar: 'X', maskedCharsLength: 5 });
}
else if ($('#TaxId').is(':checked')) {
    //$('.ssn').mask('00-0000000', { placeholder: "XX-XXXXXXX" });
    $('.ssn').attr("placeholder", "XX-XXXXXXX");
    $('.ssn').unmask().maskFeild('99-9999999', { maskedChar: 'X', maskedCharsLength: 5 });
}
else {
    $('.ssn').hide();
}
$("#TaxId").click(function () {
    $('.ssn').show();
    $('.ssn').attr("placeholder", "XX-XXXXXXX");
    $('.ssn').unmask().maskFeild('99-9999999', { maskedChar: 'X', maskedCharsLength: 5 });
});
$("#SsnId").click(function () {
    $('.ssn').show();
    $('.ssn').attr("placeholder", "XXX-XX-XXXX");
    $('.ssn').unmask().maskFeild('999-99-9999', { maskedChar: 'X', maskedCharsLength: 5 });
});
//-----------------------------


$("#Terminal").click(function () {
    if ($(this).prop('checked') == true) {
        $("#ifterminaldiv").slideDown();
    }
    else {
        $("#ifterminaldiv").slideUp();
    }

});
$("#Software").click(function () {
    if ($(this).prop('checked') == true) {
        $("#ifsoftwarediv").slideDown();
    }
    else {
        $("#ifsoftwarediv").slideUp();
    }
});

$("#SeasonalSalesyes").click(function () {
    $("#SeasonalSalesDiv").slideDown();
});
$("#SeasonalSalesno").click(function () {
    $("#SeasonalSalesDiv").slideUp();
});


/* equipment page*/


$("#OtherGateway").click(function () {
    $("#OtherGatewayDiv").slideDown();
});
$("#SecurePaygateway").click(function () {
    $("#OtherGatewayDiv").slideUp();
});

$("#OtherEBT").click(function () {
    if ($(this).prop('checked') == true) {
        $("#OthermerchantDiv").slideDown();
    }
    else {
        $("#OthermerchantDiv").slideUp();
    }
});

$("#AutoBatch").click(function () {
    $("#AutoBatchDiv").slideDown();
    $("#Batchotherdiv").slideUp();

});

$("#Batchother").click(function () {
    $("#AutoBatchDiv").slideUp();
    $("#Batchotherdiv").slideDown();
});


/*mo/to2*/
$("#otherprocessorder").click(function () {
    if ($(this).prop('checked') == true) {
        $("#processorderdiv").slideDown();
    }
    else {
        $("#processorderdiv").slideUp();
    }
});

$("#otherentercreditinfo").click(function () {
    if ($(this).prop('checked') == true) {
        $("#entercreditinfodiv").slideDown();
    }
    else {
        $("#entercreditinfodiv").slideUp();
    }
});

$("#sslyes").click(function () {
    $("#sslDiv").slideDown();
});
$("#sslno").click(function () {
    $("#sslDiv").slideUp();
});

$("#productstoredno").click(function () {
    $("#productstoreddiv").slideDown();
});
$("#productstoredyes").click(function () {
    $("#productstoreddiv").slideUp();
});

$("#usmail").click(function () {
    $("#productshippeddiv").slideUp();
});

$("#productshippedother").click(function () {
    $("#productshippeddiv").slideDown();
});

$("#MarkOther").click(function () {
    if ($(this).prop('checked') == true) {
        $("#MarketingMethodDiv").slideDown();
    }
    else {
        $("#MarketingMethodDiv").slideUp();
    }
});

/*rates & fees*/

$("#ProcessingCost").click(function () {
    $("#ProcessingCostdiv").slideDown();
    $("#TieredProcessingdiv").slideUp();

});
$("#TieredProcessing").click(function () {
    $("#ProcessingCostdiv").slideUp();
    $("#TieredProcessingdiv").slideDown();

});

$("#AmericanExpressOptQualified").click(function () {
    $("#AmericanExpressOptQualifieddiv").slideDown();
    $("#AmericanExpressOptInterchangediv").slideUp();

});
$("#AmericanExpressOptInterchange").click(function () {
    $("#AmericanExpressOptQualifieddiv").slideUp();
    $("#AmericanExpressOptInterchangediv").slideDown();

});

$("#PINDebitFlatRate").click(function () {
    $("#PINDebitFlatRatediv").slideDown();
    $("#PINDebitInterchangediv").slideUp();

});
$("#PINDebitInterchange").click(function () {
    $("#PINDebitFlatRatediv").slideUp();
    $("#PINDebitInterchangediv").slideDown();

});



$("#btnMerchantSubmit").click(function (event) {
    if ($("#msform").valid()) {
        $(this).attr("disabled", "disabled").addClass("previous").css("cursor", "not-allowed");
        //stop submit the form, we will post it manually.
        event.preventDefault();
        // Get form
        var form = $('#msform')[0];
        // Create an FormData object
        var data = new FormData(form);
        var url = $('#msform').attr('action');
        $.ajax({
            type: "POST",
            enctype: 'multipart/form-data',
            url: url,
            data: data,
            processData: false,
            contentType: false,
            cache: false,
            timeout: 600000,
            success: function (response) {
                if (response) {
                    if (response == "home") {
                        location.href = "/";
                    }
                    else {
                        $("#divMerchant").html(response)
                    }
                }
                else {
                    alert("Something went wrong to post the form");
                }
            },
            error: function (e) {
                alert("Something went wrong to post the form");
            }
        });
    }
});
function pad2(number) {

    return (number < 10 ? '0' : '') + number

}

var pastdate = new Date();
pastdate.setFullYear(pastdate.getFullYear() - 18);
$('#sandbox-container input').datepicker({
    format: 'mm/dd/yyyy',
    endDate: pastdate
})
    .on('changeDate', function (e) {
        var date = e.date;
        if (date) {
            var dateString = date.getFullYear() + "-" + pad2(date.getMonth() + 1) + "-" + pad2(date.getDate());
            var controlId = "#" + $(this).attr("id") + "String";
            $(controlId).val(dateString);
        }
    });


$('.expirydate-container input').datepicker({
    format: 'mm/dd/yyyy',
    startDate: new Date()
})
    .on('changeDate', function (e) {
        var date = e.date;
        if (date) {
            var dateString = date.getFullYear() + "-" + pad2(date.getMonth() + 1) + "-" + pad2(date.getDate());
            var controlId = "#" + $(this).attr("id") + "String";
            $(controlId).val(dateString);
        }
    });

$('#inspection-date-container input').datepicker({
    format: 'mm/dd/yyyy'
})
    .on('changeDate', function (e) {
        var date = e.date;
        var dateString = date.getFullYear() + "-" + pad2(date.getMonth() + 1) + "-" + pad2(date.getDate());
        var controlId = "#" + $(this).attr("id") + "String";
        $(controlId).val(dateString);
    });

$(".btnClientClick").click(function () {
    if ($(".totalpercent:visible").length > 0) {
        var total = 0;
        var IsPercent = true;
        $(".totalpercent:visible").each(function (index) {
            var per = parseFloat($(this).val().replace('%', ''));
            if (isNaN(per)) {
                IsPercent = false;
                return false;
            }
            total = total + per;
        });
        if (total != 100 || !IsPercent) {
            $(".totalpercent:visible:nth(0)").focus();
            alert("Total Percentage should be 100%");
            return false;
        }
    }
});

$('input[type=checkbox]:checked').each(function () {
    $(this).trigger("click");
    $(this).trigger("click");
});

// FormsCompleted and CurrentForm are set in _MerchantSteps.cshtml
function SetDefaultControls() {
    //$('input[type=radio]').attr("data-val", true);
    //$('input[type=radio]').attr("data-val-required", "required");
    if (FormsCompleted && CurrentForm) {
        if (FormsCompleted.indexOf(CurrentForm) == -1) {
            $('input[type=radio]').prop('checked', false);
        }
        else {
            // Accept checkbox disable
            $(".checkboxAccept").prop('checked', true);
            $(".checkboxAccept").attr("disabled", "disabled").addClass("checkbox-disabled");

            // default radio button
            $('input[type=radio]:checked').each(function () {
                $(this).trigger("click");
                //if ($(this).prop('type') == "checkbox") {
                //    $(this).prop('checked', true);
                //}
            });
        }
    }
    else {
        $('input[type=radio]').prop('checked', false);
    }
}

SetDefaultControls();

var defaultRangeValidator = $.validator.methods.range;
$.validator.methods.range = function (value, element, param) {
    if (element.type === 'checkbox') {
        // if it's a checkbox return true if it is checked
        return element.checked;
    } else {
        // otherwise run the default validation function
        return defaultRangeValidator.call(this, value, element, param);
    }
}

$('.fileupload input[type=file]').change(function () {
    if ($(this).val()) {
        var filename = $(this).val().replace(/C:\\fakepath\\/i, '');
        $(this).parent('.fileupload').after('<span>' + filename + '</span> <br>');
    }
});

$("#ControllingInterestyes").click(function () {
    $("#Beneficial1").find("input[type=text]").each(function (i, item) {
        var id = $(this).attr("id");
        var val = $(this).val();
        var id2 = id.replace("Owner1", "ControllingOwner");
        $("#" + id2).val(val);
    });
    $("#Beneficial1").find("select").each(function (i, item) {
        var id = $(this).attr("id");
        var val = $(this).val();
        var id2 = id.replace("Owner1", "ControllingOwner");
        $("#" + id2).val(val).trigger('change');
    });
});

if ($.trim($("#Owner1_OwnershipPercent").val())) {
    var ownershipValue = parseInt($("#Owner1_OwnershipPercent").val().replace(" %", ""));
    OwnershipFlow(ownershipValue);
}
$("#Owner1_OwnershipPercent").blur(function () {
    if ($.trim($(this).val())) {
        var ownershipValue = parseInt($(this).val().replace(" %", ""));
        OwnershipFlow(ownershipValue);
    }
});

function OwnershipFlow(ownershipValue) {    
    if (ownershipValue >= 80) {
        $("#owner1").hide();
        $("#Beneficial2").hide();
        $("#Beneficial3").hide();
        $("#Beneficial4").hide();
    }
    else if (ownershipValue < 80 && ownershipValue >= 50) {
        $("#owner1").show();
        $("#owner2").hide();
        $("#Beneficial3").hide();
        $("#Beneficial4").hide();
    }
    else if (ownershipValue < 50 && ownershipValue >= 25) {
        $("#owner1").show();
        $("#owner2").show();
        $("#owner3").hide();
        $("#Beneficial4").hide();
    }
    else {
        $("#owner1").show();
        $("#owner2").show();
        $("#owner3").show();
    }
}