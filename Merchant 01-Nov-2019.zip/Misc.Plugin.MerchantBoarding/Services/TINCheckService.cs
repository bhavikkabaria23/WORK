﻿using Misc.Plugin.MerchantBoarding.Models;
using Newtonsoft.Json;
using Nop.Services.Localization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Misc.Plugin.MerchantBoarding.Services
{
    public class TINCheckService : ITINCheckService
    {
        private readonly MerchantBoardingtSettings _merchantBoardingtSettings;
        private readonly ILocalizationService _localizationService;


        public TINCheckService(MerchantBoardingtSettings merchantBoardingtSettings,
            ILocalizationService localizationService
            )
        {
            _merchantBoardingtSettings = merchantBoardingtSettings;
            _localizationService = localizationService;
        }
        public TINCheckResponse TINCheckVerification(TINCheckModel _pModel)
        {           
            if (_merchantBoardingtSettings.EnableTINCheck)
            {
                TINCheckResponse _oTINCheckResponse = new TINCheckResponse();
                string username = (_merchantBoardingtSettings.TINCheckMode == TINCheckMode.Live) ? _merchantBoardingtSettings.TINCheckLiveUsername : _merchantBoardingtSettings.TINCheckTestUsername;
                string password = (_merchantBoardingtSettings.TINCheckMode == TINCheckMode.Live) ? _merchantBoardingtSettings.TINCheckLivePassword : _merchantBoardingtSettings.TINCheckTestPassword;

                TINCheck.PVSServiceSoapClient client = new TINCheck.PVSServiceSoapClient();
                //TIN = 134188568 // given by ronny as valid TIN
                //var result = client.ValidateTinNameAddressListMatch(
                //    new TINCheck.TinNameClass() { TIN = "587845148", LName = "1099 Pror" },
                //    new TINCheck.USPSAddressClass()
                //    {
                //        Address1 = "Suite 2080",
                //        Address2 = "23901 Calabasas Road",
                //        City = "Calabasas",
                //        State = "CA",
                //        Zip4 = "",
                //        Zip5 = "91302"
                //    },
                //        new TINCheck.UserClass() { UserLogin = "jason@securepay.com", UserPassword = "eVance1234!" });
                _pModel.TIN = !string.IsNullOrEmpty(_pModel.TIN) ? _pModel.TIN.Replace("-", "") : _pModel.TIN;
                var result = client.ValidateTinNameAddressListMatch(
                 new TINCheck.TinNameClass() { TIN = _pModel.TIN, LName = _pModel.LName },
                 new TINCheck.USPSAddressClass()
                 {
                     Address1 = _pModel.Address1,
                     Address2 = _pModel.Address2,
                     City = _pModel.City,
                     State = _pModel.State,
                     Zip4 = _pModel.Zip4,
                     Zip5 = _pModel.Zip5
                 },
                     new TINCheck.UserClass() { UserLogin = username, UserPassword = password });
                // User and password will set by Plugin configuration.
                var jsondata = JsonConvert.SerializeObject(result); // TINCheck.TINNAME_ADDRESS_LISTMATCH_RESPONSE
                _oTINCheckResponse.JsonResponse = JsonConvert.SerializeObject(result);
                _oTINCheckResponse.TINNAME_CODE = result.TINNAME_RESULT.TINNAME_CODE;
                _oTINCheckResponse.TINNAME_DETAILS = result.TINNAME_RESULT.TINNAME_DETAILS;
                _oTINCheckResponse.CustomSuccessMessage = _localizationService.GetResource("Plugin.MerchantBoarding.TINCheckSuccessMessage");
                _oTINCheckResponse.CustomErrorMessage = _localizationService.GetResource("Plugin.MerchantBoarding.TINCheckErrorMessage");
                _oTINCheckResponse.IsTINCheckVerify = (_pModel.TIN == "134188568")?true:false; // Need to check TINNAME_CODE for good positive result
                return _oTINCheckResponse;
            }
            return null;
        }
    }
}
