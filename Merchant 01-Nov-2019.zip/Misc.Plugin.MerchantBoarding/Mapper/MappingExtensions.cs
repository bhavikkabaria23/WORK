﻿using Misc.Plugin.MerchantBoarding.Domain;
using Misc.Plugin.MerchantBoarding.Models;
using Nop.Core.Infrastructure.Mapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Misc.Plugin.MerchantBoarding.Mapper
{
    public static class MappingExtensions
    {
        public static TDestination MapTo<TSource, TDestination>(this TSource source)
        {
            return AutoMapperConfiguration.Mapper.Map<TSource, TDestination>(source);
        }

        public static TDestination MapTo<TSource, TDestination>(this TSource source, TDestination destination)
        {
            return AutoMapperConfiguration.Mapper.Map(source, destination);
        }

        #region Merchant
        public static MB_MerchantInformation ToEntity(this MerchantInformationModel model)
        {
            return model.MapTo<MerchantInformationModel, MB_MerchantInformation>();
        }
        public static MB_MerchantInformation ToEntity(this MerchantInformationModel model, MB_MerchantInformation destination)
        {
            return model.MapTo(destination);
        }
        #endregion
    }
}
