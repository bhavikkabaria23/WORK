﻿using System.Web.Mvc;
using System.Web.Routing;
using Nop.Web.Framework.Mvc.Routes;

namespace Misc.Plugin.MerchantBoarding
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(RouteCollection routes)
        {
            routes.MapRoute("Plugin.RegisterPartner",
                "RegisterPartner",
                new { controller = "MerchantBoarding", action = "RegisterPartner" },
                new[] { "Misc.Plugin.MerchantBoarding.Controllers" }
           );
            routes.MapRoute("Plugin.MerchantBoarding",
                 "MerchantBoarding",
                 new { controller = "MerchantBoarding", action = "Register" },
                 new[] { "Misc.Plugin.MerchantBoarding.Controllers" }
            );
            routes.MapRoute("Plugin.merchanthtml",
               "merchanthtml",
               new { controller = "MerchantBoarding", action = "merchanthtml" },
               new[] { "Misc.Plugin.MerchantBoarding.Controllers" }
            );
            routes.MapRoute("Plugin.MerchantInformation",
             "MerchantInformation",
             new { controller = "MerchantBoarding", action = "MerchantInformation" },
             new[] { "Misc.Plugin.MerchantBoarding.Controllers" }
            );
            routes.MapRoute("Plugin.LegalInformation",
          "LegalInformation",
          new { controller = "MerchantBoarding", action = "LegalInformation" },
          new[] { "Misc.Plugin.MerchantBoarding.Controllers" }
           );
            routes.MapRoute("Plugin.BusinessInformation",
          "BusinessInformation",
          new { controller = "MerchantBoarding", action = "BusinessInformation" },
          new[] { "Misc.Plugin.MerchantBoarding.Controllers" }
         );
            routes.MapRoute("Plugin.MerchantBoarding.MerchantFees",
        "MerchantFees",
        new { controller = "MerchantBoarding", action = "MerchantFees" },
        new[] { "Misc.Plugin.MerchantBoarding.Controllers" }
       );
            routes.MapRoute("Plugin.MerchantBoarding.MerchantPDF",
       "MerchantPDF",
       new { controller = "MerchantBoarding", action = "MerchantPDF" },
       new[] { "Misc.Plugin.MerchantBoarding.Controllers" }
      );

            #region Admin Routes
            var route = routes.MapRoute("ResidualReports",
"Admin/ResidualReports",
  new { controller = "Report", action = "Index" },
           new[] { "Misc.Plugin.MerchantBoarding.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);

            route = routes.MapRoute("ResidualReports.ReportList",
"Admin/ReportList",
new { controller = "Report", action = "ReportList" },
         new[] { "Misc.Plugin.MerchantBoarding.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);

            route = routes.MapRoute("ResidualReports.AgentDetail",
"Admin/AgentDetail",
new { controller = "Report", action = "AgentDetail" },
        new[] { "Misc.Plugin.MerchantBoarding.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);

            route = routes.MapRoute("ResidualReports.MerchantList",
"Admin/MerchantList",
new { controller = "Report", action = "MerchantList" },
       new[] { "Misc.Plugin.MerchantBoarding.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);



            route = routes.MapRoute("ResidualReports.Payouts",
"Admin/Payouts",
new { controller = "Report", action = "Payouts" },
        new[] { "Misc.Plugin.MerchantBoarding.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);

            route = routes.MapRoute("ResidualReports.PayoutList",
"Admin/PayoutList",
new { controller = "Report", action = "PayoutList" },
         new[] { "Misc.Plugin.MerchantBoarding.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);

            route = routes.MapRoute("ResidualReports.AgentPayoutDetail",
"Admin/AgentPayoutDetail",
new { controller = "Report", action = "AgentPayoutDetail" },
        new[] { "Misc.Plugin.MerchantBoarding.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);

            route = routes.MapRoute("ResidualReports.PayoutMerchantList",
"Admin/PayoutMerchantList",
new { controller = "Report", action = "PayoutMerchantList" },
       new[] { "Misc.Plugin.MerchantBoarding.Controllers" });
            route.DataTokens.Add("area", "admin");
            routes.Remove(route);
            routes.Insert(0, route);
        }
        #endregion
        public int Priority
        {
            get
            {
                return 0;
            }
        }
    }
}
