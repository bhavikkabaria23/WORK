﻿using Microsoft.AspNetCore.Http;
using Misc.Plugin.MerchantBoarding.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Nop.Core;
using Nop.Core.Infrastructure;
using Nop.Services.Common;
using Nop.Services.Customers;
using Nop.Services.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Misc.Plugin.MerchantBoarding.OnlineCRM
{
    public class CRMMethods
    {
        #region Private Variable
        //private static readonly IWorkContext _workContext;
        //private static readonly ILogger _logger;
        //private static readonly ICustomerService _customerService;
        //private static readonly IHttpContextAccessor _httpContextAccessor;
        //private static readonly IGenericAttributeService _genericAttributeService;

        private static JObject registerForm = new JObject(), merchantForm = new JObject(),
       retrievedData;
        private static HttpClient httpClient;
        #endregion

        //public CRMMethods(
        //    IWorkContext workContext,
        //    ICustomerService customerService,
        //    ILogger logger,
        //    IHttpContextAccessor httpContextAccessor,
        //    IGenericAttributeService genericAttributeService
        //    )
        //{
        //    _customerService = customerService;
        //    _logger = logger;
        //    _workContext = workContext;
        //    _httpContextAccessor = httpContextAccessor;
        //    _genericAttributeService = genericAttributeService;
        //}

        #region Private Methods
        public static string GetMIDCookie()
        {            
            var currentMID = EngineContext.Current.Resolve<IHttpContextAccessor>().HttpContext.Request.Cookies["CurrentMID"];
            //var currentMID = Request.Cookies["CurrentMID"].Value;
            if (!string.IsNullOrEmpty(currentMID))
            {
                return currentMID;
            }
            return "empty_mid_cookie";
        }
        public static void CRMAPIErrorResponse(HttpResponseMessage response)
        {
            EngineContext.Current.Resolve<ILogger>().Error("CRM API Error - " + " - Status Code - " + response.StatusCode + " - " + response.Content); //$$$$
        }

        public static string GetFormCompletedStatus()
        {
            return EngineContext.Current.Resolve<IGenericAttributeService>().GetAttribute<string>(EngineContext.Current.Resolve<IWorkContext>().CurrentCustomer, "CRM_MerchantForms_Completed_" + GetMIDCookie());
            //return _workContext.CurrentCustomer.GetAttribute<string>("CRM_MerchantForms_Completed_"+GetMIDCookie());
        }

        #endregion

        #region All Forms CRM Methods - Merchant Boarding New        

        public static async Task<MerchantApplicationModel> MerchantApplicationsCRMGet()
        {          
            MerchantApplicationModel model = new MerchantApplicationModel();

            string CustomerEmail = EngineContext.Current.Resolve<IWorkContext>().CurrentCustomer.Email;
            if (!string.IsNullOrEmpty(CustomerEmail))
            {
                // Get merchant applications from customer email                
                string queryOptions = "?$filter=new_email eq '" + CustomerEmail + "'";
                //HttpResponseMessage merchantResponse = await httpClient.GetAsync("new_merchantapplications" + queryOptions);
                HttpResponseMessage merchantResponse = await OnlineCRMAPIHelper.CrmRequest(HttpMethod.Get, "new_merchantapplications" + queryOptions); //$$$$
                if (merchantResponse.StatusCode == HttpStatusCode.OK) //200
                {
                    retrievedData = JsonConvert.DeserializeObject<JObject>(
                        await merchantResponse.Content.ReadAsStringAsync());
                }
                else
                {
                    CRMAPIErrorResponse(merchantResponse);
                }
                if (retrievedData != null)
                {
                    var jvalue = retrievedData.GetValue("value");
                    if (jvalue != null && jvalue.Count() > 0)
                    {
                        model.MerchantApplicationList = JsonConvert.DeserializeObject<List<MerchantApplicationListModel>>(jvalue.ToString());
                    }
                }
            }
            return model;
        }

        public static async Task<MerchantInformationModel> MerchantInformationCRMGet()
        {
            MerchantInformationModel model = new MerchantInformationModel();

            string CustomerEmail = EngineContext.Current.Resolve<IWorkContext>().CurrentCustomer.Email;
            if (!string.IsNullOrEmpty(CustomerEmail))
            {
                // Get merchant details from customer email
                //string queryOptions = "?$select=new_merchantboardingid&$filter=new_businessemailaddress eq '" + CustomerEmail + "'";
                // https://securepay.crm.dynamics.com/api/data/v9.0/new_merchantboardings?$filter=new_businessemailaddress%20eq%20%27bhavikkabaria23@gmail.com%27                
                //https://securepay.crm.dynamics.com/api/data/v9.0/new_merchantboardings?$filter=new_businessemailaddress%20eq%20%27bhavikkabaria23@gmail.com%27%20and%20new_telephone9%20eq%20%2798978977%27
                string queryOptions = "?$filter=new_businessemailaddress eq '" + CustomerEmail + "' and new_applicationid eq '" + GetMIDCookie() + "'";
                //HttpResponseMessage merchantResponse = await httpClient.GetAsync("new_merchantboardings" + queryOptions);
                HttpResponseMessage merchantResponse = await OnlineCRMAPIHelper.CrmRequest(HttpMethod.Get, "new_merchantboardings" + queryOptions); //$$$$
                if (merchantResponse.StatusCode == HttpStatusCode.OK) //200
                {
                    retrievedData = JsonConvert.DeserializeObject<JObject>(
                        await merchantResponse.Content.ReadAsStringAsync());
                }
                else
                {
                    CRMAPIErrorResponse(merchantResponse); //$$$$
                }
                if (retrievedData != null)
                {
                    var jvalue = retrievedData.GetValue("value");
                    if (jvalue != null && jvalue.Count() > 0)
                    {
                        string merchantId = Convert.ToString(jvalue[0].SelectToken("new_merchantboardingid"));
                        model.MerchantUri = "new_merchantboardings(" + merchantId + ")"; //$$$$
                        model.FaxNumber = Convert.ToString(jvalue[0].SelectToken("new_faxnumber"));
                        model.CellPhone = Convert.ToString(jvalue[0].SelectToken("new_cell"));
                        model.MerchantName = Convert.ToString(jvalue[0].SelectToken("new_merchantname"));
                        model.LocationAddress = Convert.ToString(jvalue[0].SelectToken("new_locationaddress1"));
                        model.City = Convert.ToString(jvalue[0].SelectToken("new_city1"));
                        model.Zip = Convert.ToString(jvalue[0].SelectToken("new_zipcode1"));
                        model.CustomerEmail = Convert.ToString(jvalue[0].SelectToken("new_businessemailaddress"));
                        model.ContactName = Convert.ToString(jvalue[0].SelectToken("new_name"));
                        model.TelePhoneNumber = Convert.ToString(jvalue[0].SelectToken("new_businessphonenumber"));
                        int SelectedState1 = model.SelectedState1 = -1;
                        if (!string.IsNullOrEmpty(Convert.ToString(jvalue[0].SelectToken("new_state1"))))
                        {
                            int.TryParse(Convert.ToString(jvalue[0].SelectToken("new_state1")), out SelectedState1);
                            model.SelectedState1 = SelectedState1;
                        }

                        model.LocationAddress2 = jvalue[0].SelectToken("new_locationaddress2").ToString();
                        model.City2 = jvalue[0].SelectToken("new_city2").ToString();
                        model.Zip2 = jvalue[0].SelectToken("new_zipcode2").ToString();
                        int SelectedState2 = model.SelectedState2 = -1;
                        if (!string.IsNullOrEmpty(Convert.ToString(jvalue[0].SelectToken("new_state2"))))
                        {
                            int.TryParse(Convert.ToString(jvalue[0].SelectToken("new_state2")), out SelectedState2);
                            model.SelectedState2 = SelectedState2;
                        }
                        if (!string.IsNullOrEmpty(model.LocationAddress2) || !string.IsNullOrEmpty(model.City2)
                            || !string.IsNullOrEmpty(model.Zip2) || SelectedState2 >= 0)
                        {
                            model.IsMoreLocation = true;
                        }
                    }
                }

                // if jason != null
                //{
                // set merchant Uri and store it in model
                // Bind MerchantInformation details to MerchantInformationModel
                //}
            }
            return model;
        }

        #endregion

    }
}
