﻿using Microsoft.AspNetCore.Mvc;
using Misc.Plugin.MerchantBoarding.Models;
using Misc.Plugin.MerchantBoarding.OnlineCRM;

using Nop.Core.Infrastructure;
using Nop.Web.Factories;
using Nop.Web.Framework.Components;
using Nop.Web.Framework.Themes;
using System.Threading.Tasks;

namespace Misc.Plugin.MerchantBoarding.Components
{
    public class MerchantInformationViewComponent : NopViewComponent
    {
        private readonly ICommonModelFactory _commonModelFactory;

        public MerchantInformationViewComponent(ICommonModelFactory commonModelFactory)
        {
            _commonModelFactory = commonModelFactory;
        }
        

        public IViewComponentResult Invoke()
        {
            MerchantInformationModel model = new MerchantInformationModel();
            Task.WaitAll(Task.Run(async () => { model = await CRMMethods.MerchantInformationCRMGet(); }));

            return View("/Themes/Main/Views/MerchantBoarding/_MerchantInformation.cshtml", model);
        }
    }
}
