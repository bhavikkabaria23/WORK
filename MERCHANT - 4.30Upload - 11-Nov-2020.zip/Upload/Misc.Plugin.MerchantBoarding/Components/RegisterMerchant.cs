﻿using Microsoft.AspNetCore.Mvc;
using Nop.Core.Infrastructure;
using Nop.Web.Factories;
using Nop.Web.Framework.Components;
using Nop.Web.Framework.Themes;

namespace Misc.Plugin.MerchantBoarding.Components
{
    public class RegisterMerchantViewComponent : NopViewComponent
    {
        private readonly ICommonModelFactory _commonModelFactory;

        public RegisterMerchantViewComponent(ICommonModelFactory commonModelFactory)
        {
            _commonModelFactory = commonModelFactory;
        }

        public IViewComponentResult Invoke()
        {
            ViewBag.Error = TempData["Error"];
            ViewBag.PartnerId = TempData["PartnerId"];
            return View("/Themes/Main/Views/MerchantBoarding/Register.cshtml");
        }
    }
}
