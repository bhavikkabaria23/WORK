﻿using Microsoft.AspNetCore.Mvc;
using Misc.Plugin.MerchantBoarding.Models;
using Misc.Plugin.MerchantBoarding.OnlineCRM;
using Nop.Core;
using Nop.Core.Infrastructure;
using Nop.Services.Common;
using Nop.Services.Customers;
using Nop.Web.Factories;
using Nop.Web.Framework.Components;
using Nop.Web.Framework.Themes;
using System.Threading.Tasks;

namespace Misc.Plugin.MerchantBoarding.Components
{
    public class MerchantStepsViewComponent : NopViewComponent
    {
        private readonly ICommonModelFactory _commonModelFactory;
        private readonly IWorkContext _workContext;
        private readonly ICustomerService _customerService;
        private readonly IGenericAttributeService _genericAttributeService;

        public MerchantStepsViewComponent(ICommonModelFactory commonModelFactory, IWorkContext workContext,
            ICustomerService customerService, IGenericAttributeService genericAttributeService)
        {
            _commonModelFactory = commonModelFactory;
            _workContext = workContext;
            _customerService = customerService;
            _genericAttributeService = genericAttributeService;
        }
        

        public IViewComponentResult Invoke(string _pCurrentForm)
        {
            FormSteps model = new FormSteps();
            model.FormsCompleted = CRMMethods.GetFormCompletedStatus();
            model.CurrentForm = _pCurrentForm;
            model.MerchantDocusignSigned = _genericAttributeService.GetAttribute<string>(_workContext.CurrentCustomer,"docusign_merchant_signed_" + CRMMethods.GetMIDCookie());
            return View("/Themes/Main/Views/MerchantBoarding/_MerchantSteps.cshtml", model);
        }
    }
}
