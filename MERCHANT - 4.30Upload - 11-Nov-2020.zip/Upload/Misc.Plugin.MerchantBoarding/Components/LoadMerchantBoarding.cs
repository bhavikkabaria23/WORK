﻿using Microsoft.AspNetCore.Mvc;
using Nop.Core.Infrastructure;
using Nop.Web.Factories;
using Nop.Web.Framework.Components;
using Nop.Web.Framework.Themes;

namespace Misc.Plugin.MerchantBoarding.Components
{
    public class LoadMerchantBoardingViewComponent : NopViewComponent
    {
        private readonly ICommonModelFactory _commonModelFactory;

        public LoadMerchantBoardingViewComponent(ICommonModelFactory commonModelFactory)
        {
            _commonModelFactory = commonModelFactory;
        }

        public IViewComponentResult Invoke(string appid)
        {
            ViewBag.applicationId = appid;
            return View("/Themes/Main/Views/MerchantBoarding/LoadMerchantBoarding.cshtml");
        }
    }
}
