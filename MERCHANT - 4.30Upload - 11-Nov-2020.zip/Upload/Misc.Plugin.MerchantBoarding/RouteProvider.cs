﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;

using Nop.Web.Framework;
using Nop.Web.Framework.Localization;
using Nop.Web.Framework.Mvc.Routing;

namespace Misc.Plugin.MerchantBoarding
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(IEndpointRouteBuilder endpointRouteBuilder)
        {

            // merchantid is the CRM merchant guid.
            endpointRouteBuilder.MapControllerRoute("Plugin.RegisterMerchantForID",
                "merchant/id={merchantid}",
                new { controller = "MerchantBoarding", action = "RegisterMerchantForID" }

           );

            endpointRouteBuilder.MapControllerRoute("Plugin.RegisterPartner",
                "RegisterPartner",
                new { controller = "MerchantBoarding", action = "RegisterPartner" }

           );
            endpointRouteBuilder.MapControllerRoute("Plugin.MerchantBoarding",
                 "MerchantBoarding",
                 new { controller = "MerchantBoarding", action = "Register" }

            );
            endpointRouteBuilder.MapControllerRoute("Plugin.merchanthtml",
               "merchanthtml",
               new { controller = "MerchantBoarding", action = "merchanthtml" }

            );
            endpointRouteBuilder.MapControllerRoute("Plugin.MerchantInformation",
             "MerchantInformation",
             new { controller = "MerchantBoarding", action = "MerchantInformation" }

            );
            endpointRouteBuilder.MapControllerRoute("Plugin.LegalInformation",
          "LegalInformation",
          new { controller = "MerchantBoarding", action = "LegalInformation" }

           );
            endpointRouteBuilder.MapControllerRoute("Plugin.BusinessInformation",
          "BusinessInformation",
          new { controller = "MerchantBoarding", action = "BusinessInformation" }

         );
            endpointRouteBuilder.MapControllerRoute("Plugin.MerchantBoarding.MerchantFees",
        "MerchantFees",
        new { controller = "MerchantBoarding", action = "MerchantFees" }

       );
            endpointRouteBuilder.MapControllerRoute("Plugin.MerchantBoarding.MerchantPDF",
       "MerchantPDF",
       new { controller = "MerchantBoarding", action = "MerchantPDF" }

      );

            endpointRouteBuilder.MapControllerRoute("Plugin.MerchantBoarding.MerchantDocusignCallback",
      "MerchantDocusignCallback",
      new { controller = "MerchantBoarding", action = "MerchantDocusignCallback" }

     );

            #region Admin Routes
            endpointRouteBuilder.MapControllerRoute("ResidualReports",
"Admin/ResidualReports",
  new { controller = "Report", action = "Index", area = AreaNames.Admin }
           , null, dataTokens: new { area = "admin" });


            endpointRouteBuilder.MapControllerRoute("ResidualReports.ReportList",
"Admin/ReportList",
new { controller = "Report", action = "ReportList", area = AreaNames.Admin }
         , null, dataTokens: new { area = "admin" });


            endpointRouteBuilder.MapControllerRoute("ResidualReports.AgentDetail",
"Admin/AgentDetail",
new { controller = "Report", action = "AgentDetail", area = AreaNames.Admin }
        , null, dataTokens: new { area = "admin" });


            endpointRouteBuilder.MapControllerRoute("ResidualReports.MerchantList",
"Admin/MerchantList",
new { controller = "Report", action = "MerchantList", area = AreaNames.Admin }
       , null, dataTokens: new { area = "admin" });




            endpointRouteBuilder.MapControllerRoute("ResidualReports.Payouts",
"Admin/Payouts",
new { controller = "Report", action = "Payouts", area = AreaNames.Admin }
        , null, dataTokens: new { area = "admin" });


            endpointRouteBuilder.MapControllerRoute("ResidualReports.PayoutList",
"Admin/PayoutList",
new { controller = "Report", action = "PayoutList", area = AreaNames.Admin }
         , null, dataTokens: new { area = "admin" });


            endpointRouteBuilder.MapControllerRoute("ResidualReports.AgentPayoutDetail",
"Admin/AgentPayoutDetail",
new { controller = "Report", action = "AgentPayoutDetail", area = AreaNames.Admin }
        , null, dataTokens: new { area = "admin" });


            endpointRouteBuilder.MapControllerRoute("ResidualReports.PayoutMerchantList",
"Admin/PayoutMerchantList",
new { controller = "Report", action = "PayoutMerchantList", area = AreaNames.Admin }
       , null, dataTokens: new { area = "admin" });

        }
        public int Priority
        {
            get
            {
                return 0;
            }
        }
    }
    #endregion
}   
