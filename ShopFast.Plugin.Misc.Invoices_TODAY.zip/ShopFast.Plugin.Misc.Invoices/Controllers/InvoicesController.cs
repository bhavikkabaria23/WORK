﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.Routing;
using Nop.Core;
using Nop.Core.Caching;
using Nop.Core.Data;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Common;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Directory;
using Nop.Core.Domain.Discounts;
using Nop.Core.Domain.Localization;
using Nop.Core.Domain.Messages;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Core.Domain.Shipping;
using Nop.Core.Domain.Tax;
using Nop.Core.Domain.Vendors;
using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Services;
using Nop.Services.Catalog;
using Nop.Services.Common;
using Nop.Services.Configuration;
using Nop.Services.Customers;
using Nop.Services.Directory;
using Nop.Services.Discounts;
using Nop.Services.Events;
using Nop.Services.Helpers;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Media;
using Nop.Services.Messages;
using Nop.Services.Orders;
using Nop.Services.Payments;
using Nop.Services.Security;
using Nop.Services.Seo;
using Nop.Services.Shipping;
using Nop.Services.Stores;
using Nop.Services.Tax;
using Nop.Services.Vendors;
using Nop.Web.Areas.Admin.Infrastructure.Mapper.Extensions;
using Nop.Web.Areas.Admin.Models.Orders;
using Nop.Web.Extensions;
using Nop.Web.Factories;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Mvc;
using Nop.Web.Framework.Mvc.Filters;
using Nop.Web.Framework.Security;
using Nop.Web.Models.Common;
using Nop.Web.Models.Order;
using Nop.Web.Models.ShoppingCart;
using ShopFast.Plugin.Misc.Core.Domain;
using ShopFast.Plugin.Misc.Core.Events;
using ShopFast.Plugin.Misc.Core.Services;
using ShopFast.Plugin.Misc.Invoices.Models;
using SystemCustomerAttributeNames = ShopFast.Plugin.Misc.Core.Extensions.SystemCustomerAttributeNames;
using Nop.Web.Framework.Models.Extensions;

namespace ShopFast.Plugin.Misc.Invoices.Controllers
{
    public class InvoicesController : BasePluginController
    {
        #region Fields

        private const string DATETIME_FORMATING_STR = "{0:MM/dd/yyyy h:mm tt}";

        private readonly IWorkContext _workContext;
        private readonly IStoreService _storeService;
        private readonly ISettingService _settingService;
        private readonly ILocalizationService _localizationService;
        private readonly IITPOrderService _orderService;
        private readonly IITPCustomerService _customerService;
        private readonly IStoreContext _storeContext;
        private readonly IProductService _productService;
        private readonly IDateTimeHelper _dateTimeHelper;
        private readonly IITPInvoiceTotalCalculationService _invoiceTotalCalculationService;
        private readonly ICurrencyService _currencyService;
        private readonly IPriceFormatter _priceFormatter;
        private readonly IPaymentService _paymentService;
        private readonly ITaxService _taxService;

        private readonly RewardPointsSettings _rewardPointsSettings;
        private readonly TaxSettings _taxSettings;
        private readonly IShippingService _shippingService;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly IAddressService _addressService;
        private readonly IOrderProcessingService _orderProcessingService;
        private readonly IInvoiceCartService _invoiceCartService;
        private readonly InvoiceItemAttributeParser _invoiceItemAttributeParser;
        private readonly IGiftCardService _giftCardService;
        private readonly IProductAttributeParser _productAttributeParser;
        private readonly IPriceCalculationService _priceCalculationService;
        private readonly IProductAttributeFormatter _productAttributeFormatter;
        private readonly IRepository<Product> _productRepository;
        private readonly ICheckoutAttributeService _checkoutAttributeService;
        private readonly CurrencySettings _currencySettings;
        private readonly ICheckoutAttributeParser _checkoutAttributeParser;

        private readonly ILogger _logger;
        private readonly AddressSettings _addressSettings;
        private readonly PrepareCheckoutModels _prepareCheckoutModels;
        private readonly IDownloadService _downloadService;
        private readonly TipsCheckoutAttributeParser _tipsCheckoutAttributeParser;
        private readonly IDiscountService _discountService;
        private readonly IPermissionService _permissionService;
        private readonly IEmailAccountService _emailAccountService;
        private readonly IEmailSender _emailSender;
        private readonly EmailAccountSettings _emailAccountSettings;
        private readonly IQueuedEmailService _queuedEmailService;
        private readonly IMessageTemplateService _messageTemplateService;
        private readonly IITPMessageTokenProvider _messageTokenProvider;
        private readonly LocalizationSettings _localizationSettings;
        private readonly ITokenizer _tokenizer;
        private readonly IVendorService _vendorService;
        private readonly IEventPublisher _eventPublisher;
        private readonly OrderSettings _orderSettings;
        private readonly IAddressAttributeFormatter _addressAttributeFormatter;
        private readonly CatalogSettings _catalogSettings;
        private readonly IPdfService _pdfService;
        private readonly IEncryptionService _encryptionService;
        private readonly IRepository<Order> _orderRepository;
        private readonly IITPPartialPaymentService _partialPaymentService;
        private readonly IWebHelper _webHelper;

        private readonly ICacheManager _cacheManager;
        private readonly IAddressModelFactory _addressModelFactory;
        private readonly CustomerSettings _customerSettings;
        private readonly IStateProvinceService _stateProvinceService;
        private readonly ICountryService _countryService;
        private readonly ICustomNumberFormatter _customNumberFormatter;

        private readonly INotificationService _notificationService;
        private readonly IShoppingCartService _shoppingCartService;

        private readonly IShippingPluginManager _shippingPluginManager;
        private readonly IPaymentPluginManager _paymentPluginManager;
        private readonly VendorSettings _vendorSettings;
        private readonly IUrlHelperFactory _urlHelperFactory;
        private readonly IActionContextAccessor _actionContextAccessor;
        private readonly PdfSettings _pdfSettings;
        private readonly ICustomerAttributeFormatter _customerAttributeFormatter;
        private readonly IUrlRecordService _urlRecordService;
        private readonly INopFileProvider _fileProvider;


        #endregion

        #region Ctor

        public InvoicesController(IWorkContext workContext,
            IStoreService storeService,
            ISettingService settingService,
            ILocalizationService localizationService,
            IITPOrderService orderService,
            IITPCustomerService customerService,
            IStoreContext storeContext,
            IProductService productService,
            IDateTimeHelper dateTimeHelper,
            TaxSettings taxSettings,
            IITPInvoiceTotalCalculationService invoiceTotalCalculationService,
            ICurrencyService currencyService,
            IPriceFormatter priceFormatter,
            IPaymentService paymentService,
            ITaxService taxService,
            RewardPointsSettings rewardPointsSettings,
            IShippingService shippingService,
            IGenericAttributeService genericAttributeService,
            IAddressService addressService,
            IOrderProcessingService orderProcessingService,
            IInvoiceCartService invoiceCartService,
            InvoiceItemAttributeParser invoiceItemAttributeParser,
            IGiftCardService giftCardService,
            IProductAttributeParser productAttributeParser,
            IPriceCalculationService priceCalculationService,
            IProductAttributeFormatter productAttributeFormatter,
            IRepository<Product> productRepository,
            ICheckoutAttributeService checkoutAttributeService,
            CurrencySettings currencySettings,
            ICheckoutAttributeParser checkoutAttributeParser,
            ILogger logger,
            AddressSettings addressSettings,
            PrepareCheckoutModels prepareCheckoutModels,
            IDownloadService downloadService,
            TipsCheckoutAttributeParser tipsCheckoutAttributeParser,
            IDiscountService discountService,
            IPermissionService permissionService,
            IEmailAccountService emailAccountService,
            IEmailSender emailSender,
            EmailAccountSettings emailAccountSettings,
            IQueuedEmailService queuedEmailService,
            IMessageTemplateService messageTemplateService,
            IITPMessageTokenProvider messageTokenProvider,
            LocalizationSettings localizationSettings,
            ITokenizer tokenizer,
            IVendorService vendorService,
            IEventPublisher eventPublisher,
            OrderSettings orderSettings,
            IAddressAttributeFormatter addressAttributeFormatter,
            CatalogSettings catalogSettings,
            IPdfService pdfService,
            IEncryptionService encryptionService,
            IRepository<Order> orderRepository,
            IITPPartialPaymentService partialPaymentService,
            IWebHelper webHelper,
            ICacheManager cacheManager,
            IAddressModelFactory addressModelFactory,
            CustomerSettings customerSettings,
            IStateProvinceService stateProvinceService,
            ICountryService countryService,
            ICustomNumberFormatter customNumberFormatter,
            INotificationService notificationService,
            IShoppingCartService shoppingCartService,
            IShippingPluginManager shippingPluginManager,
        IPaymentPluginManager paymentPluginManager,
        VendorSettings vendorSettings,
        IUrlHelperFactory urlHelperFactor,
        IUrlHelperFactory urlHelperFactory,
        IActionContextAccessor actionContextAccessor,
        ICustomerAttributeFormatter customerAttributeFormatter,
        IUrlRecordService urlRecordService,
        PdfSettings pdfSettings,
        INopFileProvider fileProvider
        )
        {
            _workContext = workContext;
            _storeService = storeService;
            _settingService = settingService;
            _localizationService = localizationService;
            _orderService = orderService;
            _customerService = customerService;
            _storeContext = storeContext;
            _productService = productService;
            _dateTimeHelper = dateTimeHelper;
            _taxSettings = taxSettings;
            _invoiceTotalCalculationService = invoiceTotalCalculationService;
            _currencyService = currencyService;
            _priceFormatter = priceFormatter;
            _paymentService = paymentService;
            _taxService = taxService;
            _rewardPointsSettings = rewardPointsSettings;
            _shippingService = shippingService;
            _genericAttributeService = genericAttributeService;
            _addressService = addressService;
            _orderProcessingService = orderProcessingService;
            _invoiceCartService = invoiceCartService;
            _invoiceItemAttributeParser = invoiceItemAttributeParser;
            _giftCardService = giftCardService;
            _productAttributeParser = productAttributeParser;
            _priceCalculationService = priceCalculationService;
            _productAttributeFormatter = productAttributeFormatter;
            _productRepository = productRepository;
            _checkoutAttributeService = checkoutAttributeService;
            _currencySettings = currencySettings;
            _checkoutAttributeParser = checkoutAttributeParser;
            _logger = logger;
            _addressSettings = addressSettings;
            _prepareCheckoutModels = prepareCheckoutModels;
            _downloadService = downloadService;
            _tipsCheckoutAttributeParser = tipsCheckoutAttributeParser;
            _discountService = discountService;
            _permissionService = permissionService;
            _emailAccountService = emailAccountService;
            _emailSender = emailSender;
            _emailAccountSettings = emailAccountSettings;
            _queuedEmailService = queuedEmailService;
            _messageTemplateService = messageTemplateService;
            _messageTokenProvider = messageTokenProvider;
            _localizationSettings = localizationSettings;
            _tokenizer = tokenizer;
            _vendorService = vendorService;
            _eventPublisher = eventPublisher;
            _orderSettings = orderSettings;
            _addressAttributeFormatter = addressAttributeFormatter;
            _catalogSettings = catalogSettings;
            _pdfService = pdfService;
            _encryptionService = encryptionService;
            _orderRepository = orderRepository;
            _partialPaymentService = partialPaymentService;
            _webHelper = webHelper;
            _cacheManager = cacheManager;
            this._addressModelFactory = addressModelFactory;
            _customerSettings = customerSettings;
            _stateProvinceService = stateProvinceService;
            _countryService = countryService;
            _customNumberFormatter = customNumberFormatter;
            _notificationService = notificationService;
            _shoppingCartService = shoppingCartService;
            _shippingPluginManager = shippingPluginManager;
            _paymentPluginManager = paymentPluginManager;
            _vendorSettings = vendorSettings;
            _urlHelperFactory = urlHelperFactory;
            _actionContextAccessor = actionContextAccessor;
            _pdfSettings = pdfSettings;
            _customerAttributeFormatter = customerAttributeFormatter;
            _urlRecordService = urlRecordService;
            _fileProvider = fileProvider;
        }

        #endregion

        #region Utitlites

        [NonAction]
        protected string GetViewPath(string viewName)
        {
            return "~/Plugins/ShopFast.Misc.Invoices/Views/" + viewName + ".cshtml";
        }

        [NonAction]
        protected List<Order> GetOrders(string str, string separator = ",")
        {
            var result = str.Split(separator.ToCharArray()).ToList();
            return result.Where(id => !string.IsNullOrEmpty(id))
                .Select(id => _orderService.GetOrderById(Int32.Parse(id)))
                .Where(order => order != null).ToList();
        }

        [NonAction]
        protected List<int> GetOrderIds(string str, string separator = ",")
        {
            var result = str.Split(separator.ToCharArray()).ToList();
            return result.Where(id => !string.IsNullOrEmpty(id))
                .Select(Int32.Parse)
                .Where(id => id > 0)
                .ToList();
        }

        [NonAction]//Done
        protected void ShowNotifications(NotificationModel notificationModel)
        {
            if (notificationModel == null)
                return;

            foreach (var success in notificationModel.SuccessMessages)
            {
                _notificationService.SuccessNotification(success);
            }

            foreach (var error in notificationModel.ErrorMessages)
            {
                _notificationService.ErrorNotification(error);
            }
        }

        /// <summary>
        /// Access denied view
        /// </summary>
        /// <returns>Access denied view</returns>
        [NonAction]
        protected IActionResult AccessDeniedView()
        {
            var webHelper = EngineContext.Current.Resolve<IWebHelper>();

            //return Challenge();
            return RedirectToAction("AccessDenied", "Security", new { pageUrl = webHelper.GetRawUrl(Request) });
        }

        [NonAction]//Done
        protected virtual string ParseAndSaveCheckoutAttributesExt(List<ShoppingCartItem> cart, FormCollection form)
        {
            if (cart == null)
                throw new ArgumentNullException("cart");

            if (form == null)
                throw new ArgumentNullException("form");

            string attributesXml = _genericAttributeService.GetAttribute<string>(_workContext.CurrentCustomer,
                NopCustomerDefaults.CheckoutAttributes, _storeContext.CurrentStore.Id);
            attributesXml = _tipsCheckoutAttributeParser.ClearCheckoutAttributes(attributesXml);

            var excludeShippableAttributes = !_shoppingCartService.ShoppingCartRequiresShipping(cart);
            var checkoutAttributes = _checkoutAttributeService.GetAllCheckoutAttributes(_storeContext.CurrentStore.Id, excludeShippableAttributes);

            foreach (var attribute in checkoutAttributes)
            {
                //string controlId = string.Format("checkout_attribute_{0}", attribute.Id);
                string controlId = string.Format("checkout_attribute_{0}", attribute.Id);
                switch (attribute.AttributeControlType)
                {
                    case AttributeControlType.DropdownList:
                    case AttributeControlType.RadioList:
                    case AttributeControlType.ColorSquares:
                        {
                            var ctrlAttributes = form[controlId];
                            if (!String.IsNullOrEmpty(ctrlAttributes))
                            {
                                int selectedAttributeId = int.Parse(ctrlAttributes);
                                if (selectedAttributeId > 0)
                                    attributesXml = _checkoutAttributeParser.AddCheckoutAttribute(attributesXml,
                                        attribute, selectedAttributeId.ToString());
                            }
                        }
                        break;
                    case AttributeControlType.Checkboxes:
                        {
                            var cblAttributes = form[controlId];
                            if (!String.IsNullOrEmpty(cblAttributes))
                            {
                                foreach (var item in cblAttributes.ToString().Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                                {
                                    var selectedAttributeId = int.Parse(item);
                                    if (selectedAttributeId > 0)
                                        attributesXml = _checkoutAttributeParser.AddCheckoutAttribute(attributesXml,
                                            attribute, selectedAttributeId.ToString());
                                }
                            }
                        }
                        break;
                    case AttributeControlType.ReadonlyCheckboxes:
                        {
                            //load read-only (already server-side selected) values
                            var attributeValues = _checkoutAttributeService.GetCheckoutAttributeValues(
                                attribute.Id);
                            foreach (var selectedAttributeId in attributeValues
                                .Where(v => v.IsPreSelected)
                                .Select(v => v.Id)
                                .ToList())
                            {
                                attributesXml = _checkoutAttributeParser.AddCheckoutAttribute(attributesXml,
                                            attribute, selectedAttributeId.ToString());
                            }
                        }
                        break;
                    case AttributeControlType.TextBox:
                    case AttributeControlType.MultilineTextbox:
                        {
                            var ctrlAttributes = form[controlId];
                            if (!String.IsNullOrEmpty(ctrlAttributes))
                            {
                                var enteredText = ctrlAttributes.ToString().Trim();
                                attributesXml = _checkoutAttributeParser.AddCheckoutAttribute(attributesXml,
                                    attribute, enteredText);
                            }
                        }
                        break;
                    case AttributeControlType.Datepicker:
                        {
                            var date = form[controlId + "_day"];
                            var month = form[controlId + "_month"];
                            var year = form[controlId + "_year"];
                            DateTime? selectedDate = null;
                            try
                            {
                                selectedDate = new DateTime(Int32.Parse(year), Int32.Parse(month),
                                    Int32.Parse(date));
                            }
                            catch { }
                            if (selectedDate.HasValue)
                            {
                                attributesXml = _checkoutAttributeParser.AddCheckoutAttribute(attributesXml,
                                    attribute, selectedDate.Value.ToString("D"));
                            }
                        }
                        break;
                    case AttributeControlType.FileUpload:
                        {
                            Guid downloadGuid;
                            Guid.TryParse(form[controlId], out downloadGuid);
                            var download = _downloadService.GetDownloadByGuid(downloadGuid);
                            if (download != null)
                            {
                                attributesXml = _checkoutAttributeParser.AddCheckoutAttribute(attributesXml,
                                           attribute, download.DownloadGuid.ToString());
                            }
                        }
                        break;
                    default:
                        break;
                }
            }

            //save checkout attributes
            //_genericAttributeService.SaveAttribute(_workContext.CurrentCustomer, 
            //    Nop.Core.Domain.Customers.SystemCustomerAttributeNames.CheckoutAttributes, 
            //    attributesXml, _storeContext.CurrentStore.Id);

            return attributesXml;
        }

        [NonAction]//Done
        protected InvoiceModel PrepareInvoiceModel(InvoiceModel model = null, Order invoice = null,
            InvoiceType invoiceType = InvoiceType.Invoice)
        {
            if (model != null && model.OrderId != 0)
            {
                invoice = _orderService.GetOrderById(model.OrderId);
            }

            if (model == null)
            {
                model = new InvoiceModel();
            }

            model.OrderGuid = Guid.Empty.ToString();
            model.StoreName = _storeContext.CurrentStore.Name;
            model.InvoiceType = invoiceType;

            model.OrderStatus = OrderStatus.Pending;
            model.OrderStatusValues = OrderStatus.Pending.ToSelectList();
            model.PaymentStatus = PaymentStatus.Pending;
            model.PaymentStatusValues = PaymentStatus.Pending.ToSelectList();
            model.InvoiceDateStr = String.Format(DATETIME_FORMATING_STR, DateTime.Now);
            model.DueDateStr = String.Format(DATETIME_FORMATING_STR, DateTime.Now);
            model.DiscountBox = new InvoiceModel.DiscountBoxModel()
            {
                Display = true
            };
            model.GiftCardBox = new InvoiceModel.GiftCardBoxModel
            {
                Display = true
            };

            model.RecurringCyclePeriodValues = RecurringProductCyclePeriod.Days.ToSelectList();

            if (invoice != null)
            {
                var recurringPayment = _orderService.GetRecurringPaymentByOrderId(invoice.Id);
                if (recurringPayment != null)
                {
                    model.RecurringCycleLength = recurringPayment.CycleLength;
                    model.RecurringCyclePeriodId = recurringPayment.CyclePeriodId;
                    model.RecurringCreatedOnUtc = recurringPayment.CreatedOnUtc;
                    model.RecurringStartDateUtc = recurringPayment.StartDateUtc;
                    model.RecurringTotalCycles = recurringPayment.TotalCycles;
                }

                model.OrderId = invoice.Id;
                model.OrderGuid = invoice.OrderGuid.ToString();
                ;
                model.OrderStatus = invoice.OrderStatus;
                model.PaymentStatus = invoice.PaymentStatus;

                if (model.CustomerId == null || model.CustomerId == 0)
                {
                    model.CustomerId = invoice.CustomerId;
                }

                model.StoreName = _storeService.GetStoreById(invoice.StoreId).Name;
                model.PaymentMethodSystemName = invoice.PaymentMethodSystemName;

                model.InvoiceType = _genericAttributeService.GetAttribute<InvoiceType>(invoice, SystemCustomerAttributeNames.InvoiceType, _storeContext.CurrentStore.Id);
                model.InvoiceDateStr = String.Format(DATETIME_FORMATING_STR, invoice.CreatedOnUtc);
                model.DueDateStr = String.Format(DATETIME_FORMATING_STR, invoice.PaidDateUtc);

                //Closed invoice
                if (invoice.OrderStatus == OrderStatus.Complete)
                {
                    model.Closed = true;
                }

                model.OrderModel = PrepareOrderModel(invoice);
            }

            PrepareCheckoutAttributes(model, invoice);

            return model;
        }

        [NonAction]//Done
        protected void PrepareCheckoutAttributes(InvoiceModel model, Order invoice = null)
        {
            string attributesXml = "";
            if (invoice != null)
                attributesXml = invoice.CheckoutAttributesXml;

            model.CheckoutAttributes = new List<ShoppingCartModel.CheckoutAttributeModel>();

            var checkoutAttributes = _checkoutAttributeService.GetAllCheckoutAttributes(_storeContext.CurrentStore.Id, true);
            foreach (var attribute in checkoutAttributes)
            {
                var attributeModel = new ShoppingCartModel.CheckoutAttributeModel
                {
                    Id = attribute.Id,
                    Name = _localizationService.GetLocalized(attribute, x => x.Name),
                    TextPrompt = _localizationService.GetLocalized(attribute, x => x.TextPrompt),
                    IsRequired = attribute.IsRequired,
                    AttributeControlType = attribute.AttributeControlType,
                    DefaultValue = attribute.DefaultValue
                };
                if (!String.IsNullOrEmpty(attribute.ValidationFileAllowedExtensions))
                {
                    attributeModel.AllowedFileExtensions = attribute.ValidationFileAllowedExtensions
                        .Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                        .ToList();
                }

                if (attribute.ShouldHaveValues())
                {
                    //values
                    var attributeValues = _checkoutAttributeService.GetCheckoutAttributeValues(attribute.Id);
                    foreach (var attributeValue in attributeValues)
                    {
                        var attributeValueModel = new ShoppingCartModel.CheckoutAttributeValueModel
                        {
                            Id = attributeValue.Id,
                            Name = _localizationService.GetLocalized(attributeValue, x => x.Name),
                            ColorSquaresRgb = attributeValue.ColorSquaresRgb,
                            IsPreSelected = attributeValue.IsPreSelected,
                        };
                        attributeModel.Values.Add(attributeValueModel);

                        //display price if allowed
                        if (_permissionService.Authorize(StandardPermissionProvider.DisplayPrices))
                        {
                            decimal priceAdjustmentBase = _taxService.GetCheckoutAttributePrice(attributeValue);
                            decimal priceAdjustment = _currencyService.ConvertFromPrimaryStoreCurrency(priceAdjustmentBase, _workContext.WorkingCurrency);
                            if (priceAdjustmentBase > decimal.Zero)
                                attributeValueModel.PriceAdjustment = "+" + _priceFormatter.FormatPrice(priceAdjustment);
                            else if (priceAdjustmentBase < decimal.Zero)
                                attributeValueModel.PriceAdjustment = "-" + _priceFormatter.FormatPrice(-priceAdjustment);
                        }
                    }
                }

                //set already selected attributes
                //var selectedCheckoutAttributes = _workContext.CurrentCustomer.GetAttribute<string>(
                //    Nop.Core.Domain.Customers.SystemCustomerAttributeNames.CheckoutAttributes, _genericAttributeService, 
                //    _storeContext.CurrentStore.Id);
                switch (attribute.AttributeControlType)
                {
                    case AttributeControlType.DropdownList:
                    case AttributeControlType.RadioList:
                    case AttributeControlType.Checkboxes:
                    case AttributeControlType.ColorSquares:
                        {
                            if (!String.IsNullOrEmpty(attributesXml))
                            {
                                //clear default selection
                                foreach (var item in attributeModel.Values)
                                    item.IsPreSelected = false;

                                //select new values
                                var selectedValues = _checkoutAttributeParser.ParseCheckoutAttributeValues(attributesXml);
                                foreach (var attributeValue in selectedValues)
                                    foreach (var item in attributeModel.Values)
                                        if (attributeValue.Id == item.Id)
                                            item.IsPreSelected = true;
                            }
                        }
                        break;
                    case AttributeControlType.ReadonlyCheckboxes:
                        {
                            //do nothing
                            //values are already pre-set
                        }
                        break;
                    case AttributeControlType.TextBox:
                    case AttributeControlType.MultilineTextbox:
                        {
                            if (!String.IsNullOrEmpty(attributesXml))
                            {
                                var enteredText = _checkoutAttributeParser.ParseValues(attributesXml, attribute.Id);
                                if (enteredText.Count > 0)
                                    attributeModel.DefaultValue = enteredText[0];
                            }
                        }
                        break;
                    case AttributeControlType.Datepicker:
                        {
                            //keep in mind my that the code below works only in the current culture
                            var selectedDateStr = _checkoutAttributeParser.ParseValues(attributesXml, attribute.Id);
                            if (selectedDateStr.Count > 0)
                            {
                                DateTime selectedDate;
                                if (DateTime.TryParseExact(selectedDateStr[0], "D", CultureInfo.CurrentCulture,
                                                       DateTimeStyles.None, out selectedDate))
                                {
                                    //successfully parsed
                                    attributeModel.SelectedDay = selectedDate.Day;
                                    attributeModel.SelectedMonth = selectedDate.Month;
                                    attributeModel.SelectedYear = selectedDate.Year;
                                }
                            }

                        }
                        break;
                    default:
                        break;
                }

                model.CheckoutAttributes.Add(attributeModel);
            }
        }

        [NonAction]//Done
        protected List<ShoppingCartItem> GetShoppingCartItems(Customer customer = null, int? invoiceId = null)
        {
            List<ShoppingCartItem> cart;

            if (customer != null)
            {
                if (invoiceId != null)
                {
                    var iiams = customer.ShoppingCartItems.Select(
                            sci => _invoiceItemAttributeParser.GetInvoiceItemAttributeMapping(sci.AttributesXml)).ToList();

                    cart = customer.ShoppingCartItems
                        .Where(sci => sci.ShoppingCartType == ShoppingCartType.ShoppingCart &&
                            _invoiceItemAttributeParser.GetInvoiceItemAttributeMapping(sci.AttributesXml) != null &&
                            _invoiceItemAttributeParser.GetInvoiceItemAttributeMapping(sci.AttributesXml)
                            .InvoiceId == invoiceId)
                        .ToList();
                }
                else
                {
                    cart = customer.ShoppingCartItems
                        .Where(sci => sci.ShoppingCartType == ShoppingCartType.ShoppingCart)
                        .ToList();
                }
            }
            else
            {
                if (invoiceId != null)
                {
                    if (invoiceId == 0)
                    {
                        cart = _workContext.CurrentCustomer.ShoppingCartItems
                            .Where(sci => sci.ShoppingCartType == ShoppingCartType.ShoppingCart &&
                                _invoiceItemAttributeParser.GetInvoiceItemAttributeMapping(sci.AttributesXml) != null &&
                                _invoiceItemAttributeParser.GetInvoiceItemAttributeMapping(sci.AttributesXml)
                                .InvoiceId == 0)
                            .ToList();
                    }
                    else
                    {
                        var invoice = _orderService.GetOrderById((int)invoiceId);

                        cart = invoice.Customer.ShoppingCartItems
                            .Where(sci => sci.ShoppingCartType == ShoppingCartType.ShoppingCart &&
                                _invoiceItemAttributeParser.GetInvoiceItemAttributeMapping(sci.AttributesXml) != null &&
                                _invoiceItemAttributeParser.GetInvoiceItemAttributeMapping(sci.AttributesXml)
                                .InvoiceId == invoice.Id)
                            .ToList();
                    }
                }
                else
                {
                    cart = _workContext.CurrentCustomer.ShoppingCartItems
                        .Where(sci => sci.ShoppingCartType == ShoppingCartType.ShoppingCart)
                        .ToList();
                }
            }

            if (invoiceId == null)
                return cart;
            var listToRemove = new List<ShoppingCartItem>();
            foreach (var cartItem in cart)
            {
                var invoiceItemAttributeMapping = _invoiceItemAttributeParser
                    .GetInvoiceItemAttributeMapping(cartItem.AttributesXml);

                if ((invoiceItemAttributeMapping == null) ||
                    (invoiceItemAttributeMapping.InvoiceId != invoiceId))
                //if (invoiceItemAttributeMapping == null)
                {
                    listToRemove.Add(cartItem);
                }
            }

            foreach (var item in listToRemove)
            {
                cart.Remove(item);
            }

            return cart;
        }

        [NonAction]//Done
        protected void ClearShoppingCart(Customer customer = null, int? invoiceId = null, List<ShoppingCartItem> cart = null)
        {
            if (cart == null)
            {
                cart = GetShoppingCartItems(customer, invoiceId);
            }
            cart.ToList().ForEach(sci => _invoiceCartService.DeleteShoppingCartItem(sci, false));
        }

        //[NonAction]//Done
        //private string RenderRazorViewToString(string viewName, object model)
        //{
        //    ViewData.Model = model;
        //    using (var sw = new StringWriter())
        //    {
        //        var viewResult = ViewEngines.Engines.FindPartialView(ControllerContext, viewName);
        //        var viewContext = new ViewContext(ControllerContext, viewResult.View,
        //                                     ViewData, TempData, sw);
        //        viewResult.View.Render(viewContext, sw);
        //        viewResult.ViewEngine.ReleaseView(ControllerContext, viewResult.View);
        //        return sw.GetStringBuilder().ToString();
        //    }
        //}

        [NonAction]//Not Finished
        protected void SetOrderItems(Order order, List<ShoppingCartItem> cart)
        {
            while (order.OrderItems.Count > 0)
            {
                _orderService.DeleteOrderItem(order.OrderItems.First());
            }

            foreach (var sc in cart)
            {
                //prices
                decimal taxRate = decimal.Zero;
                decimal scUnitPrice = _priceCalculationService.GetUnitPrice(sc, true);
                decimal scSubTotal = _priceCalculationService.GetSubTotal(sc, true);
                decimal scUnitPriceInclTax = _taxService.GetProductPrice(sc.Product, scUnitPrice,
                    true, order.Customer, out taxRate);
                decimal scUnitPriceExclTax = _taxService.GetProductPrice(sc.Product, scUnitPrice,
                    false, order.Customer, out taxRate);
                decimal scSubTotalInclTax = _taxService.GetProductPrice(sc.Product, scSubTotal,
                    true, order.Customer, out taxRate);
                decimal scSubTotalExclTax = _taxService.GetProductPrice(sc.Product, scSubTotal,
                    false, order.Customer, out taxRate);

                var iiam = _invoiceItemAttributeParser.GetInvoiceItemAttributeMapping(sc.AttributesXml);
                if (iiam != null)
                {
                    if (!iiam.Taxable)
                    {
                        scUnitPriceInclTax = scUnitPriceExclTax;
                        scSubTotalInclTax = scSubTotalExclTax;
                    }
                }

                //discounts
                //Discount scDiscount = null;
                //decimal discountAmount = _priceCalculationService.GetDiscountAmount(sc, out scDiscount);
                //decimal discountAmountInclTax = _taxService.GetProductPrice(sc.Product, discountAmount, true, customer, out taxRate);
                //decimal discountAmountExclTax = _taxService.GetProductPrice(sc.Product, discountAmount, false, customer, out taxRate);
                //if (scDiscount != null && !appliedDiscounts.ContainsDiscount(scDiscount))
                //    appliedDiscounts.Add(scDiscount);

                //attributes
                string attributeDescription = _productAttributeFormatter.FormatAttributes(sc.Product,
                    sc.AttributesXml, order.Customer);

                var itemWeight = _shippingService.GetShoppingCartItemWeight(sc);

                //save order item
                var orderItem = new OrderItem()
                {
                    OrderItemGuid = Guid.NewGuid(),
                    Order = order,
                    ProductId = sc.ProductId,
                    UnitPriceInclTax = scUnitPriceInclTax,
                    UnitPriceExclTax = scUnitPriceExclTax,
                    PriceInclTax = scSubTotalInclTax,
                    PriceExclTax = scSubTotalExclTax,
                    OriginalProductCost = _priceCalculationService.GetProductCost(sc.Product, sc.AttributesXml),
                    AttributeDescription = attributeDescription,
                    AttributesXml = sc.AttributesXml,
                    Quantity = sc.Quantity,
                    //DiscountAmountInclTax = discountAmountInclTax,
                    //DiscountAmountExclTax = discountAmountExclTax,
                    DownloadCount = 0,
                    IsDownloadActivated = false,
                    LicenseDownloadId = 0,
                    ItemWeight = itemWeight,
                };
                order.OrderItems.Add(orderItem);
                //_orderService.UpdateOrder(order);

                //gift cards
                if (sc.Product.IsGiftCard)
                {
                    string giftCardRecipientName, giftCardRecipientEmail,
                        giftCardSenderName, giftCardSenderEmail, giftCardMessage;
                    _productAttributeParser.GetGiftCardAttribute(sc.AttributesXml,
                        out giftCardRecipientName, out giftCardRecipientEmail,
                        out giftCardSenderName, out giftCardSenderEmail, out giftCardMessage);

                    for (int i = 0; i < sc.Quantity; i++)
                    {
                        var gc = new GiftCard()
                        {
                            GiftCardType = sc.Product.GiftCardType,
                            PurchasedWithOrderItem = orderItem,
                            Amount = scUnitPriceExclTax,
                            IsGiftCardActivated = false,
                            GiftCardCouponCode = _giftCardService.GenerateGiftCardCode(),
                            RecipientName = giftCardRecipientName,
                            RecipientEmail = giftCardRecipientEmail,
                            SenderName = giftCardSenderName,
                            SenderEmail = giftCardSenderEmail,
                            Message = giftCardMessage,
                            IsRecipientNotified = false,
                            CreatedOnUtc = DateTime.UtcNow
                        };
                        _giftCardService.InsertGiftCard(gc);
                    }
                }

                //inventory
                //_productService.AdjustInventory(sc.Product, sc.Quantity, sc.AttributesXml);
            }

        }

        [NonAction]//Done
        protected void UpdateInvoiceItemsAttributes(Order invoice)
        {
            foreach (var invoiceItem in invoice.OrderItems)
            {
                var iiam = _invoiceItemAttributeParser.GetInvoiceItemAttributeMapping(invoiceItem.AttributesXml);
                if (iiam != null)
                {
                    invoiceItem.AttributesXml = _invoiceItemAttributeParser.AddInvoiceItemAttributes(
                        "",
                        invoiceItem.OrderId,
                        iiam.Description,
                        iiam.Taxable
                    );
                }
                else
                {
                    invoiceItem.AttributesXml = _invoiceItemAttributeParser.AddInvoiceItemAttributes(
                        "",
                        invoiceItem.OrderId,
                        invoiceItem.Product.Name,
                        !invoiceItem.Product.IsTaxExempt
                    );
                }
            }
        }

        [NonAction]//Done
        protected void SetInvoiceTotals(Order invoice, List<ShoppingCartItem> cart)
        {
            try
            {
                //var model = PrepareInvoiceTotalsModel(invoice.Id);

                decimal orderSubTotalDiscountAmountBase;
                List<DiscountForCaching> orderSubTotalAppliedDiscounts;
                decimal subTotalWithoutDiscountBase;
                decimal subTotalWithDiscountBase;
                _invoiceTotalCalculationService.GetInvoiceSubTotal(cart, false,
                    out orderSubTotalDiscountAmountBase, out orderSubTotalAppliedDiscounts,
                    out subTotalWithoutDiscountBase, out subTotalWithDiscountBase);

                invoice.OrderSubtotalExclTax = subTotalWithoutDiscountBase;
                invoice.OrderSubTotalDiscountExclTax = orderSubTotalDiscountAmountBase;

                _invoiceTotalCalculationService.GetInvoiceSubTotal(cart, true,
                    out orderSubTotalDiscountAmountBase, out orderSubTotalAppliedDiscounts,
                    out subTotalWithoutDiscountBase, out subTotalWithDiscountBase);

                invoice.OrderSubtotalInclTax = invoice.OrderSubtotalExclTax;//subTotalWithoutDiscountBase;
                invoice.OrderSubTotalDiscountInclTax = orderSubTotalDiscountAmountBase;

                invoice.OrderTotal = decimal.Zero;
                if (cart.Count > 0)
                {
                    decimal orderTotalDiscountAmountBase;
                    List<DiscountForCaching> orderTotalAppliedDiscounts;
                    List<AppliedGiftCard> appliedGiftCards;
                    int redeemedRewardPoints;
                    decimal redeemedRewardPointsAmount;

                    invoice.OrderTotal = (_invoiceTotalCalculationService.GetInvoiceTotal(cart,
                        out orderTotalDiscountAmountBase, out orderTotalAppliedDiscounts,
                        out appliedGiftCards, out redeemedRewardPoints, out redeemedRewardPointsAmount) ?? 0);

                    invoice.OrderTax = invoice.OrderTotal - invoice.OrderSubtotalExclTax;
                }
            }
            catch (Exception exc)
            {
                _notificationService.ErrorNotification(exc.Message);
            }
        }

        [NonAction]//2 Hard 2 Refactor
        protected virtual OrderTotalsModel PrepareInvoiceTotalsModel(int invoiceId, Customer customer = null, bool isEditable = true)
        {
            var cart = GetShoppingCartItems(null, invoiceId);

            var model = new OrderTotalsModel
            {
                IsEditable = isEditable
            };

            if (cart.Count > 0)
            {
                if (customer != null)
                {
                    cart.ForEach(cartItem => cartItem.Customer = customer);
                }

                //subtotal
                decimal orderSubTotalDiscountAmountBase;
                List<DiscountForCaching> orderSubTotalAppliedDiscounts;
                decimal subTotalWithoutDiscountBase;
                decimal subTotalWithDiscountBase;
                var subTotalIncludingTax = _workContext.TaxDisplayType == TaxDisplayType.IncludingTax &&
                                           !_taxSettings.ForceTaxExclusionFromOrderSubtotal;
                _invoiceTotalCalculationService.GetInvoiceSubTotal(cart, subTotalIncludingTax,
                    out orderSubTotalDiscountAmountBase, out orderSubTotalAppliedDiscounts,
                    out subTotalWithoutDiscountBase, out subTotalWithDiscountBase);
                decimal subtotalBase = subTotalWithoutDiscountBase;
                decimal subtotal = _currencyService.ConvertFromPrimaryStoreCurrency(subtotalBase,
                    _workContext.WorkingCurrency);
                model.SubTotal = _priceFormatter.FormatPrice(subtotal, true, _workContext.WorkingCurrency,
                    _workContext.WorkingLanguage, subTotalIncludingTax);

                if (orderSubTotalDiscountAmountBase > decimal.Zero)
                {
                    decimal orderSubTotalDiscountAmount =
                        _currencyService.ConvertFromPrimaryStoreCurrency(orderSubTotalDiscountAmountBase,
                            _workContext.WorkingCurrency);
                    model.SubTotalDiscount = _priceFormatter.FormatPrice(-orderSubTotalDiscountAmount, true, _workContext.WorkingCurrency, _workContext.WorkingLanguage, subTotalIncludingTax);
                }

                //LoadAllShippingRateComputationMethods
                var shippingRateComputationMethods = _shippingPluginManager.LoadActivePlugins(_workContext.CurrentCustomer, _storeContext.CurrentStore.Id);

                //tax
                bool displayTax = true;
                bool displayTaxRates = true;
                if (_taxSettings.HideTaxInOrderSummary && _workContext.TaxDisplayType == TaxDisplayType.IncludingTax)
                {
                    displayTax = false;
                    displayTaxRates = false;
                }
                else
                {
                    //SortedDictionary<decimal, decimal> taxRates;        
                    SortedDictionary<decimal, decimal> taxRates;
                    var shoppingCartTaxBase = _invoiceTotalCalculationService.GetTaxTotal(cart, shippingRateComputationMethods, out taxRates);
                    var shoppingCartTax = _currencyService.ConvertFromPrimaryStoreCurrency(shoppingCartTaxBase,
                        _workContext.WorkingCurrency);

                    if (shoppingCartTaxBase == 0 && _taxSettings.HideZeroTax)
                    {
                        displayTax = false;
                        displayTaxRates = false;
                    }
                    else
                    {
                        displayTaxRates = _taxSettings.DisplayTaxRates && taxRates.Any();
                        displayTax = !displayTaxRates;

                        model.Tax = _priceFormatter.FormatPrice(shoppingCartTax, true, false);
                        foreach (var tr in taxRates)
                        {
                            model.TaxRates.Add(new OrderTotalsModel.TaxRate
                            {
                                Rate = _priceFormatter.FormatTaxRate(tr.Key),
                                Value = _priceFormatter.FormatPrice(_currencyService.ConvertFromPrimaryStoreCurrency(tr.Value, _workContext.WorkingCurrency), true, false),
                            });
                        }
                    }
                }
                model.DisplayTaxRates = displayTaxRates;
                model.DisplayTax = displayTax;

                //total
                decimal orderTotalDiscountAmountBase;
                List<DiscountForCaching> orderTotalAppliedDiscounts;
                List<AppliedGiftCard> appliedGiftCards;
                int redeemedRewardPoints;
                decimal redeemedRewardPointsAmount;
                decimal? shoppingCartTotalBase;
                try
                {
                    shoppingCartTotalBase = _invoiceTotalCalculationService.GetInvoiceTotal(cart,
                        out orderTotalDiscountAmountBase, out orderTotalAppliedDiscounts,
                        out appliedGiftCards, out redeemedRewardPoints, out redeemedRewardPointsAmount);

                    if (shoppingCartTotalBase.HasValue)
                    {
                        decimal shoppingCartTotal =
                            _currencyService.ConvertFromPrimaryStoreCurrency(shoppingCartTotalBase.Value,
                                _workContext.WorkingCurrency);
                        model.OrderTotal = _priceFormatter.FormatPrice(shoppingCartTotal, true, false);
                    }

                    //discount
                    if (orderTotalDiscountAmountBase > decimal.Zero)
                    {
                        decimal orderTotalDiscountAmount =
                            _currencyService.ConvertFromPrimaryStoreCurrency(orderTotalDiscountAmountBase,
                                _workContext.WorkingCurrency);
                        model.OrderTotalDiscount = _priceFormatter.FormatPrice(-orderTotalDiscountAmount, true, false);
                    }

                    //gift cards
                    if (appliedGiftCards != null && appliedGiftCards.Count > 0)
                    {
                        foreach (var appliedGiftCard in appliedGiftCards)
                        {
                            var gcModel = new OrderTotalsModel.GiftCard
                            {
                                Id = appliedGiftCard.GiftCard.Id,
                                CouponCode = appliedGiftCard.GiftCard.GiftCardCouponCode,
                            };
                            decimal amountCanBeUsed =
                                _currencyService.ConvertFromPrimaryStoreCurrency(appliedGiftCard.AmountCanBeUsed,
                                    _workContext.WorkingCurrency);
                            gcModel.Amount = _priceFormatter.FormatPrice(-amountCanBeUsed, true, false);

                            var remainingAmountBase = _giftCardService.GetGiftCardRemainingAmount(appliedGiftCard.GiftCard) - appliedGiftCard.AmountCanBeUsed;
                            decimal remainingAmount = _currencyService.ConvertFromPrimaryStoreCurrency(remainingAmountBase,
                                _workContext.WorkingCurrency);
                            gcModel.Remaining = _priceFormatter.FormatPrice(remainingAmount, true, false);

                            model.GiftCards.Add(gcModel);
                        }
                    }

                    //reward points to be spent (redeemed)
                    if (redeemedRewardPointsAmount > decimal.Zero)
                    {
                        decimal redeemedRewardPointsAmountInCustomerCurrency =
                            _currencyService.ConvertFromPrimaryStoreCurrency(redeemedRewardPointsAmount,
                                _workContext.WorkingCurrency);
                        model.RedeemedRewardPoints = redeemedRewardPoints;
                        model.RedeemedRewardPointsAmount =
                            _priceFormatter.FormatPrice(-redeemedRewardPointsAmountInCustomerCurrency, true, false);
                    }

                    //reward points to be earned
                    if (_rewardPointsSettings.Enabled &&
                        _rewardPointsSettings.DisplayHowMuchWillBeEarned &&
                        shoppingCartTotalBase.HasValue)
                    {
                        model.WillEarnRewardPoints = _invoiceTotalCalculationService
                            .CalculateRewardPoints(_workContext.CurrentCustomer, shoppingCartTotalBase.Value);
                    }
                }
                catch (Exception exc)
                {

                }
            }

            return model;
        }

        [NonAction]
        protected InvoiceModel.DiscountBoxModel GetAppliedDiscount(Customer customer)
        {
            var model = new InvoiceModel.DiscountBoxModel
            {
                Display = true
            };

            try
            {
                var discount = _discountService.GetAllDiscountsForCaching(couponCode: _genericAttributeService
                               .GetAttributesForEntity(customer.Id, "Customer").First(p => p.Key == "DiscountCouponCode").Value).FirstOrDefault();

                if (discount != null)
                {
                    model.Message = _localizationService.GetResource("ShoppingCart.DiscountCouponCode.Applied");
                    model.IsApplied = true;
                    model.CurrentCode = discount.CouponCode;
                }
            }
            catch (Exception)
            {
                // customer haven't any records in genericAttributes table
            }

            return model;
        }

        // Can not Use in .NET Core. Instead use RouteUrl
        //[NonAction] 
        //protected virtual string GetStoreUrl(int storeId = 0, bool useSsl = false)
        //{
        //    var store = _storeService.GetStoreById(storeId) ?? _storeContext.CurrentStore;

        //    if (store == null)
        //        throw new Exception("No store could be loaded");

        //    return useSsl ? store.SecureUrl : store.Url;
        //}

        /// <summary>
        /// Generates an absolute URL for the specified store, routeName and route values
        /// </summary>
        /// <param name="storeId">Store identifier; Pass 0 to load URL of the current store</param>
        /// <param name="routeName">The name of the route that is used to generate URL</param>
        /// <param name="routeValues">An object that contains route values</param>
        /// <returns>Generated URL</returns>
        protected virtual string RouteUrl(int storeId = 0, string routeName = null, object routeValues = null)
        {
            //try to get a store by the passed identifier
            var store = _storeService.GetStoreById(storeId) ?? _storeContext.CurrentStore
                ?? throw new Exception("No store could be loaded");

            //ensure that the store URL is specified
            if (string.IsNullOrEmpty(store.Url))
                throw new Exception("URL cannot be null");

            //generate a URL with an absolute path
            var urlHelper = _urlHelperFactory.GetUrlHelper(_actionContextAccessor.ActionContext);
            var url = new PathString(urlHelper.RouteUrl(routeName, routeValues));

            //remove the application path from the generated URL if exists
            var pathBase = _actionContextAccessor.ActionContext?.HttpContext?.Request?.PathBase ?? PathString.Empty;
            url.StartsWithSegments(pathBase, out url);

            //compose the result
            return Uri.EscapeUriString(WebUtility.UrlDecode($"{store.Url.TrimEnd('/')}{url}"));
        }

        //[NonAction]
        //protected virtual void AddCustomerTokens(IList<Token> tokens, Customer customer)
        //{
        //    tokens.Add(new Token("Customer.Email", customer.Email));
        //    tokens.Add(new Token("Customer.Username", customer.Username));
        //    tokens.Add(new Token("Customer.FullName", _customerService.GetCustomerFullName(customer)));
        //    tokens.Add(new Token("Customer.FirstName", _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.FirstNameAttribute)));
        //    tokens.Add(new Token("Customer.LastName", _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.LastNameAttribute)));
        //    tokens.Add(new Token("Customer.VatNumber", _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.VatNumberAttribute)));
        //    tokens.Add(new Token("Customer.VatNumberStatus", ((VatNumberStatus)_genericAttributeService.GetAttribute<int>(customer, NopCustomerDefaults.VatNumberStatusIdAttribute)).ToString()));

        //    var customAttributesXml = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.CustomCustomerAttributes);
        //    tokens.Add(new Token("Customer.CustomAttributes", _customerAttributeFormatter.FormatAttributes(customAttributesXml), true));

        //    //note: we do not use SEO friendly URLS for these links because we can get errors caused by having .(dot) in the URL (from the email address)
        //    var passwordRecoveryUrl = RouteUrl(routeName: "PasswordRecoveryConfirm", routeValues: new { token = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.PasswordRecoveryTokenAttribute), email = customer.Email });
        //    var accountActivationUrl = RouteUrl(routeName: "AccountActivation", routeValues: new { token = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.AccountActivationTokenAttribute), email = customer.Email });
        //    var emailRevalidationUrl = RouteUrl(routeName: "EmailRevalidation", routeValues: new { token = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.EmailRevalidationTokenAttribute), email = customer.Email });
        //    var wishlistUrl = RouteUrl(routeName: "Wishlist", routeValues: new { customerGuid = customer.CustomerGuid });
        //    tokens.Add(new Token("Customer.PasswordRecoveryURL", passwordRecoveryUrl, true));
        //    tokens.Add(new Token("Customer.AccountActivationURL", accountActivationUrl, true));
        //    tokens.Add(new Token("Customer.EmailRevalidationURL", emailRevalidationUrl, true));
        //    tokens.Add(new Token("Wishlist.URLForCustomer", wishlistUrl, true));

        //    //event notification
        //    _eventPublisher.EntityTokensAdded(customer, tokens);
        //}

        //[NonAction]//Done
        //protected void SendEmailToCustomer(Customer receiver, Order invoice, string templateName)
        //{
        //    var store = _storeContext.CurrentStore;

        //    try
        //    {
        //        //ShopFast.Plugin.Misc.Invoices.InvoiceCreated
        //        var emailTemplate = _messageTemplateService.GetMessageTemplateByName(templateName, store.Id);

        //        if (receiver == null)
        //            throw new NopException(_localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Email.EmptyReceiver"));
        //        if (String.IsNullOrWhiteSpace(receiver.Email))
        //            throw new NopException(_localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Email.EmailEmpty"));
        //        if (!CommonHelper.IsValidEmail(receiver.Email))
        //            throw new NopException(_localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Email.EmailNotValid"));
        //        if (emailTemplate == null)
        //            throw new NopException(_localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Email.TemplateNotFound"));

        //        var emailAccount = _emailAccountService.GetEmailAccountById(_emailAccountSettings.DefaultEmailAccountId) ??
        //                           _emailAccountService.GetAllEmailAccounts().FirstOrDefault();
        //        if (emailAccount == null)
        //            throw new NopException(_localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Email.AccountNotLoaded"));

        //        var languageId = _localizationSettings.DefaultAdminLanguageId;

        //        var tokens = new List<Token>();
        //        _messageTokenProvider.AddStoreTokens(tokens, store, emailAccount);
        //        _messageTokenProvider.AddOrderTokens(tokens, invoice, languageId);
        //        AddCustomerTokens(tokens, invoice.Customer);

        //        var recurringPayment = _orderService.GetRecurringPaymentByOrderId(invoice.Id);
        //        if (recurringPayment != null)
        //        {
        //            _messageTokenProvider.AddRecurringPaymentTokens(tokens, recurringPayment);
        //        }

        //        var subjectReplaced = _tokenizer.Replace(emailTemplate.Subject, tokens, false);
        //        var bodyReplaced = _tokenizer.Replace(emailTemplate.Body, tokens, true);

        //        var email = new QueuedEmail
        //        {
        //            Priority = QueuedEmailPriority.High,
        //            EmailAccountId = emailAccount.Id,
        //            FromName = emailAccount.DisplayName,
        //            From = emailAccount.Email,
        //            ToName = receiver.GetFullName(),
        //            To = receiver.Email,
        //            Subject = subjectReplaced,
        //            Body = bodyReplaced,
        //            CreatedOnUtc = DateTime.UtcNow,
        //        };
        //        _queuedEmailService.InsertQueuedEmail(email);
        //        SuccessNotification(_localizationService.GetResource("Admin.Customers.Customers.SendEmail.Queued"));
        //    }
        //    catch (Exception exc)
        //    {
        //        ErrorNotification(exc.Message);
        //    }
        //}

        [NonAction]
        protected void FillShoppingCartWithInvoiceItems(Order invoice)
        {
            _invoiceCartService.ReOrderInvoice(invoice, false);

            var cart = GetShoppingCartItems(null, invoice.Id);
            foreach (var invoiceItem in cart)
            {
                var iiam = _invoiceItemAttributeParser.GetInvoiceItemAttributeMapping(invoiceItem.AttributesXml);
                if (iiam != null)
                {
                    //Set fields depending on attribute's values
                }
            }
        }

        [NonAction]
        protected virtual OrderDetailsModel PrepareOrderDetailsModel(Order order)
        {
            if (order == null)
                throw new ArgumentNullException("order");
            var model = new OrderDetailsModel
            {
                Id = order.Id,
                CreatedOn = _dateTimeHelper.ConvertToUserTime(order.CreatedOnUtc, DateTimeKind.Utc),
                OrderStatus = _localizationService.GetLocalizedEnum(order.OrderStatus),
                IsReOrderAllowed = _orderSettings.IsReOrderAllowed,
                IsReturnRequestAllowed = _orderProcessingService.IsReturnRequestAllowed(order),
                PdfInvoiceDisabled = _pdfSettings.DisablePdfInvoicesForPendingOrders && order.OrderStatus == OrderStatus.Pending,
                CustomOrderNumber = order.CustomOrderNumber,

                //shipping info
                ShippingStatus = _localizationService.GetLocalizedEnum(order.ShippingStatus)
            };
            if (order.ShippingStatus != ShippingStatus.ShippingNotRequired)
            {
                model.IsShippable = true;
                model.PickupInStore = order.PickupInStore;
                if (!order.PickupInStore)
                {
                    _addressModelFactory.PrepareAddressModel(model.ShippingAddress,
                        address: order.ShippingAddress,
                        excludeProperties: false,
                        addressSettings: _addressSettings);
                }
                else
                    if (order.PickupAddress != null)
                    model.PickupAddress = new AddressModel
                    {
                        Address1 = order.PickupAddress.Address1,
                        City = order.PickupAddress.City,
                        County = order.PickupAddress.County,
                        CountryName = order.PickupAddress.Country != null ? order.PickupAddress.Country.Name : string.Empty,
                        ZipPostalCode = order.PickupAddress.ZipPostalCode
                    };
                model.ShippingMethod = order.ShippingMethod;

                //shipments (only already shipped)
                var shipments = order.Shipments.Where(x => x.ShippedDateUtc.HasValue).OrderBy(x => x.CreatedOnUtc).ToList();
                foreach (var shipment in shipments)
                {
                    var shipmentModel = new OrderDetailsModel.ShipmentBriefModel
                    {
                        Id = shipment.Id,
                        TrackingNumber = shipment.TrackingNumber,
                    };
                    if (shipment.ShippedDateUtc.HasValue)
                        shipmentModel.ShippedDate = _dateTimeHelper.ConvertToUserTime(shipment.ShippedDateUtc.Value, DateTimeKind.Utc);
                    if (shipment.DeliveryDateUtc.HasValue)
                        shipmentModel.DeliveryDate = _dateTimeHelper.ConvertToUserTime(shipment.DeliveryDateUtc.Value, DateTimeKind.Utc);
                    model.Shipments.Add(shipmentModel);
                }
            }

            //billing info
            _addressModelFactory.PrepareAddressModel(model.BillingAddress,
                address: order.BillingAddress,
                excludeProperties: false,
                addressSettings: _addressSettings);

            //VAT number
            model.VatNumber = order.VatNumber;

            //payment method
            var paymentMethod = _paymentPluginManager.LoadPluginBySystemName(order.PaymentMethodSystemName);
            model.PaymentMethod = paymentMethod != null ? _localizationService.GetLocalizedFriendlyName(paymentMethod, _workContext.WorkingLanguage.Id) : order.PaymentMethodSystemName;
            model.PaymentMethodStatus = _localizationService.GetLocalizedEnum(order.PaymentStatus);
            model.CanRePostProcessPayment = _paymentService.CanRePostProcessPayment(order);
            //custom values
            model.CustomValues = _paymentService.DeserializeCustomValues(order);

            //order subtotal
            if (order.CustomerTaxDisplayType == TaxDisplayType.IncludingTax && !_taxSettings.ForceTaxExclusionFromOrderSubtotal)
            {
                //including tax

                //order subtotal
                var orderSubtotalInclTaxInCustomerCurrency = _currencyService.ConvertCurrency(order.OrderSubtotalInclTax, order.CurrencyRate);
                model.OrderSubtotal = _priceFormatter.FormatPrice(orderSubtotalInclTaxInCustomerCurrency, true, order.CustomerCurrencyCode, _workContext.WorkingLanguage, true);
                //discount (applied to order subtotal)
                var orderSubTotalDiscountInclTaxInCustomerCurrency = _currencyService.ConvertCurrency(order.OrderSubTotalDiscountInclTax, order.CurrencyRate);
                if (orderSubTotalDiscountInclTaxInCustomerCurrency > decimal.Zero)
                    model.OrderSubTotalDiscount = _priceFormatter.FormatPrice(-orderSubTotalDiscountInclTaxInCustomerCurrency, true, order.CustomerCurrencyCode, _workContext.WorkingLanguage, true);
            }
            else
            {
                //excluding tax

                //order subtotal
                var orderSubtotalExclTaxInCustomerCurrency = _currencyService.ConvertCurrency(order.OrderSubtotalExclTax, order.CurrencyRate);
                model.OrderSubtotal = _priceFormatter.FormatPrice(orderSubtotalExclTaxInCustomerCurrency, true, order.CustomerCurrencyCode, _workContext.WorkingLanguage, false);
                //discount (applied to order subtotal)
                var orderSubTotalDiscountExclTaxInCustomerCurrency = _currencyService.ConvertCurrency(order.OrderSubTotalDiscountExclTax, order.CurrencyRate);
                if (orderSubTotalDiscountExclTaxInCustomerCurrency > decimal.Zero)
                    model.OrderSubTotalDiscount = _priceFormatter.FormatPrice(-orderSubTotalDiscountExclTaxInCustomerCurrency, true, order.CustomerCurrencyCode, _workContext.WorkingLanguage, false);
            }

            if (order.CustomerTaxDisplayType == TaxDisplayType.IncludingTax)
            {
                //including tax

                //order shipping
                var orderShippingInclTaxInCustomerCurrency = _currencyService.ConvertCurrency(order.OrderShippingInclTax, order.CurrencyRate);
                model.OrderShipping = _priceFormatter.FormatShippingPrice(orderShippingInclTaxInCustomerCurrency, true, order.CustomerCurrencyCode, _workContext.WorkingLanguage, true);
                //payment method additional fee
                var paymentMethodAdditionalFeeInclTaxInCustomerCurrency = _currencyService.ConvertCurrency(order.PaymentMethodAdditionalFeeInclTax, order.CurrencyRate);
                if (paymentMethodAdditionalFeeInclTaxInCustomerCurrency > decimal.Zero)
                    model.PaymentMethodAdditionalFee = _priceFormatter.FormatPaymentMethodAdditionalFee(paymentMethodAdditionalFeeInclTaxInCustomerCurrency, true, order.CustomerCurrencyCode, _workContext.WorkingLanguage, true);
            }
            else
            {
                //excluding tax

                //order shipping
                var orderShippingExclTaxInCustomerCurrency = _currencyService.ConvertCurrency(order.OrderShippingExclTax, order.CurrencyRate);
                model.OrderShipping = _priceFormatter.FormatShippingPrice(orderShippingExclTaxInCustomerCurrency, true, order.CustomerCurrencyCode, _workContext.WorkingLanguage, false);
                //payment method additional fee
                var paymentMethodAdditionalFeeExclTaxInCustomerCurrency = _currencyService.ConvertCurrency(order.PaymentMethodAdditionalFeeExclTax, order.CurrencyRate);
                if (paymentMethodAdditionalFeeExclTaxInCustomerCurrency > decimal.Zero)
                    model.PaymentMethodAdditionalFee = _priceFormatter.FormatPaymentMethodAdditionalFee(paymentMethodAdditionalFeeExclTaxInCustomerCurrency, true, order.CustomerCurrencyCode, _workContext.WorkingLanguage, false);
            }

            //tax
            var displayTax = true;
            var displayTaxRates = true;
            if (_taxSettings.HideTaxInOrderSummary && order.CustomerTaxDisplayType == TaxDisplayType.IncludingTax)
            {
                displayTax = false;
                displayTaxRates = false;
            }
            else
            {
                if (order.OrderTax == 0 && _taxSettings.HideZeroTax)
                {
                    displayTax = false;
                    displayTaxRates = false;
                }
                else
                {
                    var taxRates = _orderService.ParseTaxRates(order, order.TaxRates);
                    displayTaxRates = _taxSettings.DisplayTaxRates && taxRates.Any();
                    displayTax = !displayTaxRates;

                    var orderTaxInCustomerCurrency = _currencyService.ConvertCurrency(order.OrderTax, order.CurrencyRate);
                    //TODO pass languageId to _priceFormatter.FormatPrice
                    model.Tax = _priceFormatter.FormatPrice(orderTaxInCustomerCurrency, true, order.CustomerCurrencyCode, false, _workContext.WorkingLanguage);

                    foreach (var tr in taxRates)
                    {
                        model.TaxRates.Add(new OrderDetailsModel.TaxRate
                        {
                            Rate = _priceFormatter.FormatTaxRate(tr.Key),
                            //TODO pass languageId to _priceFormatter.FormatPrice
                            Value = _priceFormatter.FormatPrice(_currencyService.ConvertCurrency(tr.Value, order.CurrencyRate), true, order.CustomerCurrencyCode, false, _workContext.WorkingLanguage),
                        });
                    }
                }
            }
            model.DisplayTaxRates = displayTaxRates;
            model.DisplayTax = displayTax;
            model.DisplayTaxShippingInfo = _catalogSettings.DisplayTaxShippingInfoOrderDetailsPage;
            model.PricesIncludeTax = order.CustomerTaxDisplayType == TaxDisplayType.IncludingTax;

            //discount (applied to order total)
            var orderDiscountInCustomerCurrency = _currencyService.ConvertCurrency(order.OrderDiscount, order.CurrencyRate);
            if (orderDiscountInCustomerCurrency > decimal.Zero)
                model.OrderTotalDiscount = _priceFormatter.FormatPrice(-orderDiscountInCustomerCurrency, true, order.CustomerCurrencyCode, false, _workContext.WorkingLanguage);

            //gift cards
            foreach (var gcuh in order.GiftCardUsageHistory)
            {
                model.GiftCards.Add(new OrderDetailsModel.GiftCard
                {
                    CouponCode = gcuh.GiftCard.GiftCardCouponCode,
                    Amount = _priceFormatter.FormatPrice(-(_currencyService.ConvertCurrency(gcuh.UsedValue, order.CurrencyRate)), true, order.CustomerCurrencyCode, false, _workContext.WorkingLanguage),
                });
            }

            //reward points           
            if (order.RedeemedRewardPointsEntry != null)
            {
                model.RedeemedRewardPoints = -order.RedeemedRewardPointsEntry.Points;
                model.RedeemedRewardPointsAmount = _priceFormatter.FormatPrice(-(_currencyService.ConvertCurrency(order.RedeemedRewardPointsEntry.UsedAmount, order.CurrencyRate)), true, order.CustomerCurrencyCode, false, _workContext.WorkingLanguage);
            }

            //total
            var orderTotalInCustomerCurrency = _currencyService.ConvertCurrency(order.OrderTotal, order.CurrencyRate);
            model.OrderTotal = _priceFormatter.FormatPrice(orderTotalInCustomerCurrency, true, order.CustomerCurrencyCode, false, _workContext.WorkingLanguage);

            //checkout attributes
            model.CheckoutAttributeInfo = order.CheckoutAttributeDescription;

            //order notes
            foreach (var orderNote in order.OrderNotes
                .Where(on => on.DisplayToCustomer)
                .OrderByDescending(on => on.CreatedOnUtc)
                .ToList())
            {
                model.OrderNotes.Add(new OrderDetailsModel.OrderNote
                {
                    Id = orderNote.Id,
                    HasDownload = orderNote.DownloadId > 0,
                    Note = _orderService.FormatOrderNoteText(orderNote),
                    CreatedOn = _dateTimeHelper.ConvertToUserTime(orderNote.CreatedOnUtc, DateTimeKind.Utc)
                });
            }

            //purchased products
            model.ShowSku = _catalogSettings.ShowSkuOnProductDetailsPage;
            model.ShowVendorName = _vendorSettings.ShowVendorOnOrderDetailsPage;

            var orderItems = order.OrderItems;

            var vendors = _vendorSettings.ShowVendorOnOrderDetailsPage ? _vendorService.GetVendorsByIds(orderItems.Select(item => item.Product.VendorId).ToArray()) : new List<Vendor>();

            foreach (var orderItem in orderItems)
            {
                var orderItemModel = new OrderDetailsModel.OrderItemModel
                {
                    Id = orderItem.Id,
                    OrderItemGuid = orderItem.OrderItemGuid,
                    Sku = _productService.FormatSku(orderItem.Product, orderItem.AttributesXml),
                    VendorName = vendors.FirstOrDefault(v => v.Id == orderItem.Product.VendorId)?.Name ?? string.Empty,
                    ProductId = orderItem.Product.Id,
                    ProductName = _localizationService.GetLocalized(orderItem.Product, x => x.Name),
                    ProductSeName = _urlRecordService.GetSeName(orderItem.Product),
                    Quantity = orderItem.Quantity,
                    AttributeInfo = orderItem.AttributeDescription,
                };
                //rental info
                if (orderItem.Product.IsRental)
                {
                    var rentalStartDate = orderItem.RentalStartDateUtc.HasValue
                        ? _productService.FormatRentalDate(orderItem.Product, orderItem.RentalStartDateUtc.Value) : "";
                    var rentalEndDate = orderItem.RentalEndDateUtc.HasValue
                        ? _productService.FormatRentalDate(orderItem.Product, orderItem.RentalEndDateUtc.Value) : "";
                    orderItemModel.RentalInfo = string.Format(_localizationService.GetResource("Order.Rental.FormattedDate"),
                        rentalStartDate, rentalEndDate);
                }
                model.Items.Add(orderItemModel);

                //unit price, subtotal
                if (order.CustomerTaxDisplayType == TaxDisplayType.IncludingTax)
                {
                    //including tax
                    var unitPriceInclTaxInCustomerCurrency = _currencyService.ConvertCurrency(orderItem.UnitPriceInclTax, order.CurrencyRate);
                    orderItemModel.UnitPrice = _priceFormatter.FormatPrice(unitPriceInclTaxInCustomerCurrency, true, order.CustomerCurrencyCode, _workContext.WorkingLanguage, true);

                    var priceInclTaxInCustomerCurrency = _currencyService.ConvertCurrency(orderItem.PriceInclTax, order.CurrencyRate);
                    orderItemModel.SubTotal = _priceFormatter.FormatPrice(priceInclTaxInCustomerCurrency, true, order.CustomerCurrencyCode, _workContext.WorkingLanguage, true);
                }
                else
                {
                    //excluding tax
                    var unitPriceExclTaxInCustomerCurrency = _currencyService.ConvertCurrency(orderItem.UnitPriceExclTax, order.CurrencyRate);
                    orderItemModel.UnitPrice = _priceFormatter.FormatPrice(unitPriceExclTaxInCustomerCurrency, true, order.CustomerCurrencyCode, _workContext.WorkingLanguage, false);

                    var priceExclTaxInCustomerCurrency = _currencyService.ConvertCurrency(orderItem.PriceExclTax, order.CurrencyRate);
                    orderItemModel.SubTotal = _priceFormatter.FormatPrice(priceExclTaxInCustomerCurrency, true, order.CustomerCurrencyCode, _workContext.WorkingLanguage, false);
                }

                //downloadable products
                if (_downloadService.IsDownloadAllowed(orderItem))
                    orderItemModel.DownloadId = orderItem.Product.DownloadId;
                if (_downloadService.IsLicenseDownloadAllowed(orderItem))
                    orderItemModel.LicenseId = orderItem.LicenseDownloadId.HasValue ? orderItem.LicenseDownloadId.Value : 0;
            }

            return model;
        }

        #region Invoice Info (Top section of edit page)

        [NonAction]
        protected virtual OrderModel PrepareOrderModel(Order order)
        {
            if (order == null)
                throw new ArgumentNullException("order");

            var model = new OrderModel();

            model.Id = order.Id;
            model.OrderStatus = _localizationService.GetLocalizedEnum(order.OrderStatus);
            model.OrderStatusId = order.OrderStatusId;
            model.OrderGuid = order.OrderGuid;
            var store = _storeService.GetStoreById(order.StoreId);
            model.StoreName = store != null ? store.Name : "Unknown";
            model.CustomerId = order.CustomerId;
            var customer = order.Customer;
            model.CustomerInfo = customer.IsRegistered() ? customer.Email : _localizationService.GetResource("Admin.Customers.Guest");
            model.CustomerIp = order.CustomerIp;
            model.VatNumber = order.VatNumber;
            model.CreatedOn = _dateTimeHelper.ConvertToUserTime(order.CreatedOnUtc, DateTimeKind.Utc);
            model.AllowCustomersToSelectTaxDisplayType = _taxSettings.AllowCustomersToSelectTaxDisplayType;
            model.TaxDisplayType = _taxSettings.TaxDisplayType;
            model.AffiliateId = order.AffiliateId;
            //a vendor should have access only to his products
            model.IsLoggedInAsVendor = _workContext.CurrentVendor != null;
            //custom values
            model.CustomValues = _paymentService.DeserializeCustomValues(order);

            #region Order totals

            var primaryStoreCurrency = _currencyService.GetCurrencyById(_currencySettings.PrimaryStoreCurrencyId);
            if (primaryStoreCurrency == null)
                throw new Exception("Cannot load primary store currency");

            //subtotal
            model.OrderSubtotalInclTax = _priceFormatter.FormatPrice(order.OrderSubtotalInclTax, true, primaryStoreCurrency, _workContext.WorkingLanguage, true);
            model.OrderSubtotalExclTax = _priceFormatter.FormatPrice(order.OrderSubtotalExclTax, true, primaryStoreCurrency, _workContext.WorkingLanguage, false);
            model.OrderSubtotalInclTaxValue = order.OrderSubtotalInclTax;
            model.OrderSubtotalExclTaxValue = order.OrderSubtotalExclTax;
            //discount (applied to order subtotal)
            string orderSubtotalDiscountInclTaxStr = _priceFormatter.FormatPrice(order.OrderSubTotalDiscountInclTax, true, primaryStoreCurrency, _workContext.WorkingLanguage, true);
            string orderSubtotalDiscountExclTaxStr = _priceFormatter.FormatPrice(order.OrderSubTotalDiscountExclTax, true, primaryStoreCurrency, _workContext.WorkingLanguage, false);
            if (order.OrderSubTotalDiscountInclTax > decimal.Zero)
                model.OrderSubTotalDiscountInclTax = orderSubtotalDiscountInclTaxStr;
            if (order.OrderSubTotalDiscountExclTax > decimal.Zero)
                model.OrderSubTotalDiscountExclTax = orderSubtotalDiscountExclTaxStr;
            model.OrderSubTotalDiscountInclTaxValue = order.OrderSubTotalDiscountInclTax;
            model.OrderSubTotalDiscountExclTaxValue = order.OrderSubTotalDiscountExclTax;

            //shipping
            model.OrderShippingInclTax = _priceFormatter.FormatShippingPrice(order.OrderShippingInclTax, true, primaryStoreCurrency, _workContext.WorkingLanguage, true);
            model.OrderShippingExclTax = _priceFormatter.FormatShippingPrice(order.OrderShippingExclTax, true, primaryStoreCurrency, _workContext.WorkingLanguage, false);
            model.OrderShippingInclTaxValue = order.OrderShippingInclTax;
            model.OrderShippingExclTaxValue = order.OrderShippingExclTax;

            //payment method additional fee
            if (order.PaymentMethodAdditionalFeeInclTax > decimal.Zero)
            {
                model.PaymentMethodAdditionalFeeInclTax = _priceFormatter.FormatPaymentMethodAdditionalFee(order.PaymentMethodAdditionalFeeInclTax, true, primaryStoreCurrency, _workContext.WorkingLanguage, true);
                model.PaymentMethodAdditionalFeeExclTax = _priceFormatter.FormatPaymentMethodAdditionalFee(order.PaymentMethodAdditionalFeeExclTax, true, primaryStoreCurrency, _workContext.WorkingLanguage, false);
            }
            model.PaymentMethodAdditionalFeeInclTaxValue = order.PaymentMethodAdditionalFeeInclTax;
            model.PaymentMethodAdditionalFeeExclTaxValue = order.PaymentMethodAdditionalFeeExclTax;


            //tax
            model.Tax = _priceFormatter.FormatPrice(order.OrderTax, true, false);
            var taxRates = _orderService.ParseTaxRates(order, order.TaxRates);
            var displayTaxRates = _taxSettings.DisplayTaxRates && taxRates.Any();
            var displayTax = !displayTaxRates;
            foreach (var tr in taxRates)
            {
                model.TaxRates.Add(new OrderModel.TaxRate
                {
                    Rate = _priceFormatter.FormatTaxRate(tr.Key),
                    Value = _priceFormatter.FormatPrice(tr.Value, true, false)
                });
            }

            model.DisplayTaxRates = displayTaxRates;
            model.DisplayTax = displayTax;
            model.TaxValue = order.OrderTax;
            model.TaxRatesValue = order.TaxRates;

            //discount
            if (order.OrderDiscount > 0)
                model.OrderTotalDiscount = _priceFormatter.FormatPrice(-order.OrderDiscount, true, false);
            model.OrderTotalDiscountValue = order.OrderDiscount;

            //gift cards
            foreach (var gcuh in order.GiftCardUsageHistory)
            {
                model.GiftCards.Add(new OrderModel.GiftCard
                {
                    CouponCode = gcuh.GiftCard.GiftCardCouponCode,
                    Amount = _priceFormatter.FormatPrice(-gcuh.UsedValue, true, false),
                });
            }

            //reward points
            if (order.RedeemedRewardPointsEntry != null)
            {
                model.RedeemedRewardPoints = -order.RedeemedRewardPointsEntry.Points;
                model.RedeemedRewardPointsAmount = _priceFormatter.FormatPrice(-order.RedeemedRewardPointsEntry.UsedAmount, true, false);
            }

            //total
            model.OrderTotal = _priceFormatter.FormatPrice(order.OrderTotal, true, false);
            model.OrderTotalValue = order.OrderTotal;

            //refunded amount
            if (order.RefundedAmount > decimal.Zero)
                model.RefundedAmount = _priceFormatter.FormatPrice(order.RefundedAmount, true, false);

            //used discounts
            var duh = _discountService.GetAllDiscountUsageHistory(null, null, order.Id, 0, int.MaxValue);
            foreach (var d in duh)
            {
                model.UsedDiscounts.Add(new OrderModel.UsedDiscountModel
                {
                    DiscountId = d.DiscountId,
                    DiscountName = d.Discount.Name
                });
            }

            #endregion

            #region Payment info

            if (order.AllowStoringCreditCardNumber)
            {
                //card type
                model.CardType = _encryptionService.DecryptText(order.CardType);
                //cardholder name
                model.CardName = _encryptionService.DecryptText(order.CardName);
                //card number
                model.CardNumber = _encryptionService.DecryptText(order.CardNumber);
                //cvv
                model.CardCvv2 = _encryptionService.DecryptText(order.CardCvv2);
                //expiry date
                string cardExpirationMonthDecrypted = _encryptionService.DecryptText(order.CardExpirationMonth);
                if (!String.IsNullOrEmpty(cardExpirationMonthDecrypted) && cardExpirationMonthDecrypted != "0")
                    model.CardExpirationMonth = cardExpirationMonthDecrypted;
                string cardExpirationYearDecrypted = _encryptionService.DecryptText(order.CardExpirationYear);
                if (!String.IsNullOrEmpty(cardExpirationYearDecrypted) && cardExpirationYearDecrypted != "0")
                    model.CardExpirationYear = cardExpirationYearDecrypted;

                model.AllowStoringCreditCardNumber = true;
            }
            else
            {
                string maskedCreditCardNumberDecrypted = _encryptionService.DecryptText(order.MaskedCreditCardNumber);
                if (!String.IsNullOrEmpty(maskedCreditCardNumberDecrypted))
                    model.CardNumber = maskedCreditCardNumberDecrypted;
            }


            //payment transaction info
            model.AuthorizationTransactionId = order.AuthorizationTransactionId;
            model.CaptureTransactionId = order.CaptureTransactionId;
            model.SubscriptionTransactionId = order.SubscriptionTransactionId;

            //payment method info
            var pm = _paymentPluginManager.LoadPluginBySystemName(order.PaymentMethodSystemName);
            model.PaymentMethod = pm != null ? pm.PluginDescriptor.FriendlyName : order.PaymentMethodSystemName;
            model.PaymentStatus = _localizationService.GetLocalizedEnum(order.PaymentStatus);

            //payment method buttons
            model.CanCancelOrder = _orderProcessingService.CanCancelOrder(order);
            model.CanCapture = _orderProcessingService.CanCapture(order);
            model.CanMarkOrderAsPaid = _orderProcessingService.CanMarkOrderAsPaid(order);
            model.CanRefund = _orderProcessingService.CanRefund(order);
            model.CanRefundOffline = _orderProcessingService.CanRefundOffline(order);
            model.CanPartiallyRefund = _orderProcessingService.CanPartiallyRefund(order, decimal.Zero);
            model.CanPartiallyRefundOffline = _orderProcessingService.CanPartiallyRefundOffline(order, decimal.Zero);
            model.CanVoid = _orderProcessingService.CanVoid(order);
            model.CanVoidOffline = _orderProcessingService.CanVoidOffline(order);

            model.PrimaryStoreCurrencyCode = _currencyService.GetCurrencyById(_currencySettings.PrimaryStoreCurrencyId).CurrencyCode;
            model.MaxAmountToRefund = order.OrderTotal - order.RefundedAmount;

            //recurring payment record
            var recurringPayment = _orderService.SearchRecurringPayments(0, 0, order.Id, null, 0, int.MaxValue, true).FirstOrDefault();
            if (recurringPayment != null)
            {
                model.RecurringPaymentId = recurringPayment.Id;
            }
            #endregion

            #region Billing & shipping info

            model.BillingAddress = order.BillingAddress.ToModel(model.BillingAddress);
            model.BillingAddress.FormattedCustomAddressAttributes = _addressAttributeFormatter.FormatAttributes(order.BillingAddress.CustomAttributes);
            model.BillingAddress.FirstNameEnabled = true;
            model.BillingAddress.FirstNameRequired = true;
            model.BillingAddress.LastNameEnabled = true;
            model.BillingAddress.LastNameRequired = true;
            model.BillingAddress.EmailEnabled = true;
            model.BillingAddress.EmailRequired = true;
            model.BillingAddress.CompanyEnabled = _addressSettings.CompanyEnabled;
            model.BillingAddress.CompanyRequired = _addressSettings.CompanyRequired;
            model.BillingAddress.CountryEnabled = _addressSettings.CountryEnabled;
            model.BillingAddress.StateProvinceEnabled = _addressSettings.StateProvinceEnabled;
            model.BillingAddress.CityEnabled = _addressSettings.CityEnabled;
            model.BillingAddress.CityRequired = _addressSettings.CityRequired;
            model.BillingAddress.StreetAddressEnabled = _addressSettings.StreetAddressEnabled;
            model.BillingAddress.StreetAddressRequired = _addressSettings.StreetAddressRequired;
            model.BillingAddress.StreetAddress2Enabled = _addressSettings.StreetAddress2Enabled;
            model.BillingAddress.StreetAddress2Required = _addressSettings.StreetAddress2Required;
            model.BillingAddress.ZipPostalCodeEnabled = _addressSettings.ZipPostalCodeEnabled;
            model.BillingAddress.ZipPostalCodeRequired = _addressSettings.ZipPostalCodeRequired;
            model.BillingAddress.PhoneEnabled = _addressSettings.PhoneEnabled;
            model.BillingAddress.PhoneRequired = _addressSettings.PhoneRequired;
            model.BillingAddress.FaxEnabled = _addressSettings.FaxEnabled;
            model.BillingAddress.FaxRequired = _addressSettings.FaxRequired;

            model.ShippingStatus = _localizationService.GetLocalizedEnum(order.ShippingStatus);
            if (order.ShippingStatus != ShippingStatus.ShippingNotRequired)
            {
                model.IsShippable = true;

                model.PickupInStore = order.PickupInStore;
                if (!order.PickupInStore)
                {
                    model.ShippingAddress = order.ShippingAddress.ToModel(model.ShippingAddress);
                    model.ShippingAddress.FormattedCustomAddressAttributes = _addressAttributeFormatter.FormatAttributes(order.ShippingAddress.CustomAttributes);
                    model.ShippingAddress.FirstNameEnabled = true;
                    model.ShippingAddress.FirstNameRequired = true;
                    model.ShippingAddress.LastNameEnabled = true;
                    model.ShippingAddress.LastNameRequired = true;
                    model.ShippingAddress.EmailEnabled = true;
                    model.ShippingAddress.EmailRequired = true;
                    model.ShippingAddress.CompanyEnabled = _addressSettings.CompanyEnabled;
                    model.ShippingAddress.CompanyRequired = _addressSettings.CompanyRequired;
                    model.ShippingAddress.CountryEnabled = _addressSettings.CountryEnabled;
                    model.ShippingAddress.StateProvinceEnabled = _addressSettings.StateProvinceEnabled;
                    model.ShippingAddress.CityEnabled = _addressSettings.CityEnabled;
                    model.ShippingAddress.CityRequired = _addressSettings.CityRequired;
                    model.ShippingAddress.StreetAddressEnabled = _addressSettings.StreetAddressEnabled;
                    model.ShippingAddress.StreetAddressRequired = _addressSettings.StreetAddressRequired;
                    model.ShippingAddress.StreetAddress2Enabled = _addressSettings.StreetAddress2Enabled;
                    model.ShippingAddress.StreetAddress2Required = _addressSettings.StreetAddress2Required;
                    model.ShippingAddress.ZipPostalCodeEnabled = _addressSettings.ZipPostalCodeEnabled;
                    model.ShippingAddress.ZipPostalCodeRequired = _addressSettings.ZipPostalCodeRequired;
                    model.ShippingAddress.PhoneEnabled = _addressSettings.PhoneEnabled;
                    model.ShippingAddress.PhoneRequired = _addressSettings.PhoneRequired;
                    model.ShippingAddress.FaxEnabled = _addressSettings.FaxEnabled;
                    model.ShippingAddress.FaxRequired = _addressSettings.FaxRequired;

                    model.ShippingAddressGoogleMapsUrl = $"https://maps.google.com/maps?f=q&hl=en&ie=UTF8&oe=UTF8&geocode=&q={WebUtility.UrlEncode(order.ShippingAddress.Address1 + " " + order.ShippingAddress.ZipPostalCode + " " + order.ShippingAddress.City + " " + (order.ShippingAddress.Country != null ? order.ShippingAddress.Country.Name : ""))}";

                }
                model.ShippingMethod = order.ShippingMethod;

                model.CanAddNewShipments = _orderService.HasItemsToAddToShipment(order);
            }

            #endregion

            #region Products
            model.CheckoutAttributeInfo = order.CheckoutAttributeDescription;
            bool hasDownloadableItems = false;
            var products = order.OrderItems;
            //a vendor should have access only to his products
            if (_workContext.CurrentVendor != null)
            {
                products = products
                    .Where(orderItem => orderItem.Product.VendorId == _workContext.CurrentVendor.Id)
                    .ToList();
            }
            foreach (var orderItem in products)
            {
                if (orderItem.Product.IsDownload)
                    hasDownloadableItems = true;

                var orderItemModel = new OrderItemModel
                {
                    Id = orderItem.Id,
                    ProductId = orderItem.ProductId,
                    ProductName = orderItem.Product.Name,
                    Sku = _productService.FormatSku(orderItem.Product, orderItem.AttributesXml),
                    Quantity = orderItem.Quantity,
                    IsDownload = orderItem.Product.IsDownload,
                    DownloadCount = orderItem.DownloadCount,
                    DownloadActivationType = orderItem.Product.DownloadActivationType,
                    IsDownloadActivated = orderItem.IsDownloadActivated
                };
                //license file
                if (orderItem.LicenseDownloadId.HasValue)
                {
                    var licenseDownload = _downloadService.GetDownloadById(orderItem.LicenseDownloadId.Value);
                    if (licenseDownload != null)
                    {
                        orderItemModel.LicenseDownloadGuid = licenseDownload.DownloadGuid;
                    }
                }
                //vendor
                var vendor = _vendorService.GetVendorById(orderItem.Product.VendorId);
                orderItemModel.VendorName = vendor != null ? vendor.Name : "";

                //unit price
                orderItemModel.UnitPriceInclTaxValue = orderItem.UnitPriceInclTax;
                orderItemModel.UnitPriceExclTaxValue = orderItem.UnitPriceExclTax;
                orderItemModel.UnitPriceInclTax = _priceFormatter.FormatPrice(orderItem.UnitPriceInclTax, true, primaryStoreCurrency, _workContext.WorkingLanguage, true, true);
                orderItemModel.UnitPriceExclTax = _priceFormatter.FormatPrice(orderItem.UnitPriceExclTax, true, primaryStoreCurrency, _workContext.WorkingLanguage, false, true);
                //discounts
                orderItemModel.DiscountInclTaxValue = orderItem.DiscountAmountInclTax;
                orderItemModel.DiscountExclTaxValue = orderItem.DiscountAmountExclTax;
                orderItemModel.DiscountInclTax = _priceFormatter.FormatPrice(orderItem.DiscountAmountInclTax, true, primaryStoreCurrency, _workContext.WorkingLanguage, true, true);
                orderItemModel.DiscountExclTax = _priceFormatter.FormatPrice(orderItem.DiscountAmountExclTax, true, primaryStoreCurrency, _workContext.WorkingLanguage, false, true);
                //subtotal
                orderItemModel.SubTotalInclTaxValue = orderItem.PriceInclTax;
                orderItemModel.SubTotalExclTaxValue = orderItem.PriceExclTax;
                orderItemModel.SubTotalInclTax = _priceFormatter.FormatPrice(orderItem.PriceInclTax, true, primaryStoreCurrency, _workContext.WorkingLanguage, true, true);
                orderItemModel.SubTotalExclTax = _priceFormatter.FormatPrice(orderItem.PriceExclTax, true, primaryStoreCurrency, _workContext.WorkingLanguage, false, true);

                orderItemModel.AttributeInfo = orderItem.AttributeDescription;
                if (orderItem.Product.IsRecurring)
                {
                    orderItemModel.RecurringInfo = string.Format(_localizationService.GetResource("Admin.Orders.Products.RecurringPeriod"),
                        orderItem.Product.RecurringCycleLength, _localizationService.GetLocalizedEnum(orderItem.Product.RecurringCyclePeriod));
                }

                //rental info
                if (orderItem.Product.IsRental)
                {
                    var rentalStartDate = orderItem.RentalStartDateUtc.HasValue
                        ? _productService.FormatRentalDate(orderItem.Product, orderItem.RentalStartDateUtc.Value) : string.Empty;
                    var rentalEndDate = orderItem.RentalEndDateUtc.HasValue
                        ? _productService.FormatRentalDate(orderItem.Product, orderItem.RentalEndDateUtc.Value) : string.Empty;
                    orderItemModel.RentalInfo = string.Format(_localizationService.GetResource("Order.Rental.FormattedDate"),
                        rentalStartDate, rentalEndDate);
                }

                //return requests
                //nop3.7 upgrade begin
                //orderItemModel.ReturnRequestIds = _orderService.SearchReturnRequests(0, 0, orderItem.Id, null, 0, int.MaxValue)
                //    .Select(rr => rr.Id).ToList();
                //nop3.7 upgrade end
                //gift cards
                orderItemModel.PurchasedGiftCardIds = _giftCardService.GetGiftCardsByPurchasedWithOrderItemId(orderItem.Id)
                    .Select(gc => gc.Id).ToList();

                if (orderItem.AttributesXml != null &&
                    _invoiceItemAttributeParser.GetInvoiceItemAttributeMapping(orderItem.AttributesXml) != null)
                {
                    orderItemModel.ProductName =
                        _invoiceItemAttributeParser.GetInvoiceItemAttributeMapping(orderItem.AttributesXml).Description;
                }

                model.Items.Add(orderItemModel);
            }
            model.HasDownloadableProducts = hasDownloadableItems;
            #endregion

            return model;
        }

        #endregion

        #endregion

        #region Ajax Methods

        [HttpPost]
        public IActionResult AjaxInvoiceSummary(int invoiceId, int? customerId)
        {
            //We need customer to calculate total with his applied discounts and giftcards
            Customer customer = null;
            if (customerId != null)
            {
                customer = _customerService.GetCustomerById((int)customerId);
            }
            var model = PrepareInvoiceTotalsModel(invoiceId, customer);

            return PartialView(GetViewPath("Shared/_InvoiceSummary"), model);
        }

        [HttpPost]
        public IActionResult AjaxMultiInvoicesSummary(string invoiceIds)
        {
            var invoices = GetOrders(invoiceIds);
            var model = new OrderTotalsModel
            {
                SubTotal = _priceFormatter.FormatPrice(invoices.Sum(o => o.OrderSubtotalExclTax), true, false),
                DisplayTax = invoices.Sum(o => o.OrderTax) > decimal.Zero,
                Tax = _priceFormatter.FormatPrice(invoices.Sum(o => o.OrderTax), true, false),
                OrderTotal = _priceFormatter.FormatPrice(invoices.Sum(o => o.OrderTotal), true, false)
            };

            return PartialView(GetViewPath("Shared/_InvoiceSummary"), model);
        }

        #region Customers

        [HttpPost]
        public IActionResult AjaxCustomersList(int? invoiceId, InvoiceModel model)
        {
            return PartialView("~/Plugins/ShopFast.Misc.Invoices/Views/Shared/_CustomersList.cshtml");
        }

        [NonAction]
        protected string GetCustomerDescriptionString(Customer customer)
        {
            var result = "";
            result += String.Format("{0}: {1}",
                customer.Id, customer.Email);

            if (!String.IsNullOrEmpty(customer.Username) && customer.Username != customer.Email)
                result += String.Format(", {0}",
                    customer.Username);
            if (!String.IsNullOrEmpty(_customerService.GetCustomerFullName(customer)))
                result += String.Format(", {0}",
                    _customerService.GetCustomerFullName(customer));
            if (!String.IsNullOrEmpty(_genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.CompanyAttribute)))
                result += String.Format(", {0}",
                    _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.CompanyAttribute));
            if (!String.IsNullOrEmpty(_genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.PhoneAttribute)))
                result += String.Format(", {0}",
                  _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.PhoneAttribute));

            result += "";
            return result;
        }

        public IActionResult AjaxLoadCustomers(string filter = "")
        {
            var customers = new List<Customer>();
            if (String.IsNullOrEmpty(filter))
            {
                customers.AddRange(_customerService.GetAllCustomers(
                    customerRoleIds: new int[] { _customerService.GetCustomerRoleBySystemName("Registered").Id }
                    ).ToList());
            }
            else
            {
                customers.AddRange(_customerService.GetFilteredCustomers(
                    filter: filter,
                    filterByEmail: true,
                    filterByUsername: true,
                    filterByFirstName: true,
                    filterByLastName: true,
                    filterByCompany: true,
                    filterByPhone: true,
                    customerRoleIds: new int[] { _customerService.GetCustomerRoleBySystemName("Registered").Id }
                    ).ToList());
            }

            customers = customers.Distinct().ToList();
            customers.RemoveAll(c => String.IsNullOrEmpty(c.Email));

            //return Json(customers, JsonRequestBehavior.AllowGet)r;
            //return Json(customers.Select(customer => customer.Email), JsonRequestBehavior.AllowGet);
            return Json(customers.Select(customer => GetCustomerDescriptionString(customer)));
            /*return Json(customers.Select(customer => new CustomerSelectModel
            {
                Id = customer.Id, 
                Description = GetCustomerDescriptionString(customer)
            }), JsonRequestBehavior.AllowGet);*/
        }

        [HttpPost]
        public IActionResult AjaxSetCustomerId(string email)
        {
            var customer = _customerService.GetCustomerByEmail(email);
            if (customer != null)
            {
                return Json(new
                {
                    success = true,
                    customerId = customer.Id
                });
            }
            else
            {
                return Json(new
                {
                    success = false
                });
            }
        }

        [HttpPost]
        public IActionResult AjaxCustomerInfo(int customerId)
        {
            var customerDescription = new CustomerDescriptionModel();
            /*if (customerId != null)
            {
                model.CustomerId = (int)customerId;
                model.Customer = _customerService.GetCustomerById((int)customerId);
            }*/

            var customer = _customerService.GetCustomerById(customerId);
            if (customer == null)
                return new NullJsonResult();

            var model = new CustomerDescriptionModel
            {
                Id = customerId,
                FullName = _customerService.GetCustomerFullName(customer),
                Email = customer.Email,
                Username = customer.Username,
                Company = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.CompanyAttribute),
                Phone = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.PhoneAttribute),
                Gender = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.GenderAttribute),
                DateOfBirth = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.DateOfBirthAttribute),
                StreetAddress = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.StreetAddressAttribute),
                StreetAddress2 = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.StreetAddress2Attribute),
                ZipPostalCode = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.ZipPostalCodeAttribute),
                City = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.CityAttribute),
                //Country = ),
                Country = _genericAttributeService.GetAttribute<int>(customer, NopCustomerDefaults.CountryIdAttribute) > 0 ?
                        _countryService.GetCountryById(_genericAttributeService.GetAttribute<int>(customer, NopCustomerDefaults.CountryIdAttribute)).Name : null,
                StateProvince = _genericAttributeService.GetAttribute<int>(customer, NopCustomerDefaults.StateProvinceIdAttribute) > 0 ?
                        _countryService.GetCountryById(_genericAttributeService.GetAttribute<int>(customer, NopCustomerDefaults.StateProvinceIdAttribute)).Name : null,
                Fax = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.FaxAttribute)
            };

            return PartialView("~/Plugins/ShopFast.Misc.Invoices/Views/Shared/_CustomerInfo.cshtml", model);
        }

        #endregion

        #region Discounts

        [HttpPost] //Done
        public IActionResult AjaxGetAppliedDiscount(int? customerId)
        {
            var model = new InvoiceModel.DiscountBoxModel
            {
                Display = true
            };
            if (customerId != null)
            {
                var customer = _customerService.GetCustomerById((int)customerId);
                if (customer != null)
                {
                    model = GetAppliedDiscount(customer);
                }
            }
            return Json(new
            {
                partial = RenderPartialViewToString("~/Plugins/ShopFast.Misc.Invoices/Views/Shared/_DiscountBox.cshtml",
                    model)
            });
        }

        [HttpPost] //Done
        public IActionResult AjaxApplyDiscountCoupon(string discountcouponcode, int? customerId, int? invoiceId,
            FormCollection form)
        {
            var model = new InvoiceModel.DiscountBoxModel();
            try
            {
                if (customerId == null)
                {
                    throw new Exception(_localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Warning.CustomerNotSet"));
                }
                var customer = _customerService.GetCustomerById((int)customerId);

                if (!String.IsNullOrWhiteSpace(discountcouponcode))
                {
                    var discounts = _discountService.GetAllDiscountsForCaching(couponCode: discountcouponcode, showHidden: true)
                    .Where(d => d.RequiresCouponCode)
                    .ToList();
                    if (discounts.Any())
                    {
                        var userErrors = new List<string>();
                        bool isDiscountValid = discounts.Any(discount =>
                        {
                            var validationResult = _discountService.ValidateDiscount(discount, _workContext.CurrentCustomer, new[] { discountcouponcode });
                            userErrors.AddRange(validationResult.Errors);

                            return validationResult.IsValid;
                        });

                        if (isDiscountValid)
                        {
                            _customerService.ApplyDiscountCouponCode(_workContext.CurrentCustomer, discountcouponcode);
                            model.Message = _localizationService.GetResource("ShoppingCart.DiscountCouponCode.Applied");
                            model.IsApplied = true;
                            model.CurrentCode = discounts.FirstOrDefault().CouponCode;
                        }
                        else
                        {
                            model.Message = _localizationService.GetResource("ShoppingCart.DiscountCouponCode.WrongDiscount");
                            model.IsApplied = false;
                        }
                    }
                }
                else
                {
                    model.Message = _localizationService.GetResource("ShoppingCart.DiscountCouponCode.WrongDiscount");
                    model.IsApplied = false;
                }
            }
            catch (Exception exc)
            {
                model.Message = exc.Message;
                model.CurrentCode = null;
            }

            model.Display = true;
            return Json(new
            {
                value = model.CurrentCode,
                partial = RenderPartialViewToString("~/Plugins/ShopFast.Misc.Invoices/Views/Shared/_DiscountBox.cshtml", model)
            });
        }

        [HttpPost] //Done
        public IActionResult AjaxRemoveDiscountCoupon(int invoiceId, int? customerId)
        {
            if (customerId == null)
                return new NullJsonResult();
            var customer = _customerService.GetCustomerById((int)customerId);
            if (customer != null)
            {
                _genericAttributeService.SaveAttribute<string>(customer, NopCustomerDefaults.DiscountCouponCodeAttribute, null);
            }

            return Json(new
            {
                partial = RenderPartialViewToString("~/Plugins/ShopFast.Misc.Invoices/Views/Shared/_DiscountBox.cshtml",
                    new InvoiceModel.DiscountBoxModel
                    {
                        Display = true
                    })
            });
        }

        #endregion

        #region GiftCards

        [HttpPost]
        public IActionResult AjaxApplyGiftCard(string giftcardcouponcode, int customerId)
        {
            var model = new InvoiceModel();
            model.GiftCardBox = new InvoiceModel.GiftCardBoxModel();
            if (!String.IsNullOrWhiteSpace(giftcardcouponcode))
            {
                var giftCard = _giftCardService.GetAllGiftCards(giftCardCouponCode: giftcardcouponcode).FirstOrDefault();
                bool isGiftCardValid = giftCard != null && _giftCardService.IsGiftCardValid(giftCard);
                if (isGiftCardValid)
                {
                    var customer = _customerService.GetCustomerById(customerId) ?? _workContext.CurrentCustomer;

                    _customerService.ApplyGiftCardCouponCode(customer, giftcardcouponcode);
                    _customerService.UpdateCustomer(customer);
                    model.GiftCardBox.Message = _localizationService.GetResource("ShoppingCart.GiftCardCouponCode.Applied");
                }
                else
                    model.GiftCardBox.Message = _localizationService.GetResource("ShoppingCart.GiftCardCouponCode.WrongGiftCard");
            }
            else
                model.GiftCardBox.Message = _localizationService.GetResource("ShoppingCart.GiftCardCouponCode.WrongGiftCard");

            model.GiftCardBox.Display = true;
            return Json(new
            {
                value = giftcardcouponcode,
                partial = RenderPartialViewToString("~/Plugins/ShopFast.Misc.Invoices/Views/Shared/_GiftCardBox.cshtml", model)
            });
        }

        [HttpPost] //Done
        public IActionResult AjaxRemoveGiftCard(string giftcardId)
        {
            //get gift card identifier
            int giftCardId = Convert.ToInt32(giftcardId);
            var gc = _giftCardService.GetGiftCardById(giftCardId);
            if (gc != null)
            {
                _customerService.RemoveGiftCardCouponCode(_workContext.CurrentCustomer, gc.GiftCardCouponCode);
                _customerService.UpdateCustomer(_workContext.CurrentCustomer);
            }

            return new NullJsonResult();
        }

        #endregion

        #endregion

        #region InvoicesGridActions       
        public virtual InvoiceGridListModel PrepareInvoiceListModel(InvoiceSearchListModel searchModel, int customerId = 0,
            bool dontShowPaid = false, bool showAll = false)
        {
            if (searchModel == null)
                throw new ArgumentNullException(nameof(searchModel));

            DateTime? startDateValue = (searchModel.StartDate == null) ? null
                            : (DateTime?)_dateTimeHelper.ConvertToUtcTime(searchModel.StartDate.Value, _dateTimeHelper.CurrentTimeZone);

            DateTime? endDateValue = (searchModel.EndDate == null) ? null
                            : (DateTime?)_dateTimeHelper.ConvertToUtcTime(searchModel.EndDate.Value, _dateTimeHelper.CurrentTimeZone).AddDays(1);

            OrderStatus? orderStatus = searchModel.OrderStatusId > 0 ? (OrderStatus?)(searchModel.OrderStatusId) : null;
            PaymentStatus? paymentStatus = searchModel.PaymentStatusId > 0 ? (PaymentStatus?)(searchModel.PaymentStatusId) : null;

            List<Order> invoices;
            //nop3.7 upgrade begin
            if (showAll)
            {
                invoices = _orderService.SearchOrders(storeId: searchModel.StoreId,
                    customerId: customerId,
                    warehouseId: searchModel.WarehouseId,
                    createdFromUtc: startDateValue,
                    createdToUtc: endDateValue,
                    osIds: orderStatus != null ? new List<int>() { (int)orderStatus } : null,
                    psIds: paymentStatus != null ? new List<int>() { (int)paymentStatus } : null,
                    billingEmail: searchModel.BillingEmail).ToList();
            }
            else
            {
                invoices = _orderService.SearchOrdersByGenericAttribute(storeId: searchModel.StoreId,
                    customerId: customerId,
                    warehouseId: searchModel.WarehouseId,
                    createdFromUtc: startDateValue,
                    createdToUtc: endDateValue,
                    os: orderStatus,
                    ps: paymentStatus,
                    billingEmail: searchModel.BillingEmail,
                    key: SystemCustomerAttributeNames.InvoiceType,
                    value: (searchModel.InvoiceType ?? InvoiceType.Invoice).ToString()).ToList();
            }
            //nop3.7 upgrade end

            if (dontShowPaid)
                invoices.RemoveAll(invoice => invoice.PaymentStatus == PaymentStatus.Paid);

            var invoiceListModels = CreateInvoiceListModelList(invoices).ToPagedList(searchModel);

            //Prepare Grid List Model
            var invoicesPagedList = invoices.ToPagedList(searchModel);
            var model = new InvoiceGridListModel().PrepareToGrid(searchModel, invoicesPagedList, () =>
            {
                return invoicesPagedList.Select(invoiceItem => CreateInvoiceListModel(invoiceItem));
            });
            //------------------

            return model;
        }

        [NonAction]
        protected List<InvoiceListModel> CreateInvoiceListModelList(List<Order> invoices)
        {
            return invoices.Select(invoice => new InvoiceListModel
            {
                OrderId = invoice.Id,
                Company = _genericAttributeService.GetAttribute<string>(invoice.Customer, NopCustomerDefaults.CompanyAttribute),
                FullName = _genericAttributeService.GetAttribute<string>(invoice.Customer, NopCustomerDefaults.FirstNameAttribute)
                    + " " + _genericAttributeService.GetAttribute<string>(invoice.Customer, NopCustomerDefaults.LastNameAttribute),
                Amount = _priceFormatter.FormatPrice(invoice.OrderTotal),
                Due = invoice.PaidDateUtc != null
                    ? String.Format(DATETIME_FORMATING_STR, invoice.PaidDateUtc)
                    : "",
                Created = String.Format(DATETIME_FORMATING_STR, invoice.CreatedOnUtc),
                Status = invoice.PaymentStatus.ToString()
            }).ToList();
        }

        [NonAction]
        protected InvoiceListModel CreateInvoiceListModel(Order invoice)
        {
            return new InvoiceListModel()
            {
                OrderId = invoice.Id,
                Company = _genericAttributeService.GetAttribute<string>(invoice.Customer, NopCustomerDefaults.CompanyAttribute),
                FullName = _genericAttributeService.GetAttribute<string>(invoice.Customer, NopCustomerDefaults.FirstNameAttribute)
                    + " " + _genericAttributeService.GetAttribute<string>(invoice.Customer, NopCustomerDefaults.LastNameAttribute),
                Amount = _priceFormatter.FormatPrice(invoice.OrderTotal),
                Due = invoice.PaidDateUtc != null
                    ? String.Format(DATETIME_FORMATING_STR, invoice.PaidDateUtc)
                    : "",
                Created = String.Format(DATETIME_FORMATING_STR, invoice.CreatedOnUtc),
                Status = invoice.PaymentStatus.ToString()
            };
        }

        [HttpPost]
        public IActionResult InvoiceList(InvoiceSearchListModel model, int customerId = 0,
            bool dontShowPaid = false, bool showAll = false)
        {
            try
            {
                var invoiceListModels = PrepareInvoiceListModel(model, customerId = 0,
             dontShowPaid, showAll);

                return Json(invoiceListModels);
            }
            catch (Exception exc)
            {
                _logger.Warning("Invoices: " + exc.Message);
                throw exc;
            }
        }

        [HttpPost]
        public IActionResult ChainedInvoicesList(InvoiceBaseSearchModel searchModel, int invoiceId)
        {
            try
            {
                //DataSourceResult gridModel;
                var model = new InvoiceGridListModel();
                //if (invoiceId != 0)
                //{
                var recurringPayment = _orderService.GetRecurringPaymentByOrderId(invoiceId);

                var invoices = new List<Order>() { recurringPayment.InitialOrder };
                invoices.AddRange(recurringPayment.RecurringPaymentHistory.Select(rph => _orderService.GetOrderById(rph.OrderId)));

                //var invoiceListModels = CreateInvoiceListModelList(invoices);
                
                //Prepare Grid List Model
                var invoicesPagedList = invoices.ToPagedList(searchModel);
                model = new InvoiceGridListModel().PrepareToGrid(searchModel, invoicesPagedList, () =>
                {
                    return invoicesPagedList.Select(invoiceItem => CreateInvoiceListModel(invoiceItem));
                });
                //------------------
                //gridModel = new DataSourceResult
                //{
                //    Data = new PagedList<InvoiceListModel>(invoiceListModels, command.Page - 1, command.PageSize),
                //    Total = invoiceListModels.Count
                //};
                //}
                //else
                //{
                //    gridModel = new DataSourceResult
                //    {
                //        Data = new List<Order>(),
                //        Total = 0
                //    };
                //}
                return Json(model);
            }
            catch (Exception exc)
            {
                _logger.Warning("ChainedInvoicesList: " + exc.Message);
                throw exc;
            }
        }

        [HttpPost]
        public IActionResult InvoicePaymentHistory(InvoiceBaseSearchModel searchModel,int invoiceId)
        {
            try
            {
                //DataSourceResult gridModel;
                var model = new InvoiceGridListModel();
                var invoice = _orderService.GetOrderById(invoiceId);
                //if (invoice != null)
                //{
                var payments = _partialPaymentService.GetOrderPayments(invoice).ToList();

                var invoiceListModels = CreateInvoiceListModelList(payments);                
                //Prepare Grid List Model
                var invoicesPagedList = payments.ToPagedList(searchModel);
                model = new InvoiceGridListModel().PrepareToGrid(searchModel, invoicesPagedList, () =>
                {
                    return invoicesPagedList.Select(invoiceItem => CreateInvoiceListModel(invoiceItem));
                });
                //------------------
                //gridModel = new DataSourceResult
                //{
                //    Data = new PagedList<InvoiceListModel>(invoiceListModels, command.Page - 1, command.PageSize),
                //    Total = invoiceListModels.Count
                //};
                //}
                //else
                //{
                //    gridModel = new DataSourceResult
                //    {
                //        Data = new List<Order>(),
                //        Total = 0
                //    };
                //}
                return Json(model);
            }
            catch (Exception exc)
            {
                _logger.Warning("InvoicePaymentHistory: " + exc.Message);
                throw exc;
            }
        }

        #endregion

        #region InvoiceItemsGridActions

        // Grid com
        //[HttpPost]
        //public IActionResult InvoiceItemsList(DataSourceRequest command, int invoiceId)
        //{
        //    var cart = GetShoppingCartItems(null, invoiceId);
        //    List<InvoiceItemModel> invoiceItemModels = new List<InvoiceItemModel>();
        //    foreach (var cartItem in cart)
        //    {
        //        var iiam = _invoiceItemAttributeParser.GetInvoiceItemAttributeMapping(
        //            cartItem.AttributesXml);
        //        var invoiceItemModel = new InvoiceItemModel
        //        {
        //            Id = cartItem.Id,
        //            InvoiceId = iiam.InvoiceId,
        //            Description = iiam.Description ?? cartItem.Product.Name,
        //            Quantity = cartItem.Quantity,
        //            UnitPrice = cartItem.Product.CustomerEntersPrice
        //                ? cartItem.CustomerEnteredPrice
        //                : cartItem.Product.Price,
        //            Taxable = iiam != null
        //                ? iiam.Taxable
        //                : cartItem.Product.IsTaxExempt
        //        };
        //        //invoiceItemModel.TotalPrice = invoiceItemModel.UnitPrice * invoiceItemModel.Quantity;
        //        decimal orderSubTotalDiscountAmountBase;
        //        List<DiscountForCaching> orderSubTotalAppliedDiscounts;
        //        decimal subTotalWithoutDiscountBase;
        //        decimal subTotalWithDiscountBase;
        //        _invoiceTotalCalculationService.GetInvoiceSubTotal(new List<ShoppingCartItem>() { cartItem }, true,
        //            out orderSubTotalDiscountAmountBase, out orderSubTotalAppliedDiscounts,
        //            out subTotalWithoutDiscountBase, out subTotalWithDiscountBase);
        //        invoiceItemModel.TotalPrice = subTotalWithoutDiscountBase;

        //        invoiceItemModels.Add(invoiceItemModel);
        //    }

        //    var gridModel = new DataSourceResult
        //    {
        //        Data = invoiceItemModels,
        //        Total = invoiceItemModels.Count
        //    };

        //    return Json(gridModel);
        //}

        [HttpPost]
        //public IActionResult InvoiceItemAdd([Bind(Exclude = "ConfigurationRouteValues")] InvoiceItemModel model, int invoiceId)
        public IActionResult InvoiceItemAdd(InvoiceItemModel model, int invoiceId)
        {
            if (model == null)
            {
                model = new InvoiceItemModel();
            }

            var customer = _workContext.CurrentCustomer;
            var invoice = _orderService.GetOrderById(invoiceId);
            if (invoice != null)
            {
                customer = invoice.Customer;
            }

            var product = _productService.GetProductBySku("ShopFast.Plugins.Misc.Invoices.NoPriceProduct");

            try
            {
                var warnings = _invoiceCartService.AddToCartInvoiceItem(customer: customer,
                product: product,
                shoppingCartType: ShoppingCartType.ShoppingCart,
                storeId: _storeContext.CurrentStore.Id,
                customerEnteredPrice: model.UnitPrice,
                quantity: model.Quantity,
                attributesXml: _invoiceItemAttributeParser.AddInvoiceItemAttributes(
                    "",
                    invoice != null ? invoice.Id : 0,
                    model.Description,
                    model.Taxable
                    ),
                automaticallyAddRequiredProductsIfEnabled: false).ToList();

                return Json(warnings);
            }
            catch (Exception exc)
            {
                return Json(new List<string> { exc.Message });
            }
        }

        [HttpDelete]
        //public IActionResult InvoiceItemDelete([Bind(Exclude = "ConfigurationRouteValues")] InvoiceItemModel model, int invoiceId)
        public IActionResult InvoiceItemDelete(InvoiceItemModel model, int invoiceId)
        {
            if (model == null)
            {
                model = new InvoiceItemModel();
            }

            var cart = GetShoppingCartItems(null, invoiceId);

            var cartItem = cart.Find(p => p.Id == model.Id);

            _invoiceCartService.DeleteShoppingCartItem(cartItem);

            return new NullJsonResult();
        }

        [HttpPost]
        //public IActionResult InvoiceItemUpdate([Bind(Exclude = "ConfigurationRouteValues")] InvoiceItemModel model, int invoiceId)
        public IActionResult InvoiceItemUpdate(InvoiceItemModel model, int invoiceId)
        {
            var invoice = _orderService.GetOrderById(invoiceId);

            Customer customer = _workContext.CurrentCustomer;
            if (invoice != null)
            {
                customer = invoice.Customer;
            }

            try
            {
                var warnings = _invoiceCartService.UpdateShoppingCartItem(customer: customer,
                    shoppingCartItemId: model.Id,
                    customerEnteredPrice: model.UnitPrice,
                    quantity: model.Quantity,
                    attributesXml: _invoiceItemAttributeParser.AddInvoiceItemAttributes(
                        "",
                        invoice != null ? invoice.Id : 0,
                        model.Description,
                        model.Taxable
                        )
                    );
                return Json(warnings);
            }
            catch (Exception exc)
            {
                return Json(new List<string> { exc.Message });
            }
        }

        [HttpPost]
        public IActionResult AjaxInvoiceItemCalculateTotal(int quantity, decimal unitPrice, bool taxable)
        {
            var item = new ShoppingCartItem
            {
                Customer = _workContext.CurrentCustomer,
                Quantity = quantity,
                CustomerEnteredPrice = unitPrice,
                AttributesXml = _invoiceItemAttributeParser.AddInvoiceItemAttributes("", 0, "", taxable),
                Product = _productService.GetProductBySku("ShopFast.Plugins.Misc.Invoices.NoPriceProduct")
            };

            decimal orderSubTotalDiscountAmountBase;
            List<DiscountForCaching> orderSubTotalAppliedDiscounts;
            decimal subTotalWithoutDiscountBase;
            decimal subTotalWithDiscountBase;
            _invoiceTotalCalculationService.GetInvoiceSubTotal(new List<ShoppingCartItem>() { item }, true,
                out orderSubTotalDiscountAmountBase, out orderSubTotalAppliedDiscounts,
                out subTotalWithoutDiscountBase, out subTotalWithDiscountBase);

            return Json(subTotalWithoutDiscountBase);
        }

        [HttpPost]
        public IActionResult ProductsList()
        {
            //var products = _productRepository.Table.ToList().FindAll(p => p.CustomerEntersPrice
            //    && !p.Deleted && p.Published && p.Sku != "ShopFast.Plugins.Misc.Invoices.NoPriceProduct"
            //    && p.Sku == "ShopFast.Plugins.Misc.Invoices.InvoiceItemProduct")
            //    .Select(product => new SelectListItem
            //        {
            //            Text = product.Name,
            //            Value = product.Id.ToString()
            //        }).ToList();

            var products = _productRepository.Table.Where(p => p.CustomerEntersPrice
                && !p.Deleted && p.Published && p.Sku != "ShopFast.Plugins.Misc.Invoices.NoPriceProduct"
                && p.Sku == "ShopFast.Plugins.Misc.Invoices.InvoiceItemProduct"
                ).Select(product => new SelectListItem
                {
                    Text = product.Name,
                    Value = product.Id.ToString()
                }).ToList();

            if (products.Count < 1)
            {
                products.Add(new SelectListItem
                {
                    Text = "    ",
                    Value = "    "
                });
            }

            return Json(products);
        }

        #endregion

        #region Methods

        #region Configuration Methods

        [AuthorizeAdmin]
        public IActionResult Configure()
        {
            var model = new ConfigurationModel();


            return View(GetViewPath("Shared/Configure"), model);
        }

        [HttpPost]
        [AuthorizeAdmin]
        [FormValueRequired("save-settings")]
        public IActionResult Configure(ConfigurationModel model)
        {


            return Configure();
        }

        [HttpPost, ActionName("Configure")]
        [AuthorizeAdmin]
        [FormValueRequired("default-settings")]
        public IActionResult DefaultSettings()
        {
            InvoicesPlugin.SetDefaultSettings();
            return Configure();
        }

        #endregion

        #region List/Create/Edit/View

        //nop3.7 upgrade begin
        [AuthorizeAdmin]
        public IActionResult Invoices(NotificationModel notificationModel)
        {
            return List(notificationModel, InvoiceType.Invoice);
        }

        [AuthorizeAdmin]
        public IActionResult Estimates(NotificationModel notificationModel)
        {
            return List(notificationModel, InvoiceType.Estimate);
        }

        [AuthorizeAdmin]
        public IActionResult RecurringInvoices(NotificationModel notificationModel)
        {
            return List(notificationModel, InvoiceType.RecurringInvoice);
        }

        [AuthorizeAdmin]
        protected IActionResult List(NotificationModel notificationModel, InvoiceType invoiceType = InvoiceType.Invoice)
        {
            if (invoiceType == InvoiceType.Payment)
                return Payments(notificationModel);

            //order statuses
            var model = new InvoiceSearchListModel();
            model.AvailableOrderStatuses = OrderStatus.Pending.ToSelectList(false).ToList();
            model.AvailableOrderStatuses.Insert(0, new SelectListItem
            {
                Text =
                    _localizationService.GetResource("Admin.Common.All"),
                Value = "0"
            });

            //payment statuses
            model.AvailablePaymentStatuses = PaymentStatus.Pending.ToSelectList(false).ToList();
            model.AvailablePaymentStatuses.Insert(0, new SelectListItem
            {
                Text =
                    _localizationService.GetResource("Admin.Common.All"),
                Value = "0"
            });

            //shipping statuses
            model.AvailableShippingStatuses = ShippingStatus.NotYetShipped.ToSelectList(false).ToList();
            model.AvailableShippingStatuses.Insert(0, new SelectListItem
            {
                Text =
                    _localizationService.GetResource("Admin.Common.All"),
                Value = "0"
            });

            //stores
            model.AvailableStores.Add(new SelectListItem { Text = _localizationService.GetResource("Admin.Common.All"), Value = "0" });
            foreach (var s in _storeService.GetAllStores())
                model.AvailableStores.Add(new SelectListItem { Text = s.Name, Value = s.Id.ToString() });

            //vendors
            model.AvailableVendors.Add(new SelectListItem { Text = _localizationService.GetResource("Admin.Common.All"), Value = "0" });
            foreach (var v in _vendorService.GetAllVendors(showHidden: true))
                model.AvailableVendors.Add(new SelectListItem { Text = v.Name, Value = v.Id.ToString() });

            //warehouses
            model.AvailableWarehouses.Add(new SelectListItem { Text = _localizationService.GetResource("Admin.Common.All"), Value = "0" });
            foreach (var w in _shippingService.GetAllWarehouses())
                model.AvailableWarehouses.Add(new SelectListItem { Text = w.Name, Value = w.Id.ToString() });

            //a vendor should have access only to orders with his products
            model.IsLoggedInAsVendor = _workContext.CurrentVendor != null;

            model.InvoiceType = invoiceType;

            ShowNotifications(notificationModel);
            ViewBag.Title = _localizationService.GetResource(string.Format("ShopFast.Plugins.Misc.Invoices.{0}s", invoiceType.ToString()));
            return View("~/Plugins/ShopFast.Misc.Invoices/Views/Invoices/List.cshtml", model);
        }
        //nop3.7 upgrade end

        [AuthorizeAdmin]
        public IActionResult Create(NotificationModel notificationModel, InvoiceType invoiceType = InvoiceType.Invoice)
        {
            ClearShoppingCart(null, 0);

            var model = PrepareInvoiceModel(invoiceType: invoiceType);

            ShowNotifications(notificationModel);
            ViewBag.Title = string.Format(_localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Create"),
                _localizationService.GetResource(string.Format("ShopFast.Plugins.Misc.Invoices.{0}", invoiceType.ToString())));
            return View(GetViewPath("Invoices/Edit"), model);
        }

        [HttpPost]
        [AuthorizeAdmin]
        public IActionResult Create(InvoiceModel model, FormCollection form)
        {
            var notificationModel = new NotificationModel();
            try
            {
                if (model.CustomerId == null)
                {
                    throw new Exception(_localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Warning.CustomerNotSet"));
                }
                var customer = _customerService.GetCustomerById((int)model.CustomerId);
                if (customer == null)
                {
                    throw new Exception(_localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Warning.CustomerNotFound"));
                }

                if (customer.BillingAddress == null && !customer.Addresses.Any())
                {
                    throw new Exception(_localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Warning.NoBillingAddressOnCustomer"));
                }

                if (model.IsRecurring)
                {
                    if (model.RecurringCycleLength < 0)
                    {
                        throw new Exception(_localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Warning.CycleLengthNotPositive"));
                    }
                    if (model.RecurringTotalCycles < 0)
                    {
                        throw new Exception(_localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Warning.CycleCountNotPositive"));
                    }
                }

                var cart = GetShoppingCartItems(null, 0);
                foreach (var cartItem in cart)
                {
                    cartItem.Customer = customer;
                }

                var currencyTmp = _currencyService.GetCurrencyById(_genericAttributeService.GetAttribute<int>(customer, NopCustomerDefaults.CurrencyIdAttribute));
                var customerCurrency = (currencyTmp != null && currencyTmp.Published)
                    ? currencyTmp : _workContext.WorkingCurrency;
                var primaryStoreCurrency = _currencyService.GetCurrencyById(_currencySettings.PrimaryStoreCurrencyId);
                decimal customerCurrencyRate = customerCurrency.Rate / primaryStoreCurrency.Rate;

                var invoice = new Order
                {
                    OrderGuid = Guid.NewGuid(),
                    Customer = customer,
                    BillingAddress = customer.BillingAddress ?? customer.Addresses.First(),
                    CreatedOnUtc = DateTime.Parse(model.InvoiceDateStr),
                    PaidDateUtc = DateTime.Parse(model.DueDateStr),
                    StoreId = _storeContext.CurrentStore.Id,
                    ShippingStatus = ShippingStatus.ShippingNotRequired,
                    OrderStatus = OrderStatus.Pending,//(OrderStatus)model.OrderStatusId,
                    PaymentStatus = PaymentStatus.Pending,//(PaymentStatus)model.PaymentStatusId //PaymentStatus.Pending
                    CustomerCurrencyCode = customerCurrency.CurrencyCode,
                    CurrencyRate = customerCurrencyRate,
                    CustomOrderNumber = string.Empty
                };

                invoice.CheckoutAttributesXml = ParseAndSaveCheckoutAttributesExt(cart, form);

                SetOrderItems(invoice, cart);

                SetInvoiceTotals(invoice, cart);

                _orderService.InsertOrder(invoice);

                //generate and set custom order number
                invoice.CustomOrderNumber = _customNumberFormatter.GenerateOrderCustomNumber(invoice);

                model.OrderId = invoice.Id;
                _genericAttributeService.SaveAttribute(invoice, SystemCustomerAttributeNames.InvoiceType, model.InvoiceType);

                UpdateInvoiceItemsAttributes(invoice);
                _orderService.UpdateOrder(invoice);
                ClearShoppingCart(cart: cart);

                if (model.IsRecurring)
                {
                    //Recurring Payment
                    var recurringPayment = new RecurringPayment
                    {
                        CycleLength = model.RecurringCycleLength,
                        CyclePeriod = (RecurringProductCyclePeriod)model.RecurringCyclePeriodId,
                        TotalCycles = model.RecurringTotalCycles,
                        IsActive = true,
                        InitialOrderId = invoice.Id,
                        StartDateUtc = model.RecurringStartDateUtc,
                        CreatedOnUtc = model.RecurringCreatedOnUtc
                    };
                    _orderService.InsertRecurringPayment(recurringPayment);
                }

                notificationModel.SuccessMessages.Add(
                    _localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Success.InvoiceCreated"));
                //SendEmailToCustomer(customer, invoice, "ShopFast.Plugin.Misc.Invoices.InvoiceCreated");
                _eventPublisher.Publish(new InvoiceInserted(invoice));

                ShowNotifications(notificationModel);

                return RedirectToRoute(string.Format("ShopFast.Plugin.Misc.Invoices.{0}s", model.InvoiceType.ToString()));
            }
            catch (Exception exc)
            {
                notificationModel.ErrorMessages.Add(exc.Message);

                if (model.OrderId != 0)
                {
                    return RedirectToRoute("ShopFast.Plugin.Misc.Invoices.Edit", new { notificationModel, model.OrderId });
                }

                PrepareInvoiceModel(model, invoiceType: model.InvoiceType);
                ShowNotifications(notificationModel);
                return View(GetViewPath("Invoices/Edit"), model);
            }
        }

        [AuthorizeAdmin]
        public IActionResult Edit(NotificationModel notificationModel, int? id = null)
        {
            var invoice = _orderService.GetOrderById(id.GetValueOrDefault());
            if (invoice == null)
                return new StatusCodeResult((int)HttpStatusCode.NotFound);
            //return RedirectToAction("List");
            ClearShoppingCart(null, id);

            UpdateInvoiceItemsAttributes(invoice);
            FillShoppingCartWithInvoiceItems(invoice);

            var model = PrepareInvoiceModel(invoice: invoice);

            ShowNotifications(notificationModel);
            ViewBag.Title = string.Format(_localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Edit"),
                _localizationService.GetResource(string.Format("ShopFast.Plugins.Misc.Invoices.{0}", model.InvoiceType.ToString())));
            return View(GetViewPath("Invoices/Edit"), model);
        }

        [HttpPost]
        [AuthorizeAdmin]
        public IActionResult Edit(InvoiceModel model, FormCollection form)
        {
            var notificationModel = new NotificationModel();
            try
            {
                if (model.CustomerId == null)
                {
                    throw new Exception(_localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Warning.CustomerNotSet"));
                }
                var customer = _customerService.GetCustomerById((int)model.CustomerId);
                if (customer == null)
                {
                    throw new Exception(_localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Warning.CustomerNotFound"));
                }

                if (customer.BillingAddress == null && !customer.Addresses.Any())
                {
                    throw new Exception(_localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Warning.NoBillingAddressOnCustomer"));
                }

                Order invoice = _orderService.GetOrderById(model.OrderId);

                var cart = GetShoppingCartItems(null, invoice.Id);
                foreach (var cartItem in cart)
                {
                    cartItem.Customer = customer;
                }

                invoice.CreatedOnUtc = DateTime.Parse(model.InvoiceDateStr);
                invoice.PaidDateUtc = DateTime.Parse(model.DueDateStr);
                invoice.OrderStatus = (OrderStatus)model.OrderStatusId;
                invoice.PaymentStatus = (PaymentStatus)model.PaymentStatusId;

                SetOrderItems(invoice, cart);

                SetInvoiceTotals(invoice, cart);

                invoice.CheckoutAttributesXml = ParseAndSaveCheckoutAttributesExt(cart, form);

                ClearShoppingCart(invoice.Customer, invoice.Id);

                invoice.Customer = customer;
                invoice.BillingAddress = customer.BillingAddress ?? customer.Addresses.First();

                UpdateInvoiceItemsAttributes(invoice);

                _orderService.UpdateOrder(invoice);

                //Recurring payment
                if (model.IsRecurring)
                {
                    var genericAttrs = _genericAttributeService.GetAttributesForEntity(invoice.Id, "Order")
                        .Where(ga => ga.Key == SystemCustomerAttributeNames.InvoiceType).ToList();

                    if (genericAttrs.Any(ga => ga.Value == InvoiceType.RecurringInvoice.ToString()))
                    {
                        var recurringPayment = _orderService.GetRecurringPaymentByOrderId(invoice.Id);

                        if (recurringPayment != null)
                        {
                            recurringPayment.CycleLength = model.RecurringCycleLength;
                            recurringPayment.CyclePeriodId = model.RecurringCyclePeriodId;
                            recurringPayment.CreatedOnUtc = model.RecurringCreatedOnUtc;
                            recurringPayment.StartDateUtc = model.RecurringStartDateUtc;
                            recurringPayment.TotalCycles = model.RecurringTotalCycles;

                            _orderService.UpdateRecurringPayment(recurringPayment);
                        }
                    }
                }

                notificationModel.SuccessMessages.Add(
                    _localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Success.InvoiceUpdated"));
                //SendEmailToCustomer(customer, invoice, "ShopFast.Plugin.Misc.Invoices.InvoiceUpdated");
                _eventPublisher.Publish(new InvoiceUpdated(invoice));

                ShowNotifications(notificationModel);
                return RedirectToRoute(string.Format("ShopFast.Plugin.Misc.Invoices.{0}s", model.InvoiceType.ToString()));
            }
            catch (Exception exc)
            {
                notificationModel.ErrorMessages.Add(exc.Message);

                PrepareInvoiceModel(model);
                ShowNotifications(notificationModel);
                return View(GetViewPath("Invoices/Edit"), model);
            }
        }

        [AuthorizeAdmin]
        public IActionResult View(NotificationModel notificationModel, int? id = null)
        {
            var invoice = _orderService.GetOrderById(id.GetValueOrDefault());
            if (invoice == null)
                return new StatusCodeResult((int)HttpStatusCode.NotFound);
            //return RedirectToAction("List");
            ClearShoppingCart(null, id);

            UpdateInvoiceItemsAttributes(invoice);
            FillShoppingCartWithInvoiceItems(invoice);

            var model = PrepareInvoiceModel(invoice: invoice);
            model.Closed = true;

            ShowNotifications(notificationModel);
            ViewBag.Title = string.Format(_localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.View"),
                _localizationService.GetResource(string.Format("ShopFast.Plugins.Misc.Invoices.{0}", model.InvoiceType.ToString())));
            return View(GetViewPath("Invoices/Edit"), model);
        }

        #endregion

        #region Estimates

        public IActionResult AcceptEstimate(int? id)
        {
            var notificationModel = new NotificationModel();

            var customer = _workContext.CurrentCustomer;
            if (customer == null || id == null)  //Customer is not authorized  
            {
                return new StatusCodeResult((int)HttpStatusCode.BadRequest);
            }

            var estimate = _orderService.GetOrderById((int)id);
            if (estimate == null || (estimate.Customer != customer
                && !customer.IsAdmin()))  //This estimate is declared to current authorized customer
            {
                return new StatusCodeResult((int)HttpStatusCode.BadRequest);
            }

            var genericAttributes = _genericAttributeService.GetAttributesForEntity(estimate.Id, "Order")
                .Where(p => p.Key == SystemCustomerAttributeNames.InvoiceType && p.Value == "Estimate").ToList();
            if (!genericAttributes.Any()) //This is estimate and not a simple order or invoice
            {
                return new StatusCodeResult((int)HttpStatusCode.BadRequest);
            }

            var genericAttribute = genericAttributes.First();
            genericAttribute.Value = "Invoice";
            _genericAttributeService.UpdateAttribute(genericAttribute);

            try
            {
                //SendEmailToCustomer(estimate.Customer, estimate, "ShopFast.Plugin.Misc.Invoices.InvoiceCreated");
                _eventPublisher.Publish(new InvoiceInserted(estimate));
            }
            catch (Exception exc)
            {
                notificationModel.ErrorMessages.Add(exc.Message);
            }

            if (customer.IsAdmin())
            {
                notificationModel.SuccessMessages.Add(
                    _localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Success.EstimateAccepted"));
                return RedirectToRoute("ShopFast.Plugin.Misc.Invoices.Invoices", new { notificationModel });
            }
            else
            {
                return RedirectToRoute("CustomerProfile");
            }
        }

        #endregion

        #region Recurring Invoices

        [NonAction]
        protected RecurringPayment GetRecurringPayment(int invoiceId)
        {
            var invoice = _orderService.GetOrderById(invoiceId);
            var recurringPayments = _orderService.SearchRecurringPayments(invoice.StoreId, invoice.CustomerId,
                        invoice.Id, null, 0, 1);

            RecurringPayment recurringPayment = recurringPayments.Any() ? recurringPayments.First() : null;
            if (recurringPayment == null)
            {

            }

            return recurringPayment;
        }

        //[HttpPost]
        public IActionResult ProcessNextRecurringInvoice(int id)
        {
            var notificationModel = new NotificationModel();
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageRecurringPayments))
            {
                //ErrorNotification(_localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Error.PermissionDenied"));
                notificationModel.ErrorMessages.Add(_localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Error.PermissionDenied"));
                return RedirectToRoute("ShopFast.Plugin.Misc.Invoices.RecurringInvoices");
            }

            var payment = _orderService.GetRecurringPaymentByOrderId(id);
            if (payment == null)
            {
                //ErrorNotification(_localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Error.RecurringPaymentNotFound"));
                notificationModel.ErrorMessages.Add(_localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Error.RecurringPaymentNotFound"));
                return Edit(notificationModel, id);
            }

            try
            {
                _orderProcessingService.ProcessNextRecurringPayment(payment);
                var newInvoice = _orderService.GetOrderById(payment.RecurringPaymentHistory.Last().OrderId);
                //_genericAttributeService.SaveAttribute(newInvoice, SystemCustomerAttributeNames.InvoiceType, "Recurring");

                notificationModel.SuccessMessages.Add(
                    _localizationService.GetResource("Admin.RecurringPayments.NextPaymentProcessed"));

                return Edit(notificationModel, newInvoice.Id);
            }
            catch (Exception exc)
            {
                //error
                //ErrorNotification(exc, false);
                notificationModel.ErrorMessages.Add(exc.Message);
                return Edit(notificationModel, id);
            }
        }

        //[HttpPost]
        public IActionResult CancelRecurringInvoice(int id)
        {
            var notificationModel = new NotificationModel();
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageRecurringPayments))
            {
                notificationModel.ErrorMessages.Add(
                    _localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Error.PermissionDenied"));

                return RedirectToRoute("ShopFast.Plugin.Misc.Invoices.RecurringInvoices", new { notificationModel });
            }

            //var payment = _orderService.GetRecurringPaymentById(id);
            var payment = _orderService.GetRecurringPaymentByOrderId(id);
            if (payment == null)
            {
                notificationModel.ErrorMessages.Add(
                    _localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Error.RecurringPaymentNotFound"));

                return RedirectToRoute("ShopFast.Plugin.Misc.Invoices.RecurringInvoices", new { notificationModel });
            }

            try
            {
                notificationModel.ErrorMessages.AddRange(_orderProcessingService.CancelRecurringPayment(payment));
                if (notificationModel.ErrorMessages.Count > 0)
                {
                    //foreach (var error in errors) ErrorNotification(error, false);
                }
                else
                {
                    _genericAttributeService.SaveAttribute(payment.InitialOrder, SystemCustomerAttributeNames.InvoiceType, "Invoice");
                    notificationModel.SuccessMessages.Add(_localizationService.GetResource("Admin.RecurringPayments.Cancelled"));
                }

                return Edit(notificationModel, id);
            }
            catch (Exception exc)
            {
                //error
                notificationModel.ErrorMessages.Add(exc.Message);

                return Edit(notificationModel, id);
            }
        }

        #endregion

        #region Payments
        // Grid com
        //[HttpPost]
        //public IActionResult PaymentList(DataSourceRequest command, InvoiceSearchListModel model)
        //{
        //    try
        //    {
        //        DateTime? startDateValue = (model.StartDate == null) ? null
        //                    : (DateTime?)_dateTimeHelper.ConvertToUtcTime(model.StartDate.Value, _dateTimeHelper.CurrentTimeZone);

        //        DateTime? endDateValue = (model.EndDate == null) ? null
        //                        : (DateTime?)_dateTimeHelper.ConvertToUtcTime(model.EndDate.Value, _dateTimeHelper.CurrentTimeZone).AddDays(1);

        //        OrderStatus? orderStatus = model.OrderStatusId > 0 ? (OrderStatus?)(model.OrderStatusId) : null;
        //        OrderDetailsModel a = new OrderDetailsModel();

        //        //nop3.7 upgrade begin
        //        var invoices = _orderService.SearchOrdersByGenericAttribute(storeId: model.StoreId,
        //            warehouseId: model.WarehouseId,
        //            createdFromUtc: startDateValue,
        //            createdToUtc: endDateValue,
        //            os: orderStatus,
        //            ps: PaymentStatus.Paid,
        //            billingEmail: model.BillingEmail,
        //            //pageIndex: command.Page - 1,
        //            //pageSize: command.PageSize,
        //            key: SystemCustomerAttributeNames.InvoiceType,
        //            value: InvoiceType.Invoice.ToString()).ToList();

        //        invoices.AddRange(_orderService.SearchOrdersByGenericAttribute(storeId: model.StoreId,
        //            warehouseId: model.WarehouseId,
        //            createdFromUtc: startDateValue,
        //            createdToUtc: endDateValue,
        //            os: orderStatus,
        //            ps: PaymentStatus.Pending,
        //            billingEmail: model.BillingEmail,
        //            //pageIndex: command.Page - 1,
        //            //pageSize: command.PageSize,
        //            key: SystemCustomerAttributeNames.InvoiceType,
        //            value: InvoiceType.Invoice.ToString()).ToList());

        //        //Recurring
        //        invoices.AddRange(_orderService.SearchOrdersByGenericAttribute(storeId: model.StoreId,
        //            warehouseId: model.WarehouseId,
        //            createdFromUtc: startDateValue,
        //            createdToUtc: endDateValue,
        //            os: orderStatus,
        //            ps: PaymentStatus.Paid,
        //            billingEmail: model.BillingEmail,
        //            key: SystemCustomerAttributeNames.InvoiceType,
        //            value: InvoiceType.RecurringInvoice.ToString()).ToList());

        //        invoices.AddRange(_orderService.SearchOrdersByGenericAttribute(storeId: model.StoreId,
        //            warehouseId: model.WarehouseId,
        //            createdFromUtc: startDateValue,
        //            createdToUtc: endDateValue,
        //            os: orderStatus,
        //            ps: PaymentStatus.Pending,
        //            billingEmail: model.BillingEmail,
        //            key: SystemCustomerAttributeNames.InvoiceType,
        //            value: InvoiceType.RecurringInvoice.ToString()).ToList());
        //        //nop3.7 upgrade end

        //        var invoiceListModels = invoices.Select(invoice => new InvoiceListModel
        //        {
        //            OrderId = invoice.Id,
        //            Company = _genericAttributeService.GetAttribute<string>(invoice.Customer, NopCustomerDefaults.CompanyAttribute),
        //            FullName = _genericAttributeService.GetAttribute<string>(invoice.Customer, NopCustomerDefaults.FirstNameAttribute)
        //            + " " + _genericAttributeService.GetAttribute<string>(invoice.Customer, NopCustomerDefaults.LastNameAttribute),
        //            Amount = _priceFormatter.FormatPrice(invoice.OrderTotal, true, false),
        //            Due = invoice.PaidDateUtc != null
        //                ? String.Format(DATETIME_FORMATING_STR, invoice.PaidDateUtc)
        //                : "",
        //            Created = String.Format(DATETIME_FORMATING_STR, invoice.CreatedOnUtc),
        //            Status = invoice.PaymentStatus.ToString(),
        //            Paid = invoice.PaymentStatus == PaymentStatus.Paid || invoice.OrderTotal == decimal.Zero
        //        }).ToList();

        //        var gridModel = new DataSourceResult
        //        {
        //            Data = new PagedList<InvoiceListModel>(invoiceListModels, command.Page - 1, command.PageSize),
        //            Total = invoiceListModels.Count
        //        };

        //        return Json(gridModel);
        //    }
        //    catch (Exception exc)
        //    {
        //        _logger.Warning("Invoices: " + exc.Message);
        //        throw exc;
        //    }
        //}

        [NonAction]
        protected string GetInvoiceDescriptionString(Order invoice)
        {
            var result = "";
            result += String.Format("{0}: {1} {2}",
                invoice.Id, invoice.CustomerCurrencyCode, invoice.OrderTotal.ToString("F"));

            if (!String.IsNullOrEmpty(_customerService.GetCustomerFullName(invoice.Customer)))
                result += String.Format(", {0}",
                    _customerService.GetCustomerFullName(invoice.Customer));
            if (!String.IsNullOrEmpty(_genericAttributeService.GetAttribute<string>(invoice.Customer, NopCustomerDefaults.CompanyAttribute)))
                result += String.Format(", {0}",
                    _genericAttributeService.GetAttribute<string>(invoice.Customer, NopCustomerDefaults.CompanyAttribute));

            result += "";
            return result;
        }

        public IActionResult AjaxLoadInvoices(string filter)
        {
            var invoices = new List<Order>();

            if (!String.IsNullOrEmpty(filter))
            {
                var customers = _customerService.GetFilteredCustomers(
                    filterByFirstName: true,
                    filterByLastName: true,
                    filterByCompany: true,
                    filter: filter);

                if (customers.Any())
                {
                    foreach (var customer in customers)
                    {
                        invoices.AddRange(_orderService.SearchOrdersByGenericAttribute(
                            customerId: customer.Id,
                            key: SystemCustomerAttributeNames.InvoiceType,
                            ps: PaymentStatus.Pending,
                            value: "Invoice"));
                    }
                }

                invoices.AddRange(_orderRepository.Table.Where(o => o.Id.ToString().Contains(filter)));
            }
            else
            {
                invoices.AddRange(_orderService.SearchOrdersByGenericAttribute(
                    key: SystemCustomerAttributeNames.InvoiceType,
                    ps: PaymentStatus.Pending,
                    value: "Invoice"));
            }

            invoices = invoices.Distinct().ToList();

            return Json(invoices.Select(GetInvoiceDescriptionString));
        }

        [HttpPost]
        [AuthorizeAdmin]
        public IActionResult AjaxGetInvoiceData(int? invoiceId)
        {
            if (invoiceId == null)
                return new NullJsonResult();

            var invoice = _orderService.GetOrderById((int)invoiceId);
            if (invoice == null)
                return new NullJsonResult();

            var model = PrepareOrderModel(invoice);
            //return Json(invoice.OrderTotal);
            return Json(new
            {
                Amount = invoice.OrderTotal,
                //InvoiceNotesView = RenderPartialViewToString("~/Plugins/ShopFast.Misc.Invoices/Views/InvoiceDetails/_InvoiceDetails.Notes.cshtml", 
                //    model) 
                //url = Url.RouteUrl("ShopFast.Plugin.Misc.Invoices.PayInvoice", new { id = invoice.Id })
                url = Url.RouteUrl("ShopFast.Plugin.Misc.QuickCheckout.AdminOrderQuickCheckout", new { ids = invoice.Id })
            });
        }

        [HttpPost]
        public IActionResult AjaxPaymentInfo(string paymentmethod)
        {
            var paymentMethod = _paymentPluginManager.LoadPluginBySystemName(paymentmethod);
            var paymentInfoModel = _prepareCheckoutModels.PreparePaymentInfoModel(paymentMethod);

            return PartialView("~/Plugins/ShopFast.Misc.Invoices/Views/Payments/PaymentInfo.cshtml", paymentInfoModel);
        }

        [AuthorizeAdmin]
        public IActionResult Payments(NotificationModel notificationModel)
        {
            ViewBag.Title = _localizationService.GetResource("ShopFast.Plugins.Misc.Invoices.Payments.List");

            //order statuses
            var model = new InvoiceSearchListModel();
            model.AvailableOrderStatuses = OrderStatus.Pending.ToSelectList(false).ToList();
            model.AvailableOrderStatuses.Insert(0, new SelectListItem { Text = _localizationService.GetResource("Admin.Common.All"), Value = "0" });

            //payment statuses
            model.AvailablePaymentStatuses = PaymentStatus.Pending.ToSelectList(false).ToList();
            model.AvailablePaymentStatuses.Insert(0, new SelectListItem { Text = _localizationService.GetResource("Admin.Common.All"), Value = "0" });

            //stores
            model.AvailableStores.Add(new SelectListItem { Text = _localizationService.GetResource("Admin.Common.All"), Value = "0" });
            foreach (var s in _storeService.GetAllStores())
                model.AvailableStores.Add(new SelectListItem { Text = s.Name, Value = s.Id.ToString() });

            //a vendor should have access only to orders with his products
            model.IsLoggedInAsVendor = _workContext.CurrentVendor != null;

            ShowNotifications(notificationModel);

            return View("~/Plugins/ShopFast.Misc.Invoices/Views/Payments/List.cshtml", model);
        }

        [AuthorizeAdmin]
        public IActionResult ViewPayment(int? id)
        {
            if (id == null || _orderService.GetOrderById((int)id) == null)
            {
                return new StatusCodeResult((int)HttpStatusCode.BadRequest);
            }

            var invoice = _orderService.GetOrderById((int)id);

            var model = new InvoiceModel
            {
                Amount = invoice.OrderTotal,
                PaymentOrderId = invoice.Id,
                PaymentOrderDescription = GetInvoiceDescriptionString(invoice),
                PaymentMethod = invoice.PaymentMethodSystemName,
                PaymentMethods = _prepareCheckoutModels.PreparePaymentMethodModel(new List<ShoppingCartItem>(), 0).PaymentMethods
                    .Select(pm => new SelectListItem
                    {
                        Text = pm.Name,
                        Value = pm.PaymentMethodSystemName
                    }).ToList(),
                PaymentStatusValues = PaymentStatus.Pending.ToSelectList(),
                Closed = true,
                OrderModel = PrepareOrderModel(invoice)
            };


            return View("~/Plugins/ShopFast.Misc.Invoices/Views/Payments/Edit.cshtml", model);
        }

        [AuthorizeAdmin]
        public IActionResult SearchInvoiceToPay(NotificationModel notificationModel, int? id)
        {
            if (!id.HasValue)
            {
                ShowNotifications(notificationModel);
                return View("~/Plugins/ShopFast.Misc.Invoices/Views/Payments/SelectInvoices.cshtml");
            }

            var invoice = _orderService.GetOrderById(id.GetValueOrDefault());
            if (invoice == null)
                return new NotFoundResult();

            ShowNotifications(notificationModel);
            return RedirectToRoute("ShopFast.Plugin.Misc.QuickCheckout.AdminOrderQuickCheckout", new { ids = invoice.Id });
        }

        [AuthorizeAdmin]
        [HttpPost]
        public IActionResult SearchInvoiceToPay(InvoiceSearchListModel model)
        {
            var invoices = GetOrders(model.InvoiceIds);
            if (invoices.Any())
                return RedirectToRoute("ShopFast.Plugin.Misc.QuickCheckout.AdminOrderQuickCheckout", new { ids = model.InvoiceIds });
            return SearchInvoiceToPay(new NotificationModel { Error = "Select invoices to pay" }, id: null);
        }

        [AuthorizeAdmin]
        public IActionResult DeletePayment(int? id)
        {
            if (id == null || _orderService.GetOrderById((int)id) == null)
            {
                var notificationModel = new NotificationModel();
                notificationModel.ErrorMessages.Add("Payment not found. Please refresh the page.");
                return RedirectToRoute("ShopFast.Plugin.Misc.Invoices.Payments", new { notificationModel });
            }

            _orderService.DeleteOrder(_orderService.GetOrderById((int)id));

            return RedirectToRoute("ShopFast.Plugin.Misc.Invoices.Payments");
        }

        #endregion

        #region Items

        [HttpPost]
        public IActionResult ItemsList(InvoiceBaseSearchModel searchModel)
        {
            var model = new InvoiceItemGridListModel();
            List<InvoiceItemModel> invoiceItemModels = new List<InvoiceItemModel>();

            var products = _productRepository.Table.ToList().FindAll(p =>
                p.Sku == "ShopFast.Plugins.Misc.Invoices.InvoiceItemProduct").Where(p => !p.Deleted).ToList();

            products.ForEach(delegate (Product product)
            {
                invoiceItemModels.Add(new InvoiceItemModel
                {
                    Id = product.Id,
                    Description = product.Name,
                    UnitPrice = product.Price,
                    Taxable = !product.IsTaxExempt
                });
            });

            //Prepare Grid List Model            
            var productsPagedList = products.ToPagedList(searchModel);
            model = new InvoiceItemGridListModel().PrepareToGrid(searchModel, productsPagedList, () =>
            {
                return productsPagedList.Select(product => new InvoiceItemModel
                {
                    Id = product.Id,
                    Description = product.Name,
                    UnitPrice = product.Price,
                    Taxable = !product.IsTaxExempt
                });                
            });
            //------------------

            //var gridModel = new DataSourceResult
            //{
            //    Data = invoiceItemModels,
            //    Total = invoiceItemModels.Count
            //};

            return Json(model);
        }

        [HttpPost]
        public IActionResult CreateItem(InvoiceItemModel model)
        {
            try
            {
                string script = System.IO.File.ReadAllText(_fileProvider.MapPath("~/Plugins/ShopFast.Misc.Invoices/SQL/InvoiceItemInsert.sql"));

                script = script.Replace("%InvoiceItemName%", "N'" + model.Description + "'");
                script = script.Replace("%InvoiceItemPrice%", model.UnitPrice.ToString(CultureInfo.InvariantCulture));
                script = script.Replace("%InvoiceItemIsTaxExempt%", model.Taxable ? "0" : "1");

                IDbContext dbContext = EngineContext.Current.Resolve<IDbContext>();
                dbContext.ExecuteSqlCommand(script);

                return new NullJsonResult();
            }
            catch (Exception exc)
            {
                return Json(new List<string>() { exc.Message });
            }
        }

        [HttpPost]
        public IActionResult UpdateItem(InvoiceItemModel model)
        {
            var product = _productService.GetProductById(model.Id);
            if (product != null)
            {
                product.Name = model.Description;
                product.Price = model.UnitPrice;
                product.IsTaxExempt = !model.Taxable;

                _productService.UpdateProduct(product);
            }

            return new NullJsonResult();
        }

        [HttpDelete]
        public IActionResult DeleteItem(InvoiceItemModel model)
        {
            var product = _productService.GetProductById(model.Id);
            if (product != null)
            {
                _productService.DeleteProduct(product);
            }
            return new NullJsonResult();
        }

        public IActionResult GetItem(int itemId)
        {
            var product = _productService.GetProductById(itemId);
            if (product != null)
            {
                return Json(new
                {
                    Description = product.Name,
                    UnitPrice = product.Price.ToString(CultureInfo.CurrentCulture),
                    Taxable = !product.IsTaxExempt
                });
            }
            else
            {
                return Json(new
                {
                    Description = "",
                    UnitPrice = (decimal)0,
                    Taxable = false
                });
            }
        }

        [AuthorizeAdmin]
        public IActionResult Items()
        {
            ViewBag.Title = "Items";

            return View("~/Plugins/ShopFast.Misc.Invoices/Views/Items/List.cshtml");
        }

        #endregion

        #region Invoice Details

        [HttpsRequirement(SslRequirement.Yes)]
        public IActionResult PrintOrderDetails(int orderId)
        {
            var order = _orderService.GetOrderById(orderId);
            if (order == null || order.Deleted ||
                (_workContext.CurrentCustomer.Id != order.CustomerId && !_workContext.CurrentCustomer.IsAdmin()))
                return AccessDeniedView();

            var model = PrepareOrderDetailsModel(order);
            model.PrintMode = true;

            return View("~/Views/Order/Details.cshtml", model);
        }

        //My account / Order details page / PDF invoice
        public IActionResult GetPdfInvoice(int orderId)
        {
            var order = _orderService.GetOrderById(orderId);
            if (order == null || order.Deleted ||
                (_workContext.CurrentCustomer.Id != order.CustomerId && !_workContext.CurrentCustomer.IsAdmin()))
                return AccessDeniedView();

            var orders = new List<Order>();
            orders.Add(order);
            byte[] bytes;
            using (var stream = new MemoryStream())
            {
                _pdfService.PrintOrdersToPdf(stream, orders, _workContext.WorkingLanguage.Id);
                bytes = stream.ToArray();
            }
            return File(bytes, "application/pdf", string.Format("order_{0}.pdf", order.Id));
        }

        #region Order details

        [NonAction]
        protected IActionResult RedirectToEditing(int invoiceId, NotificationModel notificationModel = null,
            string errorMessage = null, string successMessage = null)
        {
            var invoice = _orderService.GetOrderById(invoiceId);
            var genericAttr = _genericAttributeService.GetAttributesForEntity(invoiceId, "Order")
                    .FirstOrDefault(ga => ga.Key == SystemCustomerAttributeNames.InvoiceType);

            notificationModel = notificationModel ?? new NotificationModel();
            if (!String.IsNullOrEmpty(errorMessage))
                notificationModel.ErrorMessages.Add(errorMessage);
            if (!String.IsNullOrEmpty(successMessage))
                notificationModel.SuccessMessages.Add(successMessage);

            if (invoice != null && genericAttr != null)
            {
                return RedirectToRoute("ShopFast.Plugin.Misc.Invoices.Edit", new { invoiceId, notificationModel });
                /*switch (genericAttr.Value)
                {
                    case "Invoice":
                        return RedirectToRoute("ShopFast.Plugin.Misc.Invoices.EditInvoice",
                            new { invoiceId, notificationModel });
                    case "Estimate":
                        return RedirectToRoute("ShopFast.Plugin.Misc.Invoices.EditEstimate",
                            new { invoiceId, notificationModel });
                    case "Recurring":
                        return RedirectToRoute("ShopFast.Plugin.Misc.Invoices.EditRecurringInvoice",
                            new { invoiceId, notificationModel });
                }*/
            }

            return RedirectToAction("Edit", "Order", new { id = invoiceId });
            //return new HttpStatusCodeResult(HttpStatusCode.NotFound);
        }

        [NonAction]
        protected IActionResult RedirectToList(int invoiceId, NotificationModel notificationModel = null,
            string errorMessage = null, string successMessage = null)
        {
            var invoice = _orderService.GetOrderById(invoiceId);
            var invoiceType = _genericAttributeService.GetAttribute<InvoiceType>(invoice, SystemCustomerAttributeNames.InvoiceType);

            notificationModel = notificationModel ?? new NotificationModel();
            if (!String.IsNullOrEmpty(errorMessage))
                notificationModel.ErrorMessages.Add(errorMessage);
            if (!String.IsNullOrEmpty(successMessage))
                notificationModel.SuccessMessages.Add(successMessage);

            if (invoice != null)
            {
                return RedirectToRoute(string.Format("ShopFast.Plugin.Misc.Invoices.{0}s", invoiceType.ToString()));
                /*switch (genericAttr.Value)
                {
                    case "Invoice":
                        return RedirectToRoute("ShopFast.Plugin.Misc.Invoices.Invoices",
                            new { notificationModel });
                    case "Estimate":
                        return RedirectToRoute("ShopFast.Plugin.Misc.Invoices.Estimates",
                            new { notificationModel });
                    case "Recurring":
                        return RedirectToRoute("ShopFast.Plugin.Misc.Invoices.RecurringInvoices",
                            new { notificationModel });
                }*/
            }

            return RedirectToAction("List", "Order");
            //return new HttpStatusCodeResult(HttpStatusCode.NotFound);
        }

        #region Payments and other order workflow

        [HttpPost, ActionName("EditInvoiceDetails")]
        [FormValueRequired("cancelorder")]
        public IActionResult CancelOrder(int id)
        {
            var order = _orderService.GetOrderById(id);
            if (order == null)
                //No order found with the specified id
                return RedirectToList(id);

            //a vendor does not have access to this functionality
            if (_workContext.CurrentVendor != null)
                return RedirectToEditing(id);

            try
            {
                _orderProcessingService.CancelOrder(order, true);
                return RedirectToEditing(id);
            }
            catch (Exception exc)
            {
                //error
                return RedirectToEditing(id, errorMessage: exc.Message);
            }
        }

        [HttpPost, ActionName("EditInvoiceDetails")]
        [FormValueRequired("captureorder")]
        public IActionResult CaptureOrder(int id)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageOrders))
                return AccessDeniedView();

            var order = _orderService.GetOrderById(id);
            if (order == null)
                //No order found with the specified id
                return RedirectToList(id);

            //a vendor does not have access to this functionality
            if (_workContext.CurrentVendor != null)
                return RedirectToEditing(id);

            try
            {
                return RedirectToEditing(id,
                    new NotificationModel() { ErrorMessages = _orderProcessingService.Capture(order).ToList() });
            }
            catch (Exception exc)
            {
                //error
                return RedirectToEditing(id, errorMessage: exc.Message);
            }

        }

        [HttpPost, ActionName("EditInvoiceDetails")]
        [FormValueRequired("markorderaspaid")]
        public IActionResult MarkOrderAsPaid(int id)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageOrders))
                return AccessDeniedView();

            var order = _orderService.GetOrderById(id);
            if (order == null)
                //No order found with the specified id
                return RedirectToList(id);

            //a vendor does not have access to this functionality
            if (_workContext.CurrentVendor != null)
                return RedirectToEditing(id);

            try
            {
                _orderProcessingService.MarkOrderAsPaid(order);
                return RedirectToEditing(id);
            }
            catch (Exception exc)
            {
                //error
                return RedirectToEditing(id, errorMessage: exc.Message);
            }
        }

        [HttpPost, ActionName("EditInvoiceDetails")]
        [FormValueRequired("refundorderoffline")]
        public IActionResult RefundOrderOffline(int id)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageOrders))
                return AccessDeniedView();

            var order = _orderService.GetOrderById(id);
            if (order == null)
                //No order found with the specified id
                return RedirectToList(id);

            //a vendor does not have access to this functionality
            if (_workContext.CurrentVendor != null)
                return RedirectToEditing(id);

            try
            {
                _orderProcessingService.RefundOffline(order);
                return RedirectToEditing(id);
            }
            catch (Exception exc)
            {
                //error
                return RedirectToEditing(id, errorMessage: exc.Message);
            }
        }

        [HttpPost, ActionName("EditInvoiceDetails")]
        [FormValueRequired("voidorder")]
        public IActionResult VoidOrder(int id)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageOrders))
                return AccessDeniedView();

            var order = _orderService.GetOrderById(id);
            if (order == null)
                //No order found with the specified id
                return RedirectToList(id);

            //a vendor does not have access to this functionality
            if (_workContext.CurrentVendor != null)
                return RedirectToEditing(id);

            try
            {
                return RedirectToEditing(id,
                    new NotificationModel { ErrorMessages = _orderProcessingService.Void(order).ToList() });
            }
            catch (Exception exc)
            {
                //error
                return RedirectToEditing(id, errorMessage: exc.Message);
            }
        }

        [HttpPost, ActionName("EditInvoiceDetails")]
        [FormValueRequired("voidorderoffline")]
        public IActionResult VoidOrderOffline(int id)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageOrders))
                return AccessDeniedView();

            var order = _orderService.GetOrderById(id);
            if (order == null)
                //No order found with the specified id
                return RedirectToList(id);

            //a vendor does not have access to this functionality
            if (_workContext.CurrentVendor != null)
                return RedirectToEditing(id);

            try
            {
                _orderProcessingService.VoidOffline(order);
                return RedirectToEditing(id);
            }
            catch (Exception exc)
            {
                //error
                return RedirectToEditing(id, errorMessage: exc.Message);
            }
        }

        public IActionResult PartiallyRefundOrderPopup(int id, bool online)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageOrders))
                return AccessDeniedView();

            var order = _orderService.GetOrderById(id);
            if (order == null)
                //No order found with the specified id
                return RedirectToList(id);

            //a vendor does not have access to this functionality
            if (_workContext.CurrentVendor != null)
                return RedirectToEditing(id);

            return RedirectToEditing(id);
        }

        [HttpPost]
        [FormValueRequired("partialrefundorder")]
        public IActionResult PartiallyRefundOrderPopup(string btnId, string formId, int id, bool online, OrderModel model)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageOrders))
                return AccessDeniedView();

            var order = _orderService.GetOrderById(id);
            if (order == null)
                //No order found with the specified id
                return RedirectToList(id);

            //a vendor does not have access to this functionality
            if (_workContext.CurrentVendor != null)
                return RedirectToEditing(id);

            try
            {
                decimal amountToRefund = model.AmountToRefund;
                if (amountToRefund <= decimal.Zero)
                    throw new NopException("Enter amount to refund");

                decimal maxAmountToRefund = order.OrderTotal - order.RefundedAmount;
                if (amountToRefund > maxAmountToRefund)
                    amountToRefund = maxAmountToRefund;

                var errors = new List<string>();
                if (online)
                    errors = _orderProcessingService.PartiallyRefund(order, amountToRefund).ToList();
                else
                    _orderProcessingService.PartiallyRefundOffline(order, amountToRefund);

                if (errors.Count == 0)
                {
                    //success
                    ViewBag.RefreshPage = true;
                    ViewBag.btnId = btnId;
                    ViewBag.formId = formId;

                    return RedirectToEditing(id);
                }

                //error
                return RedirectToEditing(id, new NotificationModel() { ErrorMessages = errors.ToList() });
            }
            catch (Exception exc)
            {
                //error
                return RedirectToEditing(id, errorMessage: exc.Message);
            }
        }

        [HttpPost, ActionName("EditInvoiceDetails")]
        [FormValueRequired("btnSaveOrderStatus")]
        public IActionResult ChangeOrderStatus(int id, OrderModel model)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageOrders))
                return AccessDeniedView();

            var order = _orderService.GetOrderById(id);
            if (order == null)
                //No order found with the specified id
                return RedirectToList(id);

            //a vendor does not have access to this functionality
            if (_workContext.CurrentVendor != null)
                return RedirectToEditing(id);

            try
            {
                order.OrderStatusId = model.OrderStatusId;
                _orderService.UpdateOrder(order);
                return RedirectToEditing(id);
            }
            catch (Exception exc)
            {
                //error
                return RedirectToEditing(id, errorMessage: exc.Message);
            }
        }

        #endregion

        #region Edit, delete

        public IActionResult EditInvoiceDetails(int id)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageOrders))
                return AccessDeniedView();

            var order = _orderService.GetOrderById(id);
            if (order == null || order.Deleted)
                //No order found with the specified id
                return RedirectToList(id);

            //a vendor does not have access to this functionality
            if (_workContext.CurrentVendor != null)
                return RedirectToList(id);

            return RedirectToEditing(id);
        }

        [HttpPost]
        public IActionResult DeleteInvoiceDetails(int id)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageOrders))
                return AccessDeniedView();

            var order = _orderService.GetOrderById(id);
            if (order == null)
                //No order found with the specified id
                return RedirectToList(id);

            //a vendor does not have access to this functionality
            if (_workContext.CurrentVendor != null)
                return RedirectToEditing(id);

            _orderProcessingService.DeleteOrder(order);
            return RedirectToList(id);
        }

        [HttpPost, ActionName("EditInvoiceDetails")]
        [FormValueRequired("btnSaveCC")]
        public IActionResult EditCreditCardInfo(int id, OrderModel model)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageOrders))
                return AccessDeniedView();

            var order = _orderService.GetOrderById(id);
            if (order == null)
                //No order found with the specified id
                return RedirectToList(id);

            //a vendor does not have access to this functionality
            if (_workContext.CurrentVendor != null)
                return RedirectToEditing(id);

            if (order.AllowStoringCreditCardNumber)
            {
                string cardType = model.CardType;
                string cardName = model.CardName;
                string cardNumber = model.CardNumber;
                string cardCvv2 = model.CardCvv2;
                string cardExpirationMonth = model.CardExpirationMonth;
                string cardExpirationYear = model.CardExpirationYear;

                order.CardType = _encryptionService.EncryptText(cardType);
                order.CardName = _encryptionService.EncryptText(cardName);
                order.CardNumber = _encryptionService.EncryptText(cardNumber);
                order.MaskedCreditCardNumber = _encryptionService.EncryptText(_paymentService.GetMaskedCreditCardNumber(cardNumber));
                order.CardCvv2 = _encryptionService.EncryptText(cardCvv2);
                order.CardExpirationMonth = _encryptionService.EncryptText(cardExpirationMonth);
                order.CardExpirationYear = _encryptionService.EncryptText(cardExpirationYear);
                _orderService.UpdateOrder(order);
            }

            return RedirectToEditing(id);
        }

        [HttpPost, ActionName("EditInvoiceDetails")]
        [FormValueRequired("btnSaveOrderTotals")]
        public IActionResult EditOrderTotals(int id, OrderModel model)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageOrders))
                return AccessDeniedView();

            var order = _orderService.GetOrderById(id);
            if (order == null)
                //No order found with the specified id
                return RedirectToList(id);

            //a vendor does not have access to this functionality
            if (_workContext.CurrentVendor != null)
                return RedirectToEditing(id);

            order.OrderSubtotalInclTax = model.OrderSubtotalInclTaxValue;
            order.OrderSubtotalExclTax = model.OrderSubtotalExclTaxValue;
            order.OrderSubTotalDiscountInclTax = model.OrderSubTotalDiscountInclTaxValue;
            order.OrderSubTotalDiscountExclTax = model.OrderSubTotalDiscountExclTaxValue;
            order.OrderShippingInclTax = model.OrderShippingInclTaxValue;
            order.OrderShippingExclTax = model.OrderShippingExclTaxValue;
            order.PaymentMethodAdditionalFeeInclTax = model.PaymentMethodAdditionalFeeInclTaxValue;
            order.PaymentMethodAdditionalFeeExclTax = model.PaymentMethodAdditionalFeeExclTaxValue;
            order.TaxRates = model.TaxRatesValue;
            order.OrderTax = model.TaxValue;
            order.OrderDiscount = model.OrderTotalDiscountValue;
            order.OrderTotal = model.OrderTotalValue;
            _orderService.UpdateOrder(order);

            return RedirectToEditing(id);
        }

        #endregion

        #endregion

        #endregion

        #region Base Methods Overload


        #endregion

        #endregion
    }
}