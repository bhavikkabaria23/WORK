﻿
using Nop.Web.Framework.Models;

namespace ShopFast.Plugin.Misc.Invoices.Models
{
    public class InvoiceItemModel : BaseNopModel
    {
        public int Id { get; set; }
        public int InvoiceId { get; set; }
        public string Description { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal TotalPrice { get; set; }
        public bool Taxable { get; set; }

    }
    public partial class InvoiceItemGridListModel : BasePagedListModel<InvoiceItemModel>
    {
    }


}
