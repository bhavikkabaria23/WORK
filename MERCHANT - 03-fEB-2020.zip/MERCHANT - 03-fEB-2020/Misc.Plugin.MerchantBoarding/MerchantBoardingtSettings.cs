﻿using Nop.Core.Configuration;

namespace Misc.Plugin.MerchantBoarding
{
    public class MerchantBoardingtSettings : ISettings
    {
        public bool EnableTINCheck { get; set; }
        public bool EnableBlockScore { get; set; }        
        public TINCheckMode TINCheckMode { get; set; } // 0 -> Test, 1-> Live (Default 0)
        public string TINCheckTestUsername { get; set; }
        public string TINCheckTestPassword { get; set; }
        public string TINCheckLiveUsername { get; set; }
        public string TINCheckLivePassword { get; set; }
    }

    public enum TINCheckMode
    {
        Test = 0,
        Live =1
    }
}
