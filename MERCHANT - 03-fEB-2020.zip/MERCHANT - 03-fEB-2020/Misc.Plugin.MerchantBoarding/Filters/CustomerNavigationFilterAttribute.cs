﻿using System.Web.Mvc;
using Nop.Core.Infrastructure;
using Nop.Web.Models.Customer;
using Nop.Services.Localization;

namespace Misc.Plugin.MerchantBoarding.Filters
{
    public class CustomerNavigationFilterAttribute : ActionFilterAttribute
    {
        #region Fields
        
        private readonly ILocalizationService _localizationService;

        #endregion

        #region Ctor

        public CustomerNavigationFilterAttribute()
        {            
            this._localizationService = EngineContext.Current.Resolve<ILocalizationService>();
        }

        #endregion

        #region Methods
        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            var model = filterContext.Controller.ViewData.Model as CustomerNavigationModel;            
            if (model != null)
            {
                // make a conditioon based on logged in cutomer
                // if current customer id "Merchant" role and if CRM_Completed == 1
                // {
                //      Merchant Fee
                //  }
                // else if "Partner role" and if CRM_Completed == 1
                // {
                //      Partner fee
                // }

                // how to know a Merchant/Partner finish all forms and go to thankl you page??
                // for that when Merchant/Partner go to thank you page and email sent, 
                // after that add a customer generic attribute - "CRM_Completed" to "1" if it is not exist
                // (do not add when updating form, only first time)


                //model.CustomerNavigationItems.Add(new CustomerNavigationItemModel
                //{
                //    RouteName = "Plugin.MerchantBoarding.MerchantFees",
                //    Title = _localizationService.GetResource("Plugin.MerchantBoarding.MerchantFees"),
                //    Tab = CustomerNavigationEnum.VendorInfo,
                //    ItemClass = "MerchantFees"
                //});
                model.CustomerNavigationItems.Add(new CustomerNavigationItemModel
                {
                    RouteName = "Plugin.MerchantBoarding.MerchantPDF",
                    Title = _localizationService.GetResource("Plugin.MerchantBoarding.MerchantPDFTitle"),
                    Tab = CustomerNavigationEnum.VendorInfo,
                    ItemClass = "MerchantPDF"
                });

                //model.CustomerNavigationItems.Add(new CustomerNavigationItemModel
                //{
                //    RouteName = "Plugin.MerchantBoarding.PartnerFees",
                //    Title = _localizationService.GetResource("Plugin.MerchantBoarding.PartnerFees"),
                //    Tab = CustomerNavigationEnum.VendorInfo,
                //    ItemClass = "PartnerFees"
                //});
            }
        }
        #endregion
    }
}