﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TelephoneWeb.Models;

namespace TelephoneWeb.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(string SearchText)
        {
            var telephoneData = new List<TelephoneData>();
            ServiceReference1.TelefonkatalogenPortTypeClient tk = new ServiceReference1.TelefonkatalogenPortTypeClient();
            ServiceReference1.SearchType response = tk.searchxml("qry=" + SearchText);
            if (response.result.hit.Length == 0)
            {

            }
            else
            {
                //textBox2.Text = response.result.hit[0].listing.duplicates[0].listing.etternavn;
                var lst = response.result.hit;
                if (lst != null && lst.Any())
                {
                    telephoneData = lst.ToList().Select(l => new TelephoneData()
                    {
                        Name = l.listing.duplicates[0].listing.fornavn,
                        Address = l.listing.duplicates[0].listing.poststed,
                        Phone = l.listing.duplicates[0].listing.tlfnr,
                        OrgNo = l.listing.duplicates[0].listing.kommunenr,
                    }).ToList();
                }
            }
            return View(telephoneData);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}