﻿using DocuSign.eSign.Api;
using DocuSign.eSign.Client;
using DocuSign.eSign.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TelephoneWeb.Controllers
{

    public class DocusignDemoController : Controller
    {
        private static string envId = "";
        // GET: DocusignDemo
        public ActionResult Index()
        {
            double dd = 12.68976;
            decimal dd1 = Math.Round(Convert.ToDecimal(dd),2);



            var model = new Student();
            model.testdd = dd1;
            return View(model);
        }

        public ActionResult DownloadFile()
        {
            var docusignDocument = GetDocumentFromTemplate(envId);

            if (docusignDocument != Stream.Null)
            {
                var byteBuffer = new byte[docusignDocument.Length];
                docusignDocument.Read(byteBuffer, 0, (int)docusignDocument.Length);

                return File(byteBuffer, "application/pdf","test.pdf");
            }

            return new EmptyResult();
        }

        [HttpPost]
        public ActionResult Index(Student model)
        {
            model = DocuSignGenerate(model);
            return View(model);
        }

        private Student DocuSignGenerate(Student model)
        {
            // initialize client for desired environment (for production change to www)
            ApiClient apiClient = new ApiClient("https://demo.docusign.net/restapi");
            var baseUrl = "https://demo.docusign.net/restapi";
            Configuration.Default.ApiClient = apiClient;

            // configure 'X-DocuSign-Authentication' header
            //string authHeader = string.Concat("{", string.Format("\"Username\":\"{0}\",\"Password\":\"{1}\",\"IntegratorKey\":\"{2}\"",
            //    "jmartin5678@comcast.net", "Qw1declc3!", "1af7df96-1bcc-41ee-8628-2c3185ec9463"), "}");
            string authHeader = string.Concat("{", string.Format("\"Username\":\"{0}\",\"Password\":\"{1}\",\"IntegratorKey\":\"{2}\"",
                "jmartin@evanceprocessing.com", "Qw1declc3!", "0e22f21b-d194-4336-a1fa-8cc9b76eaf45"), "}");
            if (!Configuration.Default.DefaultHeader.Any())
                Configuration.Default.AddDefaultHeader("X-DocuSign-Authentication", authHeader);

            /* ---------- Step 1: Login API ----------  */
            // login call is available in the authentication api 
            AuthenticationApi authApi = new AuthenticationApi();
            LoginInformation loginInfo = authApi.Login();

            // parse the first account ID that is returned (user might belong to multiple accounts)
            var accountId = loginInfo.LoginAccounts[0].AccountId;
            baseUrl = loginInfo.LoginAccounts[0].BaseUrl;

            // Update ApiClient with the new base url from login call
            apiClient = new ApiClient(baseUrl.Substring(0, baseUrl.IndexOf("v") - 1));
            Configuration.Default.ApiClient = apiClient;

            /* ---------- Step 2: Create Envelope API ---------- */
            // create a new envelope which we will use to send the signature request            
            EnvelopeDefinition envDef = new EnvelopeDefinition();
            envDef.EmailSubject = "demo_pdf_subject - " + model.Name1;

            // Add a document to the envelope
            var pdf = Server.MapPath("/Content/Esquire_Bank.pdf");
            byte[] investorPdfFileBytes = System.IO.File.ReadAllBytes(pdf);
            var investorPdfDocument = new Document();
            investorPdfDocument.DocumentBase64 = System.Convert.ToBase64String(investorPdfFileBytes);
            investorPdfDocument.Name = "Esquire_Bank_test";
            investorPdfDocument.DocumentId = "1";
            envDef.Documents = new List<Document>();
            envDef.Documents.Add(investorPdfDocument);

            // Add a recipient to sign the documeent
            Signer signer1 = new Signer();
            signer1.Email = "bhavikkabaria_23@hotmail.com";
            signer1.Name = "Bhavik";
            signer1.RecipientId = "1";
            signer1.ClientUserId = "123";
            // Create a |SignHere| tab somewhere on the document for the recipient to sign
            signer1.Tabs = new Tabs();
            signer1.Tabs.SignHereTabs = new List<SignHere>();
            SignHere signHere = new SignHere();
            signHere.DocumentId = "1";
            signHere.PageNumber = "3";
            signHere.RecipientId = "1";
            signHere.XPosition = "150";
            signHere.YPosition = "650";
            signer1.Tabs.SignHereTabs.Add(signHere);
            var signHere4 = new SignHere();
            signHere4.DocumentId = "1";
            signHere4.PageNumber = "4";
            signHere4.RecipientId = "1";
            signHere4.XPosition = "190";
            signHere4.YPosition = "130";
            signer1.Tabs.SignHereTabs.Add(signHere4);
            var signHere3 = new SignHere();
            signHere3.DocumentId = "1";
            signHere3.PageNumber = "5";
            signHere3.RecipientId = "1";
            signHere3.XPosition = "170";
            signHere3.YPosition = "340";
            signer1.Tabs.SignHereTabs.Add(signHere3);


            Signer signer2 = new Signer();
            signer2.Email = "bhavikkabaria23@gmail.com";
            signer2.Name = "Bhavik Second owner";
            signer2.RecipientId = "2";
            signer2.ClientUserId = "234";

            signer2.Tabs = new Tabs();
            signer2.Tabs.SignHereTabs = new List<SignHere>();
            var signHere2 = new SignHere();
            signHere2.DocumentId = "1";
            signHere2.PageNumber = "3";
            signHere2.RecipientId = "2";
            signHere2.XPosition = "150";
            signHere2.YPosition = "680";
            signer2.Tabs.SignHereTabs.Add(signHere2);
            var signHere5 = new SignHere();
            signHere5.DocumentId = "1";
            signHere5.PageNumber = "4";
            signHere5.RecipientId = "2";
            signHere5.XPosition = "190";
            signHere5.YPosition = "150";
            signer2.Tabs.SignHereTabs.Add(signHere5);

            signer1.EmailNotification = new RecipientEmailNotification();
            signer1.EmailNotification.EmailSubject = "Docusign Request Owner1 (Registered Merchant) Signature";
            signer1.EmailNotification.EmailBody = "Owner 1, please sign the aggrement";

            signer2.EmailNotification = new RecipientEmailNotification();
            signer2.EmailNotification.EmailSubject = "Docusign Request Owner2 Signature";
            signer2.EmailNotification.EmailBody = "Owner 2, please sign the aggrement";


            envDef.Recipients = new Recipients();
            envDef.Recipients.Signers = new List<Signer>();
            envDef.Recipients.Signers.Add(signer1);
            envDef.Recipients.Signers.Add(signer2);

            // set envelope status to "sent" to immediately send the signature request
            envDef.Status = "sent";
            // |EnvelopesApi| contains methods related to creating and sending Envelopes (aka signature requests)
            EnvelopesApi envelopesApi = new EnvelopesApi();
            EnvelopeSummary envelopeSummary = envelopesApi.CreateEnvelope(accountId, envDef);
            envId = envelopeSummary.EnvelopeId;
            RecipientViewRequest viewOptions = new RecipientViewRequest()
            {
                //ReturnUrl = String.Format("{0}/crowdpay/SigningResult?documentType={1}&productId={2}", "https://crowdignition.com/", "SubscriptionAgreementTemplateId", 0),
                ReturnUrl = "http://localhost:63652/",
                ClientUserId = "123",  // must match clientUserId set in step #2!
                AuthenticationMethod = "email",
                UserName = "Bhavik",
                Email = "bhavikkabaria_23@hotmail.com",
            };

            // create the recipient view(aka signing URL)
            //ViewUrl recipientView = envelopesApi.CreateRecipientView(accountId, envelopeSummary.EnvelopeId, viewOptions);
            ViewUrl recipientView = envelopesApi.CreateRecipientView(accountId, envelopeSummary.EnvelopeId, viewOptions);

            model.RecipientViewUrl = recipientView.Url;

            return model;
        }

        public Stream GetDocumentFromTemplate(string templateId)
        {
            try
            {
                ApiClient apiClient = new ApiClient("https://demo.docusign.net/restapi");
                Configuration.Default.ApiClient = apiClient;                

                string authHeader = string.Concat("{", string.Format("\"Username\":\"{0}\",\"Password\":\"{1}\",\"IntegratorKey\":\"{2}\"",
                 "jmartin@evanceprocessing.com", "Qw1declc3!", "0e22f21b-d194-4336-a1fa-8cc9b76eaf45"), "}");
                if (!Configuration.Default.DefaultHeader.Any())
                    Configuration.Default.AddDefaultHeader("X-DocuSign-Authentication", authHeader);

                string accountId = null;

                AuthenticationApi authApi = new AuthenticationApi();
                LoginInformation loginInfo = authApi.Login();

                accountId = loginInfo.LoginAccounts[0].AccountId;

                EnvelopesApi envelopesApi = new EnvelopesApi();

                EnvelopeDocumentsResult docsList = envelopesApi.ListDocuments(accountId, templateId);

                if (docsList.EnvelopeDocuments.Any())
                {
                    var document = envelopesApi.GetDocument(accountId, templateId, docsList.EnvelopeDocuments[0].DocumentId);
                    return document;
                }

                return Stream.Null;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message, e.InnerException);
            }
        }
    }

    public class Student
    {
        public string Name1 { get; set; }
        public string Signature1 { get; set; }
        public string RecipientViewUrl { get; set; }
        [DisplayFormat(DataFormatString = "{0:0.00}", ApplyFormatInEditMode = true)]
        public decimal testdd { get; set; }
        
    }
}