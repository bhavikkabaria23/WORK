﻿using System.Security.Policy;
using System.Web.Mvc;
using System.Web.Routing;
using Autofac;
using Nop.Core.Configuration;
using Nop.Core.Infrastructure;
using Nop.Core.Infrastructure.DependencyManagement;
using Nop.Web.Framework.Mvc.Routes;
using ShopFast.Plugin.Misc.Core.Domain;
using ShopFast.Plugin.Misc.Invoices.Filters;

namespace ShopFast.Plugin.Misc.Invoices
{
    public class DependencyRegistrar : IDependencyRegistrar
    {
        public void Register(ContainerBuilder builder, ITypeFinder typeFinder, NopConfig config)
        {
            FilterProviders.Providers.Add(new FilterProvider());
        }
        public int Order => 1;
    }
}
