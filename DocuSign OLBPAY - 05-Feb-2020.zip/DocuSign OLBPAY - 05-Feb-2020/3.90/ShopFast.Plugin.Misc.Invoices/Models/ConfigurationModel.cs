﻿using Nop.Web.Framework.Mvc;

namespace ShopFast.Plugin.Misc.Invoices.Models
{
    public class ConfigurationModel : BaseNopModel
    {
        public int ActiveStoreScopeConfiguration { get; set; }
    }
}