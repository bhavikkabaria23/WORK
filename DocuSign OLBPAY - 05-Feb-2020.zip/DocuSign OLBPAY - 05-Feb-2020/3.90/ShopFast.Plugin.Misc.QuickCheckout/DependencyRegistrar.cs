﻿using Autofac;
using Autofac.Core;
using Autofac.Integration.Mvc;
using Nop.Core.Configuration;
using Nop.Core.Data;
using Nop.Core.Infrastructure;
using Nop.Core.Infrastructure.DependencyManagement;
using Nop.Data;
using Nop.Web.Framework.Mvc;
using ShopFast.Plugin.Misc.QuickCheckout.Services;

namespace ShopFast.Plugin.Misc.QuickCheckout
{
    public class DependencyRegistrar : IDependencyRegistrar
    {
        //nop3.7 upgrade begin
        public void Register(ContainerBuilder builder, ITypeFinder typeFinder, NopConfig config)
        {
            builder.RegisterType<QuickCheckoutPluginService>().As<QuickCheckoutPluginService>().InstancePerHttpRequest();
        }
        //nop3.7 upgrade end

        public int Order
        {
            get { return 1; }
        }

    }
}
