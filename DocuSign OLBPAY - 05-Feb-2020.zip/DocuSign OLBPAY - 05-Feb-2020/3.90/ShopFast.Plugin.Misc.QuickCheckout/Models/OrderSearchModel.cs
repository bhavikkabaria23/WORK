﻿using Nop.Admin.Models.Orders;
using Nop.Core.Domain.Common;
using Nop.Web.Framework.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Nop.Admin.Models.ShoppingCart;
using Nop.Core.Domain.Shipping;
using Nop.Web.Models.Catalog;
using Nop.Web.Models.Checkout;
using Nop.Web.Framework;
using Nop.Web.Models.Common;
using ShoppingCartModel = Nop.Web.Models.ShoppingCart.ShoppingCartModel;

namespace ShopFast.Plugin.Misc.QuickCheckout.Models
{
    public class OrderSearchModel : BaseNopModel
    {
        public OrderSearchModel()
        {
           Warnings = new List<string>();
        }

        //[RegularExpression("([1-9][0-9]*)", ErrorMessage = "Incorrect Id")]
        public int? OrderId { get; set; }
        public string OrderGuid { get; set; }

        //[DisplayFormat(DataFormatString = "{0:n2}", ApplyFormatInEditMode = true)]
        public decimal? Amount { get; set; }

        public int? CreatedDay { get; set; }
        public int? CreatedMonth { get; set; }
        public int? CreatedYear { get; set; }

        public List<string> Warnings { get; set; }
    }
}
