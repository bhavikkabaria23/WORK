﻿using Nop.Admin.Models.Orders;
using Nop.Core.Domain.Common;
using Nop.Web.Framework.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using Nop.Admin.Models.ShoppingCart;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Shipping;
using Nop.Services.Catalog;
using Nop.Web.Models.Catalog;
using Nop.Web.Models.Checkout;
using Nop.Web.Framework;
using Nop.Web.Models.Common;
using Nop.Web.Models.Order;
using ShopFast.Plugin.Misc.Core.Domain;
using ShoppingCartModel = Nop.Web.Models.ShoppingCart.ShoppingCartModel;

namespace ShopFast.Plugin.Misc.QuickCheckout.Models
{
    public class QuickCheckoutModel : BaseNopModel
    {
        public QuickCheckoutModel()
        {
            ShippingMethods = new List<CheckoutShippingMethodModel.ShippingMethodModel>();
            ExistingBillingAddresses = new List<AddressModel>();
            ExistingShippingAddresses = new List<AddressModel>();

            Items = new List<ShoppingCartModel.ShoppingCartItemModel>();

            Orders = new List<OrderDetailsModel>();

            ShowCheckoutAttributes = false;
            ShowDiscountAndGiftcard = false;
            ShowOrderItems = false;
            ShowPartialPaymentSelector = false;
            ShowPaymentOperationTypes = false;

            Warnings = new List<string>();
            WarningsPayment = new List<string>();
            WarningsShipping = new List<string>();
        }
        
        private ShoppingCartModel ShoppingCart { get; set; }

        public List<OrderDetailsModel> Orders { get; set; } //Only view
        public string OrderIds { get; set; }

        public string GetViewPath(string viewname)
        {
            // todo
            return "~/Plugins/ShopFast.Misc.QuickCheckout/Views/QuickCheckout/" + viewname + ".cshtml";
        }

        public string Layout { get; set; }
        public string Area { get; set; }

        public int? CustomerId { get; set; }

        public AddressModel BillingAddress { get; set; }
        public AddressModel ShippingAddress { get; set; }

        [NopResourceDisplayName("ShopFast.Plugins.Misc.QuickCheckout.ShippingOption")]
        public string Shippingoption { get; set; }
        public GiftCardBoxModel GiftCardBox { get; set; }
        public DiscountBoxModel DiscountBox { get; set; }

        public IList<CheckoutShippingMethodModel.ShippingMethodModel> ShippingMethods { get; set; }
        public IList<CheckoutPaymentMethodModel.PaymentMethodModel> PaymentMethods { get; set; }

        [NopResourceDisplayName("ShopFast.Plugins.Misc.QuickCheckout.ExistingBillingAddresses")]
        public IList<AddressModel> ExistingBillingAddresses { get; set; }
        [NopResourceDisplayName("ShopFast.Plugins.Misc.QuickCheckout.ExistingShippingAddresses")]
        public IList<AddressModel> ExistingShippingAddresses { get; set; }

        public bool ShowProductImages { get; set; }
        public bool IsEditable { get; set; }
        public bool IsArsUa { get; set; }
        public bool IsGuest { get; set; }
        public bool IsShowHint { get; set; }
        public bool IsAllowCustomerToWriteComment { get; set; }
        public bool TermsOfServiceOnOrderConfirmPage { get; set; }
        public bool isPaymentWorkflowRequired { get; set; }
        public bool RequiresShipping { get; set; }
        public bool AllowToSelectTheAddress { get; set; }

        public List<Nop.Web.Models.ShoppingCart.ShoppingCartModel.ShoppingCartItemModel> Items { get; set; }

        [NopResourceDisplayName("ShopFast.Plugins.Misc.QuickCheckout.CustomerComment")]
        public string CustomerComment { get; set; }
        public string MinOrderTotalWarning { get; set; }

        [NopResourceDisplayName("ShopFast.Plugins.Misc.QuickCheckout.UseDifferentAddressForShipping")]
        public bool UseDifferentAddressForShipping { get; set; }
        public bool UseRewardPoints { get; set; }

        public bool ShowDiscountAndGiftcard { get; set; }
        public bool ShowPartialPaymentSelector { get; set; }
        public bool ShowCheckoutAttributes { get; set; }
        public bool ShowOrderItems { get; set; }
        public bool ShowPaymentOperationTypes { get; set; }

        public string RemainingBalance { get; set; }

        public PaymentOperationType PaymentOperationType { get; set; }
        public decimal PartialPaymentAmount { get; set; }
        
        public ShoppingCartModel ShoppingCartModel { get; set; }

        public IList<string> Warnings { get; set; }
        public IList<string> WarningsPayment { get; set; }
        public IList<string> WarningsShipping { get; set; }
        public bool DisplayRewardPoints { get; set; }
        public string RewardPointsAmount { get; set; }
        public int RewardPointsBalance { get; set; }
        [NopResourceDisplayName("ShopFast.Plugins.Misc.QuickCheckout.PaymentMethod")]
        public string PaymentMethodSystemName { get; set; }

        public string CheckoutAttributeInfo { get; set; }
        public IList<ShoppingCartModel.CheckoutAttributeModel> CheckoutAttributes { get; set; }

        public int? OrderId
        {
            get { return Orders.Any() ? Orders.First().Id : (int?)null; }
            set
            {
                var firstOrder = Orders.FirstOrDefault();
                if (firstOrder == null)
                {
                    firstOrder = new OrderDetailsModel();
                    Orders.Add(firstOrder);
                }
                firstOrder.Id = value.GetValueOrDefault();
            }
        }

        public bool MultipleOrders
        {
            get { return Orders.Count() > 1; }
        }

        public bool IsNewOrder
        {
            get { return !Orders.Any(); }
        }

        public void SetOrderIds(string separator = ",")
        {
            OrderIds = string.Empty;
            foreach (var orderDetailsModel in Orders)
            {
                OrderIds += orderDetailsModel.Id.ToString() + separator;
            }
        }

        public class DiscountBoxModel : BaseNopModel
        {
            public DiscountBoxModel()
            {
                AppliedDiscountsWithCodes = new List<DiscountInfoModel>();
                Messages = new List<string>();
            }

            [NopResourceDisplayName("ShoppingCart.DiscountCouponCode")]
            public List<DiscountInfoModel> AppliedDiscountsWithCodes { get; set; }
            public bool Display { get; set; }
            public List<string> Messages { get; set; }
            public bool IsApplied { get; set; }

            public class DiscountInfoModel : BaseNopEntityModel
            {
                public string CouponCode { get; set; }
            }
        }

        public class FixedAdressModel : BaseNopModel
    {
        public string Name { get; set; }
        public bool Selected { get; set; }
    }

    public class GiftCardBoxModel : BaseNopModel
    {
        [NopResourceDisplayName("ShoppingCart.GiftCardCouponCode")]
        public string CurrentGiftCardCode { get; set; }
        public bool Display { get; set; }
        public string Message { get; set; }
    }

    }
}
