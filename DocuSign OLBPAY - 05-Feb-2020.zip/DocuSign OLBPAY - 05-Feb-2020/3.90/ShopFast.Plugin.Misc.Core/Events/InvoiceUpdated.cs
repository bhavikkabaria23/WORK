using Nop.Core;
using Nop.Core.Domain.Orders;

namespace ShopFast.Plugin.Misc.Core.Events
{
    /// <summary>
    /// A container for entities that have been inserted.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class InvoiceUpdated : BaseEntity
    {
        public InvoiceUpdated(Order invoice)
        {
            this.Entity = invoice;
        }

        public Order Entity { get; set; }
    }
}
