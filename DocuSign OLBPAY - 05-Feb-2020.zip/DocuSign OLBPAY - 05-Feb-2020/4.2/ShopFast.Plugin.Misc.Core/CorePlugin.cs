﻿using Nop.Services.Plugins;

namespace ShopFast.Plugin.Misc.Core 
{
    /// <summary>
    /// PLugin
    /// </summary>
    public class CorePlugin : BasePlugin
    {

        public CorePlugin()
        {
        }

        public bool Authenticate()
        {
            return true;
        }

        public override void Install()
        {
            /*IDbContext dbContext = EngineContext.Current.Resolve<IDbContext>();
            dbContext.ExecuteSqlCommand(
                "if COL_LENGTH('Order','ParentOrderId') IS NULL " + 
                "begin " +
                    "ALTER TABLE [dbo].[Order] ADD [ParentOrderId] int NULL " + 
                "end");*/

                
            base.Install();
        }

        
        public override void Uninstall()
        {
            /*IDbContext dbContext = EngineContext.Current.Resolve<IDbContext>();

            dbContext.ExecuteSqlCommand("DROP TABLE [PartialPayment]");*/
            
            base.Uninstall();
        }
    }
}
