﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc;
using System.Collections.Generic;


namespace ShopFast.Plugin.Misc.Invoices.Models
{
    public class CustomerDescriptionModel : BaseNopModel
    {
        public CustomerDescriptionModel()
        {
            this.AvailableStates = new List<SelectListItem>();
            this.AvailableCountries = new List<SelectListItem>();
        }
        public int Id { get; set; }
        public string Email { get; set; }
        public string Username { get; set; }
        public string FullName { get; set; }
        public string Company { get; set; }
        public string Phone { get; set; }
        public string Gender { get; set; }
        public string DateOfBirth { get; set; }
        public string StreetAddress { get; set; }
        public string StreetAddress2 { get; set; }
        public string ZipPostalCode { get; set; }
        public string City { get; set; }
        public bool CountryEnabled { get; set; }
        public string Country{ get; set; }
        public IList<SelectListItem> AvailableCountries { get; set; }
        public  bool StateProvinceEnabled { get; set; }
        public string StateProvince { get; set; }
        public IList<SelectListItem> AvailableStates { get; set; }
        public string Fax { get; set; }
    }
}