﻿using System.Security.Policy;
using Microsoft.AspNetCore.Routing;
using Nop.Web.Framework.Mvc.Routing;
using ShopFast.Plugin.Misc.Core.Domain;
using Nop.Web.Framework.Localization;
using Nop.Web.Framework;

namespace ShopFast.Plugin.Misc.Invoices
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(IRouteBuilder routeBuilder)
        {
            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.Invoices", "Plugin/Invoices/Invoices",
               new { controller = "Invoices", action = "Invoices", area = AreaNames.Admin },null
               );

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.Estimates", "Plugin/Invoices/Estimates",
               new { controller = "Invoices", action = "Estimates", area = AreaNames.Admin },
               null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.RecurringInvoices", "Plugin/Invoices/RecurringInvoices",
               new { controller = "Invoices", action = "RecurringInvoices", area = AreaNames.Admin },
               null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.InvoiceList", "Plugin/Invoices/InvoiceList",
               new { controller = "Invoices", action = "InvoiceList", area = AreaNames.Admin },
               null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.InvoicePaymentHistory", "Plugin/Invoices/InvoicePaymentHistory/{id}",
                new { controller = "Invoices", action = "InvoicePaymentHistory", area = AreaNames.Admin },
                null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.Create", "Plugin/Invoices/Create/{invoiceType}",
               new { controller = "Invoices", action = "Create", area = AreaNames.Admin },
               null);

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.Edit", "Plugin/Invoices/Edit/{id}",
               new { controller = "Invoices", action = "Edit", area = AreaNames.Admin },
               null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.View", "Plugin/Invoices/View/{id}",
               new { controller = "Invoices", action = "View", area = AreaNames.Admin },
               null, dataTokens: new { area = "admin" });

            /*routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.Invoices", "Plugin/Invoices/List/{invoiceType}s",
               new { controller = "Invoices", action = "List", invoiceType = InvoiceType.Invoice },
               null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.Estimates", "Plugin/Invoices/List/{invoiceType}s",
               new { controller = "Invoices", action = "List", invoiceType = InvoiceType.Estimate },
               null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.RecurringInvoices", "Plugin/Invoices/List/{invoiceType}s",
               new { controller = "Invoices", action = "List", invoiceType = InvoiceType.RecurringInvoice },
               null, dataTokens: new { area = "admin" });*/

            //Estimates
            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.AcceptEstimate", "Plugin/Invoices/AcceptEstimate/{id}",
                new { controller = "Invoices", action = "AcceptEstimate", area = AreaNames.Admin });

            //Recurring Invoices            
            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.CancelRecurringInvoice", "Plugin/Invoices/CancelRecurringInvoice/{id}",
                new { controller = "Invoices", action = "CancelRecurringInvoice", area = AreaNames.Admin },
                null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.ProcessNextRecurringInvoice", "Plugin/Invoices/ProcessNextRecurringInvoice/{id}",
                new { controller = "Invoices", action = "ProcessNextRecurringInvoice", area = AreaNames.Admin },
                null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.ChainedInvoicesList", "Plugin/Invoices/ChainedInvoicesList",
               new { controller = "Invoices", action = "ChainedInvoicesList", area = AreaNames.Admin },
               null, dataTokens: new { area = "admin" });

            //Payments
            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.Payments", "Plugin/Invoices/Payments",
               new { controller = "Invoices", action = "Payments", area = AreaNames.Admin },
               null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.PaymentList", "Plugin/Invoices/PaymentList",
               new { controller = "Invoices", action = "PaymentList", area = AreaNames.Admin },
               null, dataTokens: new { area = "admin" });

            /*routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.CreatePayment", "Plugin/Invoices/CreatePayment",
                new { controller = "Invoices", action = "CreatePayment"},
                null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.PayInvoice", "Plugin/Invoices/PayInvoice/{id}",
                new {controller = "Invoices", action = "CreatePayment"},
                null, dataTokens: new { area = "admin" });*/

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.SearchInvoiceToPay", "Plugin/Invoices/SearchInvoiceToPay",
                new { controller = "Invoices", action = "SearchInvoiceToPay", area = AreaNames.Admin },
                null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.GetInvoiceToPay", "Plugin/Invoices/GetInvoiceToPay/{id}",
                new { controller = "Invoices", action = "SearchInvoiceToPay", area = AreaNames.Admin },
                null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.ViewPayment", "Plugin/Invoices/ViewPayment/{id}",
                new { controller = "Invoices", action = "ViewPayment", area = AreaNames.Admin },
                null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.DeletePayment", "Plugin/Invoices/DeletePayment/{id}",
               new { controller = "Invoices", action = "DeletePayment", area = AreaNames.Admin },
               null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.AjaxLoadInvoices", "Plugin/Invoices/Ajax/Invoices/AjaxLoadInvoices",
                new { controller = "Invoices", action = "AjaxLoadInvoices", area = AreaNames.Admin },
                null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.AjaxGetInvoiceData", "Plugin/Invoices/Ajax/Invoices/AjaxGetInvoiceData",
                new { controller = "Invoices", action = "AjaxGetInvoiceData", area = AreaNames.Admin },
                null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.AjaxPaymentInfo", "Plugin/Invoices/Ajax/Payments/AjaxPaymentInfo",
                new { controller = "Invoices", action = "AjaxPaymentInfo", area = AreaNames.Admin },
                null, dataTokens: new { area = "admin" });

            //Ajax
            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.AjaxInvoiceSummary", "Plugin/Invoices/Ajax/Invoices/AjaxInvoiceSummary",
               new { controller = "Invoices", action = "AjaxInvoiceSummary", area = AreaNames.Admin },
               null);

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.AjaxMultiInvoicesSummary",
                "Plugin/Invoices/Ajax/Invoices/AjaxMultiInvoicesSummary",
               new { controller = "Invoices", action = "AjaxMultiInvoicesSummary", area = AreaNames.Admin },
               null, dataTokens: new { area = "admin" });

            //Kendo Grid
            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.InvoiceItemsList", "Plugin/Invoices/InvoiceItemsList",
               new { controller = "Invoices", action = "InvoiceItemsList", area = AreaNames.Admin },
               null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.InvoiceItemAdd", "Plugin/Invoices/InvoiceItemAdd",
               new { controller = "Invoices", action = "InvoiceItemAdd", area = AreaNames.Admin },
               null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.InvoiceItemUpdate", "Plugin/Invoices/InvoiceItemUpdate",
               new { controller = "Invoices", action = "InvoiceItemUpdate", area = AreaNames.Admin },
               null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.InvoiceItemDelete", "Plugin/Invoices/InvoiceItemDelete",
               new { controller = "Invoices", action = "InvoiceItemDelete", area = AreaNames.Admin },
               null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.ProductsList", "Plugin/Invoices/ProductsList",
               new { controller = "Invoices", action = "ProductsList", area = AreaNames.Admin },
               null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.AjaxInvoiceItemCalculateTotal",
                 "Plugin/Invoices/Ajax/Invoices/AjaxInvoiceItemCalculateTotal",
                 new { controller = "Invoices", action = "AjaxInvoiceItemCalculateTotal", area = AreaNames.Admin }
                 ,null);

            //Configuration
            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.DefaultSettings",
               "Plugin/Invoices/Settings/DefaultSettings",
               new { controller = "Invoices", action = "DefaultSettings", area = AreaNames.Admin },
               null, dataTokens: new { area = "admin" });

            //Payment
            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.ProceedPayment",
                 "Plugin/Invoices/ProceedPayment",
                 new { controller = "Invoices", action = "ProceedPayment", area = AreaNames.Admin }
                 ,null);

            //Customer List
            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.AjaxSetCustomerId",
                 "Plugin/Invoices/Ajax/Customer/AjaxSetCustomerId",
                 new { controller = "Invoices", action = "AjaxSetCustomerId", area = AreaNames.Admin },
                 null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.AjaxCustomersList",
               "Plugin/Invoices/Ajax/Customer/AjaxCustomersList",
               new { controller = "Invoices", action = "AjaxCustomersList", area = AreaNames.Admin },
               null);

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.AjaxLoadCustomers",
               "Plugin/Invoices/Ajax/Customer/AjaxLoadCustomers",
               new { controller = "Invoices", action = "AjaxLoadCustomers", area = AreaNames.Admin },
               null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.AjaxCustomerInfo",
               "Plugin/Invoices/Ajax/Customer/AjaxCustomerInfo",
               new { controller = "Invoices", action = "AjaxCustomerInfo", area = AreaNames.Admin },
               null, dataTokens: new { area = "admin" });

            //Discounts
            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.AjaxGetAppliedDiscount",
                 "Plugin/Invoices/Ajax/Discount/AjaxGetAppliedDiscount",
                 new { controller = "Invoices", action = "AjaxGetAppliedDiscount", area = AreaNames.Admin }
                 ,null);

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.AjaxApplyDiscountCoupon",
                 "Plugin/Invoices/Ajax/Discount/AjaxApplyDiscountCoupon",
                 new { controller = "Invoices", action = "AjaxApplyDiscountCoupon", area = AreaNames.Admin }
                 ,null);

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.AjaxRemoveDiscountCoupon",
                 "Plugin/Invoices/Ajax/Discount/AjaxRemoveDiscountCoupon",
                 new { controller = "Invoices", action = "AjaxRemoveDiscountCoupon", area = AreaNames.Admin }
                 ,null);

            //GiftCards
            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.AjaxApplyGiftCard",
                 "Plugin/Invoices/Ajax/GiftCard/AjaxApplyGiftCard",
                 new { controller = "Invoices", action = "AjaxApplyGiftCard", area = AreaNames.Admin }
                 ,null);

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.AjaxRemoveGiftCard",
                 "Plugin/Invoices/Ajax/GiftCard/AjaxRemoveGiftCard",
                 new { controller = "Invoices", action = "AjaxRemoveGiftCard", area = AreaNames.Admin }
                 ,null);

            //Items
            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.Items",
                 "Plugin/Invoices/Items",
                 new { controller = "Invoices", action = "Items", area = AreaNames.Admin },
                 null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.ItemsList",
                 "Plugin/Invoices/ItemsList",
                 new { controller = "Invoices", action = "ItemsList", area = AreaNames.Admin },
                 null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.CreateItem", "Plugin/Invoices/CreateItem",
               new { controller = "Invoices", action = "CreateItem", area = AreaNames.Admin },
               null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.UpdateItem", "Plugin/Invoices/UpdateItem",
               new { controller = "Invoices", action = "UpdateItem", area = AreaNames.Admin },
               null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.DeleteItem", "Plugin/Invoices/DeleteItem",
               new { controller = "Invoices", action = "DeleteItem", area = AreaNames.Admin },null,
               dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.GetItem", "Plugin/Invoices/GetItem",
               new { controller = "Invoices", action = "GetItem", area = AreaNames.Admin },
               null, dataTokens: new { area = "admin" });

            //Print Details / Get PDF
            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.PrintOrderDetails", "Plugin/Invoices/PrintOrderDetails/{id}",
               new { controller = "Invoices", action = "PrintOrderDetails", area = AreaNames.Admin },
               null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.GetPdfInvoice", "Plugin/Invoices/GetPdfInvoice/{id}",
               new { controller = "Invoices", action = "GetPdfInvoice", area = AreaNames.Admin },
               null, dataTokens: new { area = "admin" });

            //Invoice Deatails
            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.InvoiceDetails.CancelOrder",
                "Plugin/Invoices/InvoiceDetails/CancelOrder/{id}",
               new { controller = "Invoices", action = "CancelOrder", area = AreaNames.Admin },
               null, dataTokens: new { area = "admin" });

            routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.InvoiceDetails.Edit",
                "Plugin/Invoices/InvoiceDetails/Edit/{id}",
               new { controller = "Invoices", action = "EditInvoiceDetails", area = AreaNames.Admin },               
               null, dataTokens: new { area = "admin" });
            
            //Base Methods
            //routeBuilder.MapLocalizedRoute("ShopFast.Plugin.Misc.Invoices.Overload.PrintOrder",
            //    "orderdetails/print/{orderId}",
            //    new {controller = "Invoices", action = "PrintOrderDetails", orderId = UrlParameter.Optional},
            //    new[] {"ShopFast.Plugin.Misc.Invoices.Controllers"});
        }
        public int Priority
        {
            get
            {
                return 0;
            }
        }
    }
}
