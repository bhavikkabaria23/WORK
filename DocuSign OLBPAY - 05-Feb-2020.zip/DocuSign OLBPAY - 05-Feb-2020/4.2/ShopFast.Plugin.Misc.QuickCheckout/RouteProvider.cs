﻿

using Microsoft.AspNetCore.Routing;
using Nop.Web.Framework;
using Nop.Web.Framework.Localization;
using Nop.Web.Framework.Mvc.Routing;

namespace ShopFast.Plugin.Misc.QuickCheckout
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(IRouteBuilder routes)
        {
            routes.MapLocalizedRoute("ShopFast.Plugin.Misc.QuickCheckout.QuickCheckout",
                 "QuickCheckout",
                 new { controller = "QuickCheckout", action = "QuickCheckout" }
                );

            routes.MapLocalizedRoute("ShopFast.Plugin.Misc.QuickCheckout.OrderQuickCheckout",
                 "OrderQuickCheckout/{ids}",
                 new { controller = "QuickCheckout", action = "OrderQuickCheckout"}
                 );
            
            routes.MapLocalizedRoute("ShopFast.Plugin.Misc.QuickCheckout.AdminOrderQuickCheckout",
                "AdminOrderQuickCheckout/{ids}",
                new { controller = "QuickCheckout", action = "AdminOrderQuickCheckout", area = AreaNames.Admin }
                
            );

            routes.MapLocalizedRoute("ShopFast.Plugin.Misc.QuickCheckout.AnonymousOrderSearch",
                 "AnonymousOrderSearch",
                 new { controller = "QuickCheckout", action = "AnonymousOrderSearch" }
                 );

            routes.MapLocalizedRoute("ShopFast.Plugin.Misc.QuickCheckout.CryptedMakeAPayment",
                 "CryptedMakeAPayment/{cryptedId}",
                 new { controller = "QuickCheckout", action = "CryptedMakeAPayment" }
                 );

           routes.MapLocalizedRoute("ShopFast.Plugin.Misc.QuickCheckout.AjaxSetPaymentSection",
                "QuickCheckout/Ajax/AjaxSetPaymentSection",
                new { controller = "QuickCheckout", action = "AjaxSetPaymentSection" }
                
           );

           /*routes.MapLocalizedRoute("ShopFast.Plugin.Misc.QuickCheckout.CompleteRedirectionPayment",
               "CompleteRedirectionPayment",
               new { controller = "QuickCheckout", action = "CompleteRedirectionPayment" },
               
            );*/

           /*routes.MapLocalizedRoute("ShopFast.Plugin.Misc.QuickCheckout.AjaxProceedPayment",
              "AjaxProceedPayment",
              new { controller = "QuickCheckout", action = "AjaxProceedPayment" },
              
         );*/

           routes.MapLocalizedRoute("ShopFast.Plugin.Misc.QuickCheckout.AjaxPaymentMethod",
                "QuickCheckout/Ajax/AjaxPaymentMethod",
                new { controller = "QuickCheckout", action = "AjaxPaymentMethod" }
               );

           routes.MapLocalizedRoute("ShopFast.Plugin.Misc.QuickCheckout.AjaxShippingMethod",
                "QuickCheckout/Ajax/AjaxShippingMethod",
                new { controller = "QuickCheckout", action = "AjaxShippingMethod" }
               );

           routes.MapLocalizedRoute("ShopFast.Plugin.Misc.QuickCheckout.AjaxOrderSummary",
               "QuickCheckout/Ajax/AjaxOrderSummary",
               new { controller = "QuickCheckout", action = "AjaxOrderSummary" }
               );

           routes.MapLocalizedRoute("ShopFast.Plugin.Misc.QuickCheckout.AjaxPaymentInfo",
                "QuickCheckout/Ajax/AjaxPaymentInfo",
                new { controller = "QuickCheckout", action = "AjaxPaymentInfo" }
                );

            //Discounts
            routes.MapLocalizedRoute("ShopFast.Plugin.Misc.QuickCheckout.AjaxGetAppliedDiscount",
                 "Plugin/QuickCheckout/Ajax/AjaxGetAppliedDiscount",
                 new { controller = "QuickCheckout", action = "AjaxGetAppliedDiscount" }
                 );

            routes.MapLocalizedRoute("ShopFast.Plugin.Misc.QuickCheckout.AjaxApplyDiscountCoupon",
                 "Plugin/QuickCheckout/Ajax/AjaxApplyDiscountCoupon",
                 new { controller = "QuickCheckout", action = "AjaxApplyDiscountCoupon" }
                 );

            routes.MapLocalizedRoute("ShopFast.Plugin.Misc.QuickCheckout.AjaxRemoveDiscountCoupon",
                 "Plugin/QuickCheckout/Ajax/AjaxRemoveDiscountCoupon",
                 new { controller = "QuickCheckout", action = "AjaxRemoveDiscountCoupon" }
                 );

            //GiftCards
            routes.MapLocalizedRoute("ShopFast.Plugin.Misc.QuickCheckout.AjaxApplyGiftCard",
                 "Plugin/QuickCheckout/Ajax/AjaxApplyGiftCard",
                 new { controller = "QuickCheckout", action = "AjaxApplyGiftCard" }
                 );

            routes.MapLocalizedRoute("ShopFast.Plugin.Misc.QuickCheckout.AjaxRemoveGiftCard",
                 "Plugin/QuickCheckout/Ajax/AjaxRemoveGiftCard",
                 new { controller = "QuickCheckout", action = "AjaxRemoveGiftCard" }
                 );

            
        }
        public int Priority
        {
            get
            {
                return 0;
            }
        }
    }
}
