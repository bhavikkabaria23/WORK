﻿
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;
using Nop.Web.Framework.Models;

namespace ShopFast.Plugin.Misc.Invoices.Models
{
    public class InvoiceItemModel : BaseSearchModel
    {
        public InvoiceItemModel()
        {
            ProductItemList = new List<SelectListItem>();
        }
        public int Id { get; set; }
        public int InvoiceId { get; set; }
        public string Description { get; set; }
        public string DescriptionText { get; set; }
        public int Quantity { get; set; }
        //[DisplayFormat(DataFormatString = "{0:0.00}", ApplyFormatInEditMode = true)]
        public decimal UnitPrice { get; set; }
        public decimal TotalPrice { get; set; }
        public bool Taxable { get; set; }

        public List<SelectListItem> ProductItemList { get; set; }

    }
    public partial class InvoiceItemGridListModel : BasePagedListModel<InvoiceItemModel>
    {
    }


}
