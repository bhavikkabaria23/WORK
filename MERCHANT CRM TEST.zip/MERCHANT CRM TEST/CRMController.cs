﻿using Misc.Plugin.MerchantBoarding.Models;
using Misc.Plugin.MerchantBoarding.OnlineCRM;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace MVCTestWeb.Controllers
{
    public class CRMController : Controller
    {
        private JObject registerForm = new JObject(), merchantForm = new JObject(),
            retrievedData;

        #region Online CRM connection
        private HttpClient httpClient;
        private static string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["ConnectCRM"].ConnectionString;
        #endregion

        private async Task<NoteEntityModel> GetFIleFromNote(string subject, string entityId)
        {
            string fileName = string.Empty;
            string filebase64 = string.Empty;
            NoteEntityModel noteModel = new NoteEntityModel();
            if (!string.IsNullOrEmpty(subject))
            {
                #region Online CRM connection
                httpClient = OnlineCRMHelper.GetHttpClient(
                            connectionString,
                            OnlineCRMHelper.clientId,
                            OnlineCRMHelper.redirectUrl);
                #endregion

                // check firt any file is exist or not based on subject. if exist then just update documentbody
                // else add record in note
                var queryOptions = "?$filter=subject eq '" + subject + "' and _objectid_value eq " + entityId;
                var url = "annotations" + queryOptions;
                HttpResponseMessage noteResponse = await httpClient.GetAsync(
              url);
                JObject retrievedData = new JObject();
                JObject note = new JObject(); // add in annotations
                if (noteResponse.StatusCode == HttpStatusCode.OK) //200
                {
                    retrievedData = JsonConvert.DeserializeObject<JObject>(
                        await noteResponse.Content.ReadAsStringAsync());
                }
                if (retrievedData != null)
                {
                    var jvalue = retrievedData.GetValue("value");
                    if (jvalue != null && jvalue.Count() > 0)
                    {
                        // update note
                        noteModel.filename = Convert.ToString(jvalue[0].SelectToken("filename"));
                        noteModel.documentbody = "data:application/octet-stream;base64," + Convert.ToString(jvalue[0].SelectToken("documentbody"));
                        noteModel.documentbodybase64 = Convert.ToString(jvalue[0].SelectToken("documentbody"));
                    }
                }
            }
            if (!string.IsNullOrEmpty(noteModel.filename) && !string.IsNullOrEmpty(noteModel.documentbody))
            {
                return noteModel;
            }
            return null;
        }
        public static byte[] ReadFully(Stream input)
        {
            byte[] buffer = new byte[16 * 1024];
            using (MemoryStream ms = new MemoryStream())
            {
                int read;
                while ((read = input.Read(buffer, 0, buffer.Length)) > 0)
                {
                    ms.Write(buffer, 0, read);
                }
                return ms.ToArray();
            }
        }
        private List<bool> SetCheckBoxValues(string values, List<bool> boolValues)
        {
            try
            {
                if (!string.IsNullOrEmpty(values))
                {
                    string[] arrValues = values.Split(',');
                    if (arrValues.Length > 0)
                    {
                        for (int i = 0; i < arrValues.Length; i++)
                        {
                            int index;
                            if (int.TryParse(arrValues[i], out index))
                            {
                                boolValues[index - 1] = true;
                            }
                        }
                    }
                }
                return boolValues;
            }
            catch (Exception ex)
            {
                return boolValues;
            }
        }
        private string GetCheckboxValues(List<bool> boolValues)
        {
            string strValues = string.Empty;
            List<int> strValuesArray = new List<int>();
            try
            {
                if (boolValues != null && boolValues.Any())
                {
                    string.Join(",", boolValues.ToArray());
                    for (int i = 0; i < boolValues.Count(); i++)
                    {
                        if (boolValues[i])
                        {
                            strValuesArray.Add(i + 1);                            
                        }
                    }
                    if(strValuesArray.Any())
                    {
                        strValues = String.Join(",", strValuesArray.ToArray());
                    }
                }
                return strValues;
            }
            catch (Exception ex)
            {
                return strValues;
            }
        }
        private async Task<bool> UploadFIleInNote(NoteEntityModel model, int index = 0, string fileName = "", string filebase64 = "")
        {
            try
            {
                #region Online CRM connection
                httpClient = OnlineCRMHelper.GetHttpClient(
                            connectionString,
                            OnlineCRMHelper.clientId,
                            OnlineCRMHelper.redirectUrl);
                #endregion
                if (string.IsNullOrEmpty(filebase64) && string.IsNullOrEmpty(fileName))
                {
                    if (index >= 0) // For Upload file
                    {
                        HttpPostedFileBase filePost = Request.Files[index];
                        if (filePost != null && filePost.ContentLength > 0)
                        {
                            StreamReader reader = new StreamReader(filePost.InputStream, Encoding.UTF8);
                            //byte[] pdfBytes = System.IO.File.ReadAllBytes(pdfFile);
                            byte[] bytedata = ReadFully(filePost.InputStream);

                            //var bytedata = new byte[filePost.InputStream.Length];

                            //testing
                            //string pdfFile = Server.MapPath("Content/Esquire_Bank-bhavikkabaria23@gmail.com-28460.pdf");
                            //byte[] pdfBytes = System.IO.File.ReadAllBytes(pdfFile);
                            //string pdfBase64 = Convert.ToBase64String(pdfBytes);
                            //-------------------


                            filebase64 = Convert.ToBase64String(bytedata);                            
                            fileName = "testing_working.pdf";
                            //testing
                            //filebase64 = pdfBase64;
                            //fileName = "bhavik-test.pdf";
                            //----------------

                            //if (IsAffiliateLogo && AffiliateId > 0)
                            //{
                            //    Stream stream = filePost.InputStream;
                            //    var fileBinary = new byte[filePost.InputStream.Length];
                            //    stream.Read(fileBinary, 0, fileBinary.Length);
                            //    UploadAffiliateLogo(filePost.ContentType, fileName, fileBinary, AffiliateId);
                            //}

                        }
                    }
                    else // for Signature
                    {
                        fileName = model.subject + ".png";
                        filebase64 = model.documentbody;
                    }
                }
                if (!string.IsNullOrEmpty(filebase64) && !string.IsNullOrEmpty(fileName))
                {
                    // check firt any file is exist or not based on subject. if exist then just update documentbody
                    // else add record in note
                    var queryOptions = "?$select=annotationid&$filter=subject eq '" + model.subject + "' and _objectid_value eq " + model.entityId;
                    HttpResponseMessage noteResponse = await httpClient.GetAsync(
                  "annotations" + queryOptions);
                    JObject retrievedData = new JObject();
                    JObject note = new JObject(); // add in annotations
                    if (noteResponse.StatusCode == HttpStatusCode.OK) //200
                    {
                        retrievedData = JsonConvert.DeserializeObject<JObject>(
                            await noteResponse.Content.ReadAsStringAsync());
                    }
                    if (retrievedData != null)
                    {
                        var jvalue = retrievedData.GetValue("value");
                        if (jvalue != null && jvalue.Count() > 0)
                        {
                            // update note
                            string annotationId = jvalue[0].SelectToken("annotationid").ToString();
                            string annotationUri = httpClient.BaseAddress + "annotations(" + annotationId + ")";

                            note.Add("filename", fileName);
                            //note.Add("mimetype", "application/pdf");
                            note.Add("documentbody", filebase64);

                            HttpRequestMessage updateRequestNote = new HttpRequestMessage(
                 new HttpMethod("PATCH"), annotationUri);
                            updateRequestNote.Content = new StringContent(note.ToString(),
                                Encoding.UTF8, "application/json");
                            HttpResponseMessage updateNoteResponse =
                                await httpClient.SendAsync(updateRequestNote);
                            if (updateNoteResponse.StatusCode == HttpStatusCode.NoContent) //204
                            {
                                return true;
                            }
                            else
                            {
                                
                            }
                        }
                        else
                        {
                            // make a new entry in note
                            note.Add("notetext", model.notetext);
                            note.Add("subject", model.subject);
                            note.Add("filename", fileName);
                            //note.Add("mimetype", "application/pdf");
                            note.Add("objectid_" + model.LookupEntity + "@odata.bind", "/" + model.LookupEntity + "s(" + model.entityId + ")");
                            note.Add("documentbody", filebase64);
                            HttpRequestMessage createRequestNote =
                               new HttpRequestMessage(HttpMethod.Post, "annotations");
                            createRequestNote.Content = new StringContent(note.ToString(),
                                Encoding.UTF8, "application/json");
                            HttpResponseMessage createNoteResponse =
                                await httpClient.SendAsync(createRequestNote);
                            if (createNoteResponse.StatusCode == HttpStatusCode.NoContent)  //204
                            {
                                return true;
                            }
                            else
                            {
                                
                            }
                        }
                    }
                }
                return false;
            }
            catch (Exception ex)
            {                
                return false;
            }

        }
        public async Task<BankingInformationModel> BankingInformationCRMGet(string bankName)
        {
            #region Online CRM connection
            httpClient = OnlineCRMHelper.GetHttpClient(
                        connectionString,
                        OnlineCRMHelper.clientId,
                        OnlineCRMHelper.redirectUrl);
            #endregion

            BankingInformationModel model = new BankingInformationModel();

            string CustomerEmail = "bhavikkabaria23@gmail.com";
            #region Merchant Boarding
            if (!string.IsNullOrEmpty(CustomerEmail))
            {
                // Get merchant details from customer email                
                string queryOptions = "?$filter=new_businessemailaddress eq '" + CustomerEmail + "'";
                HttpResponseMessage merchantResponse = await httpClient.GetAsync(
                "new_merchantboardings" + queryOptions);

                if (merchantResponse.StatusCode == HttpStatusCode.OK) //200
                {
                    retrievedData = JsonConvert.DeserializeObject<JObject>(
                        await merchantResponse.Content.ReadAsStringAsync());
                }
                else
                {
                    
                }
                if (retrievedData != null)
                {
                    var jvalue = retrievedData.GetValue("value");
                    if (jvalue != null && jvalue.Count() > 0)
                    {
                        string merchantId = Convert.ToString(jvalue[0].SelectToken("new_merchantboardingid"));
                        model.MerchantId = merchantId;
                        model.MerchantUri = httpClient.BaseAddress + "new_merchantboardings(" + merchantId + ")";

                        model.AccountBankName = Convert.ToString(jvalue[0].SelectToken("new_bankname"));
                        model.Transit = Convert.ToString(jvalue[0].SelectToken("new_transitabarouting"));
                        model.Account = Convert.ToString(jvalue[0].SelectToken("new_accountdda"));
                        model.AccountContact = Convert.ToString(jvalue[0].SelectToken("new_contact"));
                        //model.AccountPhone = Convert.ToString(jvalue[0].SelectToken("new_phone"));
                        model.Owner1Name = string.Join(" ",
                            Convert.ToString(jvalue[0].SelectToken("new_firstname1")),
                            Convert.ToString(jvalue[0].SelectToken("new_middleint")),
                            Convert.ToString(jvalue[0].SelectToken("new_lastname1")),
                            Convert.ToString(jvalue[0].SelectToken("new_title")));
                        model.Owner2Name = string.Join(" ", Convert.ToString(jvalue[0].SelectToken("new_firstname2")),
                            Convert.ToString(jvalue[0].SelectToken("new_middleint1")),
                            Convert.ToString(jvalue[0].SelectToken("new_lastname2")),
                            Convert.ToString(jvalue[0].SelectToken("new_title1")));

                        #region Get File from Note entity
                        NoteEntityModel noteModel = new NoteEntityModel();
                        //BankInfo_BankStatement
                        noteModel = await GetFIleFromNote("BankInfo_BankStatement", merchantId);
                        if (noteModel != null)
                        {
                            model.FileName = noteModel.filename;
                            model.FileBase64 = noteModel.documentbody;
                        }
                        #endregion
                        
                    }
                }
            }
            #endregion            

            model.CustomerEmail = "bhavikkabaria23@gmail.com";
            model.BankName = bankName;
            return model;
        }
        public async Task<bool> BankingInformationCRMPost(FormCollection fc, BankingInformationModel model)
        {
            #region Online CRM connection
            httpClient = OnlineCRMHelper.GetHttpClient(
                        connectionString,
                        OnlineCRMHelper.clientId,
                        OnlineCRMHelper.redirectUrl);
            #endregion

            // Generate json object from model         
            //merchantForm.Add("new_bankname", model.AccountBankName);
            //merchantForm.Add("new_transitabarouting", model.Transit);
            //merchantForm.Add("new_accountdda", model.Account);
            //merchantForm.Add("new_contact", model.AccountContact);
            //merchantForm.Add("new_phone", model.AccountPhone);

            #region File Upload in Note entity
            //BankInfo_BankStatement
            NoteEntityModel noteModel = new NoteEntityModel();
            noteModel.notetext = "Please Upload Your Bank Statement Of Last 3 Months";
            noteModel.subject = "BankInfo_BankStatement";
            noteModel.LookupEntity = "new_merchantboarding";
            noteModel.entityId = model.MerchantId;
            bool noteResult = await UploadFIleInNote(noteModel, 0);
            if (noteResult)
                merchantForm.Add("new_bankinfo_bankstatement", true);
            #endregion

            // not needed now, we just showing checkbox to accept instead signature
            #region Signature Upload in Note entity
            ////BankInfo_SignaturePrincipal1
            //noteModel = new NoteEntityModel();
            //noteModel.notetext = "Signature Principal #1";
            //noteModel.subject = "BankInfo_SignaturePrincipal1";
            //noteModel.LookupEntity = "new_merchantboarding";
            //noteModel.entityId = model.MerchantId;
            //noteModel.documentbody = (!string.IsNullOrEmpty(model.FileBase642) ? model.FileBase642.Replace("data:image/png;base64,", "") : model.FileBase642);
            //noteResult = await UploadFIleInNote(noteModel, -1);
            //if (noteResult)
            //    merchantForm.Add("new_bankinfo_signatureprincipal1", true);

            ////BankInfo_SignaturePrincipal2
            //noteModel = new NoteEntityModel();
            //noteModel.notetext = "Signature Principal #2";
            //noteModel.subject = "BankInfo_SignaturePrincipal2";
            //noteModel.LookupEntity = "new_merchantboarding";
            //noteModel.entityId = model.MerchantId;
            //noteModel.documentbody = (!string.IsNullOrEmpty(model.FileBase643) ? model.FileBase643.Replace("data:image/png;base64,", "") : model.FileBase643);
            //noteResult = await UploadFIleInNote(noteModel, -1);
            //if (noteResult)
            //    merchantForm.Add("new_bankinfo_signatureprincipal2", true);
            #endregion

            //Update Merchat
            if (!string.IsNullOrEmpty(model.MerchantUri))
            {
                HttpRequestMessage updateRequest = new HttpRequestMessage(
               new HttpMethod("PATCH"), model.MerchantUri);
                updateRequest.Content = new StringContent(merchantForm.ToString(),
                    Encoding.UTF8, "application/json");
                HttpResponseMessage updateResponse =
                    await httpClient.SendAsync(updateRequest);
                if (updateResponse.StatusCode == HttpStatusCode.NoContent) //204
                {
                    return true;
                }
                else
                {
                    //throw new CrmHttpResponseException(updateResponse.Content);
                    return false;
                }
            }
            return false;
        }

        public async Task<bool> BusinessInformation2CRMPost(FormCollection fc, BusinessInformation2Model model)
        {
            #region Online CRM connection
            httpClient = OnlineCRMHelper.GetHttpClient(
                        connectionString,
                        OnlineCRMHelper.clientId,
                        OnlineCRMHelper.redirectUrl);
            #endregion

            // Generate json object from model           
            //merchantForm.Add("new_natureofbusiness", model.NatureOfBusiness);
            //if (model.NatureOfBusiness == 3)
            //    merchantForm.Add("new_youurl", model.InternetUrl);
            //if (model.NatureOfBusiness == 14)
            //    merchantForm.Add("new_ifsoexplain2", model.Other);

            //merchantForm.Add("new_seasonalsales", model.IsSeasonalSales);
            //if (model.IsSeasonalSales)
            //{
            //merchantForm.Add("new_pleaseselecthighvolumemonths1", "4,5");
            merchantForm.Add("new_pleaseselecthighvolumemonths1", GetCheckboxValues(model.VolumeMonths));
            //}
            //merchantForm.Add("new_productsorservicesbeingoffered", model.ProductsOrServices);

            //string MerchantUse = GetCheckboxValues(model.MerchantUse);
            //merchantForm.Add("new_equipmentinformationdoesthemerchantuse1", MerchantUse);
            //if (!string.IsNullOrEmpty(MerchantUse) && MerchantUse.Contains("2"))
            //{
            //    merchantForm.Add("new_whatisthepaymentapplicationname", model.PaymentApplicationName);
            //    merchantForm.Add("new_whatistheversionofthepaymentapplicationin", model.PaymentApplicationVersion);
            //}
            //if (!string.IsNullOrEmpty(MerchantUse) && MerchantUse.Contains("1"))
            //{
            //    merchantForm.Add("new_ifterminalwhattype", model.TerminalType);
            //}

            //merchantForm.Add("new_merchantnametoappearonconsumerstatement", model.MerchantNameAppear);

            //string MethodOfAcceptance = GetCheckboxValues(model.MethodOfAcceptance);
            //merchantForm.Add("new_methodofacceptancetotalstoequal1001", MethodOfAcceptance);
            //if (!string.IsNullOrEmpty(MethodOfAcceptance) && MethodOfAcceptance.Contains("1"))
            //{
            //    model.CardSwipevalue = (model.CardSwipevalue ?? string.Empty).Replace("%", "");
            //    decimal CardSwipevalue;
            //    decimal.TryParse(model.CardSwipevalue, out CardSwipevalue);
            //    merchantForm.Add("new_cardswipevaluein", CardSwipevalue);
            //}
            //if (!string.IsNullOrEmpty(MethodOfAcceptance) && MethodOfAcceptance.Contains("2"))
            //{
            //    model.Motovalue = (model.Motovalue ?? string.Empty).Replace("%", "");
            //    decimal Motovalue;
            //    decimal.TryParse(model.Motovalue, out Motovalue);
            //    merchantForm.Add("new_motovaluein", Motovalue);
            //}
            //if (!string.IsNullOrEmpty(MethodOfAcceptance) && MethodOfAcceptance.Contains("3"))
            //{
            //    model.KeyEntervalue = (model.KeyEntervalue ?? string.Empty).Replace("%", "");
            //    decimal KeyEntervalue;
            //    decimal.TryParse(model.KeyEntervalue, out KeyEntervalue);
            //    merchantForm.Add("new_keyenteredvaluein", KeyEntervalue);
            //}
            //if (!string.IsNullOrEmpty(MethodOfAcceptance) && MethodOfAcceptance.Contains("4"))
            //{
            //    model.Internetvalue = (model.Internetvalue ?? string.Empty).Replace("%", "");
            //    decimal Internetvalue;
            //    decimal.TryParse(model.Internetvalue, out Internetvalue);
            //    merchantForm.Add("new_internetvaluein1", Internetvalue);
            //}
            //merchantForm.Add("new_cardsnotaccept", model.new_cardsnotaccept);
            //merchantForm.Add("new_websiteaddress", model.new_websiteaddress);


            //Update Merchat
            model.MerchantUri = "https://securepay.crm.dynamics.com/api/data/v9.0//new_merchantboardings(e57e6ed8-bbfc-e911-a817-000d3a53b4c7)";
            if (!string.IsNullOrEmpty(model.MerchantUri))
            {
                HttpRequestMessage updateRequest = new HttpRequestMessage(
               new HttpMethod("PATCH"), model.MerchantUri);
                updateRequest.Content = new StringContent(merchantForm.ToString(),
                    Encoding.UTF8, "application/json");
                HttpResponseMessage updateResponse =
                    await httpClient.SendAsync(updateRequest);
                if (updateResponse.StatusCode == HttpStatusCode.NoContent) //204
                {
                    return true;
                }
                else
                {
                    //throw new CrmHttpResponseException(updateResponse.Content);
                    return false;
                }
            }
            return false;
        }
        // GET: CRM

        public ActionResult BankingInformation(string bankName)
        {
            BankingInformationModel model = new BankingInformationModel();
            //Task.WaitAll(Task.Run(async () => { model = await BankingInformationCRMGet(bankName); }));

            return View(model);
        }        
        [HttpPost]
        public ActionResult BankingInformation(FormCollection fc, BankingInformationModel model)
        {
            bool result = false;
            //Task.WaitAll(Task.Run(async () => { result = await BankingInformationCRMPost(fc, model); }));
            Task.WaitAll(Task.Run(async () => { result = await BusinessInformation2CRMPost(fc, new BusinessInformation2Model()); }));

            if (result == true)
            {                
                return RedirectToAction("BankingInformation", new { bankName = model.BankName });
            }
            else
            {
                return Content("");
            }
        }
    }
}