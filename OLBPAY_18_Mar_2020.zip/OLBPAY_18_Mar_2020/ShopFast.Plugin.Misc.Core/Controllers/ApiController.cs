﻿using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Core.Domain.Customers;
using Nop.Services.Customers;
using Nop.Services.Orders;
using Nop.Web.Framework.Controllers;

namespace Shopfast.Plugin.Misc.Core.Controllers
{
    public class ShopFastApiController : BasePluginController
    {
        private readonly ICustomerService _customerService;
        private readonly IRewardPointService _rewardPointService;
        private readonly IStoreContext _storeContext;

        public ShopFastApiController(ICustomerService customerService, 
            IRewardPointService rewardPointService, 
            IStoreContext storeContext)
        {
            _customerService = customerService;
            _rewardPointService = rewardPointService;
            _storeContext = storeContext;
        }

        #region Actions
        /// <summary>
        /// Returns RewardPointsBalance in xml format (int)
        /// or "No customer found" message (string)
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        //public IActionResult GetRewardPointsBalance(int id)
        //{
        //    var customer = _customerService.GetCustomerById(id);
        //    if (customer == null)
        //        return new XmlResult("No customer found");
        //    //nop3.7 upgrade begin
        //    return new XmlResult(_rewardPointService.GetRewardPointsBalance(id, _storeContext.CurrentStore.Id));
        //    //nop3.7 upgrade end
        //}


        #endregion

    }
}