﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Xml;
using Nop.Services.Orders;
using ShopFast.Plugin.Misc.Core.Models;

namespace ShopFast.Plugin.Misc.Core.Services
{
    public class TipsCheckoutAttributeParser
    {
        private readonly ICheckoutAttributeService _checkoutAttributeService;
        private const int TipsCheckoutAttributeID = 1;
        private const string RootAttributesName = "Attributes";
        private const string AttributesName = "TipCheckoutAttribute";
        private const string AmountValueName = "CustomAmountValue";
        private const string InterestValueName = "InterestValue";

        public TipsCheckoutAttributeParser(ICheckoutAttributeService checkoutAttributeService)
        {
            this._checkoutAttributeService = checkoutAttributeService;
        }

        public virtual IList<TipModel> ParseInterestValues(string attributesXml)
        {
            var selectedCheckoutAttributeValues = new List<TipModel>();
            var nodes = ParseValues(attributesXml, InterestValueName);
            if (nodes != null)
                foreach (XmlNode node in nodes)
                {
                    XmlNode attAmount = node.Attributes["amount"];
                    if (attAmount != null)
                    {
                        var amount = attAmount.Value;
                        XmlNode attIntrest = node.Attributes["intrest"];
                        if (attIntrest != null)
                        {
                            var intrest = attIntrest.Value;
                            selectedCheckoutAttributeValues.Add(new TipModel
                            {
                                Amount = amount,
                                Intrest = intrest
                            });
                        }                    
                    
                    }
                }
            return selectedCheckoutAttributeValues;

        }

        public virtual IList<string> ParseAmountValues(string attributesXml)
        {
            var selectedCheckoutAttributeValues = new List<string>();
            var nodes = ParseValues(attributesXml, AmountValueName);
            if(nodes!=null)
                foreach (XmlNode node in nodes)
                {
                    XmlNode attNode = node.Attributes["amount"];
                    if (attNode != null)
                        selectedCheckoutAttributeValues.Add(attNode.Value);
                }
            return selectedCheckoutAttributeValues;
        }

        /// <summary>
        /// Gets selected checkout attribute value
        /// </summary>
        /// <param name="attributesXml">Attributes in XML format</param>
        /// <param name="nodeValueName">Node name</param>
        /// <returns>Checkout attribute value</returns>
        private XmlNodeList ParseValues(string attributesXml, string nodeValueName)
        {
            try
            {
                var xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(attributesXml);

                var nodeList1 = xmlDoc.SelectNodes(@"//" + RootAttributesName + "/" + AttributesName);
                foreach (XmlNode node1 in nodeList1)
                {
                    if (node1.Attributes != null && node1.Attributes["ID"] != null)
                    {
                        string str1 = node1.Attributes["ID"].InnerText.Trim();
                        int id;
                        if (int.TryParse(str1, out id))
                        {
                            if (id == TipsCheckoutAttributeID)
                            {
                                return node1.SelectNodes(nodeValueName);
                            }
                        }
                    }
                }
            }
            catch (Exception exc)
            {
                Debug.Write(exc.ToString());
            }
            return null;
        }

        public virtual string AddCheckoutInterestValue(string attributesXml, string interest, string amount)
        {
            return AddCheckoutAttribute(attributesXml, interest, amount, InterestValueName);
        }
        public virtual string AddCheckoutAmountValue(string attributesXml, string value)
        {
            return AddCheckoutAttribute(attributesXml, value, AmountValueName);
        }

        /// <summary>
        /// Adds an attribute
        /// </summary>
        /// <param name="attributesXml">Attributes in XML format</param>
        /// <param name="interest">Intrest</param>
        /// <param name="amount">Custom amount or amount of Intrest in USD</param>
        /// <param name="nodeValueName">XML node name</param>
        /// <returns>Attributes</returns>        
        public string AddCheckoutAttribute(string attributesXml, string interest, string amount, string nodeValueName)
        {
            string result = string.Empty;
            try
            {
                var xmlDoc = new XmlDocument();
                if (String.IsNullOrEmpty(attributesXml))
                {
                    var element1 = xmlDoc.CreateElement(RootAttributesName);
                    xmlDoc.AppendChild(element1);
                }
                else
                {
                    xmlDoc.LoadXml(attributesXml);
                }
                var rootElement = (XmlElement)xmlDoc.SelectSingleNode(@"//" + RootAttributesName);

                XmlElement attributeElement = null;
                //find existing
                var nodeList1 = xmlDoc.SelectNodes(@"//" + RootAttributesName + "/" + AttributesName);
                foreach (XmlNode node1 in nodeList1)
                {
                    if (node1.Attributes != null && node1.Attributes["ID"] != null)
                    {
                        string str1 = node1.Attributes["ID"].InnerText.Trim();
                        int id;
                        if (int.TryParse(str1, out id))
                        {
                            if (id == TipsCheckoutAttributeID)
                            {
                                attributeElement = (XmlElement)node1;
                                break;
                            }
                        }
                    }
                }

                //create new one if not found
                if (attributeElement == null)
                {
                    attributeElement = xmlDoc.CreateElement(AttributesName);
                    attributeElement.SetAttribute("ID", TipsCheckoutAttributeID.ToString());
                    rootElement.AppendChild(attributeElement);
                }
                foreach (XmlNode node in attributeElement.ChildNodes)
                {
                    attributeElement.RemoveChild(node);
                }

                var attributeValueElement = xmlDoc.CreateElement(nodeValueName);
                if (!String.IsNullOrEmpty(interest))
                    attributeValueElement.SetAttribute("intrest", interest);
                attributeValueElement.SetAttribute("amount", amount);
                attributeElement.AppendChild(attributeValueElement);

                result = xmlDoc.OuterXml;
            }
            catch (Exception exc)
            {
                Debug.Write(exc.ToString());
            }
            return result;
        }

        /// <summary>
        /// Adds an attribute
        /// </summary>
        /// <param name="attributesXml">Attributes in XML format</param>
        /// <param name="amount">Custom amount</param>
        /// <param name="nodeValueName">XML tag name</param>
        /// <returns>Attributes</returns>        
        private string AddCheckoutAttribute(string attributesXml, string amount, string nodeValueName)
        {
            return AddCheckoutAttribute(attributesXml, "", amount, nodeValueName);
        }

        public string ClearCheckoutAttributes(string attributesXml)
        {
                        string result = string.Empty;
            try
            {
                var xmlDoc = new XmlDocument();
                if (String.IsNullOrEmpty(attributesXml))
                {

                    var element1 = xmlDoc.CreateElement(RootAttributesName);
                    xmlDoc.AppendChild(element1);
                }
                else
                {
                    xmlDoc.LoadXml(attributesXml);
                }
                var rootElement = (XmlElement) xmlDoc.SelectSingleNode(@"//" + RootAttributesName);
                var nodeList1 = xmlDoc.SelectNodes(@"//" + RootAttributesName + "/CheckoutAttribute");
                foreach (XmlNode node1 in nodeList1)
                {
                    rootElement.RemoveChild(node1);
                }
                result = xmlDoc.OuterXml;
            }
            catch (Exception exc)
            {
                Debug.Write(exc.ToString());
            }
            return result;
        }

    }
}
