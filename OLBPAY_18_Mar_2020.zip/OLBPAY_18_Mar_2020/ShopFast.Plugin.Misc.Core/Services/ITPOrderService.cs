﻿ using System;
using System.Collections.Generic;
 using System.IO;
 using System.Linq;
 using System.Security.Cryptography;
 using System.Text; 
using Nop.Core;
using Nop.Core.Data;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Common;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Core.Domain.Shipping;
using Nop.Services.Catalog;
using Nop.Services.Common;
using Nop.Services.Events;
using Nop.Services.Logging;
using Nop.Services.Orders;
using Nop.Web.Areas.Admin.Models.Catalog;
using Nop.Web.Areas.Admin.Infrastructure.Mapper.Extensions;

namespace ShopFast.Plugin.Misc.Core.Services
{
    /// <summary>
    /// Order service
    /// </summary>
    public partial class ITPOrderService : OrderService, IITPOrderService
    {
        #region Fields

        //private static readonly int PUBLIC_KEY_OLD = 887;

        // This constant string is used as a "salt" value for the PasswordDeriveBytes function calls.
        // This size of the IV (in bytes) must = (keysize / 8).  Default keysize is 256, so the IV must be
        // 32 bytes long.  Using a 16 character string here gives us 32 bytes when converted to a byte array.
        private static readonly byte[] initVectorBytes = Encoding.ASCII.GetBytes("Db620oRto14AvzMt");

        // This constant is used to determine the keysize of the encryption algorithm.
        private const int keysize = 256;
        private const string passPhrase = "d42Xy41pc4";
        private const char splitter = 'x';

        private readonly IRepository<Order> _orderRepository2;
        private readonly IRepository<GenericAttribute> _genericAttributeRepository;
        private readonly IRepository<OrderItem> _orderItemRepository2;
        private readonly IRepository<Product> _productRepository2;
        private readonly InvoiceItemAttributeParser _invoiceItemAttributeParser;
        private readonly IRepository<RecurringPayment> _recurringPaymentRepository2;
        private readonly IRepository<RecurringPaymentHistory> _recurringPaymentHistoryRepository2;
        private readonly ILogger _logger;

        #endregion

        #region Ctor

        /// <summary>
        /// Ctor
        /// </summary>
        /// <param name="orderRepository">Order repository</param>
        /// <param name="orderItemRepository">Order item repository</param>
        /// <param name="orderNoteRepository">Order note repository</param>
        /// <param name="productRepository">Product repository</param>
        /// <param name="recurringPaymentRepository">Recurring payment repository</param>
        /// <param name="customerRepository">Customer repository</param>
        /// <param name="returnRequestRepository">Return request repository</param>
        /// <param name="eventPublisher">Event published</param>
        public ITPOrderService(IRepository<Order> orderRepository,
            IRepository<OrderItem> orderItemRepository,
            IRepository<OrderNote> orderNoteRepository,
            IRepository<Product> productRepository,
            IRepository<RecurringPayment> recurringPaymentRepository,
            IRepository<Customer> customerRepository,
            IRepository<ReturnRequest> returnRequestRepository,
            IEventPublisher eventPublisher,
            IRepository<GenericAttribute> genericAttributeRepository,
            InvoiceItemAttributeParser invoiceItemAttributeParser, 
            IRepository<RecurringPayment> recurringPaymentRepository2, 
            IRepository<RecurringPaymentHistory> recurringPaymentHistoryRepository2, 
            ILogger logger)
            //nop3.7 upgrade begin
            : base( eventPublisher,
            customerRepository,
            orderRepository,
            orderItemRepository,
            orderNoteRepository,
            productRepository,
            recurringPaymentRepository)
            //nop3.7 upgrade end
        {
            _orderRepository2 = orderRepository;
            _genericAttributeRepository = genericAttributeRepository;
            _invoiceItemAttributeParser = invoiceItemAttributeParser;
            _recurringPaymentRepository2 = recurringPaymentRepository2;
            _recurringPaymentHistoryRepository2 = recurringPaymentHistoryRepository2;
            _logger = logger;
            _orderItemRepository2 = orderItemRepository;
            _productRepository2 = productRepository;
        }

        #endregion

        #region Utilites

        #endregion

        /// <summary>
        /// Gets an order
        /// </summary>
        /// <param name="orderId">The order identifier</param>
        /// <returns>Order</returns>
        public override Order GetOrderById(int orderId)
        {
            var order = base.GetOrderById(orderId);
            if (order == null)
                return null;

            /*foreach (var orderItem in order.OrderItems)
            {
                var iiam = _invoiceItemAttributeParser.GetInvoiceItemAttributeMapping(orderItem.AttributesXml);
                if (iiam != null)
                {
                    orderItem.Product = orderItem.Product.MapTo<Product, ProductModel>()
                        .MapTo<ProductModel, Product>();
                    orderItem.Product.Name = iiam.Description;
                    orderItem.Product.IsTaxExempt = !iiam.Taxable;
                }
            }*/

            return order;
        }

        /// <summary>
        /// Search orders
        /// </summary>
        /// <param name="storeId">Store identifier; 0 to load all orders</param>
        /// <param name="vendorId">Vendor identifier; null to load all orders</param>
        /// <param name="customerId">Customer identifier; 0 to load all orders</param>
        /// <param name="productId">Product identifier which was purchased in an order; 0 to load all orders</param>
        /// <param name="affiliateId">Affiliate identifier; 0 to load all orders</param>
        /// <param name="warehouseId">Warehouse identifier, only orders with products from a specified warehouse will be loaded; 0 to load all orders</param>
        /// <param name="createdFromUtc">Created date from (UTC); null to load all records</param>
        /// <param name="createdToUtc">Created date to (UTC); null to load all records</param>
        /// <param name="os">Order status; null to load all orders</param>
        /// <param name="ps">Order payment status; null to load all orders</param>
        /// <param name="ss">Order shipment status; null to load all orders</param>
        /// <param name="billingEmail">Billing email. Leave empty to load all records.</param>
        /// <param name="orderGuid">Search by order GUID (Global unique identifier) or part of GUID. Leave empty to load all orders.</param>
        /// <param name="pageIndex">Page index</param>
        /// <param name="pageSize">Page size</param>
        /// <returns>Order collection</returns>
        public virtual IPagedList<Order> SearchOrdersByGenericAttribute(int storeId = 0,
            int vendorId = 0, int customerId = 0,
            int productId = 0, int affiliateId = 0, int warehouseId = 0,
            DateTime? createdFromUtc = null, DateTime? createdToUtc = null,
            OrderStatus? os = null, PaymentStatus? ps = null, ShippingStatus? ss = null,
            string billingEmail = null, string orderGuid = null,
            int pageIndex = 0, int pageSize = int.MaxValue, string key = null, string value = null)
        {
            int? orderStatusId = null;
            if (os.HasValue)
                orderStatusId = (int)os.Value;

            int? paymentStatusId = null;
            if (ps.HasValue)
                paymentStatusId = (int)ps.Value;

            int? shippingStatusId = null;
            if (ss.HasValue)
                shippingStatusId = (int)ss.Value;

            var query = from or in _orderRepository2.Table
                        join ga in _genericAttributeRepository.Table
                            on or.Id equals ga.EntityId
                        where ga.Key == key && ga.Value == value
                        select or;
            if (storeId > 0)
                query = query.Where(o => o.StoreId == storeId);
            if (vendorId > 0)
            {
                query = query
                    .Where(o => o.OrderItems
                    .Any(orderItem => orderItem.Product.VendorId == vendorId));
            }
            if (customerId > 0)
                query = query.Where(o => o.CustomerId == customerId);
            if (productId > 0)
            {
                query = query
                    .Where(o => o.OrderItems
                    .Any(orderItem => orderItem.Product.Id == productId));
            }
            if (warehouseId > 0)
            {
                var manageStockInventoryMethodId = (int)ManageInventoryMethod.ManageStock;
                query = query
                    .Where(o => o.OrderItems
                    .Any(orderItem =>
                        //"Use multiple warehouses" enabled
                        //we search in each warehouse
                        (orderItem.Product.ManageInventoryMethodId == manageStockInventoryMethodId &&
                        orderItem.Product.UseMultipleWarehouses &&
                        orderItem.Product.ProductWarehouseInventory.Any(pwi => pwi.WarehouseId == warehouseId))
                        ||
                            //"Use multiple warehouses" disabled
                            //we use standard "warehouse" property
                        ((orderItem.Product.ManageInventoryMethodId != manageStockInventoryMethodId ||
                        !orderItem.Product.UseMultipleWarehouses) &&
                        orderItem.Product.WarehouseId == warehouseId))
                        );
            }
            if (affiliateId > 0)
                query = query.Where(o => o.AffiliateId == affiliateId);
            if (createdFromUtc.HasValue)
                query = query.Where(o => createdFromUtc.Value <= o.CreatedOnUtc);
            if (createdToUtc.HasValue)
                query = query.Where(o => createdToUtc.Value >= o.CreatedOnUtc);
            if (orderStatusId.HasValue)
                query = query.Where(o => orderStatusId.Value == o.OrderStatusId);
            if (paymentStatusId.HasValue)
                query = query.Where(o => paymentStatusId.Value == o.PaymentStatusId);
            if (shippingStatusId.HasValue)
                query = query.Where(o => shippingStatusId.Value == o.ShippingStatusId);
            if (!String.IsNullOrEmpty(billingEmail))
                query = query.Where(o => o.BillingAddress != null && !String.IsNullOrEmpty(o.BillingAddress.Email) && o.BillingAddress.Email.Contains(billingEmail));
            query = query.Where(o => !o.Deleted);
            query = query.OrderByDescending(o => o.CreatedOnUtc);



            if (!String.IsNullOrEmpty(orderGuid))
            {
                //filter by GUID. Filter in BLL because EF doesn't support casting of GUID to string
                var orders = query.ToList();
                orders = orders.FindAll(o => o.OrderGuid.ToString().ToLowerInvariant().Contains(orderGuid.ToLowerInvariant()));
                return new PagedList<Order>(orders, pageIndex, pageSize);
            }

            //database layer paging
            return new PagedList<Order>(query, pageIndex, pageSize);
        }

        /// <summary>
        /// Gets all order items
        /// </summary>
        /// <param name="orderId">Order identifier; null to load all records</param>
        /// <param name="customerId">Customer identifier; null to load all records</param>
        /// <param name="createdFromUtc">Order created date from (UTC); null to load all records</param>
        /// <param name="createdToUtc">Order created date to (UTC); null to load all records</param>
        /// <param name="os">Order status; null to load all records</param>
        /// <param name="ps">Order payment status; null to load all records</param>
        /// <param name="ss">Order shipment status; null to load all records</param>
        /// <param name="loadDownloableProductsOnly">Value indicating whether to load downloadable products only</param>
        /// <returns>Order collection</returns>
        public virtual IList<OrderItem> GetAllOrderItems(int? orderId,
            int? customerId, DateTime? createdFromUtc, DateTime? createdToUtc,
            OrderStatus? os, PaymentStatus? ps, ShippingStatus? ss,
            bool loadDownloableProductsOnly)
        {
            //_logger.Warning("GetAllOrderItems2 debug: Beginning");

            int? orderStatusId = null;
            if (os.HasValue)
                orderStatusId = (int)os.Value;

            int? paymentStatusId = null;
            if (ps.HasValue)
                paymentStatusId = (int)ps.Value;

            int? shippingStatusId = null;
            if (ss.HasValue)
                shippingStatusId = (int)ss.Value;

            var query = from orderItem in _orderItemRepository2.Table
                        join o in _orderRepository2.Table on orderItem.OrderId equals o.Id
                        join p in _productRepository2.Table on orderItem.ProductId equals p.Id
                        where (!orderId.HasValue || orderId.Value == 0 || orderId == o.Id) &&
                        (!customerId.HasValue || customerId.Value == 0 || customerId == o.CustomerId) &&
                        (!createdFromUtc.HasValue || createdFromUtc.Value <= o.CreatedOnUtc) &&
                        (!createdToUtc.HasValue || createdToUtc.Value >= o.CreatedOnUtc) &&
                        (!orderStatusId.HasValue || orderStatusId == o.OrderStatusId) &&
                        (!paymentStatusId.HasValue || paymentStatusId.Value == o.PaymentStatusId) &&
                        (!shippingStatusId.HasValue || shippingStatusId.Value == o.ShippingStatusId) &&
                        (!loadDownloableProductsOnly || p.IsDownload) &&
                        !o.Deleted
                        orderby o.CreatedOnUtc descending, orderItem.Id
                        select orderItem;

            var orderItems = query.ToList();

            foreach (var orderItem in orderItems)
            {
                var iiam = _invoiceItemAttributeParser.GetInvoiceItemAttributeMapping(orderItem.AttributesXml);
                if (iiam != null)
                {                  
                    orderItem.Product = orderItem.Product.ToModel<ProductModel>()
                        .ToEntity<Product>();
                    orderItem.Product.Name = iiam.Description;
                    orderItem.Product.IsTaxExempt = !iiam.Taxable;
                }
            }

            return orderItems;
        }

        /// <summary>
        /// Gets an order item
        /// </summary>
        /// <param name="orderItemId">Order item identifier</param>
        /// <returns>Order item</returns>
        public override OrderItem GetOrderItemById(int orderItemId)
        {
            if (orderItemId == 0)
                return null;

            var orderItem = _orderItemRepository2.GetById(orderItemId);

            var iiam = _invoiceItemAttributeParser.GetInvoiceItemAttributeMapping(orderItem.AttributesXml);
            if (iiam != null)
            {
                orderItem.Product = orderItem.Product.ToModel<ProductModel>()
                   .ToEntity<Product>();
                orderItem.Product.Name = iiam.Description;
                orderItem.Product.IsTaxExempt = !iiam.Taxable;
            }

            return orderItem;
        }

        /// <summary>
        /// Search recurring payment by order Id in recurring payments table or, if couldn't find anything, in recurring payments history
        /// </summary>
        /// <param name="storeId">The store identifier; 0 to load all records</param>
        /// <param name="orderId">The order identifier</param>
        /// <returns>Recurring payment collection</returns>
        public virtual RecurringPayment GetRecurringPaymentByOrderId(int orderId)
        {
            var query = from rp in _recurringPaymentRepository2.Table
                        join rphrepos in _recurringPaymentHistoryRepository2.Table on rp.Id equals rphrepos.RecurringPaymentId into outer
                        from rph in outer.DefaultIfEmpty()
                        where
                        (!rp.Deleted) &&
                            //(storeId == 0 || rp.InitialOrder.StoreId == storeId) &&
                        ((rp.InitialOrder.Id == orderId) || (rph.OrderId == orderId))
                        select rp;

            return query.Any() ? query.First() : null;
        }

        /// <summary>
        /// Deletes an order
        /// </summary>
        /// <param name="order">The order</param>
        public override void DeleteOrder(Order order)
        {
            if (order == null)
                throw new ArgumentNullException("order");

            order.Deleted = true;
            UpdateOrder(order);
        }

        public string GetOrderEncryptedId(Order order)
        {
            byte[] plainTextBytes = Encoding.UTF8.GetBytes(order.Id.ToString());
            using (PasswordDeriveBytes password = new PasswordDeriveBytes(passPhrase, null))
            {
                byte[] keyBytes = password.GetBytes(keysize / 8);
                using (RijndaelManaged symmetricKey = new RijndaelManaged())
                {
                    symmetricKey.Mode = CipherMode.CBC;
                    using (ICryptoTransform encryptor = symmetricKey.CreateEncryptor(keyBytes, initVectorBytes))
                    {
                        using (MemoryStream memoryStream = new MemoryStream())
                        {
                            using (CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write))
                            {
                                cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);
                                cryptoStream.FlushFinalBlock();
                                byte[] cipherTextBytes = memoryStream.ToArray();

                                var byteArray = Encoding.UTF8.GetBytes(Convert.ToBase64String(cipherTextBytes));
                                var str = "";
                                foreach (var b in byteArray)
                                {
                                    str += b.ToString("X2");
                                }
                                return str;
                                //var str = "";
                                //var byteArray = Encoding.UTF8.GetBytes(Convert.ToBase64String(cipherTextBytes));
                                //foreach (var ch in byteArray)
                                //{
                                //    str += Convert.ToInt32(ch).ToString() + splitter;
                                //}
                                //str = str.Remove(str.Length - 1);
                                //return str;
                            }
                        }
                    }
                }
            }

            //return ((long) order.Id * PUBLIC_KEY).ToString();
        }

        public int GetOrderDecryptedId(string encryptedId)
        {
            //Don't touch this
            int NumberChars = encryptedId.Length;
            byte[] bytes = new byte[NumberChars / 2];
            for (int i = 0; i < NumberChars; i += 2)
                bytes[i / 2] = Convert.ToByte(encryptedId.Substring(i, 2), 16);
            encryptedId = new string(bytes.Select(Convert.ToChar).ToArray());

            byte[] cipherTextBytes = Convert.FromBase64String(encryptedId);
            using (PasswordDeriveBytes password = new PasswordDeriveBytes(passPhrase, null))
            {
                byte[] keyBytes = password.GetBytes(keysize / 8);
                using (RijndaelManaged symmetricKey = new RijndaelManaged())
                {
                    symmetricKey.Mode = CipherMode.CBC;
                    using (ICryptoTransform decryptor = symmetricKey.CreateDecryptor(keyBytes, initVectorBytes))
                    {
                        using (MemoryStream memoryStream = new MemoryStream(cipherTextBytes))
                        {
                            using (CryptoStream cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read))
                            {
                                byte[] plainTextBytes = new byte[cipherTextBytes.Length];
                                int decryptedByteCount = cryptoStream.Read(plainTextBytes, 0, plainTextBytes.Length);
                                return Int32.Parse(Encoding.UTF8.GetString(plainTextBytes, 0, decryptedByteCount));
                            }
                        }
                    }
                }
            }

            //return (int) (Int64.Parse(encryptedId)/PUBLIC_KEY);
        }
    }
}
