using System;
using System.Collections.Generic;
using Nop.Core;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Localization;
using Nop.Core.Domain.Payments;

namespace ShopFast.Plugin.Misc.Core.Domain
{
    public partial class OrderEventArgs : EventArgs
    {
        public OrderEventArgs(int orderId, string emailTemplatePath)
        {
            OrderId = orderId;
            EmailTemplatePath = emailTemplatePath;
        }

        public int OrderId { get; set; }
        public string EmailTemplatePath { get; set; }
    }
}
