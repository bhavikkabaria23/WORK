using Nop.Core.Configuration;

namespace ShopFast.Plugin.Misc.Invoices
{
    public class InvoicesSettings : ISettings
    {

    }
}
