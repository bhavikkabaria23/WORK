﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using Nop.Web.Framework.Models;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Discounts;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;
using Nop.Web.Models.Checkout;
using Nop.Web.Models.ShoppingCart;
using ShopFast.Plugin.Misc.Core.Domain;
using Microsoft.AspNetCore.Mvc.Rendering;
using Nop.Web.Framework.Mvc.ModelBinding;
using Nop.Web.Areas.Admin.Models.Orders;

namespace ShopFast.Plugin.Misc.Invoices.Models
{
    public class InvoiceModel : BaseSearchModel
    {
        public InvoiceModel()
        {
            this.Discounts = new List<Discount>();
            this.Warnings = new List<string>();
            ItemModel = new InvoiceItemModel();
        }

        public InvoiceItemModel ItemModel { get; set; }

        //Customer Info
        [ForeignKey("Customer")]
        public int? CustomerId { get; set; }
        public virtual Customer Customer { get; set; }
        public List<SelectListItem> CustomerValues { get; set; }
        public List<string> CustomerEmails { get; set; } 

        //Invoice Details
        [NopResourceDisplayName("ShopFast.Plugins.Misc.Invoices.Details.OrderNumber")]
        public int OrderId { get; set; }
        [NopResourceDisplayName("ShopFast.Plugins.Misc.Invoices.Details.OrderGuid")]
        public string OrderGuid { get; set; }
        [NopResourceDisplayName("ShopFast.Plugins.Misc.Invoices.Details.PaymentMethod")]
        public string PaymentMethodSystemName { get; set; }
        [NopResourceDisplayName("ShopFast.Plugins.Misc.Invoices.Details.StoreName")]
        public string StoreName { get; set; }
        [NopResourceDisplayName("ShopFast.Plugins.Misc.Invoices.Details.CreatedDate")]
        public string InvoiceDateStr { get; set; }
        [NopResourceDisplayName("ShopFast.Plugins.Misc.Invoices.Details.PaidDate")]
        public string DueDateStr { get; set; }

        [NopResourceDisplayName("ShopFast.Plugins.Misc.Invoices.Details.OrderStatus")]
        public int OrderStatusId { get; set; }
        [NopResourceDisplayName("ShopFast.Plugins.Misc.Invoices.Details.OrderStatus")]
        public SelectList OrderStatusValues { get; set; }

        [NopResourceDisplayName("ShopFast.Plugins.Misc.Invoices.Details.PaymentStatus")]
        public int PaymentStatusId { get; set; }
        [NopResourceDisplayName("ShopFast.Plugins.Misc.Invoices.Details.PaymentStatus")]
        public SelectList PaymentStatusValues { get; set; }

        public bool SentToClient { get; set; }

        //Discount Details
        public IList<Discount> Discounts { get; set; }

        public List<string> Warnings { get; set; }

        public DiscountBoxModel DiscountBox { get; set; }
        public GiftCardBoxModel GiftCardBox { get; set; }

        //Recurring
        [NopResourceDisplayName("ShopFast.Plugins.Misc.Invoices.Details.RecurringCycleLength")]
        public int RecurringCycleLength { get; set; }
        [NopResourceDisplayName("ShopFast.Plugins.Misc.Invoices.Details.RecurringCyclePeriod")]
        public int RecurringCyclePeriodId { get; set; }
        [NopResourceDisplayName("ShopFast.Plugins.Misc.Invoices.Details.RecurringCyclePeriod")]
        public SelectList RecurringCyclePeriodValues { get; set; }
        [NopResourceDisplayName("ShopFast.Plugins.Misc.Invoices.Details.RecurringTotalCycles")]
        public int RecurringTotalCycles { get; set; }
        [NopResourceDisplayName("ShopFast.Plugins.Misc.Invoices.Details.RucurringStartDateUtc")]
        public DateTime RecurringStartDateUtc { get; set; }
        [NopResourceDisplayName("ShopFast.Plugins.Misc.Invoices.Details.RucurringCreatedOnUtc")]
        public DateTime RecurringCreatedOnUtc { get; set; }

        public OrderModel OrderModel { get; set; }

        public string CheckoutAttributeInfo { get; set; }
        public IList<ShoppingCartModel.CheckoutAttributeModel> CheckoutAttributes { get; set; }

        //Invoice is closed
        public bool Closed { get; set; }

        public InvoiceType InvoiceType { get; set; }

        //Payments
        public IList<SelectListItem> PaymentMethods { get; set; }
        [NopResourceDisplayName("ShopFast.Plugins.Misc.QuickCheckout.PaymentMethod")]
        public string PaymentMethod { get; set; }
        public decimal Amount { get; set; }
        public int? PaymentOrderId { get; set; }
        public string PaymentOrderDescription { get; set; }

        public OrderStatus OrderStatus
        {
            get { return (OrderStatus) this.OrderStatusId; }
            set { this.OrderStatusId = (int) value; }
        }

        public PaymentStatus PaymentStatus
        {
            get { return (PaymentStatus) this.PaymentStatusId; }
            set { this.PaymentStatusId = (int)value; }
        }

        public bool Exist
        {
            get { return this.OrderId > 0; }
        }

        public bool IsInvoice
        {
            get { return this.InvoiceType == InvoiceType.Invoice; }
        }

        public bool IsEstimate
        {
            get { return this.InvoiceType == InvoiceType.Estimate; }
        }

        public bool IsRecurring
        {
            get { return this.InvoiceType == InvoiceType.RecurringInvoice; }
        }

        public bool IsPayment
        {
            get { return this.InvoiceType == InvoiceType.Payment; }
        }


        public partial class DiscountBoxModel : BaseNopModel
        {
            public bool Display { get; set; }
            public string Message { get; set; }
            public string CurrentCode { get; set; }
            public bool IsApplied { get; set; }
        }

        public partial class GiftCardBoxModel : BaseNopModel
        {
            public bool Display { get; set; }
            public string Message { get; set; }
        }
    }
}
