﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Security.Policy;
using System.Web;
using Nop.Core;
using Nop.Core.Data;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Logging;
using Nop.Core.Domain.Messages;
using Nop.Core.Domain.Orders;
using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Services.Catalog;
using Nop.Services.Cms;
using Nop.Services.Common;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Messages;
using Nop.Services.Orders;
using Nop.Web.Framework.Menu;
using ShopFast.Plugin.Misc.Core.Services;
using ShopFast.Plugin.Misc.Core.Domain;
using SiteMapNode = Nop.Web.Framework.Menu.SiteMapNode;
using Nop.Services.Plugins;
using Microsoft.AspNetCore.Routing;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Mvc;

namespace ShopFast.Plugin.Misc.Invoices
{
    class InvoicesPlugin : BasePlugin, IAdminMenuPlugin, IMiscPlugin, IWidgetPlugin
    {
        #region Consts

        public static readonly string LAYOUT_PATH = "~/Plugins/ShopFast.Misc.Invoices/Views/Shared/_Layout.cshtml";

        #endregion

        #region Fields
        private readonly IProductService _productService;
        private readonly IRepository<Product> _productRepository;
        private readonly ICheckoutAttributeService _checkoutAttributeService;
        private readonly IRepository<EmailAccount> _emailAccountRepository;
        private readonly IRepository<MessageTemplate> _messageTemplateRepository;      
        private readonly ILocalizationService _localizationService;
        private IActionContextAccessor _actionContextAccessor;
        private readonly IUrlHelperFactory _urlHelperFactory;



        public InvoicesPlugin(IProductService productService,
            IRepository<Product> productRepository,
            ICheckoutAttributeService checkoutAttributeService,
            IRepository<EmailAccount> emailAccountRepository,
            IRepository<MessageTemplate> messageTemplateRepository,
            ILocalizationService localizationService,
            IActionContextAccessor actionContextAccessor,
            IUrlHelperFactory urlHelperFactory
            )
        {
            _productService = productService;
            _productRepository = productRepository;
            _checkoutAttributeService = checkoutAttributeService;
            _emailAccountRepository = emailAccountRepository;
            _messageTemplateRepository = messageTemplateRepository;
            _localizationService = localizationService;
            _actionContextAccessor = actionContextAccessor;
            _urlHelperFactory = urlHelperFactory;
    }

        #endregion

        #region Methods

        public static void SetDefaultSettings()
        {
            ILogger logger = EngineContext.Current.Resolve<ILogger>();

            ISettingService settingService = EngineContext.Current.Resolve<ISettingService>();
            IProductTemplateService productTemplateService = EngineContext.Current.Resolve<IProductTemplateService>();
            var settings = new InvoicesSettings() { };
            settingService.SaveSetting(settings);

            ICheckoutAttributeService checkoutAttributeService =
                EngineContext.Current.Resolve<ICheckoutAttributeService>();

            var checkoutAttributeToDel = checkoutAttributeService.GetAllCheckoutAttributes().ToList()
               .Find(p => p.Name == "InvoiceComment");
            if (checkoutAttributeToDel != null)
                checkoutAttributeService.DeleteCheckoutAttribute(checkoutAttributeToDel);

            var checkoutAttribute = checkoutAttributeService.GetAllCheckoutAttributes().ToList()
                .Find(p => p.Name == "Invoice Comment");
            if (checkoutAttribute == null)
            {
                checkoutAttributeService.InsertCheckoutAttribute(new CheckoutAttribute
                {
                    Name = "Invoice Comment",
                    TextPrompt = null,
                    IsRequired = false,
                    ShippableProductRequired = false,
                    IsTaxExempt = false,
                    TaxCategoryId = 0,
                    AttributeControlType = AttributeControlType.MultilineTextbox,
                    DisplayOrder = 1,
                    LimitedToStores = false,
                    DefaultValue = ""
                });
            }

            string script = File.ReadAllText(EngineContext.Current.Resolve<INopFileProvider>().MapPath("~/Plugins/ShopFast.Misc.Invoices/SQL/InvoiceProductInsert.sql"));
            IDbContext dbContext = EngineContext.Current.Resolve<IDbContext>();

            dbContext.ExecuteSqlCommand(script);

            //Recurring Payment Fix
            script = File.ReadAllText(EngineContext.Current.Resolve<INopFileProvider>().MapPath("~/Plugins/ShopFast.Misc.Invoices/SQL/RecurringPaymentFix.sql"));
            dbContext.ExecuteSqlCommand(script);

            foreach (var localeResource in GetLocaleResources())
            {
                ITPLocalizationService.AddOrUpdateLocaleResource(localeResource.Key, localeResource.Value);
            }

            ITPLocalizationService.AddOrUpdateLocaleResource("Account.CustomerOrders", "Invoices");
            ITPLocalizationService.AddOrUpdateLocaleResource("Admin.Customers.Customers.Orders", "Invoices");
            ITPLocalizationService.AddOrUpdateLocaleResource("Admin.Orders", "Invoices");

            InstallEmailTemplates();
        }
        
        private static void InstallEmailTemplates()
        {
            IMessageTemplateService messageTemplateService = EngineContext.Current.Resolve<IMessageTemplateService>();
            IStoreContext storeContext = EngineContext.Current.Resolve<IStoreContext>();
            IRepository<EmailAccount> emailAccountRepository = EngineContext.Current.Resolve<IRepository<EmailAccount>>();

            var eaGeneral = emailAccountRepository.Table.FirstOrDefault();
            if (eaGeneral == null)
                throw new Exception("Default email account cannot be loaded");
            var messageTemplates = new List<MessageTemplate>
            {                
                //Estimates
                new MessageTemplate
                {
                    Name = "ShopFast.Plugin.Misc.Invoices.EstimatePlaced",
                    Subject = File.ReadAllText(EngineContext.Current.Resolve<INopFileProvider>().MapPath("~/Plugins/ShopFast.Misc.Invoices/EmailTemplates/EstimatePlacedSubject.txt")),
                    Body = File.ReadAllText(EngineContext.Current.Resolve<INopFileProvider>().MapPath("~/Plugins/ShopFast.Misc.Invoices/EmailTemplates/EstimatePlacedBody.txt")),
                    IsActive = true,
                    EmailAccountId = eaGeneral.Id,
                },
                new MessageTemplate
                {
                    Name = "ShopFast.Plugin.Misc.Invoices.EstimateUpdated",
                    Subject = File.ReadAllText(EngineContext.Current.Resolve<INopFileProvider>().MapPath("~/Plugins/ShopFast.Misc.Invoices/EmailTemplates/EstimateUpdatedSubject.txt")),
                    Body = File.ReadAllText(EngineContext.Current.Resolve<INopFileProvider>().MapPath("~/Plugins/ShopFast.Misc.Invoices/EmailTemplates/EstimateUpdatedBody.txt")),
                    IsActive = true,
                    EmailAccountId = eaGeneral.Id,
                },
                //Invoices
                new MessageTemplate
                {
                    Name = "ShopFast.Plugin.Misc.Invoices.InvoiceCreated",
                    Subject = File.ReadAllText(EngineContext.Current.Resolve<INopFileProvider>().MapPath("~/Plugins/ShopFast.Misc.Invoices/EmailTemplates/InvoiceCreatedSubject.txt")),
                    Body = File.ReadAllText(EngineContext.Current.Resolve<INopFileProvider>().MapPath("~/Plugins/ShopFast.Misc.Invoices/EmailTemplates/InvoiceCreatedBody.txt")),
                    IsActive = true,
                    EmailAccountId = eaGeneral.Id,
                },
                new MessageTemplate
                {
                    Name = "ShopFast.Plugin.Misc.Invoices.InvoiceUpdated",
                    Subject = File.ReadAllText(EngineContext.Current.Resolve<INopFileProvider>().MapPath("~/Plugins/ShopFast.Misc.Invoices/EmailTemplates/InvoiceUpdatedSubject.txt")),
                    Body = File.ReadAllText(EngineContext.Current.Resolve<INopFileProvider>().MapPath("~/Plugins/ShopFast.Misc.Invoices/EmailTemplates/InvoiceUpdatedBody.txt")),
                    IsActive = true,
                    EmailAccountId = eaGeneral.Id,
                },
                //Recurring Invoices
                new MessageTemplate
                {
                    Name = "ShopFast.Plugin.Misc.Invoices.RecurringInvoiceCreated",
                    Subject = File.ReadAllText(EngineContext.Current.Resolve<INopFileProvider>().MapPath("~/Plugins/ShopFast.Misc.Invoices/EmailTemplates/RecurringInvoiceCreatedSubject.txt")),
                    Body = File.ReadAllText(EngineContext.Current.Resolve<INopFileProvider>().MapPath("~/Plugins/ShopFast.Misc.Invoices/EmailTemplates/RecurringInvoiceCreatedBody.txt")),
                    IsActive = true,
                    EmailAccountId = eaGeneral.Id,
                },
                new MessageTemplate
                {
                    Name = "ShopFast.Plugin.Misc.Invoices.RecurringInvoiceUpdated",
                    Subject = File.ReadAllText(EngineContext.Current.Resolve<INopFileProvider>().MapPath("~/Plugins/ShopFast.Misc.Invoices/EmailTemplates/RecurringInvoiceUpdatedSubject.txt")),
                    Body = File.ReadAllText(EngineContext.Current.Resolve<INopFileProvider>().MapPath("~/Plugins/ShopFast.Misc.Invoices/EmailTemplates/RecurringInvoiceUpdatedBody.txt")),
                    IsActive = true,
                    EmailAccountId = eaGeneral.Id,
                }
            };
            foreach (var messageTemplate in messageTemplates)
            {
                if (messageTemplateService.GetMessageTemplatesByName(messageTemplate.Name, storeContext.CurrentStore.Id) == null)
                {
                    messageTemplateService.InsertMessageTemplate(messageTemplate);
                }
            }
        }

        public override void Install()
        {
            SetDefaultSettings();
            
            base.Install();
        }

        public override void Uninstall()
        {
            var product = _productService.GetProductBySku("ShopFast.Plugins.Misc.Invoices.NoPriceProduct");
            if (product != null)
            {
                _productService.DeleteProduct(product);
            }

            foreach (var localeResource in GetLocaleResources())
            {
                _localizationService.DeletePluginLocaleResource(localeResource.Key);
            }

            ITPLocalizationService.AddOrUpdateLocaleResource("Account.CustomerOrders", "Orders");
            ITPLocalizationService.AddOrUpdateLocaleResource("Admin.Customers.Customers.Orders", "Orders");
            ITPLocalizationService.AddOrUpdateLocaleResource("Admin.Orders", "Orders");

            base.Uninstall();
        }

        private static Dictionary<string, string> GetLocaleResources()
        {
            /*result.Add("Enums.Nop.Core.Domain.Orders.OrderStatus.Pending", 
                "OrderStatus1");
            result.Add("Enums.Nop.Core.Domain.Orders.OrderStatus.Processing",
                "OrderStatus2");
            result.Add("Enums.Nop.Core.Domain.Orders.OrderStatus.Cancelled",
                "OrderStatus3");
            result.Add("Enums.Nop.Core.Domain.Orders.OrderStatus.Complete",
                "OrderStatus4");*/

            var result = new Dictionary<string, string>
            {
               {"ShopFast.Plugins.Misc.Invoices&Estimates", "Invoices and Estimates"},
               {"ShopFast.Plugins.Misc.Invoices.Create", "Create {0}"},
                {"ShopFast.Plugins.Misc.Invoices.Edit", "Edit {0}"},
                {"ShopFast.Plugins.Misc.Invoices.AddNew", "Add New {0}"},
                {"ShopFast.Plugins.Misc.Invoices.View", "View {0}"},
                {"ShopFast.Plugins.Misc.Invoices.Invoice", "Invoice"},
                {"ShopFast.Plugins.Misc.Invoices.Estimate", "Estimate"},
                {"ShopFast.Plugins.Misc.Invoices.RecurringInvoice", "Recurring Invoice"},
                {"ShopFast.Plugins.Misc.Invoices.Invoices", "Invoices"},
                {"ShopFast.Plugins.Misc.Invoices.Estimates", "Estimates"},
                {"ShopFast.Plugins.Misc.Invoices.RecurringInvoices", "Recurring Invoices"},
                {"ShopFast.Plugins.Misc.Invoices.Payments", "Payments"},
                {"ShopFast.Plugins.Misc.Invoices.ChainedInvoices", "Recurring payment history"},
                {"ShopFast.Plugins.Misc.Invoices.Details.OrderNumber", "Invoice Number"},
                {"ShopFast.Plugins.Misc.Invoices.Details.OrderGuid", "Invoice Guid"},
                {"ShopFast.Plugins.Misc.Invoices.Details.StoreName", "Store Name"},
                {"ShopFast.Plugins.Misc.Invoices.Details.PaymentMethod", "Payment Method"},
                {"ShopFast.Plugins.Misc.Invoices.Details.CreatedDate", "Created Date"},
                {"ShopFast.Plugins.Misc.Invoices.Details.PaidDate", "Paid Date"},
                {"ShopFast.Plugins.Misc.Invoices.Details.OrderStatus", "Invoice Status"},
                {"ShopFast.Plugins.Misc.Invoices.Details.PaymentStatus", "Payment Status"},
                {"ShopFast.Plugins.Misc.Invoices.Details.RecurringCycleLength", "Cycle Length"},
                {"ShopFast.Plugins.Misc.Invoices.Details.RecurringCyclePeriod", "Cycle Period"},
                {"ShopFast.Plugins.Misc.Invoices.Details.RecurringTotalCycles", "Total Cycles"},
                {"ShopFast.Plugins.Misc.Invoices.Details.RucurringStartDateUtc", "Start Date"},
                {"ShopFast.Plugins.Misc.Invoices.Details.RucurringCreatedOnUtc", "Created on"},
                {"ShopFast.Plugins.Misc.Invoices.Email.EmptyReceiver", "Empty receiver"},
                {"ShopFast.Plugins.Misc.Invoices.Email.EmailEmpty", "Customer email is empty"},
                {"ShopFast.Plugins.Misc.Invoices.Email.EmailNotValid", "Customer email is not valid"},
                {"ShopFast.Plugins.Misc.Invoices.Email.TemplateNotFound", "Email template not found"},
                {"ShopFast.Plugins.Misc.Invoices.Email.AccountNotLoaded", "Email account can't be loaded"},
                {
                    "ShopFast.Plugins.Misc.Invoices.Discount.CustomerNotSet",
                    "Customer is not set. Set a customer to apply discount."
                },
                {"ShopFast.Plugins.Misc.Invoices.Warning.CustomerNotSet", "Customer is not set."},
                {"ShopFast.Plugins.Misc.Invoices.Warning.CustomerNotFound", "Can't find the customer."},
                {"ShopFast.Plugins.Misc.Invoices.Warning.NoBillingAddressOnCustomer", "Cannot create an invoice for customer who has no billing address."},
                {"ShopFast.Plugins.Misc.Invoices.Warning.CycleLengthNotPositive", "Cycle length should be positive."},
                {"ShopFast.Plugins.Misc.Invoices.Warning.CycleCountNotPositive", "Cycle count should be positive."},
                {"ShopFast.Plugins.Misc.Invoices.Success.InvoiceCreated", "Invoice created"},
                {"ShopFast.Plugins.Misc.Invoices.Success.InvoiceUpdated", "Invoice updated"},
                {"ShopFast.Plugins.Misc.Invoices.Success.EstimatePlaced", "Estimate placed"},
                {"ShopFast.Plugins.Misc.Invoices.Success.EstimateUpdated", "Estimate updated"},
                {"ShopFast.Plugins.Misc.Invoices.Success.RecurringInvoiceCreated", "Recurring 0 created"},
                {"ShopFast.Plugins.Misc.Invoices.Success.RecurringInvoiceUpdated", "Recurring Invoice updated"},
                {
                    "ShopFast.Plugins.Misc.Invoices.Success.EstimateAccepted",
                    "Estimate has been succesfully transfered to invoice"
                },
                {"ShopFast.Plugins.Misc.Invoices.Success.PaymentProceed", "Payment has been complited"},
                {"ShopFast.Plugins.Misc.Invoices.Error.PermissionDenied", "Permisssion denied"},
                {
                    "ShopFast.Plugins.Misc.Invoices.Error.RecurringPaymentNotFound",
                    "No recurring payment found with the specified id"
                },
                {"ShopFast.Plugins.Misc.Invoices.Error.PaymentProceed", "Payment has failed"},
                {"ShopFast.Plugins.Misc.Invoices.Payment.MethodNotSelected", "Payment method is not selected"},
                {"ShopFast.Plugins.Misc.Invoices.Payment.ControllerNotLoaded", "Payment controller cannot be loaded"},
                {
                    "ShopFast.Plugins.Misc.Invoices.Payment.EnteredInfoNotValid",
                    "Payment information is not entered correctly"
                },
                {"ShopFast.Plugins.Misc.Invoices.Payment.ProcessFailed", "Payment process has failed"},
                {"ShopFast.Plugins.Misc.Invoices.General.SaveInvoiceButton", "Save"},
                {"ShopFast.Plugins.Misc.Invoices.General.SaveAndEmailInvoiceButton", "Save and Send Email"},
                {"ShopFast.Plugins.Misc.Invoices.General.DiscountDetails", "Discount Details"},
                {"ShopFast.Plugins.Misc.Invoices.General.Client", "Client"},
                {"ShopFast.Plugins.Misc.Invoices.General.CheckoutAttributes", "Checkout Attributes"},
                {"ShopFast.Plugins.Misc.Invoices.General.InvoiceItems", "Items"},
                {"ShopFast.Plugins.Misc.Invoices.General.InvoiceDetails", "Details"},
                {"ShopFast.Plugins.Misc.Invoices.General.Add", "Add new"},
                {"ShopFast.Plugins.Misc.Invoices.General.PaidInvoices", "Paid Invoices"},
                {"ShopFast.Plugins.Misc.Invoices.General.UnpaidInvoices", "Unpaid Invoices"},
                {"ShopFast.Plugins.Misc.Invoices.General.Amount", "Amount"},
                {"ShopFast.Plugins.Misc.Invoices.General.Invoice", "Invoice"},
                {"ShopFast.Plugins.Misc.Invoices.Estimates.Accept", "Accept Estimate"},
                {"ShopFast.Plugins.Misc.Invoices.Estimates.BackToList", "back to estimate list"},
                {"ShopFast.Plugins.Misc.Invoices.Invoices.BackToList", "back to invoice list"},
                {"ShopFast.Plugins.Misc.Invoices.RecurringInvoices.NextInvoice", "Generate Next Invoice"},
                {"ShopFast.Plugins.Misc.Invoices.RecurringInvoices.Cancel", "Cancel Recurring Payment"},
                {"ShopFast.Plugins.Misc.Invoices.RecurringInvoices.BackToList", "back to recurring invoice list"},
                {"ShopFast.Plugins.Misc.Invoices.Payments.Delete", "Delete Payment"},
                {"ShopFast.Plugins.Misc.Invoices.Payments.List", "Payments"},
                {"ShopFast.Plugins.Misc.Invoices.Payments.Create", "Create Payment"},
                {"ShopFast.Plugins.Misc.Invoices.Payments.Add", "Add New Payment"},
                {"ShopFast.Plugins.Misc.Invoices.Payments.View", "View Recurring Invoice"},
                {"ShopFast.Plugins.Misc.Invoices.Payments.Process", "Process Payment"},
                {"ShopFast.Plugins.Misc.Invoices.Payments.PaymentInfo", "Payment Info"},
                {"ShopFast.Plugins.Misc.Invoices.Payments.BackToList", "back to payment list"},
                {"ShopFast.Plugins.Misc.Invoices.Payments.PaymentMethod", "Payment method"},
                {"ShopFast.Plugins.Misc.Invoices.Items.Items", "Items"},
                {"ShopFast.Plugins.Misc.Invoices.DefaultSettings", "Default Settings"}
            };

            return result;
        }
        
        #endregion

        #region IAdminMenuPlugin
        
        //nop3.7 upgrade begin
        public void ManageSiteMap(SiteMapNode rootNode)
        {           
            var _urlHelper = _urlHelperFactory.GetUrlHelper(_actionContextAccessor.ActionContext);
            var pluginsNode = rootNode.ChildNodes.First(n => n.Title == "Plugins");
            var invoicesAndEstimatesNode = new SiteMapNode()
            {
                Visible = true,
                Title = "Invoices and Estimates",
                IconClass = "fa fa-book",
            };
            var pluginsNodeIndex = rootNode.ChildNodes.IndexOf(pluginsNode);
            rootNode.ChildNodes.Insert(pluginsNodeIndex, invoicesAndEstimatesNode);

            invoicesAndEstimatesNode.ChildNodes.Add(new SiteMapNode
            {
                Visible = true,
                Title = "Invoices",
                Url = _urlHelper.RouteUrl("ShopFast.Plugin.Misc.Invoices.Invoices"),
                IconClass = "fa fa-dot-circle-o",
            });

            invoicesAndEstimatesNode.ChildNodes.Add(new SiteMapNode
            {
                Visible = true,
                Title = "Estimates",
                Url = _urlHelper.RouteUrl("ShopFast.Plugin.Misc.Invoices.Estimates"),
                IconClass = "fa fa-dot-circle-o",
            });

            invoicesAndEstimatesNode.ChildNodes.Add(new SiteMapNode
            {
                Visible = true,
                Title = "Items",
                Url = _urlHelper.RouteUrl("ShopFast.Plugin.Misc.Invoices.Items"),
                IconClass = "fa fa-dot-circle-o",
            });

            invoicesAndEstimatesNode.ChildNodes.Add(new SiteMapNode
            {
                Visible = true,
                Title = "Recurring Invoices",
                Url = _urlHelper.RouteUrl("ShopFast.Plugin.Misc.Invoices.RecurringInvoices"),
                IconClass = "fa fa-dot-circle-o",
            });

            //invoicesAndEstimatesNode.ChildNodes.Add(new SiteMapNode
            //{
            //    Visible = true,
            //    Title = "Payments",
            //    Url = _urlHelper.RouteUrl("ShopFast.Plugin.Misc.Invoices.Payments"),
            //    IconClass = "fa fa-dot-circle-o",
            //});
        }
        //nop3.7 upgrade end

        #endregion

        public void GetConfigurationRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "Configure";
            controllerName = "Invoices";
            routeValues = new RouteValueDictionary { { "Namespaces", 
                                                         "ShopFast.Plugins.Misc.Invoices.Controllers" }, 
                                                         { "area", null } };
        }

        /// <summary>
        /// Gets widget zones where this widget should be rendered
        /// </summary>
        /// <returns>Widget zones</returns>
        public IList<string> GetWidgetZones()
        {
            return new List<string>
            { 
                //"orderdetails_page_afterproducts",
                "account_navigation_before",
                //"orderdetails_page_overview"
            };
        }

        /// <summary>
        /// Gets a name of a view component for displaying widget
        /// </summary>
        /// <param name="widgetZone">Name of the widget zone</param>
        /// <returns>View component name</returns>
        public string GetWidgetViewComponentName(string widgetZone)
        {
            return "OrderPaymentWidget";
        }

        /// <summary>
        /// Gets a value indicating whether to hide this plugin on the widget list page in the admin area
        /// </summary>
        public bool HideInWidgetList => false;

    }
}
