﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Models.NopWeb.CustomWeb
{
    public class ThemeSettings
    {
        public string ThemeName { get; set; }
        public string PresetColor { get; set; }
        public string HeaderLayout { get; set; }
        public string MegaMenu { get; set; }
        public string CategoriesHoverEffect { get; set; }
        public string ProductsPerRow { get; set; }
        public string ProductPageLayout { get; set; }
        public string FooterLayout { get; set; }
    }
}