﻿using Nop.Web.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Models.NopAdmin.Orders
{
    public class OrderModelCustom
    {
        [NopResourceDisplayName("Admin.Orders.Fields.ID")]
        public int OrderId { get; set; }
        [NopResourceDisplayName("Admin.Orders.Fields.OrderGuid")]
        public Guid OrderGuid { get; set; }
        [NopResourceDisplayName("Admin.Orders.Fields.Signature")]
        public string Signature { get; set; }
        
        [NopResourceDisplayName("Admin.Orders.Fields.OrderTempId")]
        public string OrderTempId { get; set; }
    }
}