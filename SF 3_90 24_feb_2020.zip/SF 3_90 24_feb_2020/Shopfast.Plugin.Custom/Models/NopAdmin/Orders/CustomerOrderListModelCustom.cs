﻿using Nop.Core.Domain.Orders;
using Nop.Web.Framework.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Models.NopAdmin.Orders
{
    public class CustomerOrderListModelCustom : BaseNopModel
    {
        public CustomerOrderListModelCustom()
        {
            Orders = new List<OrderDetailsModel>();          
        }

        public IList<OrderDetailsModel> Orders { get; set; }
        public string Message { get; set; }

        #region Nested classes

        public partial class OrderDetailsModel
        {
            public int Id { get; set; }
            public string CustomOrderNumber { get; set; }
            public string OrderTotal { get; set; }
            public bool IsReturnRequestAllowed { get; set; }
            public OrderStatus OrderStatusEnum { get; set; }
            public string OrderStatus { get; set; }
            public string PaymentStatus { get; set; }
            public string ShippingStatus { get; set; }
            public DateTime CreatedOn { get; set; }
            public bool IsActive { get; set; }
        }

        #endregion
    }
}