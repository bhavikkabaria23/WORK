﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nop.Web.Models.ShoppingCart;
using System.Text.RegularExpressions;

namespace Shopfast.Plugin.Custom.Helper
{
    class ProductHelper {
        internal static void ProcessSpecialAttributes(ShoppingCartModel model) {
            // No need to set 'false' and used whatever set by Admin side
            //model.ShowProductImages = false;
            foreach (var item in model.Items) {
                var attribInfo = item.AttributeInfo;
                var filtered = attribInfo.Split(new[] { @"<br />" }, StringSplitOptions.RemoveEmptyEntries)
                    .Where(s => !Regex.IsMatch(s, "Industry Type|Description|Starting|Password", RegexOptions.IgnoreCase));
                var filteredStr = string.Join("</li><li>", filtered);
                attribInfo = string.Format(@"<ul class='option-list'><li>{0}</li></ul>", filteredStr);//attribInfo.Replace(@"<br />", @"</li><li>")
                item.AttributeInfo = attribInfo;
            }
        }

    }
}
