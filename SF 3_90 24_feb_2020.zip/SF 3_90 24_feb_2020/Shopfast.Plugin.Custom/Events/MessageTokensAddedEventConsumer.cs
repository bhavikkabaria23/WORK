﻿using Nop.Core.Domain.Messages;
using Nop.Services.Events;
using Nop.Services.Messages;
using Shopfast.Plugin.Custom.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopfast.Plugin.Custom.Events
{
    public class MessageTokensAddedEventConsumer : IConsumer<MessageTokensAddedEvent<Token>>
    {
        public void HandleEvent(MessageTokensAddedEvent<Token> eventMessage)
        {
            if (eventMessage.Message.Name == MessageTemplateSystemNames.GiftCardNotification)
            {
                // get coupon code from "GiftCard.CouponCode"
                // generate QR code and save to a path
                // then use that path with "Store.URL" token
                // set path with new token "GiftCard.CouponQRCode"
                var couponCode = Convert.ToString(eventMessage.Tokens.FirstOrDefault(t => t.Key == "GiftCard.CouponCode").Value);
                var storeUrl = Convert.ToString(eventMessage.Tokens.FirstOrDefault(t => t.Key == "Store.URL").Value);
                string QRCodePath = string.Empty;
                if (!string.IsNullOrWhiteSpace(couponCode) && !string.IsNullOrWhiteSpace(storeUrl))
                {
                    QRCodePath = NopBarCodeImage.GenerateGiftCardCouponQRCode(couponCode);

                    if (!string.IsNullOrWhiteSpace(QRCodePath))
                    {
                        eventMessage.Tokens.Add(new Token("GiftCard.CouponQRCode", storeUrl + QRCodePath));
                    }
                }
            }
        }
    }
}