﻿using Nop.Core.Infrastructure;
using Nop.Core.Plugins;
using Nop.Services.Localization;
using Nop.Web.Framework.Menu;
using System.Web.Mvc;
using System.Linq;

namespace Shopfast.Plugin.Custom.Infrastructure
{
    public class Plugin:BasePlugin, IAdminMenuPlugin
    {
        public override void Install()
        {           
            //locales
            this.AddOrUpdatePluginLocaleResource("Admin.Catalog.Products.Fields.SearchGtin", "Barcode");
            this.AddOrUpdatePluginLocaleResource("Admin.Catalog.Products.Fields.BarcodeId", "Barcode Id");
            this.AddOrUpdatePluginLocaleResource("Admin.Catalog.Products.Fields.ShowOnPointOfSale", "Show on point of sale page");            
            this.AddOrUpdatePluginLocaleResource("Admin.Orders.Fields.Signature", "Signature");
            this.AddOrUpdatePluginLocaleResource("Admin.Orders.Fields.OrderTempId", "Order Temp Id");
            this.AddOrUpdatePluginLocaleResource("Admin.Configuration.Payment.Methods.Fields.IsPrimaryMethod", "Is primary");
            this.AddOrUpdatePluginLocaleResource("Admin.Configuration.Payment.Methods.Fields.IsTabletOnly", "Display On");
            this.AddOrUpdatePluginLocaleResource("Admin.Configuration.Settings.GeneralCommon.DefaultStoreThemeForAdmin", "Admin theme");
            this.AddOrUpdatePluginLocaleResource("Admin.StartMyStore", "Start My Store");
            this.AddOrUpdatePluginLocaleResource("Admin.StartMyStore.ContactInformation", "1. Contact Information");
            this.AddOrUpdatePluginLocaleResource("Admin.StartMyStore.Design", "2. Design");
            this.AddOrUpdatePluginLocaleResource("Admin.StartMyStore.Products", "3. Products");
            this.AddOrUpdatePluginLocaleResource("Admin.StartMyStore.Payments", "4. Payments");
            this.AddOrUpdatePluginLocaleResource("Admin.StartMyStore.Shipping", "5. Shipping");
            this.AddOrUpdatePluginLocaleResource("Admin.Configuration.Shipping.Methods", "Shipping methods");
            this.AddOrUpdatePluginLocaleResource("Admin.Configuration.Shipping.Restrictions", "Shipping method restrictions");
            this.AddOrUpdatePluginLocaleResource("Admin.Configuration.Shipping.Providers", "Shipping providers");            
        }

        public override void Uninstall()
        {
            this.DeletePluginLocaleResource("Admin.Catalog.Products.Fields.SearchGtin");
            this.DeletePluginLocaleResource("Admin.Catalog.Products.Fields.BarcodeId");
            this.DeletePluginLocaleResource("Admin.Catalog.Products.Fields.ShowOnPointOfSale");
            this.DeletePluginLocaleResource("Admin.Orders.Fields.Signature");
            this.DeletePluginLocaleResource("Admin.Orders.Fields.OrderTempId");
            this.DeletePluginLocaleResource("Admin.Configuration.Payment.Methods.Fields.IsPrimaryMethod");
            this.DeletePluginLocaleResource("Admin.Configuration.Payment.Methods.Fields.IsTabletOnly");
            this.DeletePluginLocaleResource("Admin.Configuration.Settings.GeneralCommon.DefaultStoreThemeForAdmin");
            this.DeletePluginLocaleResource("Admin.StartMyStore");
            this.DeletePluginLocaleResource("Admin.StartMyStore.ContactInformation");
            this.DeletePluginLocaleResource("Admin.StartMyStore.Design");
            this.DeletePluginLocaleResource("Admin.StartMyStore.Products");
            this.DeletePluginLocaleResource("Admin.StartMyStore.Payments");
            this.DeletePluginLocaleResource("Admin.StartMyStore.Shipping");
            this.DeletePluginLocaleResource("Admin.Configuration.Shipping.Methods");
            this.DeletePluginLocaleResource("Admin.Configuration.Shipping.Restrictions");
            this.DeletePluginLocaleResource("Admin.Configuration.Shipping.Providers");            
        }

        public void ManageSiteMap(SiteMapNode rootNode)
        {
            var helper = new UrlHelper(System.Web.HttpContext.Current.Request.RequestContext);
            var localizationService = EngineContext.Current.Resolve<ILocalizationService>();
            if (Nop.Core.Data.MultisiteHelper.IsAdminSite)
            {
                var menuItem = new SiteMapNode()
                {
                    SystemName = "RecuringOrderTaskConfig",
                    Title = localizationService.GetResource("Shopfast.Plugin.Customl.RecuringOrderTaskConfig.Title"),
                    Url = "/Admin/RecuringOrderTaskConfig",
                    Visible = true,
                    IconClass = "fa fa-dot-circle-o"
                };
                var firstNode = rootNode.ChildNodes.FirstOrDefault(x => x.SystemName == "System");
                if (firstNode != null)
                {
                    firstNode.ChildNodes.Add(menuItem);
                }
                else
                {
                    rootNode.ChildNodes.Add(menuItem);
                }
            }
        }
    }
}