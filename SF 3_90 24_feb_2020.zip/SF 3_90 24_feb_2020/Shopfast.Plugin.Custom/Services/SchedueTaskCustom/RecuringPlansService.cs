﻿using MultiSite.Data;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Nop.Core;
using Nop.Core.Domain.Orders;
using Nop.Services.Catalog;
using Nop.Services.Configuration;
using Nop.Services.Logging;
using Nop.Services.Orders;
using Nop.Services.Security;
using Shopfast.Plugin.Custom.Models.NopAdmin.Catalog;
using Shopfast.Plugin.Custom.Services.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Web;

namespace Shopfast.Plugin.Custom.Services.SchedueTaskCustom
{
    public class RecuringPlansService : IRecuringPlansService
    {
        private readonly ILogger _logger;
        private readonly IProductService _productService;
        private readonly IOrderService _orderService;
        private readonly ISettingService _settingService;
        private readonly IEncryptionService _encryptionService;
        private readonly IWorkflowMessageServiceCustom _workflowMessageServiceCustom;
        private readonly IPriceFormatter _priceFormatter;
        private readonly IWorkContext _workContext;
        private static string ShopfastAPIBaseUrl = System.Configuration.ConfigurationManager.AppSettings["ShopfastAPIBaseUrl"];

        public RecuringPlansService(ILogger logger, IProductService productService, ISettingService settingService,
          IOrderService orderService, IEncryptionService encryptionService,
          IWorkflowMessageServiceCustom workflowMessageServiceCustom, IPriceFormatter priceFormatter,
          IWorkContext workContext)
        {
            this._productService = productService;
            this._logger = logger;
            this._orderService = orderService;
            this._settingService = settingService;
            this._encryptionService = encryptionService;
            this._workflowMessageServiceCustom = workflowMessageServiceCustom;
            this._priceFormatter = priceFormatter;
            this._workContext = workContext;
        }

        public void ReOrderChecoutMultiple(List<Order> orders, AppProductListModel product, int months, List<SiteOrders> siteOrders, List<Owner> owners)
        {
            var productorders = orders.Where(o => o.OrderItems
                           .Any(orderItem => orderItem.Product.Id == product.Id) && o.CreatedOnUtc.Date.AddMonths(months) == DateTime.UtcNow.Date);
            if (productorders != null && productorders.Any())
            {
                _logger.Information("5. ReOrderChecoutMultiple - Get Product orders found for recuring period - " + months);
                foreach (var pOrder in productorders)
                {
                    string CardNumber = string.Empty;
                    string ExpiryMonth = string.Empty;
                    string ExpiryYear = string.Empty;
                    string VerifyCode = string.Empty;
                    var currentSiteOrder = new SiteOrders();
                    if (siteOrders != null && siteOrders.Any() && owners != null && owners.Any())
                    {
                        _logger.Information("5-1. ReOrderChecoutMultiple - pOrder " + pOrder.Id);
                        currentSiteOrder = siteOrders.OrderByDescending(s => s.CreationDate).FirstOrDefault(so => so.OrderId == pOrder.Id);
                        if (currentSiteOrder != null)
                        {
                            _logger.Information("5-2. ReOrderChecoutMultiple - currentSiteOrder " + currentSiteOrder.Id);
                            var owner = owners.FirstOrDefault(o => o.Id == currentSiteOrder.OwnerId);
                            if (owner != null)
                            {
                                _logger.Information("6-1. ReOrderChecoutMultiple - Owner encrypted crad info - card number : #" + owner.CardNumber + "# month : " + owner.ExpiryMonth + " year : " + owner.ExpiryYear + " CVV : " + owner.VerifyCode);
                                // Need to decrypt this card info
                                if (!string.IsNullOrEmpty(owner.CardNumber))
                                    CardNumber = _encryptionService.DecryptText(owner.CardNumber.Trim());
                                if (!string.IsNullOrEmpty(owner.ExpiryMonth))
                                    ExpiryMonth = _encryptionService.DecryptText(owner.ExpiryMonth.Trim());
                                if (!string.IsNullOrEmpty(owner.ExpiryYear))
                                    ExpiryYear = _encryptionService.DecryptText(owner.ExpiryYear.Trim());
                                if (!string.IsNullOrEmpty(owner.VerifyCode))
                                    VerifyCode = _encryptionService.DecryptText(owner.VerifyCode.Trim());
                                //CardNumber = "4111111111111111";
                                //ExpiryMonth = "12";
                                //ExpiryYear = "2020";
                                //VerifyCode = "999";
                                _logger.Information("6-2. ReOrderChecoutMultiple - Owner  decrypted crad info - card number : " + CardNumber + " month : " + ExpiryMonth + " year : " + ExpiryYear + " CVV : " + VerifyCode);
                            }
                        }
                    }
                    _logger.Information("7. ReOrderChecoutMultiple - Recuring for order id - " + pOrder.Id + " period - " + months + " Customer Email" + pOrder.Customer.Email);
                    string email = (pOrder.Customer != null) ? pOrder.Customer.Email : "";
                    if (!string.IsNullOrEmpty(CardNumber) &&
                        !string.IsNullOrEmpty(ExpiryMonth) &&
                        !string.IsNullOrEmpty(ExpiryYear) &&
                        !string.IsNullOrEmpty(VerifyCode))
                    {
                        _logger.Information("8. ReOrderChecoutMultiple - Checkout API started. card info found");
                        #region Checkout Transaction by API
                        CheckoutTransaction request = new CheckoutTransaction();
                        request.Products = product.Id.ToString();
                        request.Quantities = "1";
                        request.TotalAmount = Convert.ToDouble(pOrder.OrderTotal);
                        request.Email = email;
                        request.CardType = "Visa";
                        request.CardName = "test";
                        request.CardNumber = CardNumber;
                        request.ExpiryMonth = ExpiryMonth;
                        request.ExpiryYear = ExpiryYear;
                        request.VerifyCode = VerifyCode;
                        request.TransactionType = "card";
                        request.UseRewardPoints = false;
                        request.Attributes = null; // Need to ask Sanjay for how to pass attribute for reorder
                        request.IsWebOrder = true;

                        var jsonString = JsonConvert.SerializeObject(request);
                        var element = new JObject();
                        element["Data"] = jsonString;
                        byte[] byteData = Encoding.UTF8.GetBytes("{body}");
                        byteData = Encoding.UTF8.GetBytes(element.ToString());

                        using (var contentPayment = new ByteArrayContent(byteData))
                        {
                            contentPayment.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                            var client = new HttpClient();
                            var responsePayment = client.PostAsync(ShopfastAPIBaseUrl + "/sf_API/Service.svc/Json/CheckoutTransaction", contentPayment).Result;
                            if (responsePayment.IsSuccessStatusCode)
                            {
                                var checkoutResponse = responsePayment.Content.ReadAsAsync<CheckoutResponse>().Result;
                                if (checkoutResponse.CheckoutTransactionResult.Status && checkoutResponse.CheckoutTransactionResult.OrderId > 0)
                                {
                                    SiteOrders siteOrder = new SiteOrders();
                                    using (var dbContext = new Sites4Entities())
                                    {
                                        //Add this order to SiteOrders and make other orders IsActive to false for this store.
                                        var existingSiteOrders = dbContext.SiteOrders.FirstOrDefault(so => so.OrderId == pOrder.Id);
                                        _logger.Information("9. ReOrderChecoutMultiple - Old Site Order - " + JsonConvert.SerializeObject(existingSiteOrders));
                                        if (existingSiteOrders != null)
                                        {
                                            var orderUpdate = existingSiteOrders;
                                            existingSiteOrders.IsActive = false;
                                            dbContext.Entry(existingSiteOrders).CurrentValues.SetValues(orderUpdate);
                                            _logger.Information("10. ReOrderChecoutMultiple - Old Site Order Updated- " + JsonConvert.SerializeObject(existingSiteOrders));
                                        }

                                        siteOrder.StoreName = existingSiteOrders.StoreName;
                                        siteOrder.PackageId = product.Id;
                                        siteOrder.SiteId = existingSiteOrders.SiteId;
                                        siteOrder.OwnerId = existingSiteOrders.OwnerId;
                                        siteOrder.OwnerEmail = existingSiteOrders.OwnerEmail;
                                        siteOrder.PackageName = existingSiteOrders.PackageName;
                                        siteOrder.OrderId = checkoutResponse.CheckoutTransactionResult.OrderId;
                                        siteOrder.IsActive = true;
                                        siteOrder.CreationDate = DateTime.UtcNow;
                                        siteOrder.PlanExpirationDate = (months == 1) ? DateTime.UtcNow.AddMonths(1) : DateTime.UtcNow.AddYears(1); // this for yearly

                                        dbContext.SiteOrders.Add(siteOrder);
                                        dbContext.SaveChanges();

                                        // Send nitification email to store owner for successfull recuring store
                                    }
                                    _logger.Information("11. ReOrderChecoutMultiple - Recuring done successfully for Checkout response - " + JsonConvert.SerializeObject(checkoutResponse.CheckoutTransactionResult) + " at " + DateTime.UtcNow.ToString());
                                    _logger.Information("12. ReOrderChecoutMultiple - New Site Order added - " + JsonConvert.SerializeObject(siteOrder));
                                    _logger.Information("13. ReOrderChecoutMultiple - Old Order - " + pOrder.Id + " New Order Id - " + checkoutResponse.CheckoutTransactionResult.OrderId);

                                    if (siteOrder != null)
                                    {
                                        _workflowMessageServiceCustom.SendTransactionSuccessMessage(siteOrder, _priceFormatter.FormatPrice(pOrder.OrderTotal), _workContext.WorkingLanguage.Id);
                                        _logger.Information("14. ReOrderChecoutMultiple - Transaction success - Sending email to store owner");
                                    }
                                }
                                else
                                {
                                    // Send nitification email to store owner and to Admin customer of main store
                                    if (currentSiteOrder != null)
                                    {
                                        // Suspend the store
                                        using (var dbContext = new Sites4Entities())
                                        {
                                            var existingSite= dbContext.Sites.FirstOrDefault(so => so.Id == currentSiteOrder.SiteId);
                                            var siteUpdate = existingSite;
                                            existingSite.IsSuspend = true;
                                            dbContext.Entry(existingSite).CurrentValues.SetValues(siteUpdate);
                                            _logger.Information("9. ReOrderChecoutMultiple - Store is suspended for Store = " + currentSiteOrder.SiteId + ","+existingSite.StoreName+" , Transaction decline (Wrond Card) - Sending email to store owner and Admin");
                                        }                                        
                                        _workflowMessageServiceCustom.SendTransactionDeclineMessage(currentSiteOrder, _priceFormatter.FormatPrice(pOrder.OrderTotal), _workContext.WorkingLanguage.Id);
                                    }
                                    else
                                    {
                                        _logger.Information("9. ReOrderChecoutMultiple - Transaction decline (Wrond Card) - Current site order is null");
                                    }
                                }
                            }
                        }
                        #endregion
                    }
                }
            }
        }

        public bool ReOrderChecoutSingle(AppProductListModel product, int months, SiteOrders currentSiteOrder, Owner owner)
        {
            bool _bResult = false;
            Order pOrder = _orderService.GetOrderById(currentSiteOrder.OrderId);
            _logger.Information("5. ReOrderChecoutSingle - Get Product order found for recuring period - " + months);
            if (pOrder != null)
            {
                string CardNumber = string.Empty;
                string ExpiryMonth = string.Empty;
                string ExpiryYear = string.Empty;
                string VerifyCode = string.Empty;
                if (currentSiteOrder != null)
                {
                    if (owner != null)
                    {
                        _logger.Information("6-1. ReOrderChecoutSingle - Owner encrypted crad info - card number : #" + owner.CardNumber + "# month : " + owner.ExpiryMonth + " year : " + owner.ExpiryYear + " CVV : " + owner.VerifyCode);
                        // Need to decrypt this card info
                        if (!string.IsNullOrEmpty(owner.CardNumber))
                            CardNumber = _encryptionService.DecryptText(owner.CardNumber.Trim());
                        if (!string.IsNullOrEmpty(owner.ExpiryMonth))
                            ExpiryMonth = _encryptionService.DecryptText(owner.ExpiryMonth.Trim());
                        if (!string.IsNullOrEmpty(owner.ExpiryYear))
                            ExpiryYear = _encryptionService.DecryptText(owner.ExpiryYear.Trim());
                        if (!string.IsNullOrEmpty(owner.VerifyCode))
                            VerifyCode = _encryptionService.DecryptText(owner.VerifyCode.Trim());
                        //CardNumber = "4111111111111111";
                        //ExpiryMonth = "12";
                        //ExpiryYear = "2020";
                        //VerifyCode = "999";
                        _logger.Information("6-2. ReOrderChecoutSingle - Owner  decrypted crad info - card number : " + CardNumber + " month : " + ExpiryMonth + " year : " + ExpiryYear + " CVV : " + VerifyCode);
                    }
                }

                _logger.Information("7. ReOrderChecoutSingle - Recuring for order id - " + pOrder.Id + " period - " + months + " Customer Email" + pOrder.Customer.Email);
                string email = (pOrder.Customer != null) ? pOrder.Customer.Email : "";
                if (!string.IsNullOrEmpty(CardNumber) &&
                    !string.IsNullOrEmpty(ExpiryMonth) &&
                    !string.IsNullOrEmpty(ExpiryYear) &&
                    !string.IsNullOrEmpty(VerifyCode))
                {
                    _logger.Information("8. ReOrderChecoutSingle - Checkout API started. card info found");
                    #region Checkout Transaction by API
                    CheckoutTransaction request = new CheckoutTransaction();
                    request.Products = product.Id.ToString();
                    request.Quantities = "1";
                    request.TotalAmount = Convert.ToDouble(pOrder.OrderTotal);
                    request.Email = email;
                    request.CardType = "Visa";
                    request.CardName = "test";
                    request.CardNumber = CardNumber;
                    request.ExpiryMonth = ExpiryMonth;
                    request.ExpiryYear = ExpiryYear;
                    request.VerifyCode = VerifyCode;
                    request.TransactionType = "card";
                    request.UseRewardPoints = false;
                    request.Attributes = null; // Need to ask Sanjay for how to pass attribute for reorder
                    request.IsWebOrder = true;

                    var jsonString = JsonConvert.SerializeObject(request);
                    var element = new JObject();
                    element["Data"] = jsonString;
                    byte[] byteData = Encoding.UTF8.GetBytes("{body}");
                    byteData = Encoding.UTF8.GetBytes(element.ToString());

                    using (var contentPayment = new ByteArrayContent(byteData))
                    {
                        contentPayment.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                        var client = new HttpClient();
                        var responsePayment = client.PostAsync(ShopfastAPIBaseUrl + "/sf_API/Service.svc/Json/CheckoutTransaction", contentPayment).Result;
                        if (responsePayment.IsSuccessStatusCode)
                        {
                            var checkoutResponse = responsePayment.Content.ReadAsAsync<CheckoutResponse>().Result;
                            if (checkoutResponse.CheckoutTransactionResult.Status && checkoutResponse.CheckoutTransactionResult.OrderId > 0)
                            {
                                SiteOrders siteOrder = new SiteOrders();
                                using (var dbContext = new Sites4Entities())
                                {
                                    //Add this order to SiteOrders and make other orders IsActive to false for this store.
                                    var existingSiteOrders = dbContext.SiteOrders.FirstOrDefault(so => so.OrderId == pOrder.Id);
                                    _logger.Information("9. Old Site Order - " + JsonConvert.SerializeObject(existingSiteOrders));
                                    if (existingSiteOrders != null)
                                    {
                                        var orderUpdate = existingSiteOrders;
                                        existingSiteOrders.IsActive = false;
                                        dbContext.Entry(existingSiteOrders).CurrentValues.SetValues(orderUpdate);
                                        _logger.Information("10. Old Site Order Updated- " + JsonConvert.SerializeObject(existingSiteOrders));
                                    }

                                    siteOrder.StoreName = existingSiteOrders.StoreName;
                                    siteOrder.PackageId = product.Id;
                                    siteOrder.SiteId = existingSiteOrders.SiteId;
                                    siteOrder.OwnerId = existingSiteOrders.OwnerId;
                                    siteOrder.OwnerEmail = existingSiteOrders.OwnerEmail;
                                    siteOrder.PackageName = existingSiteOrders.PackageName;
                                    siteOrder.OrderId = checkoutResponse.CheckoutTransactionResult.OrderId;
                                    siteOrder.IsActive = true;
                                    siteOrder.CreationDate = DateTime.UtcNow;
                                    siteOrder.PlanExpirationDate = (months == 1) ? DateTime.UtcNow.AddMonths(1) : DateTime.UtcNow.AddYears(1); // this for yearly

                                    dbContext.SiteOrders.Add(siteOrder);
                                    dbContext.SaveChanges();

                                    // Send nitification email to store owner for successfull recuring store
                                }
                                _bResult = true;
                                _logger.Information("11. ReOrderChecoutSingle - Recuring done successfully for Checkout response - " + JsonConvert.SerializeObject(checkoutResponse.CheckoutTransactionResult) + " at " + DateTime.UtcNow.ToString());
                                _logger.Information("12. ReOrderChecoutSingle - New Site Order added - " + JsonConvert.SerializeObject(siteOrder));
                                _logger.Information("13. ReOrderChecoutSingle - Old Order - " + pOrder.Id + " New Order Id - " + checkoutResponse.CheckoutTransactionResult.OrderId + " , _bResult" + _bResult);                             
                                if (siteOrder != null)
                                {
                                    _workflowMessageServiceCustom.SendTransactionSuccessMessage(siteOrder, _priceFormatter.FormatPrice(pOrder.OrderTotal), _workContext.WorkingLanguage.Id);
                                    _logger.Information("14. ReOrderChecoutSingle - Transaction success - Sending email to store owner" + " , _bResult" + _bResult);
                                }
                            }
                            else
                            {
                                // Send nitification email to store owner and to Admin customer of main store
                                if (currentSiteOrder != null)
                                {
                                    _logger.Information("9. ReOrderChecoutSingle - Wrond Card - Sending email to store owner and Admin");
                                    _workflowMessageServiceCustom.SendTransactionDeclineMessage(currentSiteOrder, _priceFormatter.FormatPrice(pOrder.OrderTotal), _workContext.WorkingLanguage.Id);
                                }
                                else
                                {
                                    _logger.Information("9. ReOrderChecoutSingle - Wrond Card - Current site order is null");
                                }
                            }
                        }
                    }
                    #endregion
                }
            }
            return _bResult;
        }
    }
}