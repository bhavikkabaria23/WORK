﻿using Nop.Data;

namespace MultiSite.Data
{
    public class MultisiteObjectContext : NopObjectContext
    {
        public MultisiteObjectContext(string nameOrConnectionString)
            : base(Nop.Core.Data.MultisiteHelper.CurrentConnectionString) { }

        public MultisiteObjectContext(string nameOrConnectionString, bool noRewrite)
            : base(noRewrite ? nameOrConnectionString : Nop.Core.Data.MultisiteHelper.CurrentConnectionString) { }

        protected override void OnModelCreating(System.Data.Entity.DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            System.Data.Entity.Database.SetInitializer<MultisiteObjectContext>(null);
        }
    }
}
