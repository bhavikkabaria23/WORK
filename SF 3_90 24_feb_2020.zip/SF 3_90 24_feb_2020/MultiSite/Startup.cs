﻿using Microsoft.Owin;
using Owin;

namespace MultiSite
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            app.MapSignalR();
        }
    }
}