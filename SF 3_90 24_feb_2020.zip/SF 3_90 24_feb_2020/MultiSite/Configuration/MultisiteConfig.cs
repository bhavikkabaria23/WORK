﻿using System.Configuration;

namespace Nop.Core.Configuration
{
    public class MultisiteConfig : ConfigurationSection
    {
        [ConfigurationProperty("domain", DefaultValue = "shopfast.com")]
        public string Domain
        {
            get
            {
                return (string)base["domain"];
            }
        }

        [ConfigurationProperty("applicationName", DefaultValue = "SF")]
        public string ApplicationName
        {
            get
            {
                return (string)base["applicationName"];
            }
        }

        [ConfigurationProperty("trialDayCount", DefaultValue = "14")]
        public int TrialDayCount
        {
            get
            {
                return (int)base["trialDayCount"];
            }
        }

        [ConfigurationProperty("showPopupIntervalInMinutes", DefaultValue = "15")]
        public int ShowPopupIntervalInMinutes
        {
            get
            {
                return (int)base["showPopupIntervalInMinutes"];
            }
        }

        [ConfigurationProperty("showPopupWhenLeftDays", DefaultValue = "3")]
        public int ShowPopupWhenLeftDays
        {
            get
            {
                return (int)base["showPopupWhenLeftDays"];
            }
        }

        [ConfigurationProperty("defaultTheme", DefaultValue = "DefaultClean")]
        public string DefaultTheme
        {
            get
            {
                return (string)base["defaultTheme"];
            }
        }

        [ConfigurationProperty("newsFeedUrl", DefaultValue = "http://www.nopCommerce.com/NewsRSS.aspx")]
        public string NewsFeedUrl
        {
            get
            {
                return (string)base["newsFeedUrl"];
            }
        }

        [ConfigurationProperty("templateMappings")]
        public TemplateMappingConfigCollection TemplateMappings
        {
            get { return (TemplateMappingConfigCollection)this["templateMappings"]; }
        }
    }

    public class TemplateMappingConfig : ConfigurationSection
    {
        [ConfigurationProperty("dbFilename")]
        public string DatabaseFilename
        {
            get
            {
                return (string)base["dbFilename"];
            }
        }

        [ConfigurationProperty("industryType")]
        public string IndustryType
        {
            get
            {
                return (string)base["industryType"];
            }
        }
    }

    public class TemplateMappingConfigCollection : ConfigurationElementCollection
    {
        protected override ConfigurationElement CreateNewElement()
        {
            return new TemplateMappingConfig();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((TemplateMappingConfig)element).IndustryType;
        }
    }
}
