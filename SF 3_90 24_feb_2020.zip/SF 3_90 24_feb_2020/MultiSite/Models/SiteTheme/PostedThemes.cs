﻿//Store Template Theme
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MultiSite.Models.SiteTheme
{
    /// <summary>
    /// for Helper class to make posting back selected values easier
    /// </summary>
    public class PostedThemes
    {
        //this array will be used to POST values from the form to the controller
        public string[] ThemesValues { get; set; }
    }
}