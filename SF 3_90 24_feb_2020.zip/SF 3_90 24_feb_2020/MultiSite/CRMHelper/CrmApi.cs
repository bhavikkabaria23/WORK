﻿using Microsoft.Crm.Sdk.Samples.HelperCode;
using MultiSite.Models;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;


namespace MultiSite.CRMHelper
{
    public class CrmApi
    {
        //Start with base version and update with actual version later.
        private Version webAPIVersion = new Version(9, 0);

        private string getVersionedWebAPIPath()
        {
            return string.Format("v{0}/", webAPIVersion.ToString(2));
        }

        public async Task<bool> ShopfastStoreCRMPost(SiteRegistrationModel model)
        {

            Configuration config = null;
            config = new FileConfiguration(null);
            //Create a helper object to authenticate the user with this connection info.
            Authentication auth = new Authentication(config);
            //Next use a HttpClient object to connect to specified CRM Web service.
            var httpClient = new HttpClient(auth.ClientHandler, true);
            //Define the Web API base address, the max period of execute time, the 
            // default OData version, and the default response payload format.
            httpClient.BaseAddress = new Uri(config.ServiceUrl + "api/data/");

            // Generate json object from model
            var merchantForm = new JObject();
            // Store Creation form
            merchantForm.Add("new_yourstorename", model.storeName);
            merchantForm.Add("new_", model.email);

            // Store Registration form - 1
            merchantForm.Add("new_", model.email);

            // Store Registration form - 2
            merchantForm.Add("new_firstname", model.firstName);
            merchantForm.Add("new_lastname", model.lastName);
            merchantForm.Add("new_streetaddress1", model.StreetAddress);
            merchantForm.Add("new_streetaddress2", model.StreetAddress2);
            merchantForm.Add("new_city", model.City);
            merchantForm.Add("new_stateterritory", model.State);
            merchantForm.Add("new_country", model.Country);
            merchantForm.Add("new_zippostalcode", model.ZipPostalCode);
            merchantForm.Add("new_phonenumber", model.phone);
            merchantForm.Add("new_businessorpersonalwebsite", model.Website);

            HttpRequestMessage createRequest =
            new HttpRequestMessage(HttpMethod.Post, getVersionedWebAPIPath() + "new_shopfaststores");
            createRequest.Content = new StringContent(merchantForm.ToString(),
                Encoding.UTF8, "application/json");

            HttpResponseMessage createResponse =
                await httpClient.SendAsync(createRequest);
            if (createResponse.StatusCode == HttpStatusCode.NoContent) //204
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}