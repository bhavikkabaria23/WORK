﻿using System;
using System.Globalization;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Web;
using Microsoft.AspNetCore.Mvc;
using Nop.Web.Framework.Mvc.Filters;
using Nop.Web.Framework.Security;

namespace Nop.Web.Controllers
{
    public partial class HomeController : BasePublicController
    {
        [HttpsRequirement(SslRequirement.No)]
        public virtual IActionResult Index()
        {
            //VippsAPI();
            return View();
        }

        public static string FormatIso8601(DateTimeOffset dto)
        {
            string format = dto.Offset == TimeSpan.Zero
                ? "yyyy-MM-ddTHH:mm:ss.fffZ"
                : "yyyy-MM-ddTHH:mm:ss.fffzzz";

            return dto.ToString(format, CultureInfo.InvariantCulture);
        }

        private void VippsAPI()
        {
            string error = "";
            var paymentResponse = new PaymentResponse();
            try
            {
                var client = new HttpClient();
                var queryString = HttpUtility.ParseQueryString(string.Empty);

                // Request headers
                client.DefaultRequestHeaders.Add("client_id", "8da4ff12-dcc5-46b1-94e3-8711b3f1beb0");
                client.DefaultRequestHeaders.Add("client_secret", "VGNBNFBaaFJZd1JVbjJ4TVB1ZXo=");
                client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "7054d5ec81714b55bcbbdaa3f7d9b2e6");

                var uriToken = "https://apitest.vipps.no" + "/accessToken/get";

                HttpResponseMessage responseToken;

                // Request body
                byte[] byteData = Encoding.UTF8.GetBytes("{body}");

                using (var content = new ByteArrayContent(byteData))
                {
                    //content.Headers.ContentType = new MediaTypeHeaderValue("application/json; charset=utf-8");
                    responseToken = client.PostAsync(uriToken, content).Result;
                    if (responseToken.IsSuccessStatusCode)
                    {
                        var tokenResult = responseToken.Content.ReadAsAsync<TokenResult>().Result;
                        client = new HttpClient();

                        //var date = new DateTimeOffset(2016, 3, 29, 12, 20, 35, 93, TimeSpan.FromHours(-5));
                        var date = new DateTimeOffset(DateTime.Now);

                        // Request headers
                        client.DefaultRequestHeaders.Add("Authorization", "Bearer " + tokenResult.access_token);
                        client.DefaultRequestHeaders.Add("X-Request-Id", "asia123");
                        client.DefaultRequestHeaders.Add("X-TimeStamp", FormatIso8601(date));
                        //client.DefaultRequestHeaders.Add("X-TimeStamp", "2014-06-24T08:34:25-07:00");
                        client.DefaultRequestHeaders.Add("X-Source-Address", "0.0.0.0");
                        client.DefaultRequestHeaders.Add("X-App-Id", "8da4ff12-dcc5-46b1-94e3-8711b3f1beb0");
                        client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "7054d5ec81714b55bcbbdaa3f7d9b2e6");
                        //client.DefaultRequestHeaders.Add("Content-Type", "application/json");

                        var uriPayment = "https://apitest.vipps.no" + "/Ecomm/v1/payments";

                        HttpResponseMessage responsePayment;

                        // Request body

                        Random ran = new Random();
                        int orderId = ran.Next();
                        string mobileNumber = "90935902";

                        string bodyContent = "{{" +
         "\"merchantInfo\": {{" +
         "\"merchantSerialNumber\": \"{0}\"," +
         "\"callBack\": \"{1}\"" +
         "}}," +
         "\"customerInfo\": {{" +
         "\"mobileNumber\":\"{2}\"" +
         "}}," +
         "\"transaction\": {{" +
         "\"orderId\": \"{3}\"," +
         //"\"refOrderId\": \"{4}\"," +
         "\"amount\": {4}," +
         "\"transactionText\": \"{5}\"," +
         "\"timeStamp\":\"{6}\"" +
         "}}" +
         "}}";


                        //            string bodyContent = "{" +
                        //"\"merchantInfo\": {" +
                        //"\"merchantSerialNumber\": \"" + _VippsPaymentSettings.MerchantSerialNumber + "\"," +
                        //"\"callBack\": \"" + _VippsPaymentSettings.PaymentCallBackUrl + "\"" +
                        //"}," +
                        //"\"customerInfo\": {" +
                        //"\"mobileNumber\":\"" + mobileNumber + "\"" +
                        //"}," +
                        //"\"transaction\": {" +
                        //"\"orderId\": \"" + request.InitialOrderId + "\"," +
                        //     "\"refOrderId\": \"" + request.OrderGuid + "\"," +
                        //"\"amount\": " + request.OrderTotal + "," +
                        //"\"transactionText\": \"" + _VippsPaymentSettings.TransactionText + "\"," +
                        //"\"timeStamp\":\"" + FormatIso8601(date) + "\"" +
                        //"}" +
                        //"}";

                        // bodyContent = string.Format(bodyContent,
                        //_VippsPaymentSettings.MerchantSerialNumber,
                        //_VippsPaymentSettings.PaymentCallBackUrl,
                        //mobileNumber,
                        //    "878798",
                        // "119930211",
                        ////request.OrderGuid.ToString(),
                        ////request.OrderGuid.ToString(),
                        //Convert.ToInt32(request.OrderTotal),
                        //_VippsPaymentSettings.TransactionText,
                        //"2014-06-24T08:34:25-07:00"
                        ////FormatIso8601(date)
                        //);

                        bodyContent = string.Format(bodyContent,
                            "212052",
                      "https://www.demo.no/api/callback",
                        mobileNumber,
                            orderId.ToString(),
                            //request.OrderGuid.ToString(),
                            Convert.ToInt32(150 * 100),
                            "test trasaction",
                            "2014-06-24T08:34:25-07:00");

                        byteData = Encoding.UTF8.GetBytes(bodyContent);

                        using (var contentPayment = new ByteArrayContent(byteData))
                        {
                            contentPayment.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                            responsePayment = client.PostAsync(uriPayment, contentPayment).Result;
                            if (responsePayment.IsSuccessStatusCode)
                            {
                                paymentResponse = responsePayment.Content.ReadAsAsync<PaymentResponse>().Result;
                                if (!string.IsNullOrEmpty(paymentResponse.errorCode))
                                {
                                    error = "errorCode = " + paymentResponse.errorCode + " ,errorGroup = " + paymentResponse.errorGroup + " ,errorMessage = " + paymentResponse.errorMessage + ", ";
                                }
                            }
                            else
                            {
                                error += "Status Code = " + responsePayment.StatusCode + " ,Request = " + responsePayment.RequestMessage;
                            }
                        }
                    }
                }                
            }
            catch (Exception ex)
            {
                // Something else went wrong, e.g. invalid arguments passed to the order object.
                error = ex.Message;                
            }
        }
    }

    public class PaymentResponse
    {
        public string orderId { get; set; }
        public string merchantSerialNumber { get; set; }
        public TransactionInfo transactionInfo { get; set; }
        public TransactionSummary transactionSummary { get; set; }
        public string errorCode { get; set; }
        public string errorGroup { get; set; }
        public string errorMessage { get; set; }
    }

    public class TransactionInfo
    {
        public string amount { get; set; }
        public string status { get; set; }
        public string transactionId { get; set; }
        public string timeStamp { get; set; }
        public string message { get; set; }
        public string transactionText { get; set; }
    }
    public class TransactionSummary
    {
        public string capturedAmount { get; set; }
        public string remainingAmoutTocapture { get; set; }
        public string refundedAmount { get; set; }
        public string remainingAmountToRefund { get; set; }
    }


    public class TokenResult
    {
        public string access_token { get; set; }
    }
}