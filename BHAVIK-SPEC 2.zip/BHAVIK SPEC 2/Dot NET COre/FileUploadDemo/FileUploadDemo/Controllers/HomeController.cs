﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using FileUploadDemo.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using System.IO;
using System.Threading;
using Microsoft.AspNetCore.Diagnostics;

namespace FileUploadDemo.Controllers
{
    public class HomeController : Controller
    {
        private IHostingEnvironment _environment;

        private static List<long> _lnumbers = new List<long>();


        public HomeController(IHostingEnvironment environment)
        {
            _environment = environment;
        }

        private IActionResult subindex()
        {
            HomeModel model = new HomeModel();
            model.Name = "Bhvaik";
            TempData["SuccessMessage"] = "sucess message";
            return View();
        }
        public IActionResult Index()
        {
            List<HomeModel> lstmodel = new List<HomeModel>();
            List<OfferViewModel> innerlist = new List<OfferViewModel>();
            innerlist.Add(new OfferViewModel(){ StaticCode = "123"});
            innerlist.Add(new OfferViewModel() { StaticCode = "134" });
            innerlist.Add(new OfferViewModel() { StaticCode = "1678" });
            lstmodel.Add(new HomeModel()
            {
                Name = "bhavik",
                list = innerlist
            });
            innerlist = new List<OfferViewModel>();
            innerlist.Add(new OfferViewModel() { StaticCode = "234" });
            innerlist.Add(new OfferViewModel() { StaticCode = "256" });
            innerlist.Add(new OfferViewModel() { StaticCode = "287" });
            lstmodel.Add(new HomeModel()
            {
                Name = "Biren",
                list = innerlist
            });
            innerlist = new List<OfferViewModel>();
            innerlist.Add(new OfferViewModel() { StaticCode = "345" });
            innerlist.Add(new OfferViewModel() { StaticCode = "376" });
            innerlist.Add(new OfferViewModel() { StaticCode = "388" });
            lstmodel.Add(new HomeModel()
            {
                Name = "Dev",
                list = innerlist
            });

            foreach (var item in lstmodel)
            {
                item.list.ForEach(s =>
                {
                    s.StaticCode2 = item.Name+ " code";
                });
            }

            var skills = lstmodel.SelectMany(e => e.list, (e, s) => new { e.Name, s });


            List<HomeModel> lst = new List<HomeModel>();
            lst.Add(new HomeModel()
            {
                total = 10,
                Name = "bhavik"
            });
            lst.Add(new HomeModel()
            {
                total = 20,
                Name = "sanjay"
            });
            lst.Add(new HomeModel()
            {
                total = 30,
                Name = "biren"
            });

            var obj = lst.FirstOrDefault(l => l.Name == "bhavik");
            obj.total = obj.total + 70;
            

            Task.Run(() =>
            {
                for (long i = 0; i < 10; i++)
                {
                    _lnumbers.Add(i);
                    Thread.Sleep(2000);
                }
            });
            
            return View();
        }

        //[HttpPost]
        //public async Task<IActionResult> Index(ICollection<IFormFile> files)
        //{
        //    var uploads = Path.Combine(_environment.WebRootPath, "uploads");
        //    foreach (var file in files)
        //    {
        //        if (file.Length > 0)
        //        {
        //            using (var fileStream = new FileStream(Path.Combine(uploads, file.FileName), FileMode.Create))
        //            {
        //                await file.CopyToAsync(fileStream);
        //            }
        //        }
        //    }
        //    return View();
        //}

        [HttpPost]
        public async Task<IActionResult> Index(HomeModel model)
        {
           




            //var uploads = Path.Combine(_environment.WebRootPath, "uploads");

            //    if (file.Length > 0)
            //    {
            //        using (var fileStream = new FileStream(Path.Combine(uploads, Guid.NewGuid() + ".jpg"), FileMode.Create))
            //        {
            //            await file.CopyToAsync(fileStream);
            //        }
            //    }

            TempData["SuccessMessage"] = "fdfdfsdf";
            //return RedirectToAction("About", "Home");    
            Helper.IsValidate(ModelState);
            ViewBag.numbers = _lnumbers.Count();
            return View(model);
        }

        public IActionResult About()
        {
            var s = TempData["SuccessMessage"];
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            var m = TempData["model"] as HomeModel;
            var message = TempData["SuccessMessage"];
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Error()
        {
            // Get the details of the exception that occurred
            var exceptionFeature = HttpContext.Features.Get<IExceptionHandlerPathFeature>();

            if (exceptionFeature != null)
            {
                // Get which route the exception occurred at
                string routeWhereExceptionOccurred = exceptionFeature.Path;

                // Get the exception that occurred
                Exception exceptionThatOccurred = exceptionFeature.Error;
                //exceptionThatOccurred.InnerException + exceptionThatOccurred.Message;

                // TODO: Do something with the exception
                // Log it with Serilog?
                // Send an e-mail, text, fax, or carrier pidgeon?  Maybe all of the above?
                // Whatever you do, be careful to catch any exceptions, otherwise you'll end up with a blank page and throwing a 500
            }

            return View();
        }
    }

    public class HomeModel
    {
        public HomeModel()
        {
            list = new List<OfferViewModel>();
        }
        public string Name { get; set; }
        public int total { get; set; }
        //public OfferViewModel CustomerOffer { get; set; }

        public List<OfferViewModel> list { get; set; }        
    }   

    public class OfferViewModel
    {
        public string StaticCode { get; set; }
        public string StaticCode2 { get; set; }
    }
}
