﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FileUploadDemo.Models
{
    public class Helper
    {
        public static void IsValidate(ModelStateDictionary ModelState)
        {
            int i = 0;
            var r = 5 / i;
            ModelState.AddModelError("Name",
                        "Please enter name");
        }
    }
}
