﻿using System;
using SendGrid;
using SendGrid.Helpers.Mail;
using System.Net.Mail;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;


namespace SendGridDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            var _oFrom = new MailAddress("no_reply@redeal.se", "Send Grid Example");
            var _oSender = new MailAddress("no_reply@redeal.se");
            // var    _oSender = new MailAddress("no_reply@redeal.se","Send Grid Example");
            var from = new EmailAddress(_oFrom.Address, _oSender.DisplayName);

            var client2 = new SendGridClient("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");
            //var from = new EmailAddress("no_reply@redeal.se", "Send Grid Example");
            var subject = "Sending with SendGrid testing";
            var to = new EmailAddress("bhavik.kabaria@spec-india.com", "Send Grid Example");
            var plainTextContent = "Send grid email body testing";
            var htmlContent = "<a href='http://google.com'>Link</a> <strong> Send grid email body testing with HTML</strong>";
            var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);
            msg.SetClickTracking(false, true);
            //var response = client2.SendEmailAsync(msg).Result;
            client2.SendEmailAsync(msg);


            // IEnumerable<string> values;
            // if (response.Headers.TryGetValues("X-Message-Id", out values) && values != null && values.Any())
            // {
            //     string session = values.FirstOrDefault();
            // }

            // var r = JsonConvert.SerializeObject(response);

            //            client2.SendEmailAsync(msg);

            // var client3 = new SendGridClient("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");
            // HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, "https://api.sendgrid.com/v3/messages?limit=1000&query=last_event_time%20BETWEEN%20TIMESTAMP%20%222018-11-15T00%3A00%3A00.000Z%22%20AND%20TIMESTAMP%20%222018-11-15T23%3A59%3A59.000Z%22");


            // var res = client3.MakeRequest(request).Result;
            // var json = JsonConvert.SerializeObject(res);
            var d1 = DateTime.UtcNow.Date.ToString("s");
            var d2 = DateTime.UtcNow.AddDays(-1).Date.ToString("yyyy-MM-dd");
            d2 = d2+"T00%3A00%3A00.000Z";

            // using (var client = new HttpClient())
            // {
            //     // client.BaseAddress = new Uri("https://api.sendgrid.com/");
            //     client.DefaultRequestHeaders.Accept.Clear();
            //     client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            //     client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", "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");
            //     // HttpRequestMessage req = new HttpRequestMessage(HttpMethod.Get, "v3/messages?limit=1000&query=last_event_time%20BETWEEN%20TIMESTAMP%20%222018-11-15T00%3A00%3A00.000Z%22%20AND%20TIMESTAMP%20%222018-11-15T23%3A59%3A59.000Z%22");
            //     //HttpRequestMessage req = new HttpRequestMessage(HttpMethod.Get, "v3/messages?query=last_event_time>%3DTIMESTAMP%20%20%222018-11-15T23%3A59%3A59.000Z%22&limit=10");
            //     //HttpRequestMessage req = new HttpRequestMessage(HttpMethod.Get, string.Format("https://api.sendgrid.com/v3/messages?query=last_event_time>%3DTIMESTAMP%20%20%22{0}%22&limit=10",d2));
            //     HttpRequestMessage req = new HttpRequestMessage(HttpMethod.Get, "https://api.sendgrid.com/v3/messages?query=last_event_time>%3DTIMESTAMP%20%20%22"+d2+"%22&limit=10");
            //     HttpResponseMessage httpRequest = client.SendAsync(req, HttpCompletionOption.ResponseContentRead).Result;
            //     var json = httpRequest.Content.ReadAsStringAsync().Result;                
            // }
        }
    }
}
