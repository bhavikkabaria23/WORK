﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;

namespace ExportCouponData
{
    class Program
    {
        static MongoClient mongoClient = new MongoClient("mongodb://35.163.222.141:27018/Redeal");
        static IMongoDatabase _oIMongoDatabase = mongoClient.GetDatabase("Redeal");

        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            //GetCouponData();
            GetDealData();
        }

        public static void GetDealData()
        {
            Stopwatch stopWatch = new Stopwatch();

            stopWatch.Start();
            var list = GetCampaignEnumerable("Campaigns", Builders<BsonDocument>.Filter.Empty);
            stopWatch.Stop();

            stopWatch.Start();
            var listcursor = GetCampaignCursor("Campaigns", Builders<BsonDocument>.Filter.Empty);
            stopWatch.Stop();

            Console.WriteLine(stopWatch.ElapsedMilliseconds);
        }

        public static IEnumerable<BsonDocument> GetCampaignEnumerable(string _sCollectionName, FilterDefinition<BsonDocument> _fFilter)
        {
            IMongoCollection<BsonDocument> _oCollection = _oIMongoDatabase.GetCollection<BsonDocument>(_sCollectionName);
            return _oCollection.Find(_fFilter).ToEnumerable();
        }

        public static IAsyncCursor<BsonDocument> GetCampaignCursor(string _sCollectionName, FilterDefinition<BsonDocument> _fFilter)
        {
            IMongoCollection<BsonDocument> _oCollection = _oIMongoDatabase.GetCollection<BsonDocument>(_sCollectionName);

            return _oCollection.Find(_fFilter).ToCursor();
        }

        public static void GetCouponData()
        {
            IAggregateFluent<BsonDocument> _listOfCoupon;

            Stopwatch stopWatch = new Stopwatch();

            stopWatch.Start();
            _listOfCoupon = GetBsonDocumentList("Coupons", Builders<BsonDocument>.Filter.And(Builders<BsonDocument>.Filter.Eq("IsOptIn", true), Builders<BsonDocument>.Filter.Eq("Type", 0)));
            stopWatch.Stop();
            Console.WriteLine(stopWatch.ElapsedMilliseconds);

            using (var fs = new FileStream(@"D:\ExportData\CouponData.csv", FileMode.Create))
            {
                using (var sw = new StreamWriter(fs))
                {
                    int i = 0;
                    sw.WriteLine($"\"Phone\",\"Email\",\"Company Name\",\"Branch\",\"City\",\"Campaign Name\",\"Language\"");
                    foreach (var data in _listOfCoupon.ToEnumerable())
                    {
                        string Phone = string.Empty, Email = string.Empty, CompanyName = string.Empty, Branch = string.Empty, City = string.Empty, CampaignName = string.Empty, Language = string.Empty;

                        Phone = data["users"].AsBsonValue["Phone"].ToString().Replace(",", "");
                        Email = data["users"].AsBsonValue["Email"].ToString().Replace(",", "");
                        CompanyName = data["company"].AsBsonValue["CompanyName"].ToString().Replace(",", "");
                        Branch = data["company"].AsBsonValue["Branch"].ToString().Replace(",", "");
                        City = data["company"].AsBsonValue["Address"].AsBsonValue["City"].ToString().Replace(",", "");
                        CampaignName = data["campaign"].AsBsonValue["Name"].ToString().Replace(",", "");
                        Language = data["language"].AsBsonValue["Name"].ToString().Replace(",", "");

                        sw.WriteLine($"\"{ Phone }\",\"{ Email }\",\"{ CompanyName }\",\"{ Branch }\",\"{ City }\",\"{ CampaignName }\",\"{ Language }\"");
                        i++;
                        Console.WriteLine(i);
                    }
                }
            }

            Console.WriteLine("Hello");
        }

        public static IAggregateFluent<BsonDocument> GetBsonDocumentList(string _sCollectionName, FilterDefinition<BsonDocument> _fFilter)
        {
            FieldDefinition<BsonDocument> userlocalfield = "UserId";
            FieldDefinition<BsonDocument> userforeignfield = "_id";
            FieldDefinition<BsonDocument> userasfield = "users";

            FieldDefinition<BsonDocument> companieslocalfield = "CompanyId";
            FieldDefinition<BsonDocument> companiesforeignfield = "_id";
            FieldDefinition<BsonDocument> companiesasfield = "company";

            FieldDefinition<BsonDocument> campaignslocalfield = "CampaignId";
            FieldDefinition<BsonDocument> campaignsforeignfield = "_id";
            FieldDefinition<BsonDocument> campaignsasfield = "campaign";

            FieldDefinition<BsonDocument> languagelocalfield = "campaign.Language";
            FieldDefinition<BsonDocument> languageforeignfield = "Value";
            FieldDefinition<BsonDocument> languageasfield = "language";


            IMongoCollection<BsonDocument> _oCollection = _oIMongoDatabase.GetCollection<BsonDocument>(_sCollectionName);
            return _oCollection.Aggregate()
                .Match(_fFilter)
                .Lookup("RUsers", userlocalfield, userforeignfield, userasfield).Unwind(userasfield)
                .Lookup("Companies", companieslocalfield, companiesforeignfield, companiesasfield).Unwind(companiesasfield)
                .Lookup("Campaigns", campaignslocalfield, campaignsforeignfield, campaignsasfield).Unwind(campaignsasfield)
                .Lookup("Language", languagelocalfield, languageforeignfield, languageasfield).Unwind(languageasfield);
        }
    }
}
