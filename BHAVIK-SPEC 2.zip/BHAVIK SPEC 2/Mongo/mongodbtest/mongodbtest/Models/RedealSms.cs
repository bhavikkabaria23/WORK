﻿using System;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace mongodbtest.Models
{
    [CollectionName("Smses")]
    [BsonIgnoreExtraElements]
    public class RedealSms: IDbEntity<ObjectId>
    {
        public ObjectId Id { get; set; }

        public string Phone { get; set; }

        public string Sender { get; set; }
                
        public string Message { get; set; }

        public string Code { get; set; }

        public string Pin { get; set; }

        public string CouponValue { get; set; }

        public DateTime CodeExpirationDate { get; set; }

        public string WebSite { get; set; }

        public ObjectId CampaignId { get; set; }

        public ObjectId UserId { get; set; }

        public SmsSendingStatus Status { get; set; }

        public DateTime Created { get; set; }

        public long? TrackingId { get; set; }

        public SmsType Type { get; set; }

        public string Link { get; set; }

        public Language Language { get; set; }

        public string ExpirationDate { get; set; }

        [BsonIgnoreIfNull]
        public string FullLink { get; set; }
        [BsonIgnoreIfNull]
        public ObjectId? CouponId { get; set; }

    }

    public enum Language
    {
        sv,
        en,
        no,
        ru,
        fi,
        dk,
        de,
        fr,
        nl,
        pl
    }

    public enum SmsType
    {
        Invitation = 0,
        Storing = 1,
        Remind = 2
    }

    public enum SmsSendingStatus
    {
        Ready = 0,
        Sending = 1,
        Sent = 2,
        Delivered = 3,
        Failed = 4
    }
}
