﻿using System;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace mongodbtest.Models
{
    [CollectionName("Coupons")]
    public class Coupon : IDbEntity<ObjectId>
    {
        [BsonId]
        public ObjectId Id { get; set; }

        public ObjectId? UserId { get; set; }

        [BsonRequired]
        public ObjectId CampaignId { get; set; }

        [BsonRequired]
        public ObjectId CompanyId { get; set; }

        public CouponType Type { get; set; }

        public bool IsAvailable { get; set; }      

        public string Code { get; set; }

        public string NormalizedCode { get; set; }

        public string CodeValue { get; set; }
        
        public string Pin { get; set; }

        [BsonDateTimeOptions(Kind = DateTimeKind.Utc)]
        public DateTime ExpirationDate { get; set; }
       
        [BsonDateTimeOptions(Kind = DateTimeKind.Utc)]
        public DateTime? IssuedAt { get; set; }

        public bool WasSeen { get; set; }
 
        public bool SavedUsingEmail { get; set; }
       
        public bool SavedUsingSms  { get; set; }
      
        public bool IsOptIn  { get; set; }

        public InvitationChannel? InvitationChannel { get; set; }

        public bool IsDeleted { get; set; } = false;

    }

    public enum CouponType
    {
        Customer,
        Friend,
        Guest
    }
    public enum InvitationChannel
    {
        Facebook,
        Sms,
        Email
    }
    [AttributeUsage(AttributeTargets.Class)]
    public class CollectionNameAttribute : Attribute
    {
        public CollectionNameAttribute(string name)
        {
            Name = name;
        }

        public string Name { get; set; }
    }

    public interface IDbEntity<TKey>
    {
        TKey Id { get; set; }
    }
}
