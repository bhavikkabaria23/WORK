﻿using System.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MongoDB;
using MongoDB.Driver;
using MongoDB.Bson;
using MongoDB.Driver.Builders;
using mongodbtest.Models;
using System.Drawing;

namespace mongodbtest
{
    public partial class Default : System.Web.UI.Page
    {
        private MongoClient _mongoClient;
        private MongoServer _mongoServer;
        private MongoDatabase _mongoDatabase;
        protected IMongoCollection<RedealSms> Collection;

        protected void Page_Load(object sender, EventArgs e)
        {
            ////String _con = "mongodb://52.89.99.9:27017,52.89.99.9:29017/Redeal?connect=replicaSet";
            ////String _con = "mongodb://52.89.99.9:27017,52.89.99.9:29017/Redeal?connect=replicaSet";
            ////String _con = "mongodb://52.89.99.9:27017,52.89.99.9:29017/Redeal?replicaSet=RepSet&readPreference=secondaryPreferred";
            //String _con = "mongodb://52.89.99.9:25017,52.89.99.9:29017/Redeal?w=0&readPreference=primaryPreferred";
            ////String _con = "mongodb://52.89.99.9:29017,52.89.99.9:27017/Redeal";
            ////String _con = "mongodb://52.89.99.9:29017/Redeal";
            ////String _con = "mongodb://52.89.99.9:27017?replicaSet=Repset";
            ////mongodb://username:password@52.89.99.9:27017?replicaSet=Repset
            ////String _con = "mongodb://52.89.99.9:27017/Redeal";
            ////            String _con = "mongodb://localhost/Redeal";
            //String _db = "Redeal";
            //MongoUrl connection = new MongoUrl(_con);
            //_mongoClient = new MongoClient(connection);
            ////_mongoServer = _mongoClient.GetServer();
            ////_mongoDatabase = _mongoServer.GetDatabase(_db);            
            //var database = _mongoClient.GetDatabase(connection.DatabaseName);
            ////database.CreateCollection("testReplica3");

            //int i = database.ListCollections().ToList().Count();
            //try
            //{
            //    Response.Write(database.ListCollections().ToList().Count().ToString());
            //}
            //catch (Exception _ae)
            //{
            //    Response.Write("failed");
            //}


            
            String _con = ConfigurationManager.AppSettings["ConnectionString"];
            String _db = "Redeal";
            MongoUrl connection = new MongoUrl(_con);
            _mongoClient = new MongoClient(connection);
            var database = _mongoClient.GetDatabase(connection.DatabaseName);
            try
            {
                DateTime from = DateTime.Now.Date;
                from = 
                from = new DateTime(from.Year, from.Month, from.Day, 0, 0, 0);
                Collection = database.GetCollection<RedealSms>("Smses");
                totalSMS.Text = Convert.ToString(Collection.Find(v =>v.Created >= DateTime.UtcNow.Date).Count());
                long ready = Collection.Find(v => v.Created >= DateTime.Now.Date && v.Status == SmsSendingStatus.Ready).Count();
                readySMS.Text = Convert.ToString(ready);
                if(ready > 10)
                {
                    readySMS.BackColor = Color.Red;
                }
                else
                {
                    readySMS.BackColor = Color.Green;
                }
                readySMS.ForeColor = Color.White;
                readySMS.Font.Bold = true;
                sentSMS.Text = Convert.ToString(Collection.Find(v => v.Created >= DateTime.UtcNow.Date && v.Status == SmsSendingStatus.Sent).Count());
                //db.getCollection('Smses').find({ "Created":{$gte: new ISODate("2017-12-01") },"Status":0}).count()
                //db.getCollection('Smses').find({ "Created":{$gte: new ISODate("2017-12-01") } }).count()
            }
            catch (Exception _ae)
            {
                Response.Write("failed");
            }
        }
    }
}