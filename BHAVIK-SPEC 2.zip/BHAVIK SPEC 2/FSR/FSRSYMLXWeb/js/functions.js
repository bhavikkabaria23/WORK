// JavaScript Document
/**
 * To


the try catch error message
 */
function $dumpError(err) {
    if (typeof err === 'object') {
        if (err.message) {
            $consoleLog('\nMessage: ' + err.message);
            console.info('\nMessage: ' + err.message)
        }
        if (err.stack) {
            console.info('\nStacktrace:')
            console.info('====================')
            console.info(err.stack);
            $consoleLog(err.stack);
        }
    } else {
        console.info('dumpError :: argument is not an object');
    }

}

/*For getting the csv object and inspecting*/
function $simpleObjInspect(oObj, key, tabLvl) {
    key = key || "";
    tabLvl = tabLvl || 1;
    var tabs = "";
    for (var i = 1; i < tabLvl; i++) {
        tabs += "\t";
    }
    var keyTypeStr = " (" + typeof key + ")";
    if (tabLvl == 1) {
        keyTypeStr = "(self)";
    }
    var s = tabs + key + keyTypeStr + " : ";
    if (typeof oObj == "object" && oObj !== null) {
        s += typeof oObj + "\n";
        for (var k in oObj) {
            if (oObj.hasOwnProperty(k)) {
                s += $simpleObjInspect(oObj[k], k, tabLvl + 1);
            }
        }
    } else {
        s += "" + oObj + " (" + typeof oObj + ") \n";
    }
    return s;
}


/**
 * To handle the try catch errors
 */
function $handleTryCatchError(error) {
    $dumpError(error);
}

/* Custom functions for handling events */

/* On clicking cancel button*/
function $onClickCancelButton() {

    location.reload();		//Get the fresh page
    $startIpsPlanner();
}

/* On clicking cancel button */
function $onPrintButton() {
    var isPrintable = 0;
    //For maintaining the array to display in part list
    $.each(_arrayOfPlates, function (key1, val1) {
        isPrintable = 1;
    });

    /* Checking if the images are available to print or not */
    //isPrintable = 1;
    if (isPrintable == 1) {

        var ua = navigator.userAgent.toLowerCase();
        var isAndroid = ua.indexOf("android") > -1; //&& ua.indexOf("mobile");
        if (isAndroid) {
            // Do something!
            alert('Your device browser does not support printing, please take a screen shot from the menu bar.');
        } else {
            window.print();
        }
    }
}

/* On starting ips planner i.e click on start button. Not in use */
function $startIpsPlanner() {

}

/* On drags event */
function $onDrags(_draggedId, ev, dd) {
    /* Limiting the movement of images */
    $(dd.proxy).css({
        top: Math.min(dd.limit.bottom, Math.max(dd.limit.top, dd.offsetY)),
        left: Math.min(dd.limit.right, Math.max(dd.limit.left, dd.offsetX))
    });
}

/* On drag start */
function $onDragStarts(_draggedId, ev, dd) {

    var result = false;
    var arrResult = {};
    var _insertDragging = [];
    var _arrayOfPartsDisplayTemp = [];

    /* Div to limit the drag out of the main canvas div */
    var $div = $('#' + dragRegionAreaId);
    console.log("ondrags bottom - " + dragRegionAreaId);
    dd.limit = $div.offset(); //for limiting the movement out of the target div
    dd.limit.bottom = dd.limit.top + $div.outerHeight() - $('#' + _draggedId + '').outerHeight();
    dd.limit.right = dd.limit.left + ($div.outerWidth() + 0) - $('#' + _draggedId + '').outerWidth();

    //Maintaing occupiied postion / deleting the image being dragged
    $.each(_arrayOfInsertDrawn, function (key1, val1) {
        if (val1.NEW_ID == _draggedId) {
            _insertDragging = val1;
        }
    });

    if (_insertDragging.IMAGE_CATEGORY == 10) {
        //Maintaing occupiied postion / deleting the image being dragged
        $.each(_arrayOccupiedDecoraPosition, function (key1, val1) {

            if (val1 != undefined) {
                if (val1.imgId == _draggedId) {
                    _arrayOccupiedDecoraPosition.splice(key1, 1);
                    //delete(_arrayOccupiedDecoraPosition[key1]);
                }
            }
        });
    } else if (_insertDragging.IMAGE_CATEGORY == 11) {
        //Maintaing occupiied postion / deleting the image being dragged
        $.each(_arrayOccupiedSnapInsPosition, function (key1, val1) {
            if (val1 != undefined) {
                if (val1.imgId == _draggedId) {
                    _arrayOccupiedSnapInsPosition.splice(key1, 1);
                    //delete(_arrayOccupiedDecoraPosition[key1]);
                }
            }
        });
    } else {
        //Maintaing occupiied postion / deleting the image being dragged
        $.each(_arrayOccupiedPosition, function (key1, val1) {
            if (val1 != undefined) {
                if (val1.imgId == _draggedId) {
                    _arrayOccupiedPosition.splice(key1, 1);
                }
            }
        });
    }

    //For deleting the snaps ins, if they are over the decora part beding dragged

    _arrayOfPartsDisplayTemp = $.extend(true, [], _arrayOfPartsDisplay); // deep copy

    $.each(_arrayOfPartsDisplay, function (key1, val1) {

        if (val1 != undefined) {

            if ((val1.IMAGE_CATEGORY == 11) && (_insertDragging.IMAGE_CATEGORY == 10)) {

                if (val1.DECORAINS_ID == _insertDragging.NEW_ID) {
                    var _snapInsId = val1.NEW_ID;
                    var _current_left_insert1 = $('#' + _snapInsId + '').css("left");
                    var _current_top_insert1 = $('#' + _snapInsId + '').css("top");

                    $('#' + _snapInsId + '').animate({
                        top: _current_top_insert1,
                        left: _current_left_insert1
                    }, function () {
                        //$( '#'+_snapInsId+'' ).remove();
                        $('#' + _snapInsId + '').addClass('element').css({ 'display': 'none' });
                    });

                    //_arrayOfPartsDisplayTemp.splice([key1], 1);
                    delete (_arrayOfPartsDisplayTemp[key1]);
                }
            }
        }
    });

    _arrayOfPartsDisplay = [];
    _arrayOfPartsDisplay = $.extend(true, [], _arrayOfPartsDisplayTemp); // deep copy

    //For maintaining the array to display in part list
    $.each(_arrayOfPartsDisplay, function (key1, val1) {
        if (val1 != undefined) {
            if (val1.NEW_ID == _draggedId) {
                _arrayOfPartsDisplay.splice(key1, 1);
            }
        }
    });

    /* display parts list on the part list div */

    $displayList();

    var _insertCurHeight;
    var _insertCurWidth;
    var _insertCurType;
    //getting its original hieght
    $.each(_arrayOfCsvData, function (key1, val1) {
        if (val1.ID == _draggedId) {
            result = true;
            _insertCurType = val1.IMAGE_TYPE
            _insertCurHeight = val1.IMAGE_HEIGHT;
            _insertCurWidth = val1.IMAGE_WIDTH;
        }
    });

    //If insert is alreay drwan to the canvas and it is a decora insert 
    if ((_insertDragging.length != 0) && (_insertDragging.IMAGE_CATEGORY == 10)) {

        var insertCurrentHeight = _insertDragging.IMAGE_HEIGHT;
        var insertCurrentWidth = _insertDragging.IMAGE_WIDTH;
        $('#' + _draggedId + '').attr({ 'src': '' + _insertDragging.IMAGE_PATH + '' });
        //to get the the dragging insert back to original size and full image to match wid screws
        $('#' + _draggedId + '').attr({ 'width': '' + insertCurrentWidth + 'px', 'height': '' + insertCurrentHeight + 'px' });
    }

    //For getting plate size to resize the insert at run time
    _plateDrawn = {};
    $.each(_arrayOfPlates, function (key1, val1) {
        _plateDrawn = val1;
    });

    arrResult.insertCurHeight1 = false;
    arrResult.insertCurWidth1 = false;
    arrResult.insertCurType = _insertCurType;

    if (_plateDrawn) {
        if (_plateDrawn.OVER_SIZED == '2') {
            /* If plate is oversized(Very large i.e rock mount) handling insert size at run time */
            var _insertCurHeight1 = _insertCurHeight - (_insertCurHeight / 2);
            var _insertCurWidth1 = _insertCurWidth - (_insertCurWidth / 2);
            arrResult.insertCurHeight1 = _insertCurHeight1;
            arrResult.insertCurWidth1 = _insertCurWidth1;
            //$('#'+_draggedId+'').attr({'width':''+_insertCurWidth1+'px', 'height': ''+_insertCurHeight1+'px'});
        } else if (_plateDrawn.OVER_SIZED == '1') {
            /* If plate is oversized handling insert size at run time */
            var _insertCurHeight1 = _insertCurHeight - (_insertCurHeight / 4);
            var _insertCurWidth1 = _insertCurWidth - (_insertCurWidth / 4);
            arrResult.insertCurHeight1 = _insertCurHeight1;
            arrResult.insertCurWidth1 = _insertCurWidth1;

        } else if (_insertCurType == '2') {
            /* If object is an insert at run time */
            //var _insertCurHeight1 =_insertCurHeight - (_insertCurHeight/2);
            //var _insertCurWidth1 = _insertCurWidth - (_insertCurWidth/2);
            arrResult.insertCurHeight1 = _insertCurHeight;
            arrResult.insertCurWidth1 = _insertCurWidth;
        }
    }

    arrResult.result = result;
    return arrResult;
}

/*On drag ends */
function $onDragEnds(_draggedId, ev, dd) {
    //do nothing
    //console.log('dragends');	
}


/* On drop start */
function $onDropStarts(_draggedId, ev, dd) {
    //do nothing
    //console.log('dropstart');
}

/*
On drop second_steps
This function is use for drop insert/plate from side to secondstep
*/
function $onDrops(_draggedId, ev, dd) {

    if (_varIsImgDragged == 1) {

        console.log("drop insert/plate from side to secondstep");

        var _id = _draggedId;
        var _type = 1;
        var _currentImg = {};
        var _plateDrawn = {};
        var _matchfound = 0;
        var _initialImg = 0;        

        $.each(_arrayOfCsvData, function (key, val) {
            if (val.ID == _id) {                
                _type = val.IMAGE_TYPE;
                _currentImg = val;
                _initialImg = 1;

            }
        });

        //Image is draged from side bar into canvas i.e. its a proxy image 
        if (_initialImg == 1) {

            //If dragged image is not an insert
            if (_type == 1) { 				//If dragged image is a plate

                _plateDrawn = _currentImg;
                //Get poistion of center of the div
                var _centerPlatesDivHeight = $('#' + dragRegionAreaId).height();
                var _centerPlatesDivWidth = $('#' + dragRegionAreaId).width();
                var _centerPlatesDivTopPosition = $('#' + dragRegionAreaId).position().top;
                var _centerPlatesDivLeftPosition = $('#' + dragRegionAreaId).position().left;
                /*Resizing image according to its size*/
                if (_plateDrawn.OVER_SIZED == 0) {
                    var _new_h = _plateDrawn.IMAGE_HEIGHT;
                    var _new_w = _plateDrawn.IMAGE_WIDTH;
                } else if (_plateDrawn.OVER_SIZED == 1) {
                    var _new_h = _plateDrawn.IMAGE_HEIGHT - (_plateDrawn.IMAGE_HEIGHT / 4);
                    var _new_w = _plateDrawn.IMAGE_WIDTH - (_plateDrawn.IMAGE_WIDTH / 4);
                } else {
                    var _new_h = _plateDrawn.IMAGE_HEIGHT - (_plateDrawn.IMAGE_HEIGHT / 2);
                    var _new_w = _plateDrawn.IMAGE_WIDTH - (_plateDrawn.IMAGE_WIDTH / 2);
                }
                //Adjusting the position to be displayed on the canvas
                //var _nwTopbck = _centerPlatesDivTopPosition + ((_centerPlatesDivHeight / 2) - (_new_h / 2)) + 48;
                //var _nwLeftbck = _centerPlatesDivLeftPosition + ((_centerPlatesDivWidth / 2) - (_new_w / 2)) + 120;
                var _nwTopbck = _centerPlatesDivTopPosition + ((_centerPlatesDivHeight / 2) - (_new_h / 2)) + 18;
                var _nwLeftbck = _centerPlatesDivLeftPosition + ((_centerPlatesDivWidth / 2) - (_new_w / 2)) + 5;
                console.log("341 - If dragged image is a plate");
                $('#' + dragRegionAreaId).append('<img style="left:' + _nwLeftbck + 'px; top:' + _nwTopbck + 'px; position : absolute;" width="' + _new_w + '" height="' + _new_h + '" id="' + _id + '" src="' + _plateDrawn.IMAGE_PATH + '" />');                

              
                var tempPlate = CopyObject(_plateDrawn);
                tempPlate.unit = selectedUnit;                
                $.each(_arrayOfPlates, function (key1, val1) {                    
                    if (val1 && val1.unit != undefined && val1.unit == selectedUnit) {                        
                        _arrayOfPlates.splice(key1, 1);
                    }
                });                
                _arrayOfPlates.push(tempPlate); //Pushing the plate info to keep track

                _varIsImgDragged = 0;
                /* display parts list on the part list div */

                $displayList();

                $(dd.proxy).remove();
                $(this).toggleClass("dropped");

                //Change the drop down and load insert info
                $("#category_plate_div").fadeOut("slow", function () {

                    $("#category_insert_div").fadeIn("slow");
                    $('#span1').attr('class', 'parallelogram');
                    $('#span2').attr('class', 'parallelogram selected');
                    $('#print').attr('class', 'parallelogram last parallelogram_hover');
                    $('#clearDiv').attr('class', 'lftnav_btn lftnav_btn_hover');
                    $("#pagination_link").fadeOut("slow");
                    $("#back_plates").html('');
                    $("#front_plates").fadeIn("slow");
                    //$("#arrow_cover").fadeIn("slow");
                    $("#arrow_cover_insert").fadeIn("slow");
                    $removeTextOnMouseleave();

                });
                //loading images in side bar
                //var _previous_img_id = 0;
                // Bhavik - Developer code - to check configure image or not
                if (_plateDrawn.LONG_INSERT_COMPATIBLE == 0) {
                    UnitSteps[selectedUnit].IsConfigurablePlate = false;
                }
                else {
                    UnitSteps[selectedUnit].IsConfigurablePlate = true;
                }
                EnableButton(".next"); // Enable next button to go "Inserts" section
                UnitSteps[selectedUnit].AllowInsertCount = 0;
                UnitSteps[selectedUnit].AllowSnapInCount = 0;
                UnitSteps[selectedUnit].NoOfInsertCount = 0;
                UnitSteps[selectedUnit].NoOfSnapInCount = 0;
                $('.CodeLengthOption-' + selectedUnit).removeClass('active');
                //$('.PlateColorOption').removeClass('active');
                $('.CodeLengthOption-' + selectedUnit).find('input[type=radio]:').prop("checked", false);
                //$("#option1_white").prop("checked", false);
                //$("#option2_black").prop("checked", false);
                UnitSteps[selectedUnit].AllowInsertCount += parseInt(_plateDrawn.INSERT_SNAP_IN_COUNT);
                console.log("AllowInsertCount - " + UnitSteps[selectedUnit].AllowInsertCount);
                //End
            }

            //If dragged image is an insert
            if (_type == 2) {
                var _insertDrawn1 = {};
                _insertDrawn1 = _currentImg;
                var _plate_left = '';
                var _plateScrewX;
                var _plateScrewY;
                var _plateLX = [];
                var _plateLY = [];
                var _plateRX = [];
                var _plateRY = [];
                var _insertLX = [];
                var _insertLY = [];
                var _insertRX = [];
                var _insertRY = [];

                $.each(_arrayOfPlates, function (key1, val1) {
                    if (val1.unit == selectedUnit) {
                        _plateDrawn = val1;
                    }
                });

                //for handling decora insert( Long inserts)
                if (_insertDrawn1.IMAGE_CATEGORY == 10) {

                    if (_plateDrawn.LONG_INSERT_COMPATIBLE == 1) { /*If the plate drwan is compatible wid the decora insert */

                        //Getiing inserts real height and wieght		
                        var _insertCurHeight = _insertDrawn1.IMAGE_HEIGHT;
                        var _insertCurWidth = _insertDrawn1.IMAGE_WIDTH;

                        //getting extra pair for long inserts
                        _plate_id = _plateDrawn.ID;
                        _plate_left = _plateDrawn.EXTRA_PAIR;
                        var _plateArrayL = _plate_left.split('|');
                        var _numberOfScrewsPlateL = _plateArrayL.length;


                        if (_plateDrawn.OVER_SIZED == 0) { //If plate are not over sized

                            //For placing inner images only
                            var _insertCurHeight = 188;
                            var _insertCurWidth = 150;

                            //getting all screws postion 
                            for (var i = 0; i < _plateArrayL.length; i++) {
                                var _plateScrewArray = _plateArrayL[i].split(',');
                                _plateLX[i + 1] = _plateScrewArray[0];
                                _plateLY[i + 1] = _plateScrewArray[1];
                            }

                            //insert left pair
                            _insert_left = _insertDrawn1.LEFT_PAIR_1;
                            var _insertArrayL = _insert_left.split('|');
                            var _numberOfScrewsInsertL = _insertArrayL.length;

                            //getting all screws postion 
                            for (var i = 0; i < _insertArrayL.length; i++) {
                                var _insertScrewArray = _insertArrayL[i].split(',');
                                _insertLX[i + 1] = _insertScrewArray[0];
                                _insertLY[i + 1] = _insertScrewArray[1];
                            }

                            //Insert right pair
                            _insert_right = _insertDrawn1.RIGHT_PAIR_1;
                            var _insertArrayR = _insert_right.split('|');
                            var _numberOfScrewsInsertR = _insertArrayR.length;

                            //getting all screws position 
                            for (var i = 0; i < _insertArrayR.length; i++) {
                                var _insertScrewArray = _insertArrayR[i].split(',');
                                _insertRX[i + 1] = _insertScrewArray[0];
                                _insertRY[i + 1] = _insertScrewArray[1];
                            }

                        } else { //If plate is oversized                            
                            //For placing inner images only
                            var _insertCurHeight = 188 - (188 / 4);
                            var _insertCurWidth = 94 - (94 / 4);

                            //getting all screws postion 
                            for (var i = 0; i < _plateArrayL.length; i++) {
                                var _plateScrewArray = _plateArrayL[i].split(',');
                                _plateLX[i + 1] = _plateScrewArray[0] - (_plateScrewArray[0] / 4);
                                _plateLY[i + 1] = _plateScrewArray[1] - (_plateScrewArray[1] / 4);
                            }

                            //insert right pair
                            _insert_left = _insertDrawn1.LEFT_PAIR_1;
                            var _insertArrayL = _insert_left.split('|');
                            var _numberOfScrewsInsertL = _insertArrayL.length;

                            //getting all screws postion 
                            for (var i = 0; i < _insertArrayL.length; i++) {
                                var _insertScrewArray = _insertArrayL[i].split(',');
                                _insertLX[i + 1] = _insertScrewArray[0] - (_insertScrewArray[0] / 4);
                                _insertLY[i + 1] = _insertScrewArray[1] - (_insertScrewArray[1] / 4);
                            }

                            //Insert right pair
                            _insert_right = _insertDrawn1.RIGHT_PAIR_1;
                            var _insertArrayR = _insert_right.split('|');
                            var _numberOfScrewsInsertR = _insertArrayR.length;

                            //getting all screws position 
                            for (var i = 0; i < _insertArrayR.length; i++) {
                                var _insertScrewArray = _insertArrayR[i].split(',');
                                _insertRX[i + 1] = _insertScrewArray[0] - (_insertScrewArray[0] / 4);
                                _insertRY[i + 1] = _insertScrewArray[1] - (_insertScrewArray[1] / 4);
                            }

                        }

                        current_left_plate = $('#' + _plate_id + '').css("left");
                        current_top_plate = $('#' + _plate_id + '').css("top");
                        current_left_insert = $(_proxyElement).css("left");
                        current_top_insert = $(_proxyElement).css("top");

                        current_top_plate = current_top_plate.substring(0, current_top_plate.length - 2);
                        current_top_insert = current_top_insert.substring(0, current_top_insert.length - 2);
                        current_left_plate = current_left_plate.substring(0, current_left_plate.length - 2);
                        current_left_insert = current_left_insert.substring(0, current_left_insert.length - 2);

                        //To get the eiement back in original size
                        $(_proxyElement).css('width', '').css('height', '');
                        $(_proxyElement).attr({ 'width': '' + _insertCurWidth + 'px', 'height': '' + _insertCurHeight + 'px' });

                        //Getting height
                        var heightDiffInsert = _insertLY[2] - _insertRY[1];
                        var heightDiffPlate = _plateLY[2] - _plateRY[1];

                        //getting width
                        var widthDiffInsert = _insertRX[1] - _insertLX[1];
                        var widthDiffPlate = _plateRX[1] - _plateLX[1];
                        var n;
                        for (n = 1; n < (_numberOfScrewsPlateL + 1); n++) {
                            for (m = 1; m < (_numberOfScrewsInsertL + 1); m++) {

                                if ((Math.abs((parseInt(current_top_insert) + parseInt(_insertLY[m])) - (parseInt(current_top_plate) + parseInt(_plateLY[n]))) < 48) && (Math.abs((parseInt(current_left_insert) + parseInt(_insertLX[m])) - (parseInt(current_left_plate) + parseInt(_plateLX[n]))) < 80)) {
                                    var heightCompatible = 1;

                                    //If insert screws are more than 2
                                    if (_numberOfScrewsInsertR > 1) {
                                        var heightDiffPlateLower = _plateLY[n + 1] - _plateRY[n];

                                        //If insert screws are more than 2 their height must be compatible with plates
                                        if ((Math.abs(parseInt(heightDiffInsert) - parseInt(heightDiffPlateLower)) < 4)) {
                                            heightCompatible = 1;
                                        } else {
                                            heightCompatible = 0;
                                        }
                                        //Preventing from first position										
                                        if (n < m) {
                                            heightCompatible = 0;
                                        }
                                    }

                                    if (heightCompatible == 1) {

                                        var placeAvaliable = 1;
                                        $.each(_arrayOccupiedDecoraPosition, function (key1, val1) {
                                            if (n == val1.screwId) {
                                                placeAvaliable = 0;
                                            }
                                        });
                                        if (placeAvaliable == 1) {
                                            current_top_plate = (parseInt(current_top_plate) + parseInt(_plateLY[n])) - parseInt(_insertLY[m]) + 54;
                                            current_left_plate = (parseInt(current_left_plate) + parseInt(_plateLX[n])) - parseInt(_insertLX[m]) + 14;

                                            //Generating new Id for insert drwan on the canvas
                                            var newImgVar = $.now();
                                            var newInsertID = {};
                                            newInsertID = $.extend(true, {}, _insertDrawn1); // deep copy
                                            newInsertID.NEW_ID = '' + newImgVar + '';
                                            newInsertID.SCREW_ID = '' + n + '';
                                            console.log("544");
                                            $('#front_plates').append('<img style="left:' + current_left_plate + 'px; top:' + current_top_plate + 'px; position : absolute;" width="' + _insertCurWidth + '" height="' + _insertCurHeight + '" id="' + newImgVar + '" src="' + _insertDrawn1.SMALL_IMAGE_PATH + '" />');
                                            _matchfound = 1; //setting the flag to true
                                            _arrayOfInsertDrawn.push(newInsertID); //Maintaining object for all inserts
                                            newInsertID.unit = selectedUnit;
                                            _arrayOfPartsDisplay.push(newInsertID); //Maintaining object for all inserts
                                            _varIsImgDragged = 0;

                                            /* display parts list on the part list div */

                                            $displayList();

                                            //Maintaining object for all occupied position
                                            var occupiedDecoraArr = {};
                                            occupiedDecoraArr.screwId = n;
                                            occupiedDecoraArr.imgId = newImgVar;
                                            _arrayOccupiedDecoraPosition.push(occupiedDecoraArr);
                                            var occupiedDecoraArr1 = {};
                                            occupiedDecoraArr1.screwId = n + 1;
                                            occupiedDecoraArr1.imgId = newImgVar;
                                            _arrayOccupiedDecoraPosition.push(occupiedDecoraArr1);


                                            $(dd.proxy).remove();


                                            return false;
                                        }
                                    }
                                }
                            }
                        }

                        //* If image is not placed correctly 
                        if (_matchfound == 0) {
                            var original_height = _currentImg.IMAGE_HEIGHT;
                            var original_width = _currentImg.IMAGE_WIDTH;
                            var minimised_height = parseInt(_insertDrawn1.IMAGE_HEIGHT);
                            var minimised_width = parseInt(_insertDrawn1.IMAGE_WIDTH);
                            //Revert the dragged element with animation to the left bar
                            $(dd.proxy).animate({
                                top: _insertDrawn1.FIRSTPOSTOP,
                                left: _insertDrawn1.FIRSTPOSLEFT,
                                width: minimised_width,
                                height: minimised_height
                            }, function () {
                                $(dd.proxy).remove();
                            }
                            );
                        }
                    } else { /*If the plate drwan is not compatible wid the decora insert */
                        var original_height = _currentImg.IMAGE_HEIGHT;
                        var original_width = _currentImg.IMAGE_WIDTH;
                        var minimised_height = parseInt(_insertDrawn1.IMAGE_HEIGHT);
                        var minimised_width = parseInt(_insertDrawn1.IMAGE_WIDTH);
                        //Revert the dragged element with animation to the left bar
                        $(dd.proxy).animate({
                            top: _insertDrawn1.FIRSTPOSTOP,
                            left: _insertDrawn1.FIRSTPOSLEFT,
                            width: minimised_width,
                            height: minimised_height
                        }, function () {
                            $(dd.proxy).remove();
                        }
                        );
                    }

                    //Handling Of snap Ins Parts Over Decora inserts
                }
                else if (_insertDrawn1.IMAGE_CATEGORY == 11) {

                    if (_plateDrawn.LONG_INSERT_COMPATIBLE == 1) { /*If the plate drwan is compatible wid the decora insert */

                        var _arrayOfDecoraInsforSnapIns = [];

                        //For maintaining the array of decora inserts which are compatible to the snap Ins inserts
                        $.each(_arrayOfPartsDisplay, function (key1, val1) {
                            //if( (val1 != undefined ) && ((val1.PART_NUMBER == 'SS-PORT3') || (val1.PART_NUMBER == 'SS-PORT4') || (val1.PART_NUMBER == 'SS-PORT6')) ) {
                            _arrayOfDecoraInsforSnapIns.push(val1);
                            //}
                        });

                        if (_arrayOfDecoraInsforSnapIns.length != 0) {
                            /* For each compatible decora drwan will check the position of snap Ins inserts */
                            $.each(_arrayOfDecoraInsforSnapIns, function (key, val) {

                                //Getiing inserts real height and wieght		
                                var _insertCurHeight = _insertDrawn1.IMAGE_HEIGHT;
                                var _insertCurWidth = _insertDrawn1.IMAGE_WIDTH;

                                //getting extra pair for long inserts
                                var _plate_id = val.NEW_ID;
                                var _plate_left = val.EXTRA_PAIR;

                                var _plateArrayL = _plate_left.split('|');
                                var _numberOfScrewsPlateL = _plateArrayL.length;

                                if (_plateDrawn.OVER_SIZED == 0) { //If plate are not over sized

                                    //For placing inner images only
                                    var _insertCurHeight = 46;
                                    var _insertCurWidth = 54;

                                    //getting all screws postion 
                                    for (var i = 0; i < _plateArrayL.length; i++) {
                                        var _plateScrewArray = _plateArrayL[i].split(',');
                                        _plateLX[i + 1] = _plateScrewArray[0];
                                        _plateLY[i + 1] = _plateScrewArray[1];
                                    }

                                } else { //If plate is oversized

                                    //For placing inner images only
                                    var _insertCurHeight = 46 - (46 / 4);
                                    var _insertCurWidth = 39 - (39 / 4);

                                    //getting all screws postion 
                                    for (var i = 0; i < _plateArrayL.length; i++) {
                                        var _plateScrewArray = _plateArrayL[i].split(',');
                                        _plateLX[i + 1] = _plateScrewArray[0] - (_plateScrewArray[0] / 4);
                                        _plateLY[i + 1] = _plateScrewArray[1] - (_plateScrewArray[1] / 4);
                                    }

                                }

                                current_left_plate = $('#' + _plate_id + '').css("left");
                                current_top_plate = $('#' + _plate_id + '').css("top");
                                current_left_insert = $(_proxyElement).css("left");
                                current_top_insert = $(_proxyElement).css("top");

                                current_top_plate = current_top_plate.substring(0, current_top_plate.length - 2);
                                current_top_insert = current_top_insert.substring(0, current_top_insert.length - 2);
                                current_left_plate = current_left_plate.substring(0, current_left_plate.length - 2);
                                current_left_insert = current_left_insert.substring(0, current_left_insert.length - 2);

                                //To get the eiement back in original size
                                $(_proxyElement).css('width', '').css('height', '');
                                $(_proxyElement).attr({ 'width': '' + _insertCurWidth + 'px', 'height': '' + _insertCurHeight + 'px' });

                                //Getting height
                                var heightDiffInsert = _insertLY[2] - _insertRY[1];
                                var heightDiffPlate = _plateLY[2] - _plateRY[1];

                                //getting width
                                var widthDiffInsert = _insertRX[1] - _insertLX[1];
                                var widthDiffPlate = _plateRX[1] - _plateLX[1];
                                var n;

                                for (n = 1; n < (_numberOfScrewsPlateL + 1); n++) {
                                    if ((Math.abs((parseInt(current_top_insert)) - (parseInt(current_top_plate) + parseInt(_plateLY[n]))) < 40) && (Math.abs((parseInt(current_left_insert)) - (parseInt(current_left_plate) + parseInt(_plateLX[n]))) < 30)) {
                                        var heightCompatible = 1;

                                        if (heightCompatible == 1) {

                                            var placeAvaliable = 1;
											/*
											$.each( _arrayOccupiedPosition, function( key1, val1 ) {
												if( ( n == val1.screwId ) && ( _plateLX[n] == val1.screwPosX ) && ( _plateLY[n] == val1.screwPosY ) ) {
													//placeAvaliable = 0;
												}
											});
											*/

                                            //Check the avaiable place for inserting decora
                                            var placeAvaliable = 1;
                                            $.each(_arrayOccupiedSnapInsPosition, function (key1, val1) {
                                                if ((n == val1.screwId) && (_plate_id == val1.decoraId)) {
                                                    placeAvaliable = 0;
                                                }
                                            });

                                            if (placeAvaliable == 1) {

                                                current_top_plate = (parseInt(current_top_plate) + parseInt(_plateLY[n]));
                                                current_left_plate = (parseInt(current_left_plate) + parseInt(_plateLX[n]));

                                                //Generating new Id for insert drwan on the canvas
                                                var newImgVar = $.now();
                                                var newInsertID = {};
                                                newInsertID = $.extend(true, {}, _insertDrawn1); // deep copy
                                                newInsertID.NEW_ID = '' + newImgVar + '';
                                                newInsertID.SCREW_ID = '' + n + '';
                                                newInsertID.DECORAINS_ID = '' + _plate_id + '';
                                                // Insert snap in - chnaged by Bhavik Start
                                                console.log("724");
                                                $('#' + dragRegionAreaId).append('<img class="SnapInImg draggableimage" style="left:' + current_left_plate + 'px; top:' + current_top_plate + 'px; position : absolute;" width="' + _insertCurWidth + '" height="' + _insertCurHeight + '" id="' + newImgVar + '" src="' + _insertDrawn1.SMALL_IMAGE_PATH + '" />');
                                                UnitSteps[selectedUnit].NoOfSnapInCount++;
                                                CheckNextFromSnapInSection();
                                                AddElement_dd(newImgVar, dd);
                                                //End

                                                _matchfound = 1; //setting the flag to true

                                                _arrayOfInsertDrawn.push(newInsertID); //Maintaining object for all inserts
                                                newInsertID.unit = selectedUnit;
                                                _arrayOfPartsDisplay.push(newInsertID); //Maintaining object for all inserts

                                                _varIsImgDragged = 0;
                                                /* display parts list on the part list div */

                                                $displayList();

                                                //Maintaining object for all occupied position
                                                var occupiedDecoraArr = {};
                                                occupiedDecoraArr.screwId = n;
                                                occupiedDecoraArr.imgId = newImgVar;
                                                occupiedDecoraArr.decoraId = _plate_id;
                                                _arrayOccupiedSnapInsPosition.push(occupiedDecoraArr);

                                                //_arrayOccupiedSnapInsPosition

                                                $(dd.proxy).remove();



                                                return false;
                                            }
                                        }
                                    }
                                }

                                //* If image is not placed correctly 
                                if (_matchfound == 0) {

                                    var original_height = _currentImg.IMAGE_HEIGHT;
                                    var original_width = _currentImg.IMAGE_WIDTH;
                                    var minimised_height = parseInt(_insertDrawn1.IMAGE_HEIGHT) - parseInt((_insertDrawn1.IMAGE_HEIGHT / 4));
                                    var minimised_width = parseInt(_insertDrawn1.IMAGE_WIDTH) - parseInt((_insertDrawn1.IMAGE_WIDTH / 2));
                                    //Revert the dragged element with animation to the left bar
                                    $(dd.proxy).animate({
                                        top: _insertDrawn1.FIRSTPOSTOP,
                                        left: _insertDrawn1.FIRSTPOSLEFT,
                                        width: minimised_width,
                                        height: minimised_height
                                    }, function () {
                                        $(dd.proxy).remove();
                                    }
                                    );
                                }

                            });

                        } else { /*If the plate drwan is not compatible wid the decora insert */
                            var original_height = _currentImg.IMAGE_HEIGHT;
                            var original_width = _currentImg.IMAGE_WIDTH;
                            var minimised_height = parseInt(_insertDrawn1.IMAGE_HEIGHT) - parseInt((_insertDrawn1.IMAGE_HEIGHT / 4));
                            var minimised_width = parseInt(_insertDrawn1.IMAGE_WIDTH) - parseInt((_insertDrawn1.IMAGE_WIDTH / 2));
                            //Revert the dragged element with animation to the left bar
                            $(dd.proxy).animate({
                                top: _insertDrawn1.FIRSTPOSTOP,
                                left: _insertDrawn1.FIRSTPOSLEFT,
                                width: minimised_width,
                                height: minimised_height
                            }, function () {
                                $(dd.proxy).remove();
                            }
                            );
                        }

                    } else { /*If the plate drwan is not compatible wid the decora insert */
                        var original_height = _currentImg.IMAGE_HEIGHT;
                        var original_width = _currentImg.IMAGE_WIDTH;
                        var minimised_height = parseInt(_insertDrawn1.IMAGE_HEIGHT) - parseInt((_insertDrawn1.IMAGE_HEIGHT / 4));
                        var minimised_width = parseInt(_insertDrawn1.IMAGE_WIDTH) - parseInt((_insertDrawn1.IMAGE_WIDTH / 2));
                        //Revert the dragged element with animation to the left bar
                        $(dd.proxy).animate({
                            top: _insertDrawn1.FIRSTPOSTOP,
                            left: _insertDrawn1.FIRSTPOSLEFT,
                            width: minimised_width,
                            height: minimised_height
                        }, function () {
                            $(dd.proxy).remove();
                        }
                        );
                    }
                    // End Of Handling Of snap Ins Parts Over Decora inserts 

                } else { //If insert is other than decora insert( Long inserts )                    
                    //If plates are of normal size.. No need to resize
                    if (_plateDrawn.OVER_SIZED == '0') {

                        //Getiing inserts real height and wieght		
                        var _insertCurHeight = _insertDrawn1.IMAGE_HEIGHT;
                        var _insertCurWidth = _insertDrawn1.IMAGE_WIDTH;

                        //_plate_left = _plateDrawn. LEFT_PAIR_1;
                        _plate_id = _plateDrawn.ID;

                        for (var screwCount = 1; screwCount < 6; screwCount++) {

                            //Plate right pair
                            if (screwCount == 1) {
                                _plate_left = _plateDrawn.LEFT_PAIR_1;
                                _plate_right = _plateDrawn.RIGHT_PAIR_1;
                            } else if (screwCount == 2) {
                                _plate_left = _plateDrawn.LEFT_PAIR_2;
                                _plate_right = _plateDrawn.RIGHT_PAIR_2;
                            } else if (screwCount == 3) {
                                _plate_left = _plateDrawn.LEFT_PAIR_3;
                                _plate_right = _plateDrawn.RIGHT_PAIR_3;
                            } else if (screwCount == 4) {
                                _plate_left = _plateDrawn.LEFT_PAIR_4;
                                _plate_right = _plateDrawn.RIGHT_PAIR_4;
                            } else if (screwCount == 5) {
                                _plate_left = _plateDrawn.LEFT_PAIR_5;
                                _plate_right = _plateDrawn.RIGHT_PAIR_5;
                            }

                            if ((_plate_left != '') && (_plate_right != '')) {	// If plate left and right having blank values

                                //Plate left pair
                                var _plateArrayL = _plate_left.split('|');
                                var _numberOfScrewsPlateL = _plateArrayL.length;

                                //getting all screws postion 
                                for (var i = 0; i < _plateArrayL.length; i++) {
                                    var _plateScrewArray = _plateArrayL[i].split(',');
                                    _plateLX[i + 1] = _plateScrewArray[0];
                                    _plateLY[i + 1] = _plateScrewArray[1];
                                }

                                //Plate right pair
                                var _plateArrayR = _plate_right.split('|');
                                var _numberOfScrewsPlateR = _plateArrayR.length;

                                //getting all screws postion at right plate
                                for (var i = 0; i < _plateArrayR.length; i++) {
                                    var _plateScrewArray = _plateArrayR[i].split(',');
                                    _plateRX[i + 1] = _plateScrewArray[0];
                                    _plateRY[i + 1] = _plateScrewArray[1];
                                }

                                //insert right pair
                                _insert_left = _insertDrawn1.LEFT_PAIR_1;
                                var _insertArrayL = _insert_left.split('|');
                                var _numberOfScrewsInsertL = _insertArrayL.length;

                                //getting all screws postion 
                                for (var i = 0; i < _insertArrayL.length; i++) {
                                    var _insertScrewArray = _insertArrayL[i].split(',');
                                    _insertLX[i + 1] = _insertScrewArray[0];
                                    _insertLY[i + 1] = _insertScrewArray[1];
                                }

                                //Insert right pair
                                _insert_right = _insertDrawn1.RIGHT_PAIR_1;
                                var _insertArrayR = _insert_right.split('|');
                                var _numberOfScrewsInsertR = _insertArrayR.length;

                                //getting all screws position 
                                for (var i = 0; i < _insertArrayR.length; i++) {
                                    var _insertScrewArray = _insertArrayR[i].split(',');
                                    _insertRX[i + 1] = _insertScrewArray[0];
                                    _insertRY[i + 1] = _insertScrewArray[1];
                                }

                                current_left_plate = $('#' + _plate_id + '').css("left");
                                current_top_plate = $('#' + _plate_id + '').css("top");
                                current_left_insert = $(_proxyElement).css("left");
                                current_top_insert = $(_proxyElement).css("top");

                                current_top_plate = current_top_plate.substring(0, current_top_plate.length - 2);
                                current_top_insert = current_top_insert.substring(0, current_top_insert.length - 2);
                                current_left_plate = current_left_plate.substring(0, current_left_plate.length - 2);
                                current_left_insert = current_left_insert.substring(0, current_left_insert.length - 2);

                                //To get the eiement back in original size
                                $(_proxyElement).css('width', '').css('height', '');
                                $(_proxyElement).attr({ 'width': '' + _insertCurWidth + 'px', 'height': '' + _insertCurHeight + 'px' });

                                //Getting height
                                var heightDiffInsert = _insertLY[2] - _insertRY[1];
                                var heightDiffPlate = _plateLY[2] - _plateRY[1];

                                //getting width
                                var widthDiffInsert = _insertRX[1] - _insertLX[1];
                                var widthDiffPlate = _plateRX[1] - _plateLX[1];
                                var n;

                                var placeAvaliable = 1;

                                if ((Math.abs(parseInt(widthDiffInsert) - parseInt(widthDiffPlate)) < 5)) {

                                    for (n = 1; n < (_numberOfScrewsPlateL + 1); n++) {

                                        for (m = 1; m < (_numberOfScrewsInsertL + 1); m++) {

                                            if ((Math.abs((parseInt(current_top_insert) + parseInt(_insertLY[m])) - (parseInt(current_top_plate) + parseInt(_plateLY[n]))) < 48) && (Math.abs((parseInt(current_left_insert) + parseInt(_insertLX[m])) - (parseInt(current_left_plate) + parseInt(_plateLX[n]))) < 80)) {
                                                var noOfScrewsInInsert = 1;
                                                var heightCompatible = 1;

                                                //If insert screws are more than 1
                                                if (_numberOfScrewsInsertR > 1) {

                                                    var heightDiffPlateLower = _plateLY[n + 1] - _plateRY[n];
                                                    //If insert screws are more than 1 their height must be compatible with plates
                                                    if ((Math.abs(parseInt(heightDiffInsert) - parseInt(heightDiffPlateLower)) < 4)) {
                                                        heightCompatible = 1;
                                                        noOfScrewsInInsert = 2;
                                                    } else {
                                                        heightCompatible = 0;
                                                    }

                                                    //For handing three screws position covering inserts
                                                    if (heightCompatible == 0) {

                                                        if (((n == 3) && (m == 1)) || ((n == 2) && (m == 2))) {
                                                            heightCompatible = 0;
                                                        } else {
                                                            var heightDiffPlateLower = _plateLY[n + 1] - _plateRY[n - 1];

                                                            //If insert screws are more than 2 their height must be compatible with plates
                                                            if ((Math.abs(parseInt(heightDiffInsert) - parseInt(heightDiffPlateLower)) < 4)) {
                                                                heightCompatible = 1;
                                                                noOfScrewsInInsert = 3;
                                                            } else {
                                                                heightCompatible = 0;
                                                            }

                                                            //For handing four screws position covering inserts (whole plate cover)
                                                            if (heightCompatible == 0) {

                                                                if ((n == 4) && (m == 1)) {
                                                                    heightCompatible = 0;
                                                                } else {

                                                                    var heightDiffPlateLower = _plateLY[n] - _plateRY[n - 3];

                                                                    //If insert screws are more than 2 their height must be compatible with plates
                                                                    if ((Math.abs(parseInt(heightDiffInsert) - parseInt(heightDiffPlateLower)) < 4)) {
                                                                        heightCompatible = 1;
                                                                        noOfScrewsInInsert = 4;
                                                                    } else {
                                                                        heightCompatible = 0;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }

                                                    //Preventing from first position										
                                                    if (n < m) {
                                                        heightCompatible = 0;
                                                    }
                                                }

                                                if (heightCompatible == 1) {
                                                    //Preventing overlapping of inserts with checking previous position
                                                    $.each(_arrayOccupiedPosition, function (key4, val4) {

                                                        if (val4.unit == selectedUnit) {

                                                            //One Screw pair
                                                            if ((noOfScrewsInInsert == 1) && (screwCount == val4.screwCount)) {
                                                                if ((n == val4.screwIdN) && (m == val4.screwIdM)) {

                                                                    if (noOfScrewsInInsert == val4.noOfScrewsInInsert) {
                                                                        placeAvaliable = 0;
                                                                    } else {
                                                                        placeAvaliable = 0;
                                                                    }
                                                                }

                                                                if ((val4.noOfScrewsInInsert == 2) && ((val4.screwIdN + 1) == (n))) {
                                                                    placeAvaliable = 0;
                                                                } else if ((val4.noOfScrewsInInsert == 3) && (((val4.screwIdN + 1) == n) || ((val4.screwIdN + 2) == n))) {
                                                                    placeAvaliable = 0;
                                                                } else if ((val4.noOfScrewsInInsert == 4)) {
                                                                    placeAvaliable = 0;
                                                                }

                                                                //Two Screw pairs
                                                            }
                                                            else if ((noOfScrewsInInsert == 2) && (screwCount == val4.screwCount)) {

                                                                if ((n == val4.screwIdN) && (m == val4.screwIdM)) {
                                                                    if (noOfScrewsInInsert == val4.noOfScrewsInInsert) {
                                                                        placeAvaliable = 0;
                                                                    } else {
                                                                        placeAvaliable = 0;
                                                                    }
                                                                }

                                                                if ((val4.noOfScrewsInInsert == 2) && ((val4.screwIdN + 1) == n)) {
                                                                    placeAvaliable = 0;
                                                                } else if ((val4.noOfScrewsInInsert == 3)) {
                                                                    placeAvaliable = 0;
                                                                } else if ((val4.noOfScrewsInInsert == 4)) {
                                                                    placeAvaliable = 0;
                                                                } else if ((val4.noOfScrewsInInsert == 2) && ((val4.screwIdN - 1) == n)) {
                                                                    placeAvaliable = 0;
                                                                } else if ((val4.noOfScrewsInInsert == 1) && ((val4.screwIdN - 1) == n)) {
                                                                    placeAvaliable = 0;
                                                                }

                                                                //Three Screw Pairs	
                                                            } else if ((noOfScrewsInInsert == 3) && (screwCount == val4.screwCount)) {

                                                                if ((n == val4.screwIdN) && (m == val4.screwIdM)) {
                                                                    if (noOfScrewsInInsert == val4.noOfScrewsInInsert) {
                                                                        placeAvaliable = 0;
                                                                    } else {
                                                                        placeAvaliable = 0;
                                                                    }
                                                                }


                                                                if ((val4.noOfScrewsInInsert == 2)) {
                                                                    placeAvaliable = 0;
                                                                } else if ((val4.noOfScrewsInInsert == 3)) {
                                                                    placeAvaliable = 0;
                                                                } else if ((val4.noOfScrewsInInsert == 4)) {
                                                                    placeAvaliable = 0;
                                                                } else if ((val4.noOfScrewsInInsert == 1) && ((val4.screwIdN == 2) || (val4.screwIdN == 3) || ((3 == n) && (val4.screwIdN == 1)) || ((2 == n) && (val4.screwIdN == 4)))) {
                                                                    placeAvaliable = 0;
                                                                }

                                                                //Four Screw Pairs	
                                                            } else if ((noOfScrewsInInsert == 4) && (screwCount == val4.screwCount)) {
                                                                placeAvaliable = 0;
                                                            }
                                                        }
                                                    });
                                                    //End Of Preventing overlapping of inserts with checking previous position		

                                                    /* If place is available for inserts */

                                                    if (placeAvaliable == 1) {

                                                        current_top_plate = (parseInt(current_top_plate) + parseInt(_plateLY[n])) - parseInt(_insertLY[m]);
                                                        current_left_plate = (parseInt(current_left_plate) + parseInt(_plateLX[n])) - parseInt(_insertLX[m]);
                                                        //$("#"+_id).attr({'width':''+_insertCurWidth+'px', 'height': ''+_insertCurHeight+'px'});

                                                        //Generating new Id for insert drwan on the canvas
                                                        var newImgVar = $.now();
                                                        var newInsertID = {};

                                                        newInsertID = $.extend(true, {}, _insertDrawn1); // deep copy
                                                        newInsertID.NEW_ID = '' + newImgVar + '';
                                                        newInsertID.SCREW_ID = '' + n + '';

                                                        // add "insert" - chnaged by Bhavik Start
                                                        console.log("1071");
                                                        $('#' + dragRegionAreaId).append('<img class="InsertsImg draggableimage" style="left:' + current_left_plate + 'px; top:' + current_top_plate + 'px; position : absolute;" width="' + _insertCurWidth + '" height="' + _insertCurHeight + '" id="' + newImgVar + '" src="' + _insertDrawn1.IMAGE_PATH + '" />');
                                                        UnitSteps[selectedUnit].NoOfInsertCount++;
                                                        UnitSteps[selectedUnit].AllowSnapInCount += parseInt(_insertDrawn1.INSERT_SNAP_IN_COUNT);
                                                        CheckNextFromInsertSection();
                                                        AddElement_dd(newImgVar, dd);
                                                        console.log("AllowSnapInCount - " + UnitSteps[selectedUnit].AllowSnapInCount);
                                                        // End

                                                        _matchfound = 1; //setting the flag to true

                                                        _arrayOfInsertDrawn.push(newInsertID); //Maintaining object for all inserts
                                                        newInsertID.unit = selectedUnit;
                                                        _arrayOfPartsDisplay.push(newInsertID); //Maintaining object for all inserts

                                                        _varIsImgDragged = 0;

                                                        /* display parts list on the part list div.
                                                        we do not required to add inserts in price list*/

                                                        //$displayList();

                                                        //Maintaining object for all occupied position 


                                                        //Preventing of overlapping of inserts                                                        
                                                        var occupiedArr = {};
                                                        occupiedArr.noOfScrewsInInsert = noOfScrewsInInsert;
                                                        occupiedArr.screwIdN = n;
                                                        occupiedArr.screwIdM = m;
                                                        occupiedArr.screwCount = screwCount;
                                                        occupiedArr.imgId = newImgVar;
                                                        occupiedArr.unit = selectedUnit;
                                                        _arrayOccupiedPosition.push(occupiedArr);
                                                        $(dd.proxy).remove();

                                                        return false;
                                                    }
                                                }
                                            }
                                        }
                                    }

                                } else { //Animate back	

                                    var original_height = _currentImg.IMAGE_HEIGHT;
                                    var original_width = _currentImg.IMAGE_WIDTH;
                                    var minimised_height = parseInt(_insertDrawn1.IMAGE_HEIGHT) - parseInt((_insertDrawn1.IMAGE_HEIGHT / 2));
                                    var minimised_width = parseInt(_insertDrawn1.IMAGE_WIDTH) - parseInt((_insertDrawn1.IMAGE_WIDTH / 2));

                                    //Revert the dragged element with animation to the left bar
                                    $(dd.proxy).animate({
                                        top: _insertDrawn1.FIRSTPOSTOP,
                                        left: _insertDrawn1.FIRSTPOSLEFT,
                                        width: minimised_width,
                                        height: minimised_height
                                    }, function () {
                                        $(dd.proxy).remove();
                                    }
                                    );
                                    $(dd.proxy).remove();
                                }

                            } // end of If plate left and right having blank values

                        } //end of for loop for various screws		

                        //* If image is not placed correctly 
                        if (_matchfound == 0) {

                            var original_height = _currentImg.IMAGE_HEIGHT;
                            var original_width = _currentImg.IMAGE_WIDTH;
                            var minimised_height = parseInt(_insertDrawn1.IMAGE_HEIGHT) - parseInt((_insertDrawn1.IMAGE_HEIGHT / 4));
                            var minimised_width = parseInt(_insertDrawn1.IMAGE_WIDTH) - parseInt((_insertDrawn1.IMAGE_WIDTH / 2));

                            //Revert the dragged element with animation to the left bar
                            $(dd.proxy).animate({
                                top: _insertDrawn1.FIRSTPOSTOP,
                                left: _insertDrawn1.FIRSTPOSLEFT,
                                width: minimised_width,
                                height: minimised_height
                            }, function () {
                                $(dd.proxy).remove();
                            }
                            );
                        }

                    } else { //Images are oversized

                        //Gettiing inserts real height and weight						
                        if (_plateDrawn.OVER_SIZED == '1') {
                            var _insertCurHeight = _insertDrawn1.IMAGE_HEIGHT - (_insertDrawn1.IMAGE_HEIGHT / 4);
                            var _insertCurWidth = _insertDrawn1.IMAGE_WIDTH - (_insertDrawn1.IMAGE_WIDTH / 4);
                        } else { /* Imagee are like rockmaount extra large*/
                            var _insertCurHeight = _insertDrawn1.IMAGE_HEIGHT - (_insertDrawn1.IMAGE_HEIGHT / 2);
                            var _insertCurWidth = _insertDrawn1.IMAGE_WIDTH - (_insertDrawn1.IMAGE_WIDTH / 2);
                        }

                        _plate_id = _plateDrawn.ID;
                        for (var screwCount = 1; screwCount < 7; screwCount++) {

                            //Plate right pair
                            if (screwCount == 1) {
                                _plate_left = _plateDrawn.LEFT_PAIR_1;
                                _plate_right = _plateDrawn.RIGHT_PAIR_1;
                            } else if (screwCount == 2) {
                                _plate_left = _plateDrawn.LEFT_PAIR_2;
                                _plate_right = _plateDrawn.RIGHT_PAIR_2;
                            } else if (screwCount == 3) {
                                _plate_left = _plateDrawn.LEFT_PAIR_3;
                                _plate_right = _plateDrawn.RIGHT_PAIR_3;
                            } else if (screwCount == 4) {
                                _plate_left = _plateDrawn.LEFT_PAIR_4;
                                _plate_right = _plateDrawn.RIGHT_PAIR_4;
                            } else if (screwCount == 5) {
                                _plate_left = _plateDrawn.LEFT_PAIR_5;
                                _plate_right = _plateDrawn.RIGHT_PAIR_5;
                            } else if (screwCount == 6) {
                                _plate_left = _plateDrawn.LEFT_PAIR_6;
                                _plate_right = _plateDrawn.RIGHT_PAIR_6;
                            }

                            // If screw left and right blank
                            if ((_plate_left != '') && (_plate_right != '')) {

                                //Plate left pair
                                var _plateArrayL = _plate_left.split('|');
                                var _numberOfScrewsPlateL = _plateArrayL.length;

                                //getting all screws postion 
                                for (var i = 0; i < _plateArrayL.length; i++) {
                                    var _plateScrewArray = _plateArrayL[i].split(',');
                                    if (_plateDrawn.OVER_SIZED == '1') {
                                        _plateLX[i + 1] = _plateScrewArray[0] - (_plateScrewArray[0] / 4);
                                        _plateLY[i + 1] = _plateScrewArray[1] - (_plateScrewArray[1] / 4);
                                    } else {
                                        _plateLX[i + 1] = _plateScrewArray[0] - (_plateScrewArray[0] / 2);
                                        _plateLY[i + 1] = _plateScrewArray[1] - (_plateScrewArray[1] / 2);
                                    }
                                }

                                //Plate right pair
                                //_plate_right = _plateDrawn. RIGHT_PAIR_1;
                                var _plateArrayR = _plate_right.split('|');
                                var _numberOfScrewsPlateR = _plateArrayR.length;

                                //getting all screws postion at right plate
                                for (var i = 0; i < _plateArrayR.length; i++) {
                                    var _plateScrewArray = _plateArrayR[i].split(',');
                                    if (_plateDrawn.OVER_SIZED == '1') {
                                        _plateRX[i + 1] = _plateScrewArray[0] - (_plateScrewArray[0] / 4);
                                        _plateRY[i + 1] = _plateScrewArray[1] - (_plateScrewArray[1] / 4);
                                    } else {
                                        _plateRX[i + 1] = _plateScrewArray[0] - (_plateScrewArray[0] / 2);
                                        _plateRY[i + 1] = _plateScrewArray[1] - (_plateScrewArray[1] / 2);
                                    }
                                }

                                //insert right pair
                                _insert_left = _insertDrawn1.LEFT_PAIR_1;
                                var _insertArrayL = _insert_left.split('|');
                                var _numberOfScrewsInsertL = _insertArrayL.length;

                                //getting all screws postion 
                                for (var i = 0; i < _insertArrayL.length; i++) {
                                    var _insertScrewArray = _insertArrayL[i].split(',');
                                    if (_plateDrawn.OVER_SIZED == '1') {
                                        _insertLX[i + 1] = _insertScrewArray[0] - (_insertScrewArray[0] / 4);
                                        _insertLY[i + 1] = _insertScrewArray[1] - (_insertScrewArray[1] / 4);
                                    } else {
                                        _insertLX[i + 1] = _insertScrewArray[0] - (_insertScrewArray[0] / 2);
                                        _insertLY[i + 1] = _insertScrewArray[1] - (_insertScrewArray[1] / 2);
                                    }
                                }

                                //Insert right pair
                                _insert_right = _insertDrawn1.RIGHT_PAIR_1;
                                var _insertArrayR = _insert_right.split('|');
                                var _numberOfScrewsInsertR = _insertArrayR.length;

                                //getting all screws position 
                                for (var i = 0; i < _insertArrayR.length; i++) {
                                    var _insertScrewArray = _insertArrayR[i].split(',');
                                    if (_plateDrawn.OVER_SIZED == '1') {
                                        _insertRX[i + 1] = _insertScrewArray[0] - (_insertScrewArray[0] / 4);
                                        _insertRY[i + 1] = _insertScrewArray[1] - (_insertScrewArray[1] / 4);
                                    } else {
                                        _insertRX[i + 1] = _insertScrewArray[0] - (_insertScrewArray[0] / 2);
                                        _insertRY[i + 1] = _insertScrewArray[1] - (_insertScrewArray[1] / 2);
                                    }
                                }

                                current_left_plate = $('#' + _plate_id + '').css("left");
                                current_top_plate = $('#' + _plate_id + '').css("top");
                                current_left_insert = $(_proxyElement).css("left");
                                current_top_insert = $(_proxyElement).css("top");

                                current_top_plate = current_top_plate.substring(0, current_top_plate.length - 2);
                                current_top_insert = current_top_insert.substring(0, current_top_insert.length - 2);
                                current_left_plate = current_left_plate.substring(0, current_left_plate.length - 2);
                                current_left_insert = current_left_insert.substring(0, current_left_insert.length - 2);

                                //To get the eiement back in original size
                                $(_proxyElement).css('width', '').css('height', '');
                                $(_proxyElement).attr({ 'width': '' + _insertCurWidth + 'px', 'height': '' + _insertCurHeight + 'px' });

                                //Getting height
                                var heightDiffInsert = _insertLY[2] - _insertLY[1];
                                var heightDiffPlate = _plateLY[2] - _plateLY[1];

                                //getting width
                                var widthDiffInsert = _insertRX[1] - _insertLX[1];
                                var widthDiffPlate = _plateRX[1] - _plateLX[1];
                                var n;

                                /* If width difference is compatible */
                                if ((Math.abs(parseInt(widthDiffInsert) - parseInt(widthDiffPlate)) < 5)) {
                                    for (n = 1; n < (_numberOfScrewsPlateL + 1); n++) {
                                        for (m = 1; m < (_numberOfScrewsInsertL + 1); m++) {

                                            var topDifferenceToCheck;
                                            var leftDifferenceToCheck;
                                            //Adjustinmg the near by position as per plate size
                                            if (_plateDrawn.OVER_SIZED == '1') {

                                                topDifferenceToCheck = 40;
                                                leftDifferenceToCheck = 60;
                                            } else {

                                                topDifferenceToCheck = 20;
                                                leftDifferenceToCheck = 25;
                                            }

                                            if ((Math.abs((parseInt(current_top_insert) + parseInt(_insertLY[m])) - (parseInt(current_top_plate) + parseInt(_plateLY[n]))) < topDifferenceToCheck) && (Math.abs((parseInt(current_left_insert) + parseInt(_insertLX[m])) - (parseInt(current_left_plate) + parseInt(_plateLX[n]))) < leftDifferenceToCheck)) {

                                                var heightCompatible = 1;
                                                //If insert screws are more than 1
                                                //alert('_numberOfScrewsInsertR '+_numberOfScrewsInsertR);
                                                if (_numberOfScrewsInsertR > 1) {

                                                    //Preventing from first position										
                                                    if (n < m) {
                                                        heightCompatible = 0;
                                                    } else {
                                                        var heightDiffPlateLower = _plateLY[n + 1] - _plateLY[n];
                                                        //If insert screws are more than 2 their hieght must be compatible with plates
                                                        if ((Math.abs(parseInt(heightDiffInsert) - parseInt(heightDiffPlateLower)) < 5)) {
                                                            heightCompatible = 1;
                                                        } else {
                                                            heightCompatible = 0;
                                                        }
                                                    }

                                                    //For handing three screws position covering inserts 
                                                    if (heightCompatible == 0) {

                                                        //Preventing upper and lower position for long inserts
                                                        if (((n == 3) && (m == 1)) || ((n == 2) && (m == 2))) {
                                                            heightCompatible = 0;
                                                        } else {
                                                            var heightDiffPlateLower = _plateLY[n + 1] - _plateRY[n - 1];

                                                            //If insert screws are more than 2 their height must be compatible with plates
                                                            if ((Math.abs(parseInt(heightDiffInsert) - parseInt(heightDiffPlateLower)) < 4)) {
                                                                heightCompatible = 1;
                                                                //return false;
                                                            } else {
                                                                heightCompatible = 0;
                                                            }

                                                            //For handing four screws position covering inserts (whole plate cover)
                                                            if (heightCompatible == 0) {

                                                                if ((n == 4) && (m == 1)) {
                                                                    heightCompatible = 0;
                                                                } else {

                                                                    var heightDiffPlateLower = _plateLY[n] - _plateRY[n - 3];

                                                                    //If insert screws are more than 2 their height must be compatible with plates
                                                                    if ((Math.abs(parseInt(heightDiffInsert) - parseInt(heightDiffPlateLower)) < 4)) {
                                                                        heightCompatible = 1;
                                                                    } else {
                                                                        heightCompatible = 0;
                                                                    }
                                                                }

                                                            }
                                                        }
                                                    }
                                                }

                                                if (heightCompatible == 1) {


                                                    //Preventing overlapping of inserts with checking previous position
                                                    $.each(_arrayOccupiedPosition, function (key4, val4) {

                                                        //One Screw pair
                                                        if ((noOfScrewsInInsert == 1) && (screwCount == val4.screwCount)) {
                                                            if ((n == val4.screwIdN) && (m == val4.screwIdM)) {

                                                                if (noOfScrewsInInsert == val4.noOfScrewsInInsert) {
                                                                    placeAvaliable = 0;
                                                                } else {
                                                                    placeAvaliable = 0;
                                                                }
                                                            }

                                                            if ((val4.noOfScrewsInInsert == 2) && ((val4.screwIdN + 1) == (n))) {
                                                                placeAvaliable = 0;
                                                            } else if ((val4.noOfScrewsInInsert == 3) && (((val4.screwIdN + 1) == n) || ((val4.screwIdN + 2) == n))) {
                                                                placeAvaliable = 0;
                                                            } else if ((val4.noOfScrewsInInsert == 4)) {
                                                                placeAvaliable = 0;
                                                            }

                                                            //Two Screw pairs
                                                        } else if ((noOfScrewsInInsert == 2) && (screwCount == val4.screwCount)) {


                                                            if ((n == val4.screwIdN) && (m == val4.screwIdM)) {
                                                                if (noOfScrewsInInsert == val4.noOfScrewsInInsert) {
                                                                    placeAvaliable = 0;
                                                                } else {
                                                                    placeAvaliable = 0;
                                                                }
                                                            }

                                                            if ((val4.noOfScrewsInInsert == 2) && ((val4.screwIdN + 1) == n)) {
                                                                placeAvaliable = 0;
                                                            } else if ((val4.noOfScrewsInInsert == 3)) {
                                                                placeAvaliable = 0;
                                                            } else if ((val4.noOfScrewsInInsert == 4)) {
                                                                placeAvaliable = 0;
                                                            } else if ((val4.noOfScrewsInInsert == 2) && ((val4.screwIdN - 1) == n)) {
                                                                placeAvaliable = 0;
                                                            } else if ((val4.noOfScrewsInInsert == 1) && ((val4.screwIdN - 1) == n)) {
                                                                placeAvaliable = 0;
                                                            }

                                                            //Three Screw Pairs	
                                                        } else if ((noOfScrewsInInsert == 3) && (screwCount == val4.screwCount)) {

                                                            if ((n == val4.screwIdN) && (m == val4.screwIdM)) {
                                                                if (noOfScrewsInInsert == val4.noOfScrewsInInsert) {
                                                                    placeAvaliable = 0;
                                                                } else {
                                                                    placeAvaliable = 0;
                                                                }
                                                            }

                                                            if ((val4.noOfScrewsInInsert == 2)) {
                                                                placeAvaliable = 0;
                                                            } else if ((val4.noOfScrewsInInsert == 3)) {
                                                                placeAvaliable = 0;
                                                            } else if ((val4.noOfScrewsInInsert == 4)) {
                                                                placeAvaliable = 0;
                                                            } else if ((val4.noOfScrewsInInsert == 1) && ((val4.screwIdN == 2) || (val4.screwIdN == 3) || ((3 == n) && (val4.screwIdN == 1)) || ((2 == n) && (val4.screwIdN == 4)))) {
                                                                placeAvaliable = 0;
                                                            }

                                                            //Four Screw Pairs	
                                                        } else if ((noOfScrewsInInsert == 4) && (screwCount == val4.screwCount)) {
                                                            placeAvaliable = 0;
                                                        }

                                                    });
                                                    //End Of Preventing overlapping of inserts with checking previous position	

                                                    var placeAvaliable = 1;
                                                    $.each(_arrayOccupiedPosition, function (key1, val1) {
                                                        if ((n == val1.screwId) && (_plateLX[n] == val1.screwPosX) && (_plateLY[n] == val1.screwPosY)) {
                                                            //placeAvaliable = 0;
                                                        }
                                                    });

                                                    if (placeAvaliable == 1) {

                                                        current_top_plate = (parseInt(current_top_plate) + parseInt(_plateLY[n])) - parseInt(_insertLY[m]);
                                                        current_left_plate = (parseInt(current_left_plate) + parseInt(_plateLX[n])) - parseInt(_insertLX[m]);

                                                        //Generating new Id for insert drwan on the canvas
                                                        var newImgVar = $.now();
                                                        var newInsertID = {};

                                                        newInsertID = $.extend(true, {}, _insertDrawn1); // deep copy
                                                        newInsertID.NEW_ID = '' + newImgVar + '';
                                                        newInsertID.SCREW_ID = '' + n + '';
                                                        console.log("1448");
                                                        $('#front_plates').append('<img style="left:' + current_left_plate + 'px; top:' + current_top_plate + 'px; position : absolute;" width="' + _insertCurWidth + '" height="' + _insertCurHeight + '" id="' + newImgVar + '" src="' + _insertDrawn1.IMAGE_PATH + '" />');
                                                        _matchfound = 1; //setting the flag to true
                                                        _arrayOfInsertDrawn.push(newInsertID); //Maintaining object for all inserts

                                                        newInsertID.unit = selectedUnit;
                                                        _arrayOfPartsDisplay.push(newInsertID); //Maintaining object for all inserts
                                                        _varIsImgDragged = 0;
                                                        /* display parts list on the part list div */

                                                        $displayList();

                                                        //Maintaining object for all 
                                                        /*var occupiedArr = {};
                                                        occupiedArr.screwId = n;
                                                        occupiedArr.screwPosX = _plateLX[n];
                                                        occupiedArr.screwPosY = _plateLY[n];
                                                        _arrayOccupiedPosition.push(occupiedArr);*/
                                                        /*var occupiedArr = {};
                                                        occupiedArr.noOfScrewsInInsert = noOfScrewsInInsert;
                                                        occupiedArr.screwIdN = n;
                                                        occupiedArr.screwIdM = m;
                                                        occupiedArr.screwCount = screwCount;
                                                        occupiedArr.imgId = newImgVar;
                                                        _arrayOccupiedPosition.push(occupiedArr);*/

                                                        //Preventing of overlapping of inserts
                                                        var occupiedArr = {};
                                                        occupiedArr.noOfScrewsInInsert = noOfScrewsInInsert;
                                                        occupiedArr.screwIdN = n;
                                                        occupiedArr.screwIdM = m;
                                                        occupiedArr.screwCount = screwCount;
                                                        occupiedArr.imgId = newImgVar;
                                                        occupiedArr.unit = selectedUnit;
                                                        _arrayOccupiedPosition.push(occupiedArr);

                                                        $(dd.proxy).remove();

                                                        //iScroll.refresh();
                                                        return false;
                                                    }
                                                }
                                            }
                                        }
                                    }

                                } else { //Animate back			
                                    var original_height = _currentImg.IMAGE_HEIGHT;
                                    var original_width = _currentImg.IMAGE_WIDTH;
                                    var minimised_height = parseInt(_insertDrawn1.IMAGE_HEIGHT) - parseInt((_insertDrawn1.IMAGE_HEIGHT / 2));
                                    var minimised_width = parseInt(_insertDrawn1.IMAGE_WIDTH) - parseInt((_insertDrawn1.IMAGE_WIDTH / 2));

                                    //Revert the dragged element with animation to the left bar
                                    $(dd.proxy).animate({
                                        top: _insertDrawn1.FIRSTPOSTOP,
                                        left: _insertDrawn1.FIRSTPOSLEFT,
                                        width: minimised_width,
                                        height: minimised_height
                                    }, function () {
                                        $(dd.proxy).remove();
                                    }
                                    );
                                    $(dd.proxy).remove();
                                }
                            } // End of screw left and right blank 

                        } //end of for loop for various screws

                        //* If image is not placed correctly 
                        if (_matchfound == 0) {

                            var original_height = _currentImg.IMAGE_HEIGHT;
                            var original_width = _currentImg.IMAGE_WIDTH;
                            var minimised_height = parseInt(_insertDrawn1.IMAGE_HEIGHT) - parseInt((_insertDrawn1.IMAGE_HEIGHT / 4));
                            var minimised_width = parseInt(_insertDrawn1.IMAGE_WIDTH) - parseInt((_insertDrawn1.IMAGE_WIDTH / 2));

                            //Revert the dragged element with animation to the left bar
                            $(dd.proxy).animate({
                                top: _insertDrawn1.FIRSTPOSTOP,
                                left: _insertDrawn1.FIRSTPOSLEFT,
                                width: minimised_width,
                                height: minimised_height
                            }, function () {
                                $(dd.proxy).remove();
                            }
                            );
                        }

                    } //end of image oversized
                } //End of other than decora
            } //end of type 2

        } else { //Image is being rearranged on the canvas            
            //Animate back to first position	
            /* Reading obect of Insert drawn yet */
            $.each(_arrayOfInsertDrawn, function (key1, val1) {
                var valId = val1.NEW_ID;
                if (valId == _id) {
                    _type = val1.IMAGE_TYPE;
                    _currentImg = val1;
                }
            });

            //Retaining it back to original size
            var original_height = _currentImg.IMAGE_HEIGHT;
            var original_width = _currentImg.IMAGE_WIDTH;
            var minimised_height = parseInt(_currentImg.IMAGE_HEIGHT) - parseInt((_currentImg.IMAGE_HEIGHT / 4));
            var minimised_width = parseInt(_currentImg.IMAGE_WIDTH) - parseInt((_currentImg.IMAGE_WIDTH / 4));

            //Revert the dragged element with animation to the left bar
            //Animate to previous position	
            $('#' + _id + '').animate({
                top: _currentImg.FIRSTPOSTOP,
                left: _currentImg.FIRSTPOSLEFT,
                width: minimised_width,
                height: minimised_height
            }, function () {
                $('#' + _id + '').remove();
            }
            );

            $.each(_arrayOfInsertDrawn, function (key1, val1) {
                if (val1 != undefined) {
                    if (val1.NEW_ID == _draggedId) {
                        _arrayOfInsertDrawn.splice(key1, 1);
                    }
                }
            });
        }
    }
}

/*
On drop withen plates div i.e. canvas 
When an insert is already been drawn to canvas, and we are changing its position
changes by bhavik
*/
function $onClearInsertSnapIn(_draggedId, dd, type) {
    $onDragStarts(_draggedId, null, dd);
    _varIsImgDragged = 1;
    //dd.limit.bottom = 0;
    //dd.limit.top = 0;
    //dd.limit.right = 0;
    //dd.limit.left = 0;
    $('#' + _draggedId + '').css("left", $('#' + _draggedId + '').position().left + 200);
    //$('#' + _draggedId + '').css("top",0);
    $onDropsWithenCanvas(_draggedId, null, dd);
}
function test(_id) {
    var _type = 2;
    var _insertDrawn = {};
    $.each(_arrayOfInsertDrawn, function (key1, val1) {
        var valId = val1.NEW_ID;
        if (valId == _id) {
            _type = val1.IMAGE_TYPE;
            _insertDrawn = val1;
        }
    });

    //start Remove insert count. change by bhavik
    UnitSteps[selectedUnit].NoOfInsertCount--;
    UnitSteps[selectedUnit].AllowSnapInCount -= parseInt(_insertDrawn.INSERT_SNAP_IN_COUNT);
    CheckNextFromInsertSection();
    console.log("Remove insert due to wrong place");
    // end                            
    //Retaining it back to original size
    //var original_height = _currentImg.IMAGE_HEIGHT;
    //var original_width = _currentImg.IMAGE_WIDTH;
    var minimised_height = parseInt(_insertDrawn.IMAGE_HEIGHT) - parseInt((_insertDrawn.IMAGE_HEIGHT / 4));
    var minimised_width = parseInt(_insertDrawn.IMAGE_WIDTH) - parseInt((_insertDrawn.IMAGE_WIDTH / 4));

    //Revert the dragged element with animation to the left bar
    //Animate to previous position	
    $('#' + _id + '').animate({
        top: _insertDrawn.FIRSTPOSTOP,
        left: _insertDrawn.FIRSTPOSLEFT,
        width: minimised_width,
        height: minimised_height
    }, function () {
        $('#' + _id + '').remove();
    }
    );

    $.each(_arrayOfInsertDrawn, function (key1, val1) {
        if (val1 != undefined) {
            if (val1.NEW_ID == _id) {
                _arrayOfInsertDrawn.splice(key1, 1);
            }
        }
    });

    //Maintaing occupiied postion / deleting the image being dragged
    $.each(_arrayOccupiedPosition, function (key1, val1) {
        if (val1 != undefined) {
            if (val1.imgId == _id) {
                _arrayOccupiedPosition.splice(key1, 1);
            }
        }
    });
}
function $onDropsWithenCanvas(_draggedId, ev, dd) {

    if (_varIsImgDragged == 1) {

        console.log('drop within the canvas');
        var _id = _draggedId;
        var _type = 2;
        var _currentImg = {};
        var _insertDrawn = {};
        var _plateDrawn = {};
        var _initialImg = 0;
        var _matchfound = 0;

        /* Reading CSV object */
        $.each(_arrayOfCsvData, function (key1, val1) {
            if (val1.ID == _id) {
                _type = val1.IMAGE_TYPE;
                _currentImg = val1;
                _initialImg = 1;
            }
        });

        /* Reading obect of Insert drawn yet */
        $.each(_arrayOfInsertDrawn, function (key1, val1) {
            var valId = val1.NEW_ID;
            if (valId == _id) {
                _type = val1.IMAGE_TYPE;
                _currentImg = val1;
            }
        });

        //If dragged image is an insert and already been drawn to images
        if (_initialImg == 0) {

            if (_type == 2 && (_initialImg != 1)) {

                _insertDrawn = _currentImg;

                var _plateScrewX;
                var _plateScrewY;
                var _insertCurHeight = _insertDrawn.IMAGE_HEIGHT;
                var _insertCurWidth = _insertDrawn.IMAGE_WIDTH;
                var _plateLX = [];
                var _plateLY = [];
                var _plateRX = [];
                var _plateRY = [];
                var _insertLX = [];
                var _insertLY = [];
                var _insertRX = [];
                var _insertRY = [];
                var _matchfound = 0;

                //Getting plate type and compatibility with insret                 
                $.each(_arrayOfPlates, function (key1, val1) {                    
                    if (val1.unit == selectedUnit) {
                        _plateDrawn = val1;
                    }
                });

                //for handling decora insert( Long inserts)
                if (_insertDrawn.IMAGE_CATEGORY == 10) {

                    if (_plateDrawn.LONG_INSERT_COMPATIBLE == 1) { /*If the plate drwan is compatible wid the decora insert */

                        //Getiing inserts real height and wieght		
                        var _insertCurHeight = _insertDrawn.IMAGE_HEIGHT;
                        var _insertCurWidth = _insertDrawn.IMAGE_WIDTH;

                        //getting extra pair for long inserts
                        _plate_id = _plateDrawn.ID;
                        _plate_left = _plateDrawn.EXTRA_PAIR;
                        var _plateArrayL = _plate_left.split('|');
                        var _numberOfScrewsPlateL = _plateArrayL.length;

                        if (_plateDrawn.OVER_SIZED == 0) { //If plate are not over sized

                            //For placing inner images only
                            var _insertCurHeight = 188;
                            var _insertCurWidth = 94;

                            //getting all screws postion 
                            for (var i = 0; i < _plateArrayL.length; i++) {
                                var _plateScrewArray = _plateArrayL[i].split(',');
                                _plateLX[i + 1] = _plateScrewArray[0];
                                _plateLY[i + 1] = _plateScrewArray[1];
                            }

                            //insert right pair
                            _insert_left = _insertDrawn.LEFT_PAIR_1;
                            var _insertArrayL = _insert_left.split('|');
                            var _numberOfScrewsInsertL = _insertArrayL.length;

                            //getting all screws postion 
                            for (var i = 0; i < _insertArrayL.length; i++) {
                                var _insertScrewArray = _insertArrayL[i].split(',');
                                _insertLX[i + 1] = _insertScrewArray[0];
                                _insertLY[i + 1] = _insertScrewArray[1];
                            }

                            //Insert right pair
                            _insert_right = _insertDrawn.RIGHT_PAIR_1;
                            var _insertArrayR = _insert_right.split('|');
                            var _numberOfScrewsInsertR = _insertArrayR.length;

                            //getting all screws position 
                            for (var i = 0; i < _insertArrayR.length; i++) {
                                var _insertScrewArray = _insertArrayR[i].split(',');
                                _insertRX[i + 1] = _insertScrewArray[0];
                                _insertRY[i + 1] = _insertScrewArray[1];
                            }

                        } else { //If plate is oversized

                            //For placing inner images only
                            var _insertCurHeight = 188 - (188 / 4);
                            var _insertCurWidth = 94 - (94 / 4);

                            //getting all screws postion 
                            for (var i = 0; i < _plateArrayL.length; i++) {
                                var _plateScrewArray = _plateArrayL[i].split(',');
                                _plateLX[i + 1] = _plateScrewArray[0] - (_plateScrewArray[0] / 4);
                                _plateLY[i + 1] = _plateScrewArray[1] - (_plateScrewArray[1] / 4);
                            }

                            //insert right pair
                            _insert_left = _insertDrawn.LEFT_PAIR_1;
                            var _insertArrayL = _insert_left.split('|');
                            var _numberOfScrewsInsertL = _insertArrayL.length;

                            //getting all screws postion 
                            for (var i = 0; i < _insertArrayL.length; i++) {
                                var _insertScrewArray = _insertArrayL[i].split(',');
                                _insertLX[i + 1] = _insertScrewArray[0] - (_insertScrewArray[0] / 4);
                                _insertLY[i + 1] = _insertScrewArray[1] - (_insertScrewArray[1] / 4);
                            }

                            //Insert right pair
                            _insert_right = _insertDrawn.RIGHT_PAIR_1;
                            var _insertArrayR = _insert_right.split('|');
                            var _numberOfScrewsInsertR = _insertArrayR.length;

                            //getting all screws position 
                            for (var i = 0; i < _insertArrayR.length; i++) {
                                var _insertScrewArray = _insertArrayR[i].split(',');
                                _insertRX[i + 1] = _insertScrewArray[0] - (_insertScrewArray[0] / 4);
                                _insertRY[i + 1] = _insertScrewArray[1] - (_insertScrewArray[1] / 4);
                            }

                        }

                        current_left_plate = $('#' + _plate_id + '').css("left");
                        current_top_plate = $('#' + _plate_id + '').css("top");
                        current_left_insert = $('#' + _id + '').css("left");
                        current_top_insert = $('#' + _id + '').css("top");

                        current_top_plate = current_top_plate.substring(0, current_top_plate.length - 2);
                        current_top_insert = current_top_insert.substring(0, current_top_insert.length - 2);
                        current_left_plate = current_left_plate.substring(0, current_left_plate.length - 2);
                        current_left_insert = current_left_insert.substring(0, current_left_insert.length - 2);

                        //To get the eiement back in original size
                        $(_proxyElement).css('width', '').css('height', '');
                        $(_proxyElement).attr({ 'width': '' + _insertCurWidth + 'px', 'height': '' + _insertCurHeight + 'px' });

                        //Getting height of insert and the plate 
                        var heightDiffInsert = _insertLY[2] - _insertLY[1];
                        var heightDiffPlate = _plateLY[2] - _plateRY[1];

                        //getting width of the insert and the plate 
                        var widthDiffInsert = _insertRX[1] - _insertLX[1];
                        var widthDiffPlate = _plateRX[1] - _plateLX[1];
                        var n;

                        for (n = 1; n < (_numberOfScrewsPlateL + 1); n++) {

                            for (m = 1; m < (_numberOfScrewsInsertL + 1); m++) {

                                if ((Math.abs((parseInt(current_top_insert) + parseInt(_insertLY[m])) - (parseInt(current_top_plate) + parseInt(_plateLY[n]))) < 40) && (Math.abs((parseInt(current_left_insert) + parseInt(_insertLX[m])) - (parseInt(current_left_plate) + parseInt(_plateLX[n]))) < 40)) {

                                    var heightCompatible = 1;

                                    //If insert screws are more than 2
                                    if (_numberOfScrewsInsertL > 1) {

                                        var heightDiffPlateLower = _plateLY[n + 1] - _plateLY[n];

                                        //If insert screws are more than 2 their height must be compatible with plates
                                        if ((Math.abs(parseInt(heightDiffInsert) - parseInt(heightDiffPlateLower)) < 4)) {
                                            heightCompatible = 1;
                                        } else {
                                            heightCompatible = 0;
                                        }
                                        //Preventing from first position										
                                        if (n < m) {
                                            heightCompatible = 0;
                                        }
                                    }

                                    if (heightCompatible == 1) {

                                        //Check the avaiable place for inserting decora
                                        var placeAvaliable = 1;
                                        $.each(_arrayOccupiedDecoraPosition, function (key1, val1) {
                                            if (n == val1.screwId) {
                                                placeAvaliable = 0;
                                            }
                                        });

                                        if (placeAvaliable == 1) {
                                            current_top_plate = (parseInt(current_top_plate) + parseInt(_plateLY[n])) - parseInt(_insertLY[m]) + 54;
                                            current_left_plate = (parseInt(current_left_plate) + parseInt(_plateLX[n])) - parseInt(_insertLX[m]) + 14;

                                            //Generating new Id for insert drwan on the canvas
                                            var newImgVar = $.now();

                                            $('#' + _id + '').attr({ 'width': '' + _insertCurWidth + 'px', 'height': '' + _insertCurHeight + 'px' });
                                            $('#' + _id + '').addClass('element').css({ 'border': '0px', 'left': '' + current_left_plate + 'px', 'top': '' + current_top_plate + 'px' }); $('#' + _id + '').attr({ 'src': '' + _insertDrawn.SMALL_IMAGE_PATH + '' });

                                            _matchfound = 1; //setting the flag to true
                                            _insertDrawn.unit = selectedUnit;
                                            _arrayOfPartsDisplay.push(_insertDrawn); //Maintaining object for all inserts
                                            _varIsImgDragged = 0;

                                            /* display parts list on the part list div */
                                            $displayList();

                                            //Maintaining object for all occupied position
                                            var occupiedDecoraArr = {};
                                            occupiedDecoraArr.screwId = n;
                                            occupiedDecoraArr.imgId = _id;
                                            _arrayOccupiedDecoraPosition.push(occupiedDecoraArr);

                                            var occupiedDecoraArr1 = {};
                                            occupiedDecoraArr1.screwId = n + 1;
                                            occupiedDecoraArr.imgId = _id;
                                            _arrayOccupiedDecoraPosition.push(occupiedDecoraArr1);


											/*//Maintaining object for all occupied position
											var occupiedArr = {};
											occupiedArr.screwId = n;
											occupiedArr.screwPosX = _plateLX[n];
											occupiedArr.screwPosY = _plateLY[n];
											_arrayOccupiedPosition.push(occupiedArr);*/

                                            return false;
                                        }
                                    }
                                }
                            }
                        }

                        //* If image is not placed correctly 
                        if (_matchfound == 0) {

                            var original_height = _currentImg.IMAGE_HEIGHT;
                            var original_width = _currentImg.IMAGE_WIDTH;
                            var minimised_height = parseInt(_insertDrawn.IMAGE_HEIGHT);
                            var minimised_width = parseInt(_insertDrawn.IMAGE_WIDTH);
                            //Revert the dragged element with animation to the left bar
                            $(dd.proxy).animate({
                                top: _insertDrawn.FIRSTPOSTOP,
                                left: _insertDrawn.FIRSTPOSLEFT,
                                width: minimised_width,
                                height: minimised_height
                            }, function () {
                                //$('#'+_id+'').remove();
                                $(dd.proxy).remove();
                            }
                            );

                            $.each(_arrayOfInsertDrawn, function (key1, val1) {
                                if (val1 != undefined) {
                                    if (val1.NEW_ID == _id) {
                                        _arrayOfInsertDrawn.splice(key1, 1);
                                    }
                                }
                            });
                        }
                    } else { /*If the plate drwan is not compatible wid the decora insert */
                        var original_height = _currentImg.IMAGE_HEIGHT;
                        var original_width = _currentImg.IMAGE_WIDTH;
                        var minimised_height = parseInt(_insertDrawn.IMAGE_HEIGHT);
                        var minimised_width = parseInt(_insertDrawn.IMAGE_WIDTH);

                        //Revert the dragged element with animation to the left bar
                        $(dd.proxy).animate({
                            top: _insertDrawn.FIRSTPOSTOP,
                            left: _insertDrawn.FIRSTPOSLEFT,
                            width: minimised_width,
                            height: minimised_height
                        }, function () {
                            //$('#'+_id+'').remove();
                            $(dd.proxy).remove();
                        }
                        );

                        $.each(_arrayOfInsertDrawn, function (key1, val1) {
                            if (val1 != undefined) {
                                if (val1.NEW_ID == _id) {
                                    _arrayOfInsertDrawn.splice(key1, 1);
                                }
                            }
                        });

                    }

                    //Handling Of snap Ins Parts Over Decora inserts
                } else if (_insertDrawn.IMAGE_CATEGORY == 11) {

                    if (_plateDrawn.LONG_INSERT_COMPATIBLE == 1) { /*If the plate drwan is compatible wid the decora insert */

                        var _arrayOfDecoraInsforSnapIns = [];

                        //For maintaining the array of decora inserts which are compatible to the snap Ins inserts
                        $.each(_arrayOfPartsDisplay, function (key1, val1) {

                            //if( (val1 != undefined ) && ((val1.PART_NUMBER == 'SS-PORT3') || (val1.PART_NUMBER == 'SS-PORT4') || (val1.PART_NUMBER == 'SS-PORT6')) ) {
                            _arrayOfDecoraInsforSnapIns.push(val1);
                            //}

                        });



                        /* For each compatible decora drwan will check the position of snap Ins inserts */
                        $.each(_arrayOfDecoraInsforSnapIns, function (key, val) {

                            //Getiing inserts real height and wieght		
                            var _insertCurHeight = _insertDrawn.IMAGE_HEIGHT;
                            var _insertCurWidth = _insertDrawn.IMAGE_WIDTH;

                            //getting extra pair for long inserts
                            var _plate_id = val.NEW_ID;
                            var _plate_left = val.EXTRA_PAIR;

                            var _plateArrayL = _plate_left.split('|');
                            var _numberOfScrewsPlateL = _plateArrayL.length;

                            if (_plateDrawn.OVER_SIZED == 0) { //If plate are not over sized

                                //For placing inner images only
                                var _insertCurHeight = 46;
                                var _insertCurWidth = 54;

                                //getting all screws postion 
                                for (var i = 0; i < _plateArrayL.length; i++) {
                                    var _plateScrewArray = _plateArrayL[i].split(',');
                                    _plateLX[i + 1] = _plateScrewArray[0];
                                    _plateLY[i + 1] = _plateScrewArray[1];
                                }

                            } else { //If plate is oversized

                                //For placing inner images only
                                var _insertCurHeight = 46 - (46 / 4);
                                var _insertCurWidth = 54 - (54 / 4);

                                //getting all screws postion 
                                for (var i = 0; i < _plateArrayL.length; i++) {
                                    var _plateScrewArray = _plateArrayL[i].split(',');
                                    _plateLX[i + 1] = _plateScrewArray[0] - (_plateScrewArray[0] / 4);
                                    _plateLY[i + 1] = _plateScrewArray[1] - (_plateScrewArray[1] / 4);
                                }

                            }

                            current_left_plate = $('#' + _plate_id + '').css("left");
                            current_top_plate = $('#' + _plate_id + '').css("top");
                            current_left_insert = $('#' + _id + '').css("left");
                            current_top_insert = $('#' + _id + '').css("top");

                            current_top_plate = current_top_plate.substring(0, current_top_plate.length - 2);
                            current_top_insert = current_top_insert.substring(0, current_top_insert.length - 2);
                            current_left_plate = current_left_plate.substring(0, current_left_plate.length - 2);
                            current_left_insert = current_left_insert.substring(0, current_left_insert.length - 2);

                            var n;

                            var placeAvaliable = 1;
                            for (n = 1; n < (_numberOfScrewsPlateL + 1); n++) {
                                console.log("------------------");
                                console.log(current_top_insert);
                                console.log(current_top_plate);
                                console.log(_plateLY[n]);
                                console.log(current_left_insert);
                                console.log(current_left_plate);
                                console.log(_plateLX[n]);
                                if ((Math.abs((parseInt(current_top_insert)) - (parseInt(current_top_plate) + parseInt(_plateLY[n]))) < 40) && (Math.abs((parseInt(current_left_insert)) - (parseInt(current_left_plate) + parseInt(_plateLX[n]))) < 30)) {

                                    var heightCompatible = 1;

                                    if (heightCompatible == 1) {

                                        _arrayOccupiedSnapInsPosition

                                        /*$.each( _arrayOccupiedPosition, function( key1, val1 ) {
                                            if( ( n == val1.screwId ) && ( _plateLX[n] == val1.screwPosX ) && ( _plateLY[n] == val1.screwPosY ) ) {
                                                //placeAvaliable = 0;
                                            }
                                        });*/

                                        //Check the avaiable place for inserting decora

                                        var placeAvaliable = 1;
                                        $.each(_arrayOccupiedSnapInsPosition, function (key1, val1) {
                                            if ((n == val1.screwId) && (_plate_id == val1.decoraId)) {
                                                placeAvaliable = 0;
                                            }
                                        });

                                        if (placeAvaliable == 1) {

                                            current_top_plate = (parseInt(current_top_plate) + parseInt(_plateLY[n]));
                                            current_left_plate = (parseInt(current_left_plate) + parseInt(_plateLX[n]));

                                            //Generating new Id for insert drwan on the canvas
                                            var newImgVar = $.now();

                                            $('#' + _id + '').attr({ 'width': '' + _insertCurWidth + 'px', 'height': '' + _insertCurHeight + 'px' });
                                            $('#' + _id + '').addClass('element').css({ 'border': '0px', 'left': '' + current_left_plate + 'px', 'top': '' + current_top_plate + 'px' });
                                            $('#' + _id + '').attr({ 'src': '' + _insertDrawn.SMALL_IMAGE_PATH + '' });

                                            //$('#front_plates').append('<img style="left:'+current_left_plate+'px; top:'+ current_top_plate +'px; position : absolute;" width="'+_insertCurWidth+'" height="'+_insertCurHeight+'" id="'+newImgVar+'" src="' + _insertDrawn1.SMALL_IMAGE_PATH + '" />');

                                            _matchfound = 1; //setting the flag to true

                                            _insertDrawn.DECORAINS_ID = '' + _plate_id + '';

                                            _insertDrawn.unit = selectedUnit;
                                            _arrayOfPartsDisplay.push(_insertDrawn); //Maintaining object for all inserts

                                            _varIsImgDragged = 0;
                                            /* display parts list on the part list div */
                                            $displayList();

                                            //Maintaining object for all occupied position
                                            var occupiedDecoraArr = {};
                                            occupiedDecoraArr.screwId = n;
                                            occupiedDecoraArr.imgId = _id;
                                            occupiedDecoraArr.decoraId = _plate_id;
                                            _arrayOccupiedSnapInsPosition.push(occupiedDecoraArr);

                                            /*var occupiedArr = {};
                                            occupiedArr.screwId = n;
                                            occupiedArr.screwPosX = _plateLX[n];
                                            occupiedArr.screwPosY = _plateLY[n];
                                            _arrayOccupiedPosition.push(occupiedArr);*/



                                            return false;
                                        }
                                    }
                                }
                            }

                        });

                        //* If image is not placed correctly 
                        if (_matchfound == 0) {
                            // Change by Bhavik - Remove snap in if not dragged in right place
                            UnitSteps[selectedUnit].NoOfSnapInCount--;
                            console.log("Remove snap in - 2131");
                            CheckNextFromSnapInSection();
                            RemoveElement_dd(_draggedId, dd);
                            // end
                            var original_height = _currentImg.IMAGE_HEIGHT;
                            var original_width = _currentImg.IMAGE_WIDTH;
                            var minimised_height = parseInt(_insertDrawn.IMAGE_HEIGHT) - parseInt((_insertDrawn.IMAGE_HEIGHT / 4));
                            var minimised_width = parseInt(_insertDrawn.IMAGE_WIDTH) - parseInt((_insertDrawn.IMAGE_WIDTH / 2));
                            //Revert the dragged element with animation to the left bar
                            $('#' + _id + '').animate({
                                top: _insertDrawn.FIRSTPOSTOP,
                                left: _insertDrawn.FIRSTPOSLEFT,
                                width: minimised_width,
                                height: minimised_height
                            }, function () {
                                $('#' + _id + '').remove();
                            }
                            );
                        }

                    } else { /*If the plate drwan is not compatible wid the decora insert */
                        var original_height = _currentImg.IMAGE_HEIGHT;
                        var original_width = _currentImg.IMAGE_WIDTH;
                        var minimised_height = parseInt(_insertDrawn.IMAGE_HEIGHT) - parseInt((_insertDrawn.IMAGE_HEIGHT / 4));
                        var minimised_width = parseInt(_insertDrawn.IMAGE_WIDTH) - parseInt((_insertDrawn.IMAGE_WIDTH / 2));
                        //Revert the dragged element with animation to the left bar
                        $('#' + _id + '').animate({
                            top: _insertDrawn.FIRSTPOSTOP,
                            left: _insertDrawn.FIRSTPOSLEFT,
                            width: minimised_width,
                            height: minimised_height
                        }, function () {
                            $('#' + _id + '').remove();
                        }
                        );
                    }
                    // End Of Handling Of snap Ins Parts Over Decora inserts 

                } else { //If insert is other than decora insert( Long inserts )                    
                    if (_plateDrawn.OVER_SIZED == '0') { //Plate is not oversized

                        //Getting real height and width of plate
                        var _insertCurHeight = _insertDrawn.IMAGE_HEIGHT;
                        var _insertCurWidth = _insertDrawn.IMAGE_WIDTH;

                        _plate_id = _plateDrawn.ID;
                        _plate_left = _plateDrawn.LEFT_PAIR_1;
                        /* Checking for each screws position*/
                        for (var screwCount = 1; screwCount < 6; screwCount++) {

                            if (screwCount == 1) {
                                _plate_left = _plateDrawn.LEFT_PAIR_1;
                                _plate_right = _plateDrawn.RIGHT_PAIR_1;
                            } else if (screwCount == 2) {
                                _plate_left = _plateDrawn.LEFT_PAIR_2;
                                _plate_right = _plateDrawn.RIGHT_PAIR_2;
                            } else if (screwCount == 3) {
                                _plate_left = _plateDrawn.LEFT_PAIR_3;
                                _plate_right = _plateDrawn.RIGHT_PAIR_3;
                            } else if (screwCount == 4) {
                                _plate_left = _plateDrawn.LEFT_PAIR_4;
                                _plate_right = _plateDrawn.RIGHT_PAIR_4;
                            } else if (screwCount == 5) {
                                _plate_left = _plateDrawn.LEFT_PAIR_5;
                                _plate_right = _plateDrawn.RIGHT_PAIR_5;
                            } else if (screwCount == 6) {
                                _plate_left = _plateDrawn.LEFT_PAIR_6;
                                _plate_right = _plateDrawn.RIGHT_PAIR_6;
                            }

                            if ((_plate_left != '') && (_plate_right != '')) {	//if screws are not blank. 

                                var _plateArrayL = _plate_left.split('|');
                                var _numberOfScrewsPlateL = _plateArrayL.length;

                                //getting all screws position 
                                for (var i = 0; i < _plateArrayL.length; i++) {
                                    var _plateScrewArray = _plateArrayL[i].split(',');
                                    _plateLX[i + 1] = _plateScrewArray[0];
                                    _plateLY[i + 1] = _plateScrewArray[1];
                                }

                                //Plate right pair
                                var _plateArrayR = _plate_right.split('|');
                                var _numberOfScrewsPlateR = _plateArrayR.length;

                                //getting all screws postion at right plate
                                for (var i = 0; i < _plateArrayR.length; i++) {
                                    var _plateScrewArray = _plateArrayR[i].split(',');
                                    _plateRX[i + 1] = _plateScrewArray[0];
                                    _plateRY[i + 1] = _plateScrewArray[1];
                                }

                                //insert right pair
                                _insert_left = _insertDrawn.LEFT_PAIR_1;
                                var _insertArrayL = _insert_left.split('|');
                                var _numberOfScrewsInsertL = _insertArrayL.length;

                                //getting all screws postion 
                                for (var i = 0; i < _insertArrayL.length; i++) {
                                    var _insertScrewArray = _insertArrayL[i].split(',');
                                    _insertLX[i + 1] = _insertScrewArray[0];
                                    _insertLY[i + 1] = _insertScrewArray[1];
                                }

                                //Insert right pair
                                _insert_right = _insertDrawn.RIGHT_PAIR_1;
                                var _insertArrayR = [];
                                _insertArrayR = _insert_right.split('|');
                                var _numberOfScrewsInsertR = _insertArrayR.length;

                                //getting all screws postion 
                                for (var i = 0; i < _insertArrayR.length; i++) {
                                    var _insertScrewArray = _insertArrayR[i].split(',');
                                    _insertRX[i + 1] = _insertScrewArray[0];
                                    _insertRY[i + 1] = _insertScrewArray[1];
                                }

                                //Getting  top n left of plate and insert
                                current_left_plate = $('#' + _plate_id + '').css("left");
                                current_top_plate = $('#' + _plate_id + '').css("top");
                                current_left_insert = $('#' + _id + '').css("left");
                                current_top_insert = $('#' + _id + '').css("top");

                                //Getting px out of the string
                                current_top_plate = current_top_plate.substring(0, current_top_plate.length - 2);
                                current_top_insert = current_top_insert.substring(0, current_top_insert.length - 2);
                                current_left_plate = current_left_plate.substring(0, current_left_plate.length - 2);
                                current_left_insert = current_left_insert.substring(0, current_left_insert.length - 2);

                                //To get th eiement back in original sizee
                                $('#' + _id + '').css('width', '').css('height', '');
                                $('#' + _id + '').attr({ 'width': '' + _insertCurWidth + 'px', 'height': '' + _insertCurHeight + 'px' });

                                //Getting height
                                var heightDiffInsert = _insertLY[2] - _insertRY[1];
                                var heightDiffPlate = _plateLY[2] - _plateRY[1];

                                //getting width
                                var widthDiffInsert = _insertRX[1] - _insertLX[1];
                                var widthDiffPlate = _plateRX[1] - _plateLX[1];
                                var n;

                                var placeAvaliable = 1;
                                if ((Math.abs(parseInt(widthDiffInsert) - parseInt(widthDiffPlate)) < 5)) {

                                    for (n = 1; n < (_numberOfScrewsPlateL + 1); n++) {
                                        for (m = 1; m < (_numberOfScrewsInsertL + 1); m++) {
                                            //Checking the screws of plates and inserts 
                                            if ((Math.abs((parseInt(current_top_insert) + parseInt(_insertLY[m])) - (parseInt(current_top_plate) + parseInt(_plateLY[n]))) < 48) && (Math.abs((parseInt(current_left_insert) + parseInt(_insertLX[m])) - (parseInt(current_left_plate) + parseInt(_plateLX[n]))) < 80)) {
                                                var heightCompatible = 1;
                                                var noOfScrewsInInsert = 1;
                                                //If insert screws are more than 1, calulate height also
                                                if (_numberOfScrewsInsertR > 1) {

                                                    var heightDiffPlateLower = _plateLY[n + 1] - _plateRY[n];

                                                    //If insert screws are more than 1 their hieght must be compatible with plates
                                                    if ((Math.abs(parseInt(heightDiffInsert) - parseInt(heightDiffPlateLower)) < 5)) {
                                                        heightCompatible = 1;
                                                        noOfScrewsInInsert = 2;
                                                    } else {
                                                        heightCompatible = 0;
                                                    }

                                                    //Preventing from first position of plate second position of insert										
                                                    if (n < m) {
                                                        heightCompatible = 0;
                                                    }

                                                    //For handing three screws position covering inserts
                                                    if (heightCompatible == 0) {

                                                        if (((n == 3) && (m == 1)) || ((n == 2) && (m == 2))) {

                                                            heightCompatible = 0;

                                                        } else {
                                                            var heightDiffPlateLower = _plateLY[n + 1] - _plateRY[n - 1];

                                                            //If insert screws are more than 2 their height must be compatible with plates
                                                            if ((Math.abs(parseInt(heightDiffInsert) - parseInt(heightDiffPlateLower)) < 4)) {
                                                                heightCompatible = 1;
                                                                noOfScrewsInInsert = 3;
                                                            } else {
                                                                heightCompatible = 0;
                                                            }
                                                        }

                                                        //For handing four screws position covering inserts (whole plate cover)
                                                        if (heightCompatible == 0) {

                                                            if ((n == 4) && (m == 1)) {
                                                                heightCompatible = 0;
                                                            } else {

                                                                var heightDiffPlateLower = _plateLY[n] - _plateRY[n - 3];

                                                                //If insert screws are more than 3 their height must be compatible with plates
                                                                if ((Math.abs(parseInt(heightDiffInsert) - parseInt(heightDiffPlateLower)) < 4)) {
                                                                    heightCompatible = 1;
                                                                    noOfScrewsInInsert = 4
                                                                } else {
                                                                    heightCompatible = 0;
                                                                }
                                                            }

                                                        }

                                                    }
                                                }

                                                /* Compatible height */
                                                if (heightCompatible == 1) {

                                                    current_top_plate = (parseInt(current_top_plate) + parseInt(_plateLY[n])) - parseInt(_insertLY[m]);
                                                    current_left_plate = (parseInt(current_left_plate) + parseInt(_plateLX[n])) - parseInt(_insertLX[m]);

                                                    //Preventing drop out of targeted div
                                                    allowedTop = Math.min(dd.limit.bottom, Math.max(dd.limit.top, current_top_plate)),
                                                        allowedLeft = Math.min(dd.limit.right, Math.max(dd.limit.left, current_left_plate))

                                                    if ((current_left_plate <= allowedLeft) && (current_top_plate <= allowedTop)) {

														/*var placeAvaliable = 1;
														$.each( _arrayOccupiedPosition, function( key1, val1 ) {
															if( ( n == val1.screwId ) && ( _plateLX[n] == val1.screwPosX ) && ( _plateLY[n] == val1.screwPosY ) ) {
																//placeAvaliable = 0;
															}
														});*/

                                                        //Preventing overlapping of inserts with checking previous position
                                                        $.each(_arrayOccupiedPosition, function (key4, val4) {

                                                            //One Screw pair
                                                            if ((noOfScrewsInInsert == 1) && (screwCount == val4.screwCount)) {
                                                                if ((n == val4.screwIdN) && (m == val4.screwIdM)) {

                                                                    if (noOfScrewsInInsert == val4.noOfScrewsInInsert) {
                                                                        placeAvaliable = 0;
                                                                    } else {
                                                                        placeAvaliable = 0;
                                                                    }
                                                                }

                                                                if ((val4.noOfScrewsInInsert == 2) && ((val4.screwIdN + 1) == (n))) {
                                                                    placeAvaliable = 0;
                                                                } else if ((val4.noOfScrewsInInsert == 3) && (((val4.screwIdN + 1) == n) || ((val4.screwIdN + 2) == n))) {
                                                                    placeAvaliable = 0;
                                                                } else if ((val4.noOfScrewsInInsert == 4)) {
                                                                    placeAvaliable = 0;
                                                                }

                                                                //Two Screw pairs
                                                            } else if ((noOfScrewsInInsert == 2) && (screwCount == val4.screwCount)) {

                                                                if ((n == val4.screwIdN) && (m == val4.screwIdM)) {
                                                                    if (noOfScrewsInInsert == val4.noOfScrewsInInsert) {
                                                                        placeAvaliable = 0;
                                                                    } else {
                                                                        placeAvaliable = 0;
                                                                    }
                                                                }

                                                                if ((val4.noOfScrewsInInsert == 2) && ((val4.screwIdN + 1) == n)) {
                                                                    placeAvaliable = 0;
                                                                } else if ((val4.noOfScrewsInInsert == 3)) {
                                                                    placeAvaliable = 0;
                                                                } else if ((val4.noOfScrewsInInsert == 4)) {
                                                                    placeAvaliable = 0;
                                                                } else if ((val4.noOfScrewsInInsert == 2) && ((val4.screwIdN - 1) == n)) {
                                                                    placeAvaliable = 0;
                                                                } else if ((val4.noOfScrewsInInsert == 1) && ((val4.screwIdN - 1) == n)) {
                                                                    placeAvaliable = 0;
                                                                }

                                                                //Three Screw Pairs	
                                                            } else if ((noOfScrewsInInsert == 3) && (screwCount == val4.screwCount)) {

                                                                if ((n == val4.screwIdN) && (m == val4.screwIdM)) {
                                                                    if (noOfScrewsInInsert == val4.noOfScrewsInInsert) {
                                                                        placeAvaliable = 0;
                                                                    } else {
                                                                        placeAvaliable = 0;
                                                                    }
                                                                }

                                                                if ((val4.noOfScrewsInInsert == 2)) {
                                                                    placeAvaliable = 0;
                                                                } else if ((val4.noOfScrewsInInsert == 3)) {
                                                                    placeAvaliable = 0;
                                                                } else if ((val4.noOfScrewsInInsert == 4)) {
                                                                    placeAvaliable = 0;
                                                                    //	} else if( (val4.noOfScrewsInInsert == 1) && ( ( (val4.screwIdN -1)== n ) || ( (val4.screwIdN -2)== n ) || ( (val4.screwIdN + 1)== n ) || ( (val4.screwIdN + 2)== n )) ){
                                                                } else if ((val4.noOfScrewsInInsert == 1) && ((val4.screwIdN == 2) || (val4.screwIdN == 3) || ((3 == n) && (val4.screwIdN == 1)) || ((2 == n) && (val4.screwIdN == 4)))) {
                                                                    placeAvaliable = 0;
                                                                }

                                                                //Four Screw Pairs	
                                                            } else if ((noOfScrewsInInsert == 4) && (screwCount == val4.screwCount)) {
                                                                placeAvaliable = 0;
                                                            }

                                                        });
                                                        //End Of Preventing overlapping of inserts with checking previous position	

                                                        //If place is not already occupied by insert                                                         
                                                        if (placeAvaliable == 1) {

                                                            _matchfound = 1;

                                                            $('#' + _id + '').attr({ 'width': '' + _insertCurWidth + 'px', 'height': '' + _insertCurHeight + 'px' });
                                                            $('#' + _id + '').addClass('element').css({ 'border': '0px', 'left': '' + current_left_plate + 'px', 'top': '' + current_top_plate + 'px' });
                                                            //_arrayOfInsertDrawn.push(newInsertID); //Maintaining object for all inserts
                                                            _insertDrawn.unit = selectedUnit;
                                                            _arrayOfPartsDisplay.push(_insertDrawn); //Maintaining object for all inserts
                                                            /* display parts list on the part list div */
                                                            $displayList();
                                                            _varIsImgDragged = 0;

                                                            //Preventing of overlapping of inserts
                                                            var occupiedArr = {};
                                                            occupiedArr.noOfScrewsInInsert = noOfScrewsInInsert;
                                                            occupiedArr.screwIdN = n;
                                                            occupiedArr.screwIdM = m;
                                                            occupiedArr.screwCount = screwCount;
                                                            occupiedArr.imgId = _id;
                                                            occupiedArr.unit = selectedUnit;
                                                            _arrayOccupiedPosition.push(occupiedArr);

															/*var occupiedArr = {};
															occupiedArr.screwId = n;
															occupiedArr.screwPosX = _plateLX[n];
															occupiedArr.screwPosY = _plateLY[n];*/
                                                            //_arrayOccupiedPosition.push(occupiedArr);									
                                                            return false;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }

                                } else {
                                    //Animate back to original position	
                                    var original_height = _currentImg.IMAGE_HEIGHT;
                                    var original_width = _currentImg.IMAGE_WIDTH;
                                    var minimised_height = parseInt(_insertDrawn.IMAGE_HEIGHT) - parseInt((_insertDrawn.IMAGE_HEIGHT / 2));
                                    var minimised_width = parseInt(_insertDrawn.IMAGE_WIDTH) - parseInt((_insertDrawn.IMAGE_WIDTH / 2));

                                    //Revert the dragged element with animation to the left bar
                                    $('#' + _id + '').animate({
                                        top: _insertDrawn.FIRSTPOSTOP,
                                        left: _insertDrawn.FIRSTPOSLEFT,
                                        width: minimised_width,
                                        height: minimised_height
                                    }, function () {
                                        $('#' + _id + '').remove();
                                    }
                                    );

                                    $.each(_arrayOfInsertDrawn, function (key1, val1) {
                                        if (val1 != undefined) {
                                            if (val1.NEW_ID == _id) {
                                                _arrayOfInsertDrawn.splice(key1, 1);
                                            }
                                        }
                                    });

                                }
                            } //End of if screws are not blank. 
                        }

                        if (_matchfound == 0) {
                            //start Remove insert count. change by bhavik
                            UnitSteps[selectedUnit].NoOfInsertCount--;
                            UnitSteps[selectedUnit].AllowSnapInCount -= parseInt(_insertDrawn.INSERT_SNAP_IN_COUNT);
                            CheckNextFromInsertSection();
                            RemoveElement_dd(_draggedId, dd);
                            CLearSnapIns();
                            console.log("Remove insert due to wrong place");
                            // end                            
                            //Retaining it back to original size
                            var original_height = _currentImg.IMAGE_HEIGHT;
                            var original_width = _currentImg.IMAGE_WIDTH;
                            var minimised_height = parseInt(_insertDrawn.IMAGE_HEIGHT) - parseInt((_insertDrawn.IMAGE_HEIGHT / 4));
                            var minimised_width = parseInt(_insertDrawn.IMAGE_WIDTH) - parseInt((_insertDrawn.IMAGE_WIDTH / 4));

                            //Revert the dragged element with animation to the left bar
                            //Animate to previous position	
                            $('#' + _id + '').animate({
                                top: _insertDrawn.FIRSTPOSTOP,
                                left: _insertDrawn.FIRSTPOSLEFT,
                                width: minimised_width,
                                height: minimised_height
                            }, function () {
                                $('#' + _id + '').remove();
                            }
                            );

                            $.each(_arrayOfInsertDrawn, function (key1, val1) {
                                if (val1 != undefined) {
                                    if (val1.NEW_ID == _id) {
                                        _arrayOfInsertDrawn.splice(key1, 1);
                                    }
                                }
                            });
                        }

                    } else {//plate is oversized                        
                        //Getting height and width of plate and reducing the size to get it fit on the canvas
                        //var _insertCurHeight = _insertDrawn.IMAGE_HEIGHT - (_insertDrawn.IMAGE_HEIGHT/4);
                        //var _insertCurWidth = _insertDrawn.IMAGE_WIDTH - (_insertDrawn.IMAGE_WIDTH/4);

                        if (_plateDrawn.OVER_SIZED == '1') {
                            var _insertCurHeight = _insertDrawn.IMAGE_HEIGHT - (_insertDrawn.IMAGE_HEIGHT / 4);
                            var _insertCurWidth = _insertDrawn.IMAGE_WIDTH - (_insertDrawn.IMAGE_WIDTH / 4);
                        } else {
                            var _insertCurHeight = _insertDrawn.IMAGE_HEIGHT - (_insertDrawn.IMAGE_HEIGHT / 2);
                            var _insertCurWidth = _insertDrawn.IMAGE_WIDTH - (_insertDrawn.IMAGE_WIDTH / 2);
                        }

                        _plate_id = _plateDrawn.ID;
                        var _plate_left;

                        for (var screwCount = 1; screwCount < 7; screwCount++) {

                            //Plate right pair
                            if (screwCount == 1) {
                                _plate_left = _plateDrawn.LEFT_PAIR_1;
                                _plate_right = _plateDrawn.RIGHT_PAIR_1;
                            } else if (screwCount == 2) {
                                _plate_left = _plateDrawn.LEFT_PAIR_2;
                                _plate_right = _plateDrawn.RIGHT_PAIR_2;
                            } else if (screwCount == 3) {
                                _plate_left = _plateDrawn.LEFT_PAIR_3;
                                _plate_right = _plateDrawn.RIGHT_PAIR_3;
                            } else if (screwCount == 4) {
                                _plate_left = _plateDrawn.LEFT_PAIR_4;
                                _plate_right = _plateDrawn.RIGHT_PAIR_4;
                            } else if (screwCount == 5) {
                                _plate_left = _plateDrawn.LEFT_PAIR_5;
                                _plate_right = _plateDrawn.RIGHT_PAIR_5;
                            } else if (screwCount == 6) {
                                _plate_left = _plateDrawn.LEFT_PAIR_6;
                                _plate_right = _plateDrawn.RIGHT_PAIR_6;
                            }

                            // If screws plates are not blank
                            if ((_plate_left != '') && (_plate_right != '')) {

                                //Plate left pair
                                var _plateArrayL = _plate_left.split('|');
                                var _numberOfScrewsPlateL = _plateArrayL.length;

                                //getting all screws postion 
                                for (var i = 0; i < _plateArrayL.length; i++) {
                                    var _plateScrewArray = _plateArrayL[i].split(',');
                                    if (_plateDrawn.OVER_SIZED == '1') {
                                        _plateLX[i + 1] = _plateScrewArray[0] - (_plateScrewArray[0] / 4);
                                        _plateLY[i + 1] = _plateScrewArray[1] - (_plateScrewArray[1] / 4);
                                    } else {
                                        _plateLX[i + 1] = _plateScrewArray[0] - (_plateScrewArray[0] / 2);
                                        _plateLY[i + 1] = _plateScrewArray[1] - (_plateScrewArray[1] / 2);
                                    }
                                }

                                //Plate right pair
                                var _plateArrayR = _plate_right.split('|');
                                var _numberOfScrewsPlateR = _plateArrayR.length;

                                //getting all screws postion at right plate
                                for (var i = 0; i < _plateArrayR.length; i++) {
                                    var _plateScrewArray = _plateArrayR[i].split(',');
                                    if (_plateDrawn.OVER_SIZED == '1') {
                                        _plateRX[i + 1] = _plateScrewArray[0] - (_plateScrewArray[0] / 4);
                                        _plateRY[i + 1] = _plateScrewArray[1] - (_plateScrewArray[1] / 4);
                                    } else {
                                        _plateRX[i + 1] = _plateScrewArray[0] - (_plateScrewArray[0] / 2);
                                        _plateRY[i + 1] = _plateScrewArray[1] - (_plateScrewArray[1] / 2);
                                    }
                                }

                                //insert right pair
                                _insert_left = _insertDrawn.LEFT_PAIR_1;
                                var _insertArrayL = _insert_left.split('|');
                                var _numberOfScrewsInsertL = _insertArrayL.length;

                                //getting all screws postion 
                                for (var i = 0; i < _insertArrayL.length; i++) {
                                    var _insertScrewArray = _insertArrayL[i].split(',');
                                    if (_plateDrawn.OVER_SIZED == '1') {
                                        _insertLX[i + 1] = _insertScrewArray[0] - (_insertScrewArray[0] / 4);
                                        _insertLY[i + 1] = _insertScrewArray[1] - (_insertScrewArray[1] / 4);
                                    } else {
                                        _insertLX[i + 1] = _insertScrewArray[0] - (_insertScrewArray[0] / 2);
                                        _insertLY[i + 1] = _insertScrewArray[1] - (_insertScrewArray[1] / 2);
                                    }
                                }

                                //Insert right pair
                                _insert_right = _insertDrawn.RIGHT_PAIR_1;
                                var _insertArrayR = _insert_right.split('|');
                                var _numberOfScrewsInsertR = _insertArrayR.length;

                                //getting all screws position 
                                for (var i = 0; i < _insertArrayR.length; i++) {
                                    var _insertScrewArray = _insertArrayR[i].split(',');
                                    if (_plateDrawn.OVER_SIZED == '1') {
                                        _insertRX[i + 1] = _insertScrewArray[0] - (_insertScrewArray[0] / 4);
                                        _insertRY[i + 1] = _insertScrewArray[1] - (_insertScrewArray[1] / 4);
                                    } else {
                                        _insertRX[i + 1] = _insertScrewArray[0] - (_insertScrewArray[0] / 2);
                                        _insertRY[i + 1] = _insertScrewArray[1] - (_insertScrewArray[1] / 2);
                                    }
                                }

                                //Getting  top n left of plate and insert
                                current_left_plate = $('#' + _plate_id + '').css("left");
                                current_top_plate = $('#' + _plate_id + '').css("top");
                                current_left_insert = $('#' + _id + '').css("left");
                                current_top_insert = $('#' + _id + '').css("top");

                                //Getting px out of the string
                                current_top_plate = current_top_plate.substring(0, current_top_plate.length - 2);
                                current_top_insert = current_top_insert.substring(0, current_top_insert.length - 2);
                                current_left_plate = current_left_plate.substring(0, current_left_plate.length - 2);
                                current_left_insert = current_left_insert.substring(0, current_left_insert.length - 2);

                                //To get th eiement back in original size
                                $('#' + _id + '').css('width', '').css('height', '');
                                $('#' + _id + '').attr({ 'width': '' + _insertCurWidth + 'px', 'height': '' + _insertCurHeight + 'px' });

                                //Getting height
                                var heightDiffInsert = _insertLY[2] - _insertRY[1];
                                var heightDiffPlate = _plateLY[2] - _plateRY[1];

                                //getting width
                                var widthDiffInsert = _insertRX[1] - _insertLX[1];
                                var widthDiffPlate = _plateRX[1] - _plateLX[1];
                                var _matchfound = 0;
                                var placeAvaliable = 1;

                                //If width is compatible between plates's screws and insert's screws
                                if ((Math.abs(parseInt(widthDiffInsert) - parseInt(widthDiffPlate)) < 5)) {

                                    for (var n = 1; n < (_numberOfScrewsPlateL + 1); n++) {
                                        for (m = 1; m < (_numberOfScrewsInsertL + 1); m++) {

                                            var topDifferenceToCheck;
                                            var leftDifferenceToCheck;

                                            //Adjustinmg the near by position as per plate size
                                            if (_plateDrawn.OVER_SIZED == '1') {
                                                topDifferenceToCheck = 40;
                                                leftDifferenceToCheck = 60;
                                            } else {
                                                topDifferenceToCheck = 20;
                                                leftDifferenceToCheck = 25;
                                            }

                                            //Checking the screws of plates and inserts 
                                            if ((Math.abs((parseInt(current_top_insert) + parseInt(_insertLY[m])) - (parseInt(current_top_plate) + parseInt(_plateLY[n]))) < topDifferenceToCheck) && (Math.abs((parseInt(current_left_insert) + parseInt(_insertLX[m])) - (parseInt(current_left_plate) + parseInt(_plateLX[n]))) < leftDifferenceToCheck)) {
                                                var heightCompatible = 1;
                                                var noOfScrewsInInsert = 1;
                                                //If insert screws are more than 2, calulate height also
                                                if (_numberOfScrewsInsertR > 1) {

                                                    var heightDiffPlateLower = _plateLY[n + 1] - _plateRY[n];

                                                    //If insert screws are more than 1 their hieght must be compatible with plates
                                                    if ((Math.abs(parseInt(heightDiffInsert) - parseInt(heightDiffPlateLower)) < 3)) {
                                                        heightCompatible = 1;
                                                        noOfScrewsInInsert = 2
                                                    } else {
                                                        heightCompatible = 0;
                                                    }

                                                    //Preventing from first position of plate second position of insert										
                                                    if (n < m) {
                                                        heightCompatible = 0;
                                                    }

                                                    //For handing threee screws position covering inserts 
                                                    if (heightCompatible == 0) {

                                                        if (((n == 3) && (m == 1)) || ((n == 2) && (m == 2))) {

                                                            heightCompatible = 0;

                                                        } else {
                                                            var heightDiffPlateLower = _plateLY[n + 1] - _plateRY[n - 1];

                                                            //If insert screws are more than 2 their height must be compatible with plates
                                                            if ((Math.abs(parseInt(heightDiffInsert) - parseInt(heightDiffPlateLower)) < 4)) {
                                                                heightCompatible = 1;
                                                                noOfScrewsInInsert = 3;
                                                            } else {
                                                                heightCompatible = 0;
                                                            }
                                                        }

                                                        //For handing four screws position covering inserts (whole plate cover)
                                                        if (heightCompatible == 0) {

                                                            if ((n == 4) && (m == 1)) {
                                                                heightCompatible = 0;
                                                            } else {

                                                                var heightDiffPlateLower = _plateLY[n] - _plateRY[n - 3];

                                                                //If insert screws are more than 2 their height must be compatible with plates
                                                                if ((Math.abs(parseInt(heightDiffInsert) - parseInt(heightDiffPlateLower)) < 4)) {
                                                                    heightCompatible = 1;
                                                                    noOfScrewsInInsert = 4;
                                                                } else {
                                                                    heightCompatible = 0;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }

                                                //* Compatible height 
                                                if (heightCompatible == 1) {

                                                    current_top_plate = (parseInt(current_top_plate) + parseInt(_plateLY[n])) - parseInt(_insertLY[m]);
                                                    current_left_plate = (parseInt(current_left_plate) + parseInt(_plateLX[n])) - parseInt(_insertLX[m]);

                                                    //Preventing drop out of targeted div
                                                    allowedTop = Math.min(dd.limit.bottom, Math.max(dd.limit.top, current_top_plate)),
                                                        allowedLeft = Math.min(dd.limit.right, Math.max(dd.limit.left, current_left_plate))

                                                    if ((current_left_plate <= allowedLeft) && (current_top_plate <= allowedTop)) {

														/*var placeAvaliable = 1;
														$.each( _arrayOccupiedPosition, function( key1, val1 ) {
															if( ( n == val1.screwId ) && ( _plateLX[n] == val1.screwPosX ) && ( _plateLY[n] == val1.screwPosY ) ) {
																//placeAvaliable = 0;
															}
														});*/

                                                        //Preventing overlapping of inserts with checking previous position
                                                        $.each(_arrayOccupiedPosition, function (key4, val4) {

                                                            //One Screw pair
                                                            if ((noOfScrewsInInsert == 1) && (screwCount == val4.screwCount)) {
                                                                if ((n == val4.screwIdN) && (m == val4.screwIdM)) {

                                                                    if (noOfScrewsInInsert == val4.noOfScrewsInInsert) {
                                                                        placeAvaliable = 0;
                                                                    } else {
                                                                        placeAvaliable = 0;
                                                                    }
                                                                }

                                                                if ((val4.noOfScrewsInInsert == 2) && ((val4.screwIdN + 1) == (n))) {
                                                                    placeAvaliable = 0;
                                                                } else if ((val4.noOfScrewsInInsert == 3) && (((val4.screwIdN + 1) == n) || ((val4.screwIdN + 2) == n))) {
                                                                    placeAvaliable = 0;
                                                                } else if ((val4.noOfScrewsInInsert == 4)) {
                                                                    placeAvaliable = 0;
                                                                }

                                                                //Two Screw pairs
                                                            } else if ((noOfScrewsInInsert == 2) && (screwCount == val4.screwCount)) {

                                                                if ((n == val4.screwIdN) && (m == val4.screwIdM)) {
                                                                    if (noOfScrewsInInsert == val4.noOfScrewsInInsert) {
                                                                        placeAvaliable = 0;
                                                                    } else {
                                                                        placeAvaliable = 0;
                                                                    }
                                                                }

                                                                if ((val4.noOfScrewsInInsert == 2) && ((val4.screwIdN + 1) == n)) {
                                                                    placeAvaliable = 0;
                                                                } else if ((val4.noOfScrewsInInsert == 3)) {
                                                                    placeAvaliable = 0;
                                                                } else if ((val4.noOfScrewsInInsert == 4)) {
                                                                    placeAvaliable = 0;
                                                                } else if ((val4.noOfScrewsInInsert == 2) && ((val4.screwIdN - 1) == n)) {
                                                                    placeAvaliable = 0;
                                                                } else if ((val4.noOfScrewsInInsert == 1) && ((val4.screwIdN - 1) == n)) {
                                                                    placeAvaliable = 0;
                                                                }

                                                                //Three Screw Pairs	
                                                            } else if ((noOfScrewsInInsert == 3) && (screwCount == val4.screwCount)) {

                                                                if ((n == val4.screwIdN) && (m == val4.screwIdM)) {
                                                                    if (noOfScrewsInInsert == val4.noOfScrewsInInsert) {
                                                                        placeAvaliable = 0;
                                                                    } else {
                                                                        placeAvaliable = 0;
                                                                    }
                                                                }

                                                                if ((val4.noOfScrewsInInsert == 2)) {
                                                                    placeAvaliable = 0;
                                                                } else if ((val4.noOfScrewsInInsert == 3)) {
                                                                    placeAvaliable = 0;
                                                                } else if ((val4.noOfScrewsInInsert == 4)) {
                                                                    placeAvaliable = 0;
                                                                } else if ((val4.noOfScrewsInInsert == 1) && ((val4.screwIdN == 2) || (val4.screwIdN == 3) || ((3 == n) && (val4.screwIdN == 1)) || ((2 == n) && (val4.screwIdN == 4)))) {
                                                                    placeAvaliable = 0;
                                                                }

                                                                //Four Screw Pairs	
                                                            } else if ((noOfScrewsInInsert == 4) && (screwCount == val4.screwCount)) {
                                                                placeAvaliable = 0;
                                                            }

                                                        });
                                                        //End Of Preventing overlapping of inserts with checking previous position	

                                                        if (placeAvaliable == 1) {

                                                            $('#' + _id + '').attr({ 'width': '' + _insertCurWidth + 'px', 'height': '' + _insertCurHeight + 'px' });
                                                            $('#' + _id + '').addClass('element').css({ 'border': '0px', 'left': '' + current_left_plate + 'px', 'top': '' + current_top_plate + 'px' });
                                                            //$('#front_plates').append('<img style="left:'+current_left_plate+'px; top:'+ current_top_plate +'px; position : absolute;" width="'+_insertCurWidth+'" height="'+_insertCurHeight+'" id="drawn'+ _id + '" src="' + _insertDrawn.IMAGE_PATH + '" />'); 

                                                            _matchfound = 1;

                                                            _insertDrawn.unit = selectedUnit;
                                                            _arrayOfPartsDisplay.push(_insertDrawn); //Maintaining object for all inserts
                                                            /* display parts list on the part list div */
                                                            $displayList();

                                                            _varIsImgDragged = 0;

															/*
															var occupiedArr = {};
															occupiedArr.screwId = n;
															occupiedArr.screwPosX = _plateLX[n];
															occupiedArr.screwPosY = _plateLY[n];
															_arrayOccupiedPosition.push(occupiedArr);	
															*/
                                                            //Preventing of overlapping of inserts
                                                            var occupiedArr = {};
                                                            occupiedArr.noOfScrewsInInsert = noOfScrewsInInsert;
                                                            occupiedArr.screwIdN = n;
                                                            occupiedArr.screwIdM = m;
                                                            occupiedArr.screwCount = screwCount;
                                                            occupiedArr.imgId = _id;
                                                            occupiedArr.unit = selectedUnit;
                                                            _arrayOccupiedPosition.push(occupiedArr);

                                                            return false;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }

                                } else {

                                    //Animate back to original position	
                                    var original_height = _currentImg.IMAGE_HEIGHT;
                                    var original_width = _currentImg.IMAGE_WIDTH;
                                    var minimised_height = parseInt(_insertDrawn.IMAGE_HEIGHT) - parseInt((_insertDrawn.IMAGE_HEIGHT / 2));
                                    var minimised_width = parseInt(_insertDrawn.IMAGE_WIDTH) - parseInt((_insertDrawn.IMAGE_WIDTH / 2));

                                    //Revert the dragged element with animation to the left bar
                                    $('#' + _id + '').animate({
                                        top: _insertDrawn.FIRSTPOSTOP,
                                        left: _insertDrawn.FIRSTPOSLEFT,
                                        width: minimised_width,
                                        height: minimised_height
                                    }, function () {
                                        $('#' + _id + '').remove();
                                    }
                                    );

                                    $.each(_arrayOfInsertDrawn, function (key1, val1) {
                                        if (val1 != undefined) {
                                            if (val1.NEW_ID == _id) {
                                                _arrayOfInsertDrawn.splice(key1, 1);
                                            }
                                        }
                                    });

                                }
                            } //end of If screws plates are not blank 
                        }

                        if (_matchfound == 0) {

                            //Retaining it back to original size
                            var original_height = _currentImg.IMAGE_HEIGHT;
                            var original_width = _currentImg.IMAGE_WIDTH;
                            var minimised_height = parseInt(_insertDrawn.IMAGE_HEIGHT) - parseInt((_insertDrawn.IMAGE_HEIGHT / 4));
                            var minimised_width = parseInt(_insertDrawn.IMAGE_WIDTH) - parseInt((_insertDrawn.IMAGE_WIDTH / 4));

                            //Revert the dragged element with animation to the left bar
                            //Animate to previous position	
                            $('#' + _id + '').animate({
                                top: _insertDrawn.FIRSTPOSTOP,
                                left: _insertDrawn.FIRSTPOSLEFT,
                                width: minimised_width,
                                height: minimised_height
                            }, function () {
                                $('#' + _id + '').remove();
                            }
                            );

                            $.each(_arrayOfInsertDrawn, function (key1, val1) {
                                if (val1 != undefined) {
                                    if (val1.NEW_ID == _id) {
                                        _arrayOfInsertDrawn.splice(key1, 1);
                                    }
                                }
                            });

                        }
                    }//plate is oversized
                }

            } else { //Dragged img is not insert

                var original_height = _currentImg.IMAGE_HEIGHT;
                var original_width = _currentImg.IMAGE_WIDTH;
                var minimised_height = parseInt(_currentImg.IMAGE_HEIGHT) - parseInt((_currentImg.IMAGE_HEIGHT / 4));
                var minimised_width = parseInt(_currentImg.IMAGE_WIDTH) - parseInt((_currentImg.IMAGE_WIDTH / 2));

                //Revert the dragged element with animation to the left bar
                $(dd.proxy).animate({
                    top: _currentImg.FIRSTPOSTOP,
                    left: _currentImg.FIRSTPOSLEFT,
                    width: minimised_width,
                    height: minimised_height
                }, function () {
                    $(dd.proxy).remove();
                }
                );
            }

        } else {

            var original_height = _currentImg.IMAGE_HEIGHT;
            var original_width = _currentImg.IMAGE_WIDTH;
            var minimised_height = parseInt(_currentImg.IMAGE_HEIGHT) - parseInt((_currentImg.IMAGE_HEIGHT / 4));
            var minimised_width = parseInt(_currentImg.IMAGE_WIDTH) - parseInt((_currentImg.IMAGE_WIDTH / 2));

            //Revert the dragged element with animation to the left bar
            $(dd.proxy).animate({
                top: _currentImg.FIRSTPOSTOP,
                left: _currentImg.FIRSTPOSLEFT,
                width: minimised_width,
                height: minimised_height
            }, function () {
                $(dd.proxy).remove();
            }
            );
        }
    }
}

//On drop end
function $onDropEnds(_draggedId, ev, dd) {
    //do nothing
    //console.log('dropends');
}

//Show description on mouseover to side part description block
function $showTextOnMouseover(_imgId, ev, dd) {

    //do nothing
    var _img_mouseover = '';
    var found_info = 0;

    $.each(_arrayOfCsvData, function (key1, val1) {
        if (val1.ID == _imgId) {
            found_info = 1;
            _img_mouseover = val1;
        }
    });

    if (found_info == 0) {
        $.each(_arrayOfInsertDrawn, function (key1, val1) {
            if (val1.NEW_ID == _imgId) {
                found_info = 1;
                _img_mouseover = val1;
            }
        });
    }

    if (found_info == 0) {
        $.each(_arrayOfInsertDrawn, function (key1, val1) {
            if (val1.ID == _imgId) {
                _img_mouseover = val1;
            }
        });
    }

    if (_img_mouseover != '') {
        //Showing it to the part box	
        $('.img_disbox').html('Part Number: ' + _img_mouseover.PART_NUMBER + '<br><br> Description : ' + _img_mouseover.IMAGE_DESCRIPTION + '<br><br> Price: ' + _img_mouseover.IMAGE_PRICE + '');
    }
}

/*Remove description on mouseover from side block */
function $removeTextOnMouseleave() {
    $('.img_disbox').html('Part Number: <br><br> Description: <br><br> Price: ');
}

/* On changing category plates select box */
function $changeCategoryPlatesOLD(_categoryPlateId) {

    if (_categoryPlateId == undefined) {
        $onClickCancelButton();
        return false;
    }
    //loading images in side bar
    _varCategoryOnDisplay = _categoryPlateId;
    var _previousImgId = 0;
    var _countImages = 0;
    _varfirstImgNumber = 1;

    //if ((_categoryPlateId == '1') || (_categoryPlateId == '2') || (_categoryPlateId == '3') || (_categoryPlateId == '4')) {
    $("#pagination_link").fadeIn("slow");
    //} else {
    //	$("#pagination_link").fadeOut("fast");	
    //}

    $("#arrow_cover").fadeOut("slow");

    $('#back_plates').html('');//set back plates to empty

    $.each(_arrayOfCsvData, function (key1, val1) {
        if ((val1.IMAGE_TYPE == 1) && (val1.IMAGE_CATEGORY == _categoryPlateId)) {

            if (_categoryPlateId == '3') { //For category Id 3

                var original_height = val1.IMAGE_HEIGHT;
                var original_width = val1.IMAGE_WIDTH;

                var minimised_height = parseInt(val1.IMAGE_HEIGHT) - (parseInt((val1.IMAGE_HEIGHT / 2)) + parseInt((val1.IMAGE_HEIGHT / 14)));
                var minimised_width = parseInt(val1.IMAGE_WIDTH) - (parseInt((val1.IMAGE_WIDTH / 2)) + parseInt((val1.IMAGE_WIDTH / 14)));

                var _backPlatesDivPosition = $('#back_plates').position();
                var _backPlatesDivWidth = $('#back_plates').width();
                var _nwbck = _backPlatesDivPosition.left + ((_backPlatesDivWidth / 2) - (minimised_width / 2));

                if (_countImages > 0) {
                    var position = $('#' + _previousImgId).position();
                    var new_height = position.top + ($('#' + _previousImgId).height()) + 25;
                    $('#back_plates').append('<img style="left:' + _nwbck + 'px;top:' + new_height + 'px;" width="' + minimised_width + '" height="' + minimised_height + '" id="' + val1.ID + '" src="' + val1.IMAGE_PATH + '" class="noprint" />');
                } else {
                    var topPosition = $('#back_plates').position();
                    var new_height = topPosition.top + 25;
                    $('#back_plates').append('<img style="left:' + _nwbck + 'px;top:' + new_height + 'px;" width="' + minimised_width + '" height="' + minimised_height + '" id="' + val1.ID + '" src="' + val1.IMAGE_PATH + '"  class="noprint" />');
                }
                val1.FIRSTPOSLEFT = _nwbck;
                val1.FIRSTPOSTOP = new_height;
                _previousImgId = val1.ID;
                _countImages = _countImages + 1;
                _varCurrentImgNumber = _countImages;

            } else { //for categoryid other than 3

                if (_countImages < 3) {

                    var original_height = val1.IMAGE_HEIGHT;
                    var original_width = val1.IMAGE_WIDTH;
                    /* Reducing size of insert to display */
                    if (val1.OVER_SIZED == 0) {
                        var minimised_height = parseInt(val1.IMAGE_HEIGHT) - (parseInt((val1.IMAGE_HEIGHT / 2)) + parseInt((val1.IMAGE_HEIGHT / 7)));
                        var minimised_width = parseInt(val1.IMAGE_WIDTH) - (parseInt((val1.IMAGE_WIDTH / 2)) + parseInt((val1.IMAGE_WIDTH / 7)));
                    } else if (val1.OVER_SIZED == 1) {
                        var minimised_height = parseInt(val1.IMAGE_HEIGHT) - (parseInt((val1.IMAGE_HEIGHT / 2)) + parseInt((val1.IMAGE_HEIGHT / 4)));
                        var minimised_width = parseInt(val1.IMAGE_WIDTH) - (parseInt((val1.IMAGE_WIDTH / 2)) + parseInt((val1.IMAGE_WIDTH / 4)));
                    } else {
                        var minimised_height = parseInt(val1.IMAGE_HEIGHT) - (parseInt((val1.IMAGE_HEIGHT / 2)) + parseInt((val1.IMAGE_HEIGHT / 2.8)));
                        var minimised_width = parseInt(val1.IMAGE_WIDTH) - (parseInt((val1.IMAGE_WIDTH / 2)) + parseInt((val1.IMAGE_WIDTH / 2.8)));
                    }

                    var _backPlatesDivPosition = $('#back_plates').position();
                    var _backPlatesDivWidth = $('#back_plates').width();
                    var _nwbck = _backPlatesDivPosition.left + ((_backPlatesDivWidth / 2) - (minimised_width / 2));

                    if (_countImages > 0) {
                        var position = $('#' + _previousImgId).position();
                        var new_height = position.top + ($('#' + _previousImgId).height()) + 10;
                        $('#back_plates').append('<img style="left:' + _nwbck + 'px;top:' + new_height + 'px;" width="' + minimised_width + '" height="' + minimised_height + '" id="' + val1.ID + '" src="' + val1.IMAGE_PATH + '"  class="noprint" />');
                    } else {
                        var topPosition = $('#back_plates').position();
                        var new_height = topPosition.top + 10;
                        $('#back_plates').append('<img style="left:' + _nwbck + 'px;top:' + new_height + 'px;" width="' + minimised_width + '" height="' + minimised_height + '" id="' + val1.ID + '" src="' + val1.IMAGE_PATH + '"  class="noprint" />');
                    }
                    val1.FIRSTPOSLEFT = _nwbck;
                    val1.FIRSTPOSTOP = new_height;
                    _previousImgId = val1.ID;
                    _countImages = _countImages + 1;
                    _varCurrentImgNumber = _countImages;
                }

                $('#Previous').attr({ 'src': 'images/pre_btn_disable.png' });
            }
        }
    });


    $('#Next').attr({ 'src': 'images/next_btn.png' });
}

function $changeCategoryPlates(_categoryPlateId,appendDivId) {
    var draggableimageClass = "draggableimage";
    if (!appendDivId)
        appendDivId = "back_plates";
    else
        draggableimageClass = "non-draggableimage";
    if (_categoryPlateId == undefined) {
        $onClickCancelButton();
        return false;
    }
    //loading images in side bar
    _varCategoryOnDisplay = _categoryPlateId;
    var _previousImgId = 0;
    var _countImages = 0;
    _varfirstImgNumber = 1;

    //if ((_categoryPlateId == '1') || (_categoryPlateId == '2') || (_categoryPlateId == '3') || (_categoryPlateId == '4')) {
    $("#pagination_link").fadeIn("slow");
    //} else {
    //	$("#pagination_link").fadeOut("fast");	
    //}

    $("#arrow_cover").fadeOut("slow");

    $('#back_plates').html('');//set back plates to empty    
    $.each(_arrayOfCsvData, function (key1, val1) {
        if ((val1.IMAGE_TYPE == 1) && (val1.IMAGE_CATEGORY == _categoryPlateId)) {
            var original_height = val1.IMAGE_HEIGHT;
            var original_width = val1.IMAGE_WIDTH;
            /* Reducing size of insert to display */
            var minimised_height = parseInt(val1.IMAGE_HEIGHT / 2);
            var minimised_width = parseInt(val1.IMAGE_WIDTH / 2);
            //if (val1.OVER_SIZED === 0) {
            //    var minimised_height = parseInt(val1.IMAGE_HEIGHT) - (parseInt((val1.IMAGE_HEIGHT / 2)) + parseInt((val1.IMAGE_HEIGHT / 2)));
            //    var minimised_width = parseInt(val1.IMAGE_WIDTH) - (parseInt((val1.IMAGE_WIDTH / 2)) + parseInt((val1.IMAGE_WIDTH / 2)));
            //} else if (val1.OVER_SIZED === 1) {
            //    var minimised_height = parseInt(val1.IMAGE_HEIGHT) - (parseInt((val1.IMAGE_HEIGHT / 2)) + parseInt((val1.IMAGE_HEIGHT / 4)));
            //    var minimised_width = parseInt(val1.IMAGE_WIDTH) - (parseInt((val1.IMAGE_WIDTH / 2)) + parseInt((val1.IMAGE_WIDTH / 4)));
            //} else {
            //    var minimised_height = parseInt(val1.IMAGE_HEIGHT) - (parseInt((val1.IMAGE_HEIGHT / 2)) + parseInt((val1.IMAGE_HEIGHT / 2.8)));
            //    var minimised_width = parseInt(val1.IMAGE_WIDTH) - (parseInt((val1.IMAGE_WIDTH / 2)) + parseInt((val1.IMAGE_WIDTH / 2.8)));
            //}

            var _backPlatesDivPosition = $('#back_plates').position();
            var _backPlatesDivWidth = $('#back_plates').width();
            var _nwbck = _backPlatesDivPosition.left + ((_backPlatesDivWidth / 2) - (minimised_width / 2));
            var topPosition = $('#back_plates').position();
            var new_height = topPosition.top + 10;          ;
            $("#"+appendDivId).append(
                '<div class="swiper-slide p-3">' +
                '<div class="shadow-all radius10 h-100">' +
                '<div class="p-3 pt-2 pb-2 plates-img-section">' +
                '<img height="' + minimised_height + '" width="' + minimised_width + '" id="' + val1.ID + '" class="img-fluid ' + draggableimageClass+'" src="' + val1.IMAGE_PATH + '">' +
                '</div>' +
                '<div class="bt-1">' +
                '<p class="text-primary font-weight-bold mb-1 mt-3">Part Number:</p>' +
                '<p class="text-muted">' + val1.PART_NUMBER + '</p>' +
                '</div>' +
                '<div class="bt-1 px-2">' +
                '<p class="text-primary font-weight-bold mb-1 mt-3">Description:</p>' +
                '<p class="text-muted">' + val1.IMAGE_DESCRIPTION + '</p>' +
                '</div>' +
                '</div>' +
                '</div>'
            );
            val1.FIRSTPOSLEFT = _nwbck;
            val1.FIRSTPOSTOP = new_height;
            _previousImgId = val1.ID;
            $('#Previous').attr({ 'src': 'images/pre_btn_disable.png' });
        }
    });
    $('#Next').attr({ 'src': 'images/next_btn.png' });
}

/* on changing category inserts from select box */
function $changeCategoryInserts(_categoryInsertId, control) {

    //$("#pagination_link").fadeOut("fast");

    //if(_categoryInsertId==undefined){
    //	$onClickCancelButton();
    //	return false;	
    //}
    //loading images in side bar
    _varCategoryOnDisplay = _categoryInsertId;
    //var _previousImgId = 0;    
    //var _countImages = 0;

    //if( (_categoryInsertId != 9) && (_categoryInsertId != 8)) {
    //	$("#pagination_link_insert").fadeIn("fast");
    //} else {
    //	$("#pagination_link_insert").fadeOut("fast");	
    //}	
    //$("#arrow_cover_insert").fadeOut("slow");

    //making the front plate div empty by getting default images only
    //$.each(_arrayOfCsvData, function (key, val) {
    //    if (val.IMAGE_TYPE == 2) {

    //        var _idElem = val.ID;
    //        $('#' + _idElem + '').remove();
    //    }
    //});
    //var displayImg;

    //if (_categoryInsertId == 1) {
    //    displayImg = 5;
    //} else if (_categoryInsertId == 2) {
    //    displayImg = 6;
    //} else if (_categoryInsertId == 3) {
    //    displayImg = 7;
    //} else if (_categoryInsertId == 4) {
    //    displayImg = 7;
    //} else if (_categoryInsertId == 5) {
    //    displayImg = 6;
    //} else if (_categoryInsertId == 6) {
    //    displayImg = 7;
    //} else if (_categoryInsertId == 7) {
    //    displayImg = 3;
    //} else if (_categoryInsertId == 8) {
    //    displayImg = 5;
    //} else if (_categoryInsertId == 9) {
    //    displayImg = 5;
    //} else if (_categoryInsertId == 10) {
    //    displayImg = 1;
    //} else if (_categoryInsertId == 11) {
    //    displayImg = 6;
    //}
    $(control).html("");
    var SnapinClass = "inserts-img-section";
    if (_categoryInsertId == 1) {
        SnapinClass = "inserts-img-section";
    }
    else if (_categoryInsertId == 11) {
        SnapinClass = "snapins-img-section";
    }
    $.each(_arrayOfCsvData, function (key1, val1) {
        if ((val1.IMAGE_TYPE == 2) && (val1.IMAGE_CATEGORY == _categoryInsertId)) {
            $(control).append(
                //'<div class="swiper-slide p-3">' +                
                //'<div class="' + SnapinClass + '">' +
                //'<img id="' + val1.ID + '" src="' + val1.IMAGE_PATH + '" class="img-fluid draggableimage" />' +
                //'</div>' +
                //'<h5 class="mt-3 text-primary">' + val1.PART_NUMBER + '</h5>' +                
                //'</div>'

                '<div class="swiper-slide p-3">' +
                '<div class="w-100 h-100">' +
                '<div class="p-2 pt-2 pb-2 shadow-all radius10 ' + SnapinClass + '">' +
                '<img id="' + val1.ID + '" src="' + val1.IMAGE_PATH + '" class="img-fluid draggableimage" />' +
                '</div>' +
                '<h5 class="mt-3 text-primary">' + val1.PART_NUMBER + '</h5>' +
                '</div>' +
                '</div>'
            );
            //if (_countImages < displayImg) {
            //var original_height = val1.IMAGE_HEIGHT;
            //var original_width = val1.IMAGE_WIDTH;
            /* Reducing size of insert to display */
            //if (val1.OVER_SIZED == 0) {
            //    var minimised_height = parseInt(val1.IMAGE_HEIGHT) - parseInt((val1.IMAGE_HEIGHT / 4));
            //    var minimised_width = parseInt(val1.IMAGE_WIDTH) - parseInt((val1.IMAGE_WIDTH / 4));
            //} else {
            //    var minimised_height = parseInt(val1.IMAGE_HEIGHT) - parseInt((val1.IMAGE_HEIGHT / 2));
            //    var minimised_width = parseInt(val1.IMAGE_WIDTH) - parseInt((val1.IMAGE_WIDTH / 2));
            //}

            ////for decora image 
            //if (val1.IMAGE_CATEGORY == 10) {
            //    var minimised_height = parseInt(val1.IMAGE_HEIGHT);
            //    var minimised_width = parseInt(val1.IMAGE_WIDTH);
            //}

            //var _backPlatesDivPosition = $('#front_plates').position();
            //var _backPlatesDivWidth = $('#back_plates').width();
            //var _nwbck = _backPlatesDivPosition.left + ((_backPlatesDivWidth / 2) - (minimised_width / 2));

            //if (_countInserts > 0) {
            //    var position = $('#' + _previousImgId).position();
            //    var new_height = position.top + ($('#' + _previousImgId).height()) + 14;
            //    $('#front_plates').append('<img style="left:' + _nwbck + 'px;top:' + new_height + 'px;" width="' + minimised_width + '" height="' + minimised_height + '" id="' + val1.ID + '" src="' + val1.IMAGE_PATH + '" class="noprint" />');
            //} else {
            //    var topPosition = $('#front_plates').position();
            //    var new_height = topPosition.top + 14;
            //    $('#front_plates').append('<img style="left:' + _nwbck + 'px;top:' + new_height + 'px;" width="' + minimised_width + '" height="' + minimised_height + '" id="' + val1.ID + '" src="' + val1.IMAGE_PATH + '" class="noprint" />');
            //}

            //_previousImgId = val1.ID;                
            //val1.FIRSTPOSLEFT = _nwbck;
            //val1.FIRSTPOSTOP = new_height;
            //_countImages = _countImages + 1;
            //_varCurrentImgNumber = _countImages;

            //}
        }
    });
    //$('#PreviousIns').attr({'src':'images/pre_btn_disable.png'});
    //$('#NextIns').attr({'src':'images/next_btn.png'});
}

/* On loading previous images of plates by select box */
function $onClickPreviousButton() {

    _categoryPlateId = _varCategoryOnDisplay;
    //loading images in side bar
    var _previousImgId = 0;
    var _countImages = 1;
    var _countImgDrawn = 0;
    var _countcurrentImg = _varfirstImgNumber;
    var first = 1;

    if (_countcurrentImg == 1) {
        //Do nothing
    } else {
        $('#back_plates').html('');//set back plates to empty
        $.each(_arrayOfCsvData, function (key1, val1) {
            if ((val1.IMAGE_TYPE == 1) && (val1.IMAGE_CATEGORY == _categoryPlateId)) {
                if (_countImages < (_countcurrentImg) && _countImages > (_countcurrentImg - 4)) {
                    if (first == 1) {
                        _varfirstImgNumber = _countImages;
                    }
                    first = 0;
                    var original_height = val1.IMAGE_HEIGHT;
                    var original_width = val1.IMAGE_WIDTH;
                    /* Reducing size of insert to display */
                    if (val1.OVER_SIZED == 0) {
                        var minimised_height = parseInt(val1.IMAGE_HEIGHT) - (parseInt((val1.IMAGE_HEIGHT / 2)) + parseInt((val1.IMAGE_HEIGHT / 7)));
                        var minimised_width = parseInt(val1.IMAGE_WIDTH) - (parseInt((val1.IMAGE_WIDTH / 2)) + parseInt((val1.IMAGE_WIDTH / 7)));
                    } else if (val1.OVER_SIZED == 1) {
                        var minimised_height = parseInt(val1.IMAGE_HEIGHT) - (parseInt((val1.IMAGE_HEIGHT / 2)) + parseInt((val1.IMAGE_HEIGHT / 4)));
                        var minimised_width = parseInt(val1.IMAGE_WIDTH) - (parseInt((val1.IMAGE_WIDTH / 2)) + parseInt((val1.IMAGE_WIDTH / 4)));
                    } else {
                        var minimised_height = parseInt(val1.IMAGE_HEIGHT) - (parseInt((val1.IMAGE_HEIGHT / 2)) + parseInt((val1.IMAGE_HEIGHT / 2.8)));
                        var minimised_width = parseInt(val1.IMAGE_WIDTH) - (parseInt((val1.IMAGE_WIDTH / 2)) + parseInt((val1.IMAGE_WIDTH / 2.8)));
                    }

                    var _backPlatesDivPosition = $('#back_plates').position();
                    var _backPlatesDivWidth = $('#back_plates').width();
                    var _nwbck = _backPlatesDivPosition.left + ((_backPlatesDivWidth / 2) - (minimised_width / 2));
                    if (_countImgDrawn > 0) {
                        var position = $('#' + _previousImgId).position();
                        var new_height = position.top + ($('#' + _previousImgId).height()) + 15;
                        $('#back_plates').append('<img style="left:' + _nwbck + 'px;top:' + new_height + 'px;" width="' + minimised_width + '" height="' + minimised_height + '" id="' + val1.ID + '" src="' + val1.IMAGE_PATH + '" class="noprint" />');
                    } else {
                        var topPosition = $('#back_plates').position();
                        var new_height = topPosition.top + 15;
                        $('#back_plates').append('<img style="left:' + _nwbck + 'px;top:' + new_height + 'px;" width="' + minimised_width + '" height="' + minimised_height + '" id="' + val1.ID + '" src="' + val1.IMAGE_PATH + '" class="noprint" />');
                    }
                    val1.FIRSTPOSLEFT = _nwbck;
                    val1.FIRSTPOSTOP = new_height;
                    _previousImgId = val1.ID;
                    _countImgDrawn = _countImgDrawn + 1;
                    _varCurrentImgNumber = _countImages;
                }
                _countImages = _countImages + 1;
            }
        });
    }
    if (_varfirstImgNumber == 1) {
        $('#Previous').attr({ 'src': 'images/pre_btn_disable.png' });
    } else {
        $('#Previous').attr({ 'src': 'images/pre_btn.png' });
    }
    $('#Next').attr({ 'src': 'images/next_btn.png' });

}

/* On loading next page images of plates */
function $onClickNextButton() {
    //CategoryId on display side bar
    _categoryPlateId = _varCategoryOnDisplay;
    //loading images in side bar
    var _previousImgId = 0;
    var _countImages = 1;
    var _countImgDrawn = 0;
    var _countcurrentImg = _varCurrentImgNumber;
    var first = 1;

    $.each(_arrayOfCsvData, function (key1, val1) {
        if ((val1.IMAGE_TYPE == 1) && (val1.IMAGE_CATEGORY == _categoryPlateId)) {
            if (_countImages > (_countcurrentImg) && _countImages < (_countcurrentImg + 4)) {
                if (first == 1) {
                    $('#back_plates').html('');//set back plates to empty
                    _varfirstImgNumber = _countImages;
                }
                first = 0;
                var original_height = val1.IMAGE_HEIGHT;
                var original_width = val1.IMAGE_WIDTH;
                //var minimised_height = parseInt(val1.IMAGE_HEIGHT) - parseInt((val1.IMAGE_HEIGHT/2));

                if (val1.OVER_SIZED == 0) {
                    var minimised_height = parseInt(val1.IMAGE_HEIGHT) - (parseInt((val1.IMAGE_HEIGHT / 2)) + parseInt((val1.IMAGE_HEIGHT / 7)));
                    var minimised_width = parseInt(val1.IMAGE_WIDTH) - (parseInt((val1.IMAGE_WIDTH / 2)) + parseInt((val1.IMAGE_WIDTH / 7)));
                } else if (val1.OVER_SIZED == 1) {
                    var minimised_height = parseInt(val1.IMAGE_HEIGHT) - (parseInt((val1.IMAGE_HEIGHT / 2)) + parseInt((val1.IMAGE_HEIGHT / 4)));
                    var minimised_width = parseInt(val1.IMAGE_WIDTH) - (parseInt((val1.IMAGE_WIDTH / 2)) + parseInt((val1.IMAGE_WIDTH / 4)));
                } else {
                    var minimised_height = parseInt(val1.IMAGE_HEIGHT) - (parseInt((val1.IMAGE_HEIGHT / 2)) + parseInt((val1.IMAGE_HEIGHT / 2.8)));
                    var minimised_width = parseInt(val1.IMAGE_WIDTH) - (parseInt((val1.IMAGE_WIDTH / 2)) + parseInt((val1.IMAGE_WIDTH / 2.8)));
                }

                var _backPlatesDivPosition = $('#back_plates').position();
                var _backPlatesDivWidth = $('#back_plates').width();
                var _nwbck = _backPlatesDivPosition.left + ((_backPlatesDivWidth / 2) - (minimised_width / 2));

                if (_countImgDrawn > 0) {
                    var position = $('#' + _previousImgId).position();
                    var new_height = position.top + ($('#' + _previousImgId).height()) + 15;
                    $('#back_plates').append('<img style="left:' + _nwbck + 'px;top:' + new_height + 'px;" width="' + minimised_width + '" height="' + minimised_height + '" id="' + val1.ID + '" src="' + val1.IMAGE_PATH + '"  class="noprint" />');
                } else {
                    var topPosition = $('#back_plates').position();
                    var new_height = topPosition.top + 15;
                    $('#back_plates').append('<img style="left:' + _nwbck + 'px;top:' + new_height + 'px;" width="' + minimised_width + '" height="' + minimised_height + '" id="' + val1.ID + '" src="' + val1.IMAGE_PATH + '"  class="noprint" />');
                }
                val1.FIRSTPOSLEFT = _nwbck;
                val1.FIRSTPOSTOP = new_height;
                _previousImgId = val1.ID;
                _countImgDrawn = _countImgDrawn + 1;
                _varCurrentImgNumber = _countImages;
            }
            _countImages = _countImages + 1;
        }
    });
    $('#Previous').attr({ 'src': 'images/pre_btn.png' });
    if ((_countImages) < (_varCurrentImgNumber + 4)) {
        $('#Next').attr({ 'src': 'images/next_btn_disable.png' });
    } else {
        $('#Next').attr({ 'src': 'images/next_btn.png' });
    }


}

/* On loading previous page images for inserts */
function $onClickPreviousButtonInsert() {

    _categoryInsertId = _varCategoryOnDisplay;

    if (_categoryInsertId == undefined) {
        $onClickCancelButton();
        return false;
    }
    //loading images in side bar
    var _previousImgId = 0;
    var _countInserts = 0;
    var _countImages = 1;
    var _countImgDrawn = 0;
    var _countcurrentImg = _varfirstImgNumber;
    var first = 1;

    var displayImg;
    if (_categoryInsertId == 1) {
        displayImg = 5;
    } else if (_categoryInsertId == 2) {
        displayImg = 6;
    } else if (_categoryInsertId == 3) {
        displayImg = 7;
    } else if (_categoryInsertId == 4) {
        displayImg = 7;
    } else if (_categoryInsertId == 5) {
        displayImg = 6;
    } else if (_categoryInsertId == 6) {
        displayImg = 7;
    } else if (_categoryInsertId == 7) {
        displayImg = 3;
    } else if (_categoryInsertId == 8) {
        displayImg = 5;
    } else if (_categoryInsertId == 9) {
        displayImg = 5;
    } else if (_categoryInsertId == 10) {
        displayImg = 1;
    } else if (_categoryInsertId == 11) {
        displayImg = 6;
    }

    if (_countcurrentImg == 1) {
        //Do nothing
    } else {
        //making the front plate div empty by getting default images only
        $.each(_arrayOfCsvData, function (key, val) {
            if (val.IMAGE_TYPE == 2) {
                var _idElem = val.ID;
                $('#' + _idElem + '').remove();
            }
        });

        $.each(_arrayOfCsvData, function (key1, val1) {
            if ((val1.IMAGE_TYPE == 2) && (val1.IMAGE_CATEGORY == _categoryInsertId)) {

                if (_countImages < (_countcurrentImg) && _countImages > ((_countcurrentImg - (displayImg + 1)))) {


                    if (first == 1) {
                        $('#back_plates').html('');//set back plates to empty
                        _varfirstImgNumber = _countImages;
                    }
                    first = 0;
                    var original_height = val1.IMAGE_HEIGHT;
                    var original_width = val1.IMAGE_WIDTH;
                    if (val1.OVER_SIZED == 0) {
                        var minimised_height = parseInt(val1.IMAGE_HEIGHT) - parseInt((val1.IMAGE_HEIGHT / 4));
                        var minimised_width = parseInt(val1.IMAGE_WIDTH) - parseInt((val1.IMAGE_WIDTH / 4));
                    } else {
                        var minimised_height = parseInt(val1.IMAGE_HEIGHT) - parseInt((val1.IMAGE_HEIGHT / 2));
                        var minimised_width = parseInt(val1.IMAGE_WIDTH) - parseInt((val1.IMAGE_WIDTH / 2));
                    }
                    //for decora image 
                    if (val1.IMAGE_CATEGORY == 10) {
                        var minimised_height = parseInt(val1.IMAGE_HEIGHT);
                        var minimised_width = parseInt(val1.IMAGE_WIDTH);
                    }

                    var _backPlatesDivPosition = $('#front_plates').position();
                    var _backPlatesDivWidth = $('#back_plates').width();
                    var _nwbck = _backPlatesDivPosition.left + ((_backPlatesDivWidth / 2) - (minimised_width / 2));

                    if (_countInserts > 0) {
                        var position = $('#' + _previousImgId).position();
                        var new_height = position.top + ($('#' + _previousImgId).height()) + 14;
                        $('#front_plates').append('<img style="left:' + _nwbck + 'px;top:' + new_height + 'px;" width="' + minimised_width + '" height="' + minimised_height + '" id="' + val1.ID + '" src="' + val1.IMAGE_PATH + '"  class="noprint" />');
                    } else {
                        var topPosition = $('#front_plates').position();
                        var new_height = topPosition.top + 13;
                        $('#front_plates').append('<img style="left:' + _nwbck + 'px;top:' + new_height + 'px;" width="' + minimised_width + '" height="' + minimised_height + '" id="' + val1.ID + '" src="' + val1.IMAGE_PATH + '"  class="noprint" />');
                    }
                    _previousImgId = val1.ID;
                    _countInserts = _countInserts + 1;
                    val1.FIRSTPOSLEFT = _nwbck;
                    val1.FIRSTPOSTOP = new_height;
                    _varCurrentImgNumber = _countImages;
                }
                _countImages = _countImages + 1;
            }
            //$("#pagination_link_insert").fadeIn("fast");
        });
    }

    $('#NextIns').attr({ 'src': 'images/next_btn.png' });
    if (_varfirstImgNumber == 1) {
        $('#PreviousIns').attr({ 'src': 'images/pre_btn_disable.png' });
    } else {
        $('#PreviousIns').attr({ 'src': 'images/pre_btn.png' });
    }

}

//On loading next images for imserts
function $onClickNextButtonInsert() {

    _categoryInsertId = _varCategoryOnDisplay;

    if (_categoryInsertId == undefined) {
        $onClickCancelButton();
        return false;
    }
    //loading images in side bar
    var _previousImgId = 0;
    var _countInserts = 0;
    var _countImages = 1;
    var _countImgDrawn = 0;
    var _countcurrentImg = _varCurrentImgNumber;
    var first = 1;
    var displayImg;

    if (_categoryInsertId == 1) {
        displayImg = 5;
    } else if (_categoryInsertId == 2) {
        displayImg = 6;
    } else if (_categoryInsertId == 3) {
        displayImg = 7;
    } else if (_categoryInsertId == 4) {
        displayImg = 7;
    } else if (_categoryInsertId == 5) {
        displayImg = 6;
    } else if (_categoryInsertId == 6) {
        displayImg = 7;
    } else if (_categoryInsertId == 7) {
        displayImg = 3;
    } else if (_categoryInsertId == 8) {
        displayImg = 5;
    } else if (_categoryInsertId == 9) {
        displayImg = 5;
    } else if (_categoryInsertId == 10) {
        displayImg = 1;
    } else if (_categoryInsertId == 11) {
        displayImg = 6;
    }

    $.each(_arrayOfCsvData, function (key1, val1) {
        if ((val1.IMAGE_TYPE == 2) && (val1.IMAGE_CATEGORY == _categoryInsertId)) {

            if (_countImages > (_countcurrentImg) && _countImages < (_countcurrentImg + (displayImg + 1))) {

                if (first == 1) {
                    //making the front plate div empty by getting default images only
                    $.each(_arrayOfCsvData, function (key, val) {
                        if (val.IMAGE_TYPE == 2) {
                            var _idElem = val.ID;
                            $('#' + _idElem + '').remove();
                        }
                    });
                    _varfirstImgNumber = _countImages;
                }

                first = 0;
                var original_height = val1.IMAGE_HEIGHT;
                var original_width = val1.IMAGE_WIDTH;

                if (val1.OVER_SIZED == 0) {
                    var minimised_height = parseInt(val1.IMAGE_HEIGHT) - parseInt((val1.IMAGE_HEIGHT / 4));
                    var minimised_width = parseInt(val1.IMAGE_WIDTH) - parseInt((val1.IMAGE_WIDTH / 4));
                } else {
                    var minimised_height = parseInt(val1.IMAGE_HEIGHT) - parseInt((val1.IMAGE_HEIGHT / 2));
                    var minimised_width = parseInt(val1.IMAGE_WIDTH) - parseInt((val1.IMAGE_WIDTH / 2));
                }
                //for decora image 
                if (val1.IMAGE_CATEGORY == 10) {
                    var minimised_height = parseInt(val1.IMAGE_HEIGHT);
                    var minimised_width = parseInt(val1.IMAGE_WIDTH);
                }
                var _backPlatesDivPosition = $('#front_plates').position();
                var _backPlatesDivWidth = $('#back_plates').width();
                var _nwbck = _backPlatesDivPosition.left + ((_backPlatesDivWidth / 2) - (minimised_width / 2));

                if (_countImgDrawn > 0) {

                    var position = $('#' + _previousImgId).position();
                    var new_height = position.top + ($('#' + _previousImgId).height()) + 14;
                    $('#front_plates').append('<img style="left:' + _nwbck + 'px;top:' + new_height + 'px;" width="' + minimised_width + '" height="' + minimised_height + '" id="' + val1.ID + '" src="' + val1.IMAGE_PATH + '"  class="noprint" />');

                } else {

                    var topPosition = $('#front_plates').position();
                    var new_height = topPosition.top + 13;
                    $('#front_plates').append('<img style="left:' + _nwbck + 'px;top:' + new_height + 'px;" width="' + minimised_width + '" height="' + minimised_height + '" id="' + val1.ID + '" src="' + val1.IMAGE_PATH + '"  class="noprint" />');

                }
                val1.FIRSTPOSLEFT = _nwbck;
                val1.FIRSTPOSTOP = new_height;
                _previousImgId = val1.ID;
                _countInserts = _countInserts + 1;
                _countImgDrawn = _countImgDrawn + 1;
                _varCurrentImgNumber = _countImages;

            }

            _countImages = _countImages + 1;

        }// $("#pagination_link_insert").fadeIn("fast");
    });

    if ((_countImages) < (_countcurrentImg + (displayImg + 1))) {
        $('#NextIns').attr({ 'src': 'images/next_btn_disable.png' });
    } else {
        $('#NextIns').attr({ 'src': 'images/next_btn.png' });
    }

    $('#PreviousIns').attr({ 'src': 'images/pre_btn.png' });

}

function $displayListOld() {
    console.log("$displayList - price list");
    var _img_display = [];
    var _qtyFlag = 0;
    $('#scroller').html('');

    /* getting part info from the initial object loaded */
    $.each(_arrayOfPlates, function (key1, val1) {
        val1.qty = 1;
        _img_display.push(val1);
    });

    /* getting part info from the object drawn on the canvas */
    $.each(_arrayOfPartsDisplay, function (key1, val1) {

        var newInsertVal = {};
        _qtyFlag = 0;

        if (val1 != undefined) {
            $.each(_img_display, function (key2, val2) {
                if (val2 != undefined) {
                    /* If image is already present, increase its quantity by 1 */
                    if (val1.ID == val2.ID) {
                        val2.qty = val2.qty + 1;
                        _qtyFlag = 0;
                        return false;
                    } else { /* Else insert the obj */
                        _qtyFlag = 1;
                        newInsertVal = $.extend(true, {}, val1); // deep copy
                    }
                }
            });
        }

        if (_qtyFlag == 1) {
            newInsertVal.qty = 1;
            _img_display.push(newInsertVal);
        }
    });

    var selVal = $('input[name=color]:radio:checked').val();

    if (selVal == undefined) {
        /* display part info from the object of total images drawn */
        $.each(_img_display, function (key1, val1) {
            console.log("$displayList - price list - white");
            $('#scroller').append('<div class="listcell_data"><span class="listcell1_data"> ' + val1.qty + ' </span><span class="listcell2_data">' + val1.PART_NUMBER + '</span><span class="listcell3_data">' + val1.IMAGE_DESCRIPTION + '</span><span class="listcell4_data"> ' + val1.IMAGE_PRICE + ' </span></div>');
            myScroll.refresh();
        });
    } else {
        /* display part info from the object of total images drawn with color selected */
        $.each(_img_display, function (key1, val1) {
            $('#scroller').append('<div class="listcell_data"><span class="listcell1_data"> ' + val1.qty + ' </span><span class="listcell2_data">' + val1.PART_NUMBER + '-' + selVal + '</span><span class="listcell3_data">' + val1.IMAGE_DESCRIPTION + '</span><span class="listcell4_data"> ' + val1.IMAGE_PRICE + ' </span></div>');
            myScroll.refresh();
        });
    }

    myScroll.refresh();
}

/* display parts list on the part list div - bhavik */

function $displayList() {
    console.log("$displayList - price list");
    var _img_display = [];
    var _qtyFlag = 0;
    $('.PriceTable-' + selectedUnit + ' .ListTable').html('');

    /* getting part info from the initial object loaded */
    $.each(_arrayOfPlates, function (key1, val1) {
        val1.qty = 1;
        _img_display.push(val1);
    });

    /* getting part info from the object drawn on the canvas */
    $.each(_arrayOfPartsDisplay, function (key1, val1) {

        var newInsertVal = {};
        _qtyFlag = 0;

        if (val1 != undefined) {
            $.each(_img_display, function (key2, val2) {
                if (val2 != undefined && val2.unit == selectedUnit) {
                    /* If image is already present, increase its quantity by 1 */
                    if (val1.ID == val2.ID) {
                        val2.qty = val2.qty + 1;
                        _qtyFlag = 0;
                        return false;
                    } else { /* Else insert the obj */
                        _qtyFlag = 1;
                        newInsertVal = $.extend(true, {}, val1); // deep copy
                    }
                }
            });
        }

        if (_qtyFlag == 1) {
            newInsertVal.qty = 1;
            _img_display.push(newInsertVal);
        }
    });

    if (selectedUnit == UnitEnum.Main) {
        $('.PriceTable-' + selectedUnit + ' .PartNumber').html("Main Unit");
    }
    else if (selectedUnit == UnitEnum.Satellite1) {
        $('.PriceTable-' + selectedUnit + ' .PartNumber').html("Satellite #1");
    }
    else if (selectedUnit == UnitEnum.Satellite2) {
        $('.PriceTable-' + selectedUnit + ' .PartNumber').html("Satellite #2");
    }

    var CodeLengthVal = $('.CodeLengthOption-' + selectedUnit).find('input[type=radio]:checked').val();
    console.log(CodeLengthVal);
    if (CodeLengthVal == undefined) {
        CodeLengthVal = "6";
    }
    /* display part info from the object of total images drawn */
    $.each(_img_display, function (key1, val1) {
        if (val1.unit == selectedUnit) {
            if (val1.IMAGE_TYPE == 1) {
                $('.PriceTable-' + selectedUnit + ' .ListPlateTr').remove();
                $('.PriceTable-' + selectedUnit + ' .ListTable').append(
                    '<tr class="ListPlateTr"><td class="text-center">'
                    + val1.qty
                    + '</td><td class="PartColor">'
                    + val1.PART_NUMBER + "-X-" + CodeLengthVal
                    + '</td><td>'
                    + val1.IMAGE_DESCRIPTION
                    + '</td><td id="PlatePrice" class="text-primary text-right UnitPrice">'
                    + val1.IMAGE_PRICE
                    + '</td></tr>');
            }
            else if (val1.IMAGE_TYPE == 2) {
                if (parseInt(val1.qty) > 1) {
                    var image_Price = val1.IMAGE_PRICE.replace("$", "");
                    val1.IMAGE_PRICE = "$" + (parseFloat(val1.qty) * parseFloat(image_Price)).toFixed(2);
                }
                if (val1.IMAGE_CATEGORY == 11) { // Display price only for snap In not for insert
                    var PartColorDescClass = "PartColorDesc";
                    if (val1.PART_NUMBER == "SS-SCAT6A") {
                        PartColorDescClass = "";
                    }
                    $('.PriceTable-' + selectedUnit + ' .ListTable').append(
                        '<tr class="ListSnapInsTr"' + val1.ID + '><td class="text-center">'
                        + val1.qty
                        + '</td><td class="PartColor">'
                        + val1.PART_NUMBER
                        + '</td><td class="' + PartColorDescClass+'">'
                        + val1.IMAGE_DESCRIPTION
                        + '</td><td id="SnapInsPrice" class="text-primary text-right UnitPrice">'
                        + val1.IMAGE_PRICE
                        + '</td></tr>');
                }
            }
        }
    });

    var ColorVal = $('.PlateColorOption').find('input[type=radio]:checked').val();
    var ColorValSnapin = "X";
    var ColorValDesc = "";
    console.log(ColorVal);
    if (ColorVal == undefined) {
        ColorVal = "X";      
    }
    if (ColorVal == "WHT") {
        ColorValDesc = "White";
        ColorValSnapin = "W";        
        $('.PartColor').each(function () {
            $(this).html($(this).text().replace("-X", "-" + ColorValSnapin));
            $(this).html($(this).text().replace("-B", "-" + ColorValSnapin));
        });        
    }
    if (ColorVal == "BLK") {
        ColorValDesc = "Black";
        ColorValSnapin = "B";
        $('.PartColor').each(function () {
            $(this).html($(this).text().replace("-X", "-" + ColorValSnapin));
            $(this).html($(this).text().replace("-W", "-" + ColorValSnapin));
        });        
    }
    $('.PartColorDesc').each(function () {
        $(this).html($(this).text().replace("Black ", "").replace("White ", ""));
        $(this).html(ColorValDesc + " " + $(this).text());
    });

    var TotalPriceSum = parseFloat(0);
    $('.PriceTable-' + selectedUnit + ' .ListTable tr').each(function () {
        var PlatePrice = $(this).find("#PlatePrice").text().replace("$", "");
        var SnapInsPrice = $(this).find("#SnapInsPrice").text().replace("$", "");
        if (PlatePrice == "" || PlatePrice == null)
            PlatePrice = parseFloat(0);
        if (SnapInsPrice == "" || SnapInsPrice == null)
            SnapInsPrice = parseFloat(0);

        TotalPriceSum += parseFloat(PlatePrice) + parseFloat(SnapInsPrice);
        console.log(TotalPriceSum);
        $('.PriceTable-' + selectedUnit + ' .GrandTotal').text("$" + TotalPriceSum.toFixed(2));
    });

}


/* On change the color of part from the radio buttons */
function $onChangeColor(colorCode) {
    var _img_display = [];
    var _qty;

    $('.PriceTable-' + selectedUnit + ' .ListTable').html('');

    /* getting part info from the initial object loaded */
    $.each(_arrayOfPlates, function (key1, val1) {
        _img_display.push(val1);
        _qty = 1;
    });
    /* getting part info from the object drawn on the canvas */
    $.each(_arrayOfPartsDisplay, function (key1, val1) {
        _img_display.push(val1);
        _qty = 1;
    });
    /* getting part info from the initial object loaded */
    $.each(_img_display, function (key1, val1) {
        _qty = 1;
        $('.PriceTable-' + selectedUnit + ' .ListTable').append(
            '<tr class="ListSnapInsTr"' + val1.ID + '><td class="text-center">'
            + val1.qty
            + '</td><td>'
            + val1.PART_NUMBER
            + '</td><td>'
            + val1.IMAGE_DESCRIPTION
            + '</td><td id="SnapInsPrice" class="text-primary text-right UnitPrice">'
            + val1.IMAGE_PRICE
            + '</td></tr>');
    });

}

function $loadPopupBox() {	// To Load the Popupbox
    var _backPlatesDivPosition = $('#wraper').position();
    var _backPlatesDivWidth = $('#wraper').width();
    var _nwbck = _backPlatesDivPosition.left + ((_backPlatesDivWidth / 2) - 320);

    $('#dialog').fadeIn("slow");
    $("#dialog").css({ // this is just for style
        "left": _nwbck
        //"opacity": "0.3"  
    });
}

function $unloadPopupBox() {	// TO Unload the Popupbox
    $('#dialog').fadeOut("slow");
    $("#dialog").css({ // this is just for style		
        //"opacity": "1"  
    });
}	