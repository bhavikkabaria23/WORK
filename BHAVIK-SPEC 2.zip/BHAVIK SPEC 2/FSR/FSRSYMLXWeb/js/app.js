﻿//Global Variables
/* Enums Start */
const UnitEnum = {
    Main: 0,
    Satellite1: 1,
    Satellite2: 2,
    Color: 3
}
/* End */

var UnitSteps = [];
UnitSteps.push({
    IsConfigurablePlate: true, // this will be used in function.js to identify the plate is configure or not
    AllowInsertCount: 0,
    AllowSnapInCount: 0,
    NoOfInsertCount: 0,
    NoOfSnapInCount: 0
});
UnitSteps.push({
    IsConfigurablePlate: true, // this will be used in function.js to identify the plate is configure or not
    AllowInsertCount: 0,
    AllowSnapInCount: 0,
    NoOfInsertCount: 0,
    NoOfSnapInCount: 0
});
UnitSteps.push({
    IsConfigurablePlate: true, // this will be used in function.js to identify the plate is configure or not
    AllowInsertCount: 0,
    AllowSnapInCount: 0,
    NoOfInsertCount: 0,
    NoOfSnapInCount: 0
});
//var IsConfigurablePlate = true; // this will be used in function.js to identify the plate is configure or not
//var AllowInsertCount = 0;
//var AllowSnapInCount = 0;
//var NoOfInsertCount = 0;
//var NoOfSnapInCount = 0;
var _arrayOfdd = [];
var currentStep = 0;
var dragRegionAreaId = "second_step1";
var selectedUnit = -1;
var completedStep = [];
var Model_MU = "",// Main Unit
    Model_MU_AC = "", // Main Unit Cord Length
    Model_S1U_MT = "",// Satellite 1 Mounting type
    Model_S1U = "",   // Satellite 1 unit
    Model_S1U_AC = "",// Satellite 1 unit Cord Length
    Model_S2U_MT = "",// Satellite 2 Mounting type
    Model_S2U = "",   // Satellite 2 unit
    Model_S2U_AC = "",// Satellite 2 unit Cord Length
    Model_C = ""      // Model color
var ModelNumber = "{M}-{M_AC}:{S1_MT}{S1}-{S1_AC}:{S2_MT}{S2}-{S2_AC}:{C}";
$v3(document).ready(function (e) {
    $v3('[data-toggle="tooltip"]').tooltip();

    $(document).on("click", '.childCategoryRadio', function () {        
        if (selectedUnit != parseInt($(this).val())) {
            $('.parent_steps .step').removeClass('active');
            $('.childCategoryRadio').addClass('active');
            //$("#category-container").addClass("fixed-category");
            $(".drag-region-area").parent('div').removeClass("drag_area_print").removeAttr("style");
            $(".Step-tabs-div").addClass("show-element").removeClass("hide-element");
            $("#printUnitDiv").hide();
            $(".print-nav").removeClass("show-element").addClass("hide-element");
            $("#configureDiv").hide();
            $("#wizardDiv").show();
            //GoToNextStep();
            selectedUnit = parseInt($(this).val());
            SetUnitArea();
            form.navigateTo(1);

            var _categoryPlateId = $(this).data('catergoryid');
            $changeCategoryPlates(_categoryPlateId);
        }
        //else {
        //    $(this).addClass('active');
        //}
    });

    $(document).on("click", '.PlateColorOption', function () {
        var optionVal = $(this).find('input[type=radio]').val();
        $(".drag-region-area img").each(function () {
            var src = $(this).attr("src");
            if (optionVal == "WHT") {
                src = src.replace("_allwhite", "_white");
                src = src.replace("_black", "_white");
            }
            else {
                src = src.replace("_allwhite", "_black");
                src = src.replace("_white", "_black");
            }
            $(this).attr("src", src);
        });
        $displayList();
        setTimeout(function () {
            $("#option_systemcolor").trigger('click');
        }, 500);
    });

    $(document).on("click", '.CodeLengthOption-0,.CodeLengthOption-1,.CodeLengthOption-2', function () {
        EnableButton(".next");
        $displayList();
    });

    // It can be use latter on
    $(document).on("click", '#InsertSnapInClear', function () {
        if (currentStep == 2) {
            ClearInserts();
            CLearSnapIns();
        }
        else if (currentStep == 3) {
            CLearSnapIns();
        }
    });

    $(document).on("click", '.satellite-option', function () {
        if (!$(this).hasClass("allow-menu")) {
            return false;
        }
        if (selectedUnit != parseInt($(this).val())) {
            $('.parent_steps .step').removeClass('active');
            $(this).addClass('active');
            //$("#configureDiv").hide();
            //$("#wizardDiv").show();
            $(".drag-region-area").parent('div').removeClass("drag_area_print").removeAttr("style");
            $(".Step-tabs-div").addClass("show-element").removeClass("hide-element");
            $("#printUnitDiv").hide();
            $(".print-nav").removeClass("show-element").addClass("hide-element");
            selectedUnit = parseInt($(this).val());
            SetUnitArea();
            form.navigateTo(0);
            var _categoryPlateId = $('.mountingTypeRadio-' + selectedUnit).find('input[type=radio]:checked').data('catergoryid');
            if (_categoryPlateId) {
                $changeCategoryPlates(_categoryPlateId);
            }

            $displayList();
        }
        //else {
        //    $(this).addClass('active');
        //}
    });

    $(document).on("click", '.mountingTypeRadio-1,.mountingTypeRadio-2', function () {
        EnableButton(".next");
        $displayList();
        var _categoryPlateId = $(this).find('input[type=radio]').data('catergoryid');
        $changeCategoryPlates(_categoryPlateId);
    });

    $(document).on("click", '#option_systemcolor', function () {
        if (!$(this).hasClass("allow-menu")) {
            return false;
        }
        $('.parent_steps .step').removeClass('active');
        $(this).addClass('active');
        selectedUnit = -1;
        $(".drag-region-area").parent('div').addClass("drag_area_print");
        $("#configureDiv").hide();
        $(".Step-tabs-div").addClass("hide-element").removeClass("show-element");
        $("#printUnitDiv").show();
        $(".print-nav").addClass("show-element").removeClass("hide-element");
        $("#print_div_main_unit").find('canvas').remove();
        $("#print_div_satellite1_unit").html('');
        $("#print_div_satellite2_unit").html('');
        $(".PrintPriceContainer").html("");


        //$("#drag_area_div1").show(); // temp
        //$("#drag_area_div1").css("max-width",$("#drag_area_div1").find('img:first').width()+80); // temp


        $("#drag_area_div1").hide();
        $("#drag_area_div2").hide();
        $("#drag_area_div3").hide();

        // Set the ModelNumber
        SetModel();

        $(".PriceTableDiv").show();
        $("#drag_area_div1").show();
        $("#drag_area_div1").css("max-width", $("#drag_area_div1").find('img:first').width() + 80);
        html2canvas(document.querySelector("#second_step1")).then(canvas => {
            canvas.id = "main_canvas";
            document.body.appendChild(canvas);
            $('#main_canvas').css("width", $('#main_canvas').width() - ($('#main_canvas').width() / 4));
            $('#main_canvas').css("height", $('#main_canvas').height() - ($('#main_canvas').height() / 4));
            $('#main_canvas').appendTo("#print_div_main_unit");
            $("#drag_area_div1").hide();
            $(".PriceTable-0").clone().appendTo(".PrintPriceContainer");

            $("#drag_area_div2").show();
            $("#drag_area_div2").css("max-width", $("#drag_area_div2").find('img:first').width() + 54);
            html2canvas(document.querySelector("#second_step2")).then(canvas => {
                canvas.id = "satellite1_canvas";
                document.body.appendChild(canvas);
                $('#satellite1_canvas').css("width", $('#satellite1_canvas').width() - ($('#satellite1_canvas').width() / 4));
                $('#satellite1_canvas').css("height", $('#satellite1_canvas').height() - ($('#satellite1_canvas').height() / 4));
                $('#satellite1_canvas').appendTo("#print_div_satellite1_unit");
                $("#drag_area_div2").hide();
                $(".PriceTable-1").clone().appendTo(".PrintPriceContainer");

                if ($("#second_step3").find('img').length > 0) {
                    $("#drag_area_div3").show();
                    $("#drag_area_div3").css("max-width", $("#drag_area_div3").find('img:first').width() + 54);
                    html2canvas(document.querySelector("#second_step3")).then(canvas => {
                        canvas.id = "satellite2_canvas";
                        document.body.appendChild(canvas);
                        $('#satellite2_canvas').css("width", $('#satellite2_canvas').width() - ($('#satellite2_canvas').width() / 4));
                        $('#satellite2_canvas').css("height", $('#satellite2_canvas').height() - ($('#satellite2_canvas').height() / 4));
                        $('#satellite2_canvas').appendTo("#print_div_satellite2_unit");
                        $("#drag_area_div3").hide();
                        $(".PriceTable-2").clone().appendTo(".PrintPriceContainer");
                        $("#print_div_satellite2_unit").show();
                    });
                }
                else {
                    $("#print_div_satellite2_unit").hide();
                }
            });
        });
    });

    $(document).on("click", '.StepIndicatorButtons-0 button', function () {
        $("#option_satelliteunit1").trigger("click");
    });
    $(document).on("click", '.StepIndicatorButtons-1 .btn-satellite2', function () {
        $("#option_satelliteunit2").trigger("click");
    });
    $(document).on("click", '.StepIndicatorButtons-1 .btn-system-color', function () {
        $("#option_systemcolor").trigger("click");
    });
    $(document).on("click", '.StepIndicatorButtons-2 button', function () {
        $("#option_systemcolor").trigger("click");
    });

    //$('.parent_steps .step span').click(function (event) {
    //    $('.parent_steps .step span').parent().removeClass('active');
    //    $(this).parent().addClass('active');
    //});
});

function SwipeContainer() {
    setTimeout(function () {
        var swiper = new Swiper('.swiper-container-step1', {
            slidesPerView: 3,
            spaceBetween: 0,
            simulateTouch: false,
            centeredSlides: false,
            slidesPerGroup: 3,
            navigation: {
                nextEl: '.swiper-button-next1',
                prevEl: '.swiper-button-prev1',
            },
            breakpoints: {
                1024: {
                    slidesPerView: 4
                },
                767: {
                    slidesPerView: 4,
                    spaceBetween: 10
                }
            }
        });
    }, 100);


    $('.nav-btn').click(function () {

        var swiper = new Swiper('.swiper-container-step2', {
            slidesPerView: 3,
            spaceBetween: 0,
            simulateTouch: false,
            navigation: {
                nextEl: '.swiper-button-next2',
                prevEl: '.swiper-button-prev2',
            },
            breakpoints: {
                1024: {
                    slidesPerView: 2,
                },
                767: {
                    slidesPerView: 1,
                    spaceBetween: 10,
                }
            }
        });

        var swiper = new Swiper('.swiper-container-step3', {
            slidesPerView: 7,
            spaceBetween: 0,
            simulateTouch: false,
            navigation: {
                nextEl: '.swiper-button-next3',
                prevEl: '.swiper-button-prev3',
            },
            breakpoints: {
                1024: {
                    slidesPerView: 2,
                },
                767: {
                    slidesPerView: 1,
                    spaceBetween: 10,
                }
            }
        });
        var swiper = new Swiper('.swiper-container-step4', {
            slidesPerView: 3,
            spaceBetween: 0,
            simulateTouch: false,
            navigation: {
                nextEl: '.swiper-button-next4',
                prevEl: '.swiper-button-prev4',
            },
            breakpoints: {
                1024: {
                    slidesPerView: 2,
                },
                767: {
                    slidesPerView: 1,
                    spaceBetween: 10,
                }
            }
        });
    });
}
function SwipeContainerStatic() {
    setTimeout(function () {
        var swiper = new Swiper('.swiper-container-static', {
            slidesPerView: 4,
            spaceBetween: 0,
            simulateTouch: false,
            slidesPerGroup: 3,
            navigation: {
                nextEl: '.swiper-button-next1',
                prevEl: '.swiper-button-prev1',
            },
            breakpoints: {
                1024: {
                    slidesPerView: 4
                },
                767: {
                    slidesPerView: 4,
                    spaceBetween: 10
                }
            }
        });
    }, 100);    
}

function DisableButton(controlid) {
    $(controlid).addClass('disabled-button').attr("disabled", "disabled");
}
function EnableButton(controlid) {
    $(controlid).removeClass('disabled-button').removeAttr("disabled", "disabled");
}
function CheckNextFromInsertSection() {
    console.clear();
    console.log("CheckNextFromInsertSection - AllowInsertCount = " + UnitSteps[selectedUnit].AllowInsertCount);
    console.log("CheckNextFromInsertSection - NoOfInsertCount = " + UnitSteps[selectedUnit].NoOfInsertCount);
    if (UnitSteps[selectedUnit].AllowInsertCount == UnitSteps[selectedUnit].NoOfInsertCount) {
        EnableButton(".next");
    }
    else {
        DisableButton(".next");
    }
}
function CheckNextFromSnapInSection() {
    console.log("CheckNextFromSnapInSection - AllowSnapInCount = " + UnitSteps[selectedUnit].AllowSnapInCount);
    console.log("CheckNextFromSnapInSection - NoOfSnapInCount = " + UnitSteps[selectedUnit].NoOfSnapInCount);
    if (UnitSteps[selectedUnit].AllowSnapInCount == UnitSteps[selectedUnit].NoOfSnapInCount) {
        EnableButton(".next");
    }
    else {
        DisableButton(".next");
    }
}

function InsertSnapInDraggable(stepIndex) {
    if (stepIndex == 2) {
        $("#" + dragRegionAreaId + " .InsertsImg").addClass("draggableimage");
    }
    else {
        $("#" + dragRegionAreaId + " .InsertsImg").removeClass("draggableimage");
    }
    if (stepIndex == 3) {
        $("#" + dragRegionAreaId + " .SnapInImg").addClass("draggableimage");
    }
    else {
        $("#" + dragRegionAreaId + " .SnapInImg").removeClass("draggableimage");
    }
}
function AddElement_dd(_draggedId, dd) {
    _arrayOfdd.push({ "_draggedId": _draggedId, "eledd": dd });
}
function RemoveElement_dd(_draggedId, dd) {
    $.each(_arrayOfdd, function (key1, val1) {
        if (val1 != undefined) {
            if (val1._draggedId == _draggedId) {
                _arrayOfdd.splice(key1, 1);
            }
        }
    });
}
function ClearInserts() {
    $("#" + dragRegionAreaId).find(".InsertsImg").each(function () {
        var _draggedId = $(this).attr("id");
        $.each(_arrayOfdd, function (key1, val1) {
            if (val1 != undefined) {
                if (val1._draggedId == _draggedId) {
                    $onClearInsertSnapIn(_draggedId, val1.eledd);
                    DisableButton(".next");
                }
            }
        });
    });
}
function CLearSnapIns() {
    $("#" + dragRegionAreaId).find(".SnapInImg").each(function () {
        var _draggedId = $(this).attr("id");
        $.each(_arrayOfdd, function (key1, val1) {
            if (val1 != undefined) {
                if (val1._draggedId == _draggedId) {
                    $onClearInsertSnapIn(_draggedId, val1.eledd);
                    DisableButton(".next");
                }
            }
        });
    });
}

function SetStepCondition() {
    $(".drag-region-area").parent('div').hide();
    var ColorVal = $('.PlateColorOption').find('input[type=radio]:checked').val();
    if (currentStep == 0) {
        if ($("#" + dragRegionAreaId).find('img').length > 0) {
            $("#" + dragRegionAreaId).parent('div').show();
            $(".SwipeContainerStatic").hide();
        }
        else {
            $(".SwipeContainerStatic").show();
            $changeCategoryPlates("12", "back_plates_static");
            $changeCategoryPlates("22", "back_plates_static");
            SwipeContainerStatic();
        }
        if (selectedUnit == UnitEnum.Satellite1) {
            $(".mountingTypeRadio-1").show();
            $(".mountingTypeRadio-2").hide();
        }
        else if (selectedUnit == UnitEnum.Satellite2) {
            $(".mountingTypeRadio-1").hide();
            $(".mountingTypeRadio-2").show();
        }
        var mountingTypeVal = $('.mountingTypeRadio-' + selectedUnit).find('input[type=radio]:checked').val();
        if (mountingTypeVal) {
            EnableButton(".next");
        }
        else {
            DisableButton(".next");
        }
        ColorVal = "";
        // Clamp or Under table 
    }
    if (currentStep == 1) {
        if ($("#" + dragRegionAreaId).find('img').length == 0) {
            DisableButton(".next");
        }
        else {
            EnableButton(".next");
        }
        $("#" + dragRegionAreaId).parent('div').show();
        ColorVal = "";
        SwipeContainer();
        //$(".stepheader").html("Base Unit (Please drag and drop any Base Unit)");      
    }
    else if (currentStep == 2) {
        $("#" + dragRegionAreaId).parent('div').show();
        ColorVal = "";
        ///$(".stepheader").html("Please drag and drop any Insert Plate)");
    }
    else if (currentStep == 3) {
        $("#" + dragRegionAreaId).parent('div').show();
        ColorVal = "";
        //$(".stepheader").html("Snap-Ins (Please drag and drop any Snap-In)");
    }
    else if (currentStep == 4) {
        $("#" + dragRegionAreaId).parent('div').show();
        $(".CodeLengthOption-0").hide();
        $(".CodeLengthOption-1").hide();
        $(".CodeLengthOption-2").hide();
        if (selectedUnit == UnitEnum.Main) {
            $(".CodeLengthOption-0").show();
        }
        else if (selectedUnit == UnitEnum.Satellite1) {
            $(".CodeLengthOption-1").show();
        }
        else if (selectedUnit == UnitEnum.Satellite2) {
            $(".CodeLengthOption-2").show();
        }
        var CodeLengthVal = $('.CodeLengthOption-' + selectedUnit).find('input[type=radio]:checked').val();
        if (CodeLengthVal) {
            EnableButton(".next");
        }
        else {
            DisableButton(".next");
        }
        //$(".stepheader").html("AC Cord Length (Please Choose any AC Cord Length option)");
    }
    else if (currentStep == 5) {
        $("#" + dragRegionAreaId).parent('div').show();
        if ($.inArray(selectedUnit, completedStep) == -1) {
            completedStep.push(selectedUnit);
        }

        $(".PriceTableDiv").hide();        
        //$(".stepheader").html("Parts List");

        $(".StepIndicatorButtons").hide();
        $(".StepIndicatorButtons-" + selectedUnit).show();
    }
    if (ColorVal == "WHT") {
        $(".drag-region-area img").each(function () {
            var src = $(this).attr("src");
            src = src.replace("_black", "_white");
            src = src.replace("_allwhite", "_white");
            $(this).attr("src", src);
        });
    }
    else if (ColorVal == "BLK") {
        $(".drag-region-area img").each(function () {
            var src = $(this).attr("src");
            src = src.replace("_white", "_black");
            src = src.replace("_allwhite", "_black");
            $(this).attr("src", src);
        });
    }
    else {
        $(".drag-region-area img").each(function () {
            var src = $(this).attr("src");
            src = src.replace("_black", "_allwhite");
            src = src.replace("_white", "_allwhite");
            $(this).attr("src", src);
        });
    }
    CheckUnitFlow();
}

function GoToNextStep() {
    EnableButton(".next");
    $(".next").trigger("click");
    DisableButton(".next");
}

function CheckUnitFlow() {
    if ($.inArray(UnitEnum.Main, completedStep) > -1) {
        //$("#option_mainunit").addClass('completed').removeClass('active');
        $("#option_satelliteunit1").attr("disabled", false).removeClass('disabled-menu').addClass('allow-menu');
    }
    if ($.inArray(UnitEnum.Satellite1, completedStep) > -1) {
        //$("#option_satelliteunit1").addClass('completed').removeClass('active');
        $("#option_satelliteunit2").attr("disabled", false).removeClass('disabled-menu').addClass('allow-menu');
        $("#option_systemcolor").attr("disabled", false).removeClass('disabled-menu').addClass('allow-menu');
    }
    if ($.inArray(UnitEnum.Satellite2, completedStep) > -1) {
        //$("#option_satelliteunit2").addClass('completed').removeClass('active');
    }
    if ($.inArray(UnitEnum.Color, completedStep) > -1) {
        //$("#option_systemcolor").addClass('completed').removeClass('active');
    }
}

function SetUnitArea() {
    //$(".drag-region-area").parent('div').hide();    
    $(".modal-steps").hide();
    if (selectedUnit == UnitEnum.Main) {
        dragRegionAreaId = "second_step1";        
//        $(".nav-first-step").remove();
        $(".unit-steps-0").show();
    }
    else if (selectedUnit == UnitEnum.Satellite1) {
        dragRegionAreaId = "second_step2";
        $(".unit-steps-1").show();
        //$(".modal-steps").prepend('<div class="step nav-first-step" data-step="0" data-step-skip="true"><div class="dot" data-toggle="tooltip" data-placement="bottom" title=" Mounting Type"></div></div>');
    }
    else if (selectedUnit == UnitEnum.Satellite2) {
        dragRegionAreaId = "second_step3";
        $(".unit-steps-1").show();
        //$(".modal-steps").prepend('<div class="step nav-first-step" data-step="0" data-step-skip="true"><div class="dot" data-toggle="tooltip" data-placement="bottom" title=" Mounting Type"></div></div>');
    }
} 

function SetModel() {
    var CodeLengthVal_0 = $('.CodeLengthOption-0').find('input[type=radio]:checked').val();
    var CodeLengthVal_1 = $('.CodeLengthOption-1').find('input[type=radio]:checked').val();
    var CodeLengthVal_2 = $('.CodeLengthOption-2').find('input[type=radio]:checked').val();
    var mountingTypeVal_1 = $('.mountingTypeRadio-1').find('input[type=radio]:checked').val();
    var mountingTypeVal_2 = $('.mountingTypeRadio-2').find('input[type=radio]:checked').val();
    var ColorVal = $('.PlateColorOption').find('input[type=radio]:checked').val();
    $.each(_arrayOfPlates, function (key1, val1) {
        if (val1.unit == UnitEnum.Main) {
            Model_MU = val1.PART_NUMBER;
        }
        else if (val1.unit == UnitEnum.Satellite1) {
            Model_S1U = val1.PART_NUMBER;
        }
        else if (val1.unit == UnitEnum.Satellite2) {
            Model_S2U = val1.PART_NUMBER;
        }
    });

    Model_MU_AC = CodeLengthVal_0;

    Model_S1U_AC = CodeLengthVal_1;
    Model_S1U_MT = mountingTypeVal_1;

    Model_S2U_AC = CodeLengthVal_2;
    Model_S2U_MT = mountingTypeVal_2;

    ModelNumber = Model_MU + "-" + Model_MU_AC + ":" + Model_S1U_MT + Model_S1U + "-" + Model_S1U_AC;
    if (Model_S2U) {
        ModelNumber += ":" + Model_S2U_MT + Model_S2U + "-" + Model_S2U_AC;
    }
    if (ColorVal) {
        if (ColorVal == "WHT") {
            Model_C = "W";
        }
        else if (ColorVal == "BLK") {
            Model_C = "B";
        }
        ModelNumber += ":" + Model_C;
    }
    if (ModelNumber) {
        var TotalPriceSum = parseFloat(0);
        $('.StepPriceContainer .GrandTotal').each(function () {
            var PlatePrice = $(this).text().replace("$", "");
            if (PlatePrice == "" || PlatePrice == null)
                PlatePrice = parseFloat(0);
            TotalPriceSum += parseFloat(PlatePrice);
        });

        $('.PrintModelContainer .ListPlateTr').remove();
        $('.PrintModelContainer .ListTable').append(
            '<tr class="ListPlateTr"><td>'
            + ModelNumber
            + '</td><td id="PlatePrice" class="text-primary text-right UnitPrice font-weight-bold">'
            + '$' + TotalPriceSum.toFixed(2)
            + '</td></tr>');
    }
}

function CopyObject(mainObj) {
    let objCopy = {}; // objCopy will store a copy of the mainObj
    let key;

    for (key in mainObj) {
        objCopy[key] = mainObj[key]; // copies each property to the objCopy object
    }
    return objCopy;
}