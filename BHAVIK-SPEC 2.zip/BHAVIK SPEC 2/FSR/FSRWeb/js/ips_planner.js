
// JavaScript Document
//Defining global parameters and array
var _arrayOfCsvData = []; //array for csv data

var _arrayOfPlates = []; //array for plates drwan data

var _arrayOfInsertDrawn = []; //array for inserts drwan data

var _arrayOccupiedPosition = []; //array of screws position drawn

var _arrayOccupiedDecoraPosition = []; //array of screws position of decora inserts drawn

var _arrayOccupiedSnapInsPosition = []; //array of screws position of snap ins insert drawn

var _arrayOfPartsDisplay = []; //array of screws position drawn

var _varCurrentImgNumber; //number of last image displayed in side bar for going next page

var _varfirstImgNumber; //number of first image displayed in side bar for going previous page

var _varCategoryOnDisplay; //category Id of the category on display in side bar

var _varIsStarted = 0; //Get the start button status i.e clicked or not

var _varIsImgDragged = 0; //Prevent multiple select i.e multi drag 

//load csv
$(document).ready(function (e) {
    try {
        //Read csv of images with plates and inserts
        $.get('images.csv', function (data) {
            var _csvToObject = $.csv.toObjects(data);
            //pushing images in an array of images with plates and inserts
            $.each(_csvToObject, function (key, value) {
                _arrayOfCsvData.push(value);
            });
            //$consoleLog($simpleObjInspect(_arrayOfCsvData));
        });
    } catch (e) {
        $handleTryCatchError(e);
    }
});


//For showing orientation support for landscape for android tablets
$(document).ready(function (e) {
    try {

        var uagent = navigator.userAgent.toLowerCase();
        //If it is for iPad
        if (uagent.search("ipad") > -1) {

            //Do Nothing

        } else {
            //In case it is been used for the android devices
            if (window.innerHeight > window.innerWidth) {
                //commented by bhavik
                //alert("This website is not supported in portrait mode, please continue with landscape mode!");
            }
        }

    } catch (e) {
        $handleTryCatchError(e);
    }
});


//For changing orientation need to refresh for iPad and show meassage for android tablets
$(document).ready(function (e) {
    try {

        // Listen for orientation changes
        window.addEventListener("orientationchange", function () {

            // Announce the new orientation number
            var uagent = navigator.userAgent.toLowerCase();
            /* If it is an iPad browser, content need to be refreshed as orientation */
            if (uagent.search("ipad") > -1) {
                /* Alert user for refreshing the content */
                alert("Content will be refreshed on changing orientation!");
                $onClickCancelButton();

            } else {
                //Samsung android tablets do not support portrait orientation
                if (window.innerHeight < window.innerWidth) {
                    //commented by bhavik
                    //alert("This website is not supported in portrait mode, please continue with landscape mode!");
                }
            }

        }, false);

    } catch (e) {
        $handleTryCatchError(e);
    }
});


/* Handling th option of clear */
$(document).ready(function () {
    try {
        /* Handling th option of clear */
        $("#clear").on("click", function () {

            var isClearable = 0;

            //For maintaining the array to display in part list
            $.each(_arrayOfPlates, function (key1, val1) {
                isClearable = 1;
            });

            if (isClearable == 1) {
                //Showing the confirm box to verify from the user.
                var r = confirm("Clearing will remove all inserts and the selected mounting " + '\n' + " plate from the work area." + '\n' + "Are you sure you want to proceed?");
                if (r == true) {
                    $onClickCancelButton(isClearable);
                } else {
                    //"You pressed Cancel! DO Nothing!";
                }
            }
        });
    } catch (e) {
        $handleTryCatchError(e);
    }
})

/* Handling th option of print */
$(document).ready(function () {
    try {
        /* Handling th option of print */
        $("#print").on("click", function () {
            $onPrintButton();
        });
    } catch (e) {
        $handleTryCatchError(e);
    }
})


/* Handling th option of help */
$(document).ready(function () {
    try {
        /* Handling th option of print */
        $("#help").on("click", function () {

            if (_varIsStarted == 1) {
                //$( "#dialog" ).dialog( "open" );
                $loadPopupBox();
            }

            //$onPrintButton();
        });
    } catch (e) {
        $handleTryCatchError(e);
    }
})

/*
$( "#help" ).click(function() {
	if(_varIsStarted == 1) {							
		$( "#dialog" ).dialog( "open" );
	}
});*/


/* On clicking start button load required elements */
$(document).ready(function () {
    try {
        /* On clicking start button load required elements */
        $("#startplanner").on("click", function () {

            $startIpsPlanner();

        });
    } catch (e) {
        $handleTryCatchError(e);
    }
})

/* Onchanges the drop down of plate's category */
$(document).ready(function () {
    try {
        /* Onchanges the drop down of plate's category */
        $('#category_plate').on("change", function () {
            var _categoryPlateId = $(this).val();
            $changeCategoryPlates(_categoryPlateId);
        });
    } catch (e) {
        $handleTryCatchError(e);
    }
})

/* onScrolling the div for platess category */


/* Ondrag over the images from the side bar to canvas */
$(document).ready(function () {
    try {
        /* On drag event on images */
        $(document).on("drag ", ".draggableimage", function (ev, dd) {
            var _draggedId = $(this).attr("id");
            $onDrags(_draggedId, ev, dd);
        })
    } catch (e) {
        $handleTryCatchError(e);
    }
})


/*$(document).ready(function(){
	try{
	
		$( document ).on("click",".draggableimage",function( ev, dd ){
			var _draggedId = $(this).attr("id");
			
			ev.stopImmediatePropagation();
			ev.preventDefault();											
		})
	}catch(e){
		$handleTryCatchError(e);
	}
})*/


/* dragstart event over the images */
$(document).ready(function () {
    try {
        /* On dragstart event on images */
        $(document).on("dragstart", ".draggableimage", function (ev, dd) {
            var _draggedId = $(this).attr("id");
            _varIsImgDragged = 1;

            var res = $onDragStarts(_draggedId, ev, dd);

            if (res.result === true) {                
                /* Creating proxy of the images to move them later */
                if (res.insertCurType == '1') {
                    CLearSnapIns();
                    ClearInserts();
                    $("#second_step").html("");
                }
                if ((res.insertCurHeight1 == false) && (res.insertCurWidth1 == false)) {
                    _proxyElement = $(this).clone();                    
                    _proxyElement.css("opacity", .99);
                    _proxyElement.css("z-index", 99999)
                        .appendTo($("#second_step"));
                    return _proxyElement;
                } else {
                    _proxyElement = $(this).clone();
                    _proxyElement.css("opacity", .99);
                    _proxyElement.css("z-index", 99999)
                    _proxyElement.attr({ 'width': '' + res.insertCurWidth1 + 'px', 'height': '' + res.insertCurHeight1 + 'px' })                        
                        .appendTo($("#second_step"));   
                    return _proxyElement;
                }
            }

        })
    } catch (e) {
        $handleTryCatchError(e);
    }
})

/* dragend event over the images */
$(document).ready(function () {
    try {
        /* On dragend event on images */
        $(document).on("dragend", ".draggableimage", function (ev, dd) {
            var _draggedId = $(this).attr("id");

            //Image drags end here
            _varIsImgDragged = 0;
            $onDragEnds(_draggedId, ev, dd);
        })
    } catch (e) {
        $handleTryCatchError(e);
    }
})

/* dropstart event over the images */
$(document).ready(function () {
    try {
        /* On dropstart event on images */
        $(document).on("dropstart", ".draggableimage", function (ev, dd) {
            var _draggedId = $(this).attr("id");
            $onDropStarts(_draggedId, ev, dd);
        })
    } catch (e) {
        $handleTryCatchError(e);
    }
})


/* drop event over the images */
$(document).ready(function () {

    try {
        /* On dropstart event on images */
        $(document).on("drop", "#second_step", function (ev, dd) {
            var _draggedId = dd.drag.id;
            $onDrops(_draggedId, ev, dd);
        })
    } catch (e) {
        $handleTryCatchError(e);
    }

    try {
        $(document).on("drop", ".draggableimage", function (ev, dd) {
            var _draggedId = dd.drag.id;
            var _isSnapIns = 0;

            /* Reading CSV object */
            $.each(_arrayOfCsvData, function (key1, val1) {
                if ((val1.ID == _draggedId) && (val1.IMAGE_CATEGORY == 11)) {

                    _isSnapIns = 1;

                }
            });

            if (_isSnapIns == 0) {
                $onDropsWithenCanvas(_draggedId, ev, dd);
            } else {
                $onDrops(_draggedId, ev, dd);
            }

        })
    } catch (e) {
        $handleTryCatchError(e);
    }

})

/* dropend event over the images */
$(document).ready(function () {
    try {
        /* On dropend event on images */
        $(document).on("dropend", ".draggableimage", function (ev, dd) {
            var _draggedId = $(this).attr("id");
            $onDropEnds(_draggedId, ev, dd);
        })
    } catch (e) {
        $handleTryCatchError(e);
    }
})

/* show description in the bottom right box on mouseover the images */
$(document).ready(function () {
    try {
        $(document).on("mouseover", ".draggableimage", function (ev, dd) {
            var _imgFocusedId = $(this).attr("id");
            $showTextOnMouseover(_imgFocusedId, ev, dd);
        })
    } catch (e) {
        $handleTryCatchError(e);
    }
})


/* remove description in the bottom right box on mouseleave the images */
$(document).ready(function () {
    try {
        $(document).on("mouseleave", ".draggableimage", function (ev, dd) {
            $removeTextOnMouseleave();
        })
    } catch (e) {
        $handleTryCatchError(e);
    }
})

/* show description in the bottom right box on mouseover the images already drwan in canvas */
$(document).ready(function () {
    try {
        $(document).on("mouseover", "#second_step>img", function (ev, dd) {
            var _imgFocusedId = $(this).attr("id");
            $showTextOnMouseover(_imgFocusedId, ev, dd);
        })
    } catch (e) {
        $handleTryCatchError(e);
    }
})

/* remove description in the bottom right box on mouseleave the images already drwan in canvas*/
$(document).ready(function () {
    try {
        $(document).on("mouseleave", "#second_step>img", function (ev, dd) {
            $removeTextOnMouseleave();
        })
    } catch (e) {
        $handleTryCatchError(e);
    }
})

/* show description in the bottom right box on touchstart event on iDevices */
$(document).ready(function () {
    try {
        $(document).on("touchstart", ".draggableimage", function (ev, dd) {
            var _imgFocusedId = $(this).attr("id");
            $showTextOnMouseover(_imgFocusedId, ev, dd);
        })
    } catch (e) {
        $handleTryCatchError(e);
    }
})


/* remove description in the bottom right box on touchend event on iDevices */
$(document).ready(function () {
    try {
        $(document).on("touchend", ".draggableimage", function (ev, dd) {
            $removeTextOnMouseleave();
        })
    } catch (e) {
        $handleTryCatchError(e);
    }
})

/* show description in the bottom right box on touchstart event on iDevices images already drwan in canvas**/
$(document).ready(function () {
    try {
        $(document).on("touchstart", "#wraper>img", function (ev, dd) {
            var _imgFocusedId = $(this).attr("id");
            $showTextOnMouseover(_imgFocusedId, ev, dd);
        })
    } catch (e) {
        $handleTryCatchError(e);
    }
})

/* remove description in the bottom right box on touchend event on iDevices images already drwan in canvas* */
$(document).ready(function () {
    try {
        $(document).on("touchend", "#second_step>img", function (ev, dd) {
            $removeTextOnMouseleave();
        })
    } catch (e) {
        $handleTryCatchError(e);
    }
})


/* Onchanges the drop down of insert's category */
$(document).ready(function () {
    try {
        /* Onchanges the drop down of insert's category */
        $('#category_insert').on("change", function () {
            var _categoryInsertId = $(this).val();
            $changeCategoryInserts(_categoryInsertId);
        });
    } catch (e) {
        $handleTryCatchError(e);
    }
})

/* on click previous button to load previous PLATE image */
$(document).ready(function () {
    try {
        /* Handling th option of privious page load of plate */
        $("#Previous").on("click", function () {
            $onClickPreviousButton();
        });
    } catch (e) {
        $handleTryCatchError(e);
    }
})

/* on click next button to load next PLATE image */
$(document).ready(function () {
    try {
        /* Handling the option of next page load of plate */
        $("#Next").on("click", function () {
            $onClickNextButton();
        });
    } catch (e) {
        $handleTryCatchError(e);
    }
})

/* on click previous button to load previous page load of inserts */
$(document).ready(function () {
    try {
        /* Handling the option of previous page load of insert */
        $("#PreviousIns").on("click", function () {
            $onClickPreviousButtonInsert();
        });
    } catch (e) {
        $handleTryCatchError(e);
    }
})

/* on click next button to load next INSERT image */
$(document).ready(function () {
    try {
        /* Handling the option of next page load of insert */
        $("#NextIns").on("click", function () {
            $onClickNextButtonInsert();
        });
    } catch (e) {
        $handleTryCatchError(e);
    }
})

/* clicking on white colour */
$(document).ready(function () {
    try {
        /* Handling the option of white colour */
        $("#white").on("click", function () {
            $onChangeColor('WHT');
        });
    } catch (e) {
        $handleTryCatchError(e);
    }
})

/* clicking on ivory colour */
$(document).ready(function () {
    try {
        /* Handling the option of ivory colour */
        $("#ivory").on("click", function () {
            $onChangeColor('IVO');
        });
    } catch (e) {
        $handleTryCatchError(e);
    }
})

/* clicking on black colour */
$(document).ready(function () {
    try {
        /* Handling the option of black colour */
        $("#black").on("click", function () {
            $onChangeColor('BLK');
        });
    } catch (e) {
        $handleTryCatchError(e);
    }
})

/* clicking on black colour */
$(document).ready(function () {
    try {
        /* Handling the option of black colour */
        $('#popupBoxClose').click(function () {
            $unloadPopupBox();
        });
    } catch (e) {
        $handleTryCatchError(e);
    }
})



