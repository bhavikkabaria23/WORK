﻿//Global Variables
var IsConfigurablePlate = true; // this will be used in function.js to identify the plate is configure or not
var AllowInsertCount = 0;
var AllowSnapInCount = 0;
var NoOfInsertCount = 0;
var NoOfSnapInCount = 0;
var _arrayOfdd = [];
var currentStep = 0;
$v3(document).ready(function (e) {
    $v3('[data-toggle="tooltip"]').tooltip();
    $(document).on("click", '.childCategoryRadio', function () {        
        $("#configureDiv").hide();
        $("#wizardDiv").show();
    });
    try {
        //Read csv of images with plates and inserts
        $.get('./category.csv', function (data) {
            var lines = data.split('\n');
            var hideEleClass = "";
            for (var i = 1; i < lines.length; i++) {
                if (lines[i].split(',')[0] == "3" || lines[i].split(',')[0] == "4") {
                    hideEleClass = "hide-element";
                }
                if (lines[i] !== "" && lines[i].length > 2) {
                    $("#category-container").append(
                        '<div class="product-item col-12 col-md-6 mt-5">' +
                        '<div class="card">' +
                        '<img class="card-img-top" src="' + lines[i].split(',')[2] + '" alt="' + lines[i].split(',')[1] + '">' +
                        '<div class="card-body">' +
                        '<h4 class="card-title text-muted">' + lines[i].split(',')[1] + '</h4>' +
                        '<div class=" btn-group-toggle d-flex justify-content-around" data-toggle="buttons">' +
                        '<label class="btn btn-outline-primary childCategoryRadio">' +
                        '<input data-catergoryid="' + lines[i].split(',')[0] + '2" type="radio" name="options' + lines[i].split(',')[0] + '" autocomplete="off" checked> 2-AC' +
                        '</label>' +
                        '<label class="btn btn-outline-primary childCategoryRadio">' +
                        '<input data-catergoryid="' + lines[i].split(',')[0] + '3" type="radio" name="options' + lines[i].split(',')[0] + '" autocomplete="off" checked> 3-AC' +
                        '</label>' +
                        '<label class="btn btn-outline-primary childCategoryRadio">' +
                        '<input data-catergoryid="' + lines[i].split(',')[0] + '4" type="radio" name="options' + lines[i].split(',')[0] + '" autocomplete="off" checked> 4-AC' +
                        '</label>' +
                        '<label class="btn btn-outline-primary childCategoryRadio ' + hideEleClass + '">' +
                        '<input data-catergoryid="' + lines[i].split(',')[0] + '5" type="radio" name="options' + lines[i].split(',')[0] + '" autocomplete="off" checked> 5-AC' +
                        '</label>' +
                        '</div>' +
                        '</div>' +
                        '</div>' +
                        '</div>'
                    );
                }
            }
        });
    } catch (e) {

    }

    $(document).on("click", '.childCategoryRadio', function () {
        SwipeContainer();
        var _categoryPlateId = $(this).find('input[type=radio]').data('catergoryid');
        $changeCategoryPlates(_categoryPlateId);        
    });    

    $(document).on("click", '.inputspace #black', function () {
        $("#second_step img,#front_plates img").each(function () {
            var src = $(this).attr("src");
            src = src.replace("allwhite", "black");
            $(this).attr("src", src);
        });
    });

    $(document).on("click", '.PlateColorOption', function () {
        var optionVal = $(this).find('input[type=radio]').val();
        EnableButton(".next");
        $("#second_step img").each(function () {
            var src = $(this).attr("src");
            if (optionVal == "WHT") {
                src = src.replace("_allwhite", "_white");
                src = src.replace("_black", "_white");
            }
            else {
                src = src.replace("_allwhite", "_black");
                src = src.replace("_white", "_black");
            }
            $(this).attr("src", src);
        });
        $displayList();
    });

    $(document).on("click", '.CodeLengthOption', function () {
        EnableButton(".next");
        $displayList();
    });

    // It can be use latter on
    $(document).on("click", '#InsertSnapInClear', function () {
        if (currentStep == 1) {
            ClearInserts();
            CLearSnapIns();
        }
        else if (currentStep == 2) {
            CLearSnapIns();
        }
    });
});

function SwipeContainer() {
    setTimeout(function () {
        var swiper = new Swiper('.swiper-container-step1', {
            slidesPerView: 3,
            spaceBetween: 0,
            simulateTouch: false,
            slidesPerGroup: 3,
            navigation: {
                nextEl: '.swiper-button-next1',
                prevEl: '.swiper-button-prev1',
            },
            breakpoints: {
                1024: {
                    slidesPerView: 4
                },
                767: {
                    slidesPerView: 4,
                    spaceBetween: 10
                }
            }
        });
    }, 100);


    $('.nav-btn').click(function () {

        var swiper = new Swiper('.swiper-container-step2', {
            slidesPerView: 3,
            spaceBetween: 0,
            simulateTouch: false,
            navigation: {
                nextEl: '.swiper-button-next2',
                prevEl: '.swiper-button-prev2',
            },
            breakpoints: {
                1024: {
                    slidesPerView: 2,
                },
                767: {
                    slidesPerView: 1,
                    spaceBetween: 10,
                }
            }
        });

        var swiper = new Swiper('.swiper-container-step3', {
            slidesPerView: 7,
            spaceBetween: 0,
            simulateTouch: false,
            navigation: {
                nextEl: '.swiper-button-next3',
                prevEl: '.swiper-button-prev3',
            },
            breakpoints: {
                1024: {
                    slidesPerView: 2,
                },
                767: {
                    slidesPerView: 1,
                    spaceBetween: 10,
                }
            }
        });
        var swiper = new Swiper('.swiper-container-step4', {
            slidesPerView: 3,
            spaceBetween: 0,
            simulateTouch: false,
            navigation: {
                nextEl: '.swiper-button-next4',
                prevEl: '.swiper-button-prev4',
            },
            breakpoints: {
                1024: {
                    slidesPerView: 2,
                },
                767: {
                    slidesPerView: 1,
                    spaceBetween: 10,
                }
            }
        });
    });
}

function DisableButton(controlid) {
    $(controlid).addClass('disabled-button').attr("disabled", "disabled");
}
function EnableButton(controlid) {
    $(controlid).removeClass('disabled-button').removeAttr("disabled", "disabled");
}
function CheckNextFromInsertSection() {
    console.clear();
    console.log("CheckNextFromInsertSection - AllowInsertCount = " + AllowInsertCount);
    console.log("CheckNextFromInsertSection - NoOfInsertCount = " + NoOfInsertCount);
    if (AllowInsertCount == NoOfInsertCount) {
        EnableButton(".next");
    }
    else {
        DisableButton(".next");
    }
}
function CheckNextFromSnapInSection() {
    console.log("CheckNextFromSnapInSection - AllowSnapInCount = " + AllowSnapInCount);
    console.log("CheckNextFromSnapInSection - NoOfSnapInCount = " + NoOfSnapInCount);
    if (AllowSnapInCount == NoOfSnapInCount) {
        EnableButton(".next");
    }
    else {
        DisableButton(".next");
    }
}

function InsertSnapInDraggable(stepIndex) {
    if (stepIndex == 1) {
        $("#second_step .InsertsImg").addClass("draggableimage");
    }
    else {
        $("#second_step .InsertsImg").removeClass("draggableimage");
    }
    if (stepIndex == 2) {
        $("#second_step .SnapInImg").addClass("draggableimage");
    }
    else {
        $("#second_step .SnapInImg").removeClass("draggableimage");
    }
}
function AddElement_dd(_draggedId, dd) {
    _arrayOfdd.push({ "_draggedId": _draggedId, "eledd": dd });
}
function RemoveElement_dd(_draggedId, dd) {
    $.each(_arrayOfdd, function (key1, val1) {
        if (val1 != undefined) {
            if (val1._draggedId == _draggedId) {
                _arrayOfdd.splice(key1, 1);
            }
        }
    });
}
function ClearInserts() {
    $(".InsertsImg").each(function () {
        var _draggedId = $(this).attr("id");
        $.each(_arrayOfdd, function (key1, val1) {
            if (val1 != undefined) {
                if (val1._draggedId == _draggedId) {
                    $onClearInsertSnapIn(_draggedId, val1.eledd);
                    DisableButton(".next");
                }
            }
        });
    });
}
function CLearSnapIns() {
    $(".SnapInImg").each(function () {
        var _draggedId = $(this).attr("id");
        $.each(_arrayOfdd, function (key1, val1) {
            if (val1 != undefined) {
                if (val1._draggedId == _draggedId) {
                    $onClearInsertSnapIn(_draggedId, val1.eledd);
                    DisableButton(".next");
                }
            }
        });
    });
}

function SetStepCondition() {
    var ColorVal = $('.PlateColorOption').find('input[type=radio]:checked').val();
    if (currentStep == 0) {
        ColorVal = "";
        //$(".stepheader").html("Base Unit (Please drag and drop any Base Unit)");      
    }
    else if (currentStep == 1) {
        ColorVal = "";
        ///$(".stepheader").html("Please drag and drop any Insert Plate)");
    }
    else if (currentStep == 2) {
        ColorVal = "";
        //$(".stepheader").html("Snap-Ins (Please drag and drop any Snap-In)");
    }
    else if (currentStep == 3) {
        var CodeLengthVal = $('.CodeLengthOption').find('input[type=radio]:checked').val();
        if (CodeLengthVal) {
            EnableButton(".next");
        }
        else {
            DisableButton(".next");
        }
        //$(".stepheader").html("AC Cord Length (Please Choose any AC Cord Length option)");
    }
    else if (currentStep == 4) {
        if (ColorVal) {
            EnableButton(".next");
        }
        else {
            DisableButton(".next");
        }
        //$(".stepheader").html("Color (Please Choose any Color option)");
    }
    else if (currentStep == 5) {        
        html2canvas(document.querySelector("#second_step")).then(canvas => {
            document.body.appendChild(canvas);
            $("#print_div").html('');
            $('canvas').appendTo("#print_div");
        });
        //$(".stepheader").html("Parts List");
    }
    if (ColorVal == "WHT") {
        $("#second_step img").each(function () {
            var src = $(this).attr("src");
            src = src.replace("_black", "_white");
            src = src.replace("_allwhite", "_white");
            $(this).attr("src", src);
        });
    }
    else if (ColorVal == "BLK") {
        $("#second_step img").each(function () {
            var src = $(this).attr("src");
            src = src.replace("_white", "_black");
            src = src.replace("_allwhite", "_black");
            $(this).attr("src", src);
        });
    }
    else {
        $("#second_step img").each(function () {
            var src = $(this).attr("src");
            src = src.replace("_black", "_allwhite");
            src = src.replace("_white", "_allwhite");
            $(this).attr("src", src);
        });
    }
}
