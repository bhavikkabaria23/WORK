﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using Nop.Core;
using Shopfast.Plugin.Payments.DejavooPosTerminal.Models;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Payments;
using Nop.Services.Stores;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;
using System.Xml;
using Nop.Core.Infrastructure;
using Nop.Core.Domain.Orders;
using Nop.Services.Orders;
using Nop.Core.Domain.Discounts;

namespace Shopfast.Plugin.Payments.DejavooPosTerminal.Controllers
{
    public class DejavooPosTerminalController : BasePaymentController
    {
        private readonly IWorkContext _workContext;
        private readonly IStoreService _storeService;
        private readonly ISettingService _settingService;
        private readonly ILocalizationService _localizationService;

        public DejavooPosTerminalController(IWorkContext workContext,
            IStoreService storeService,
            ISettingService settingService,
            ILocalizationService localizationService)
        {
            this._workContext = workContext;
            this._storeService = storeService;
            this._settingService = settingService;
            this._localizationService = localizationService;
        }

        [AdminAuthorize]
        [ChildActionOnly]
        public ActionResult Configure()
        {
            //load settings for a chosen store scope
            var storeScope = this.GetActiveStoreScopeConfiguration(_storeService, _workContext);
            var dejavooPosTerminalSettings = _settingService.LoadSetting<DejavooPosTerminalSettings>(storeScope);

            var model = new ConfigurationModel();
            model.PortNumber = dejavooPosTerminalSettings.PortNumber;
            model.IPAddress = dejavooPosTerminalSettings.IPAddress;
            model.AdditionalFee = dejavooPosTerminalSettings.AdditionalFee;
            model.AdditionalFeePercentage = dejavooPosTerminalSettings.AdditionalFeePercentage;

            model.ActiveStoreScopeConfiguration = storeScope;
            if (storeScope > 0)
            {
                model.PortNumber_OverrideForStore = _settingService.SettingExists(dejavooPosTerminalSettings, x => x.PortNumber, storeScope);
                model.IPAddress_OverrideForStore = _settingService.SettingExists(dejavooPosTerminalSettings, x => x.IPAddress, storeScope);
                model.AdditionalFee_OverrideForStore = _settingService.SettingExists(dejavooPosTerminalSettings, x => x.AdditionalFee, storeScope);
                model.AdditionalFeePercentage_OverrideForStore = _settingService.SettingExists(dejavooPosTerminalSettings, x => x.AdditionalFeePercentage, storeScope);
            }
            return View("~/Plugins/Payments.DejavooPosTerminal/Views/DejavooPosTerminal/Configure.cshtml", model);
        }

        [HttpPost]
        [AdminAuthorize]
        [ChildActionOnly]
        public ActionResult Configure(ConfigurationModel model)
        {
            if (!ModelState.IsValid)
                return Configure();

            //load settings for a chosen store scope
            var storeScope = this.GetActiveStoreScopeConfiguration(_storeService, _workContext);
            var dejavooPosTerminalSettings = _settingService.LoadSetting<DejavooPosTerminalSettings>(storeScope);

            //save settings
            dejavooPosTerminalSettings.PortNumber = model.PortNumber;
            dejavooPosTerminalSettings.IPAddress = model.IPAddress;
            dejavooPosTerminalSettings.AdditionalFee = model.AdditionalFee;
            dejavooPosTerminalSettings.AdditionalFeePercentage = model.AdditionalFeePercentage;

            /* We do not clear cache after each setting update.
             * This behavior can increase performance because cached settings will not be cleared 
             * and loaded from database after each update */

            if (model.PortNumber_OverrideForStore || storeScope == 0)
                _settingService.SaveSetting(dejavooPosTerminalSettings, x => x.PortNumber, storeScope, false);
            else if (storeScope > 0)
                _settingService.DeleteSetting(dejavooPosTerminalSettings, x => x.PortNumber, storeScope);

            if (model.IPAddress_OverrideForStore || storeScope == 0)
                _settingService.SaveSetting(dejavooPosTerminalSettings, x => x.IPAddress, storeScope, false);
            else if (storeScope > 0)
                _settingService.DeleteSetting(dejavooPosTerminalSettings, x => x.IPAddress, storeScope);

            if (model.AdditionalFee_OverrideForStore || storeScope == 0)
                _settingService.SaveSetting(dejavooPosTerminalSettings, x => x.AdditionalFee, storeScope, false);
            else if (storeScope > 0)
                _settingService.DeleteSetting(dejavooPosTerminalSettings, x => x.AdditionalFee, storeScope);

            if (model.AdditionalFeePercentage_OverrideForStore || storeScope == 0)
                _settingService.SaveSetting(dejavooPosTerminalSettings, x => x.AdditionalFeePercentage, storeScope, false);
            else if (storeScope > 0)
                _settingService.DeleteSetting(dejavooPosTerminalSettings, x => x.AdditionalFeePercentage, storeScope);

            //now clear settings cache
            _settingService.ClearCache();

            SuccessNotification(_localizationService.GetResource("Admin.Plugins.Saved"));
            return Configure();
        }

        [ChildActionOnly]
        public ActionResult PaymentInfo()
        {
            var model = new PaymentInfoModel();
            return View("~/Plugins/Payments.DejavooPosTerminal/Views/DejavooPosTerminal/PaymentInfo.cshtml", model);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult SetPaymentInfo(string responseData)
        {
            var paymentInfoModel = new PaymentInfoModel();
            if (!string.IsNullOrEmpty(responseData))
            {
                Session["terminalResponseData"] = responseData;
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(responseData);
                paymentInfoModel.Status = Convert.ToString(doc.GetElementsByTagName("RespMSG")[0].InnerXml);
                string ExtData = Convert.ToString(doc.GetElementsByTagName("ExtData")[0].InnerXml);
                List<string> ExtDataElements = new List<string>();
                ExtDataElements = ExtData.Split(',').ToList();
                var CreditCardType = ExtDataElements.FirstOrDefault(e => e.Contains("CardType"));
                if (CreditCardType != null)
                {
                    paymentInfoModel.CreditCardType = CreditCardType.Split('=')[1] ?? "";
                }
                var CardholderName = ExtDataElements.FirstOrDefault(e => e.Contains("Name"));
                if (CardholderName != null)
                {
                    paymentInfoModel.CardholderName = CardholderName.Split('=')[1] ?? "";
                }
                var CardNumber = ExtDataElements.FirstOrDefault(e => e.Contains("AcntLast4"));
                if (CardNumber != null)
                {
                    paymentInfoModel.CardNumber = CardNumber.Split('=')[1] ?? "";
                }
                paymentInfoModel.ExpireMonth = "01";
                paymentInfoModel.ExpireYear = "2020";
                paymentInfoModel.CardCode = "123";
            }
            return Json(new { paymentInfoModel });
        }

        [HttpPost]
        public ActionResult GetAPIUrl(bool testAPIUrl = false, string Discount = "0")
        {
            string portNo = Convert.ToString(EngineContext.Current.Resolve<DejavooPosTerminalSettings>().PortNumber);
            string ipAddress = EngineContext.Current.Resolve<DejavooPosTerminalSettings>().IPAddress;
            Random r = new Random();
            int n = r.Next();
            List<ShoppingCartItem> cart = (from sci in EngineContext.Current.Resolve<IWorkContext>().CurrentCustomer.ShoppingCartItems
                                           where sci.ShoppingCartType == ShoppingCartType.ShoppingCart
                                           where sci.StoreId == EngineContext.Current.Resolve<IStoreContext>().CurrentStore.Id
                                           select sci).ToList<ShoppingCartItem>();
            decimal? totalAmount = null;
            decimal discountAmount = 0;
            List<Discount> discount4 = null;
            List<AppliedGiftCard> appliedGiftCards = null;
            int redeemedRewardPoints = 0;
            decimal redeemedRewardPointsAmount = 0;
            totalAmount = EngineContext.Current.Resolve<IOrderTotalCalculationService>().GetShoppingCartTotal(cart, out discountAmount, out discount4, out appliedGiftCards, out redeemedRewardPoints, out redeemedRewardPointsAmount, false, true);
            if (decimal.Parse(Discount) > 0M)
            {
                discountAmount += decimal.Parse(Discount);
                decimal? nullable6 = totalAmount;
                decimal num38 = decimal.Parse(Discount);
                totalAmount = nullable6.HasValue ? new decimal?(nullable6.GetValueOrDefault() - num38) : null;
            }
            string url = "";
            if (!testAPIUrl)
            {
                url = "http://" + ipAddress + ":" + portNo + "/cgi.html?TerminalTransaction=<request><PaymentType>Credit</PaymentType><TransType>Sale</TransType><Amount>" + Convert.ToString(totalAmount) + "</Amount><InvNum>687</InvNum><RefId>" + n.ToString() + "</RefId><AuthKey>234123-74653252-663525223</AuthKey><RegisterId>3</RegisterId></request>";
                //  http://192.168.0.40:8483/cgi.html?TerminalTransaction=<request><PaymentType>Credit</PaymentType><TransType>Sale</TransType><Amount>1.00</Amount><InvNum>687</InvNum><RefId>747086456</RefId><AuthKey>234123-74653252-663525223</AuthKey><RegisterId>3</RegisterId></request>
            }
            else
            {
                url = "/DejavooPosTerminal/testAPIResponse";
            }
            return Json(new { url });
        }
        public ActionResult testAPIResponse()
        {
            string responseData = @"<response> 
                <RefId>777</RefId> 
            <RegisterId>3</RegisterId>
            <InvNum>687</InvNum> 
            <ResultCode>0</ResultCode> 
            <RespMSG>APPROVED</RespMSG> 
            <Message>Approved</Message> 
            <AuthCode>198208</AuthCode>
            <PNRef>00000026</PNRef>
            <PaymentType>Credit</PaymentType>
            <HostSpecific>TID: 001,</HostSpecific>                    
            <ExtData>InvNum=687,CardType=VISA,BatchNum=167003,Tip=0.00,CashBack=0.00,Fee=0.00,AcntLast4=3736,Name=YAKOV%2fRONNY,SVC=0.00,TotalAmt=1.00,DISC=0.00,Donation=0.00,SHFee=0.00,RwdPoints=0,RwdBalance=0,RwdIssued=,EBTFSLedgerBalance=,EBTFSAvailBalance=,EBTFSBeginBalance=,EBTCashLedgerBalance=,EBTCashAvailBalance=,EBTCashBeginBalance=,RewardCode=,AcqRefData=,ProcessData=,RefNo=,RewardQR=,Language=English,EntryType=Swipe,table_num=0,clerk_id=,ticket_num=</ExtData>
            <EMVData>AID=A0000000041010,AppName=MasterCardCredit,TVR=0800008000,TSI=E800</EMVData> 
            <Sign>Qk2aAQAAAAAAAD4AAAAoAAAAYAAAAB0AAAABAAEAAAAAAFwBAADEDgAAxA4AAAAAAAAAAAAAAAAAAP///wD////z//////////////+D//////////////4P//////////////g//////////////+D//////////////4P//////////////g///////////////D//////////////8P//////////////wf//////////////h//////////////+H//////////////4P//////////////w///////////////j///////////////n///////////////H//////////////CP/////////////gCf////////////wAcf///////////4AP8///////////8AH////////////8AD////////////4AB///+f///////gAB////+P//////wAD//////B/////gAP///////gH///AAH////////8Bn/wAP//////////xn/wf/////////8=</Sign> <Token></Token> </response>";
            return Json(new { responseData }, JsonRequestBehavior.AllowGet);
        }

        [NonAction]
        public override IList<string> ValidatePaymentForm(FormCollection form)
        {
            var warnings = new List<string>();
            return warnings;
        }

        [NonAction]
        public override ProcessPaymentRequest GetPaymentInfo(FormCollection form)
        {
            var paymentInfo = new ProcessPaymentRequest();
            paymentInfo.CreditCardType = form["CreditCardType"];
            paymentInfo.CreditCardName = form["CardholderName"];
            paymentInfo.CreditCardNumber = form["CardNumber"];
            paymentInfo.CreditCardExpireMonth = int.Parse(form["ExpireMonth"]);
            paymentInfo.CreditCardExpireYear = int.Parse(form["ExpireYear"]);
            paymentInfo.CreditCardCvv2 = form["CardCode"];
            return paymentInfo;
        }


    }
}