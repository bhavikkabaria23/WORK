using System;
using System.Collections.Generic;
using System.Web.Routing;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Core.Plugins;
using Shopfast.Plugin.Payments.DejavooPosTerminal.Controllers;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Orders;
using Nop.Services.Payments;
using System.Web;
using System.Xml;

namespace Shopfast.Plugin.Payments.DejavooPosTerminal
{
    /// <summary>
    /// Manual payment processor
    /// </summary>
    public class DejavooPosTerminalPaymentProcessor : BasePlugin, IPaymentMethod
    {
        #region Fields

        private readonly DejavooPosTerminalSettings _dejavooPosTerminalSettings;
        private readonly ISettingService _settingService;
        private readonly IOrderTotalCalculationService _orderTotalCalculationService;
        private readonly HttpContextBase _httpContext;

        #endregion

        #region Ctor

        public DejavooPosTerminalPaymentProcessor(DejavooPosTerminalSettings dejavooPosTerminalSettings,
            ISettingService settingService, IOrderTotalCalculationService orderTotalCalculationService
            , HttpContextBase httpContext)
        {
            this._dejavooPosTerminalSettings = dejavooPosTerminalSettings;
            this._settingService = settingService;
            this._orderTotalCalculationService = orderTotalCalculationService;
            this._httpContext = httpContext;
        }

        #endregion

        #region Methods
        
        /// <summary>
        /// Process a payment
        /// </summary>
        /// <param name="processPaymentRequest">Payment info required for an order processing</param>
        /// <returns>Process payment result</returns>
        public ProcessPaymentResult ProcessPayment(ProcessPaymentRequest processPaymentRequest)
        {
            var result = new ProcessPaymentResult();
            try
            {
                string responseData = (string)_httpContext.Session["terminalResponseData"];
                _httpContext.Session["terminalResponseData"] = null;
                if (!string.IsNullOrEmpty(responseData))
                {
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(responseData);
                    string status = Convert.ToString(doc.GetElementsByTagName("RespMSG")[0].InnerXml);
                    if (status.ToLower() == "approved")
                    {
                        result.AllowStoringCreditCardNumber = true;
                        result.NewPaymentStatus = PaymentStatus.Paid;
                        result.AuthorizationTransactionCode = Convert.ToString(doc.GetElementsByTagName("AuthCode")[0].InnerXml);
                        result.AuthorizationTransactionId = Convert.ToString(doc.GetElementsByTagName("PNRef")[0].InnerXml);
                        result.AuthorizationTransactionResult = status;
                        result.CaptureTransactionId = Convert.ToString(doc.GetElementsByTagName("PNRef")[0].InnerXml);
                        result.CaptureTransactionResult = status;
                        result.SubscriptionTransactionId = Convert.ToString(doc.GetElementsByTagName("PNRef")[0].InnerXml);
                    }
                    else
                    {
                        result.AddError(status);
                    }
                }
                else
                {
                    result.AddError("Failed");
                }
            }
            catch (Exception ex)
            {
                result.AddError(ex.Message);
            }
         
            return result;
        }

        /// <summary>
        /// Post process payment (used by payment gateways that require redirecting to a third-party URL)
        /// </summary>
        /// <param name="postProcessPaymentRequest">Payment info required for an order processing</param>
        public void PostProcessPayment(PostProcessPaymentRequest postProcessPaymentRequest)
        {
            //nothing
        }                

        /// <summary>
        /// Returns a value indicating whether payment method should be hidden during checkout
        /// </summary>
        /// <param name="cart">Shoping cart</param>
        /// <returns>true - hide; false - display.</returns>
        public bool HidePaymentMethod(IList<ShoppingCartItem> cart)
        {
            //you can put any logic here
            //for example, hide this payment method if all products in the cart are downloadable
            //or hide this payment method if current customer is from certain country
            return false;
        }

           /// <summary>
        /// Gets additional handling fee
        /// </summary>
        /// <returns>Additional handling fee</returns>
        public decimal GetAdditionalHandlingFee(IList<ShoppingCartItem> cart)
        {
            var result = this.CalculateAdditionalFee(_orderTotalCalculationService,  cart,
                _dejavooPosTerminalSettings.AdditionalFee, _dejavooPosTerminalSettings.AdditionalFeePercentage);
            return result;
        }

        /// <summary>
        /// Captures payment
        /// </summary>
        /// <param name="capturePaymentRequest">Capture payment request</param>
        /// <returns>Capture payment result</returns>
        public CapturePaymentResult Capture(CapturePaymentRequest capturePaymentRequest)
        {
            var result = new CapturePaymentResult();
            result.AddError("Capture method not supported");
            return result;
        }

        /// <summary>
        /// Refunds a payment
        /// </summary>
        /// <param name="refundPaymentRequest">Request</param>
        /// <returns>Result</returns>
        public RefundPaymentResult Refund(RefundPaymentRequest refundPaymentRequest)
        {
            var result = new RefundPaymentResult();
            result.AddError("Refund method not supported");
            return result;
        }

        /// <summary>
        /// Voids a payment
        /// </summary>
        /// <param name="voidPaymentRequest">Request</param>
        /// <returns>Result</returns>
        public VoidPaymentResult Void(VoidPaymentRequest voidPaymentRequest)
        {
            var result = new VoidPaymentResult();
            result.AddError("Void method not supported");
            return result;
        }

         /// <summary>
        /// Process recurring payment
        /// </summary>
        /// <param name="processPaymentRequest">Payment info required for an order processing</param>
        /// <returns>Process payment result</returns>
        public ProcessPaymentResult ProcessRecurringPayment(ProcessPaymentRequest processPaymentRequest)
        {
            var result = new ProcessPaymentResult();
            result.AddError("Recurring payment not supported");
            return result;
        }

        /// <summary>
        /// Cancels a recurring payment
        /// </summary>
        /// <param name="cancelPaymentRequest">Request</param>
        /// <returns>Result</returns>
        public CancelRecurringPaymentResult CancelRecurringPayment(CancelRecurringPaymentRequest cancelPaymentRequest)
        {
            var result = new CancelRecurringPaymentResult();
            result.AddError("Recurring payment not supported");
            return result;
        }

        /// <summary>
        /// Gets a value indicating whether customers can complete a payment after order is placed but not completed (for redirection payment methods)
        /// </summary>
        /// <param name="order">Order</param>
        /// <returns>Result</returns>
        public bool CanRePostProcessPayment(Order order)
        {
            if (order == null)
                throw new ArgumentNullException("order");

            //it's not a redirection payment method. So we always return false
            return false;
        }

        /// <summary>
        /// Gets a route for provider configuration
        /// </summary>
        /// <param name="actionName">Action name</param>
        /// <param name="controllerName">Controller name</param>
        /// <param name="routeValues">Route values</param>
        public void GetConfigurationRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "Configure";
            controllerName = "DejavooPosTerminal";
            routeValues = new RouteValueDictionary { { "Namespaces", "Shopfast.Plugin.Payments.DejavooPosTerminal.Controllers" }, { "area", null } };
        }

        /// <summary>
        /// Gets a route for payment info
        /// </summary>
        /// <param name="actionName">Action name</param>
        /// <param name="controllerName">Controller name</param>
        /// <param name="routeValues">Route values</param>
        public void GetPaymentInfoRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "PaymentInfo";
            controllerName = "DejavooPosTerminal";
            routeValues = new RouteValueDictionary { { "Namespaces", "Shopfast.Plugin.Payments.DejavooPosTerminal.Controllers" }, { "area", null } };
        }

        public Type GetControllerType()
        {
            return typeof(DejavooPosTerminalController);
        }

        public override void Install()
        {
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.Payments.DejavooPosTerminal.Fields.PortNumber", "Port");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.Payments.DejavooPosTerminal.Fields.IPAddress", "IP Address");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.Payments.DejavooPosTerminal.Fields.AdditionalFee", "Additional fee");
            this.AddOrUpdatePluginLocaleResource("Shopfast.Plugin.Payments.DejavooPosTerminal.Fields.AdditionalFeePercentage", "Additional fee. Use percentage");

            base.Install();
        }

        public override void Uninstall()
        {
            //settings
            _settingService.DeleteSetting<DejavooPosTerminalSettings>();

            this.DeletePluginLocaleResource("Shopfast.Plugin.Payments.DejavooPosTerminal.Fields.PortNumber");
            this.DeletePluginLocaleResource("Shopfast.Plugin.Payments.DejavooPosTerminal.Fields.IPAddress");
            this.DeletePluginLocaleResource("Shopfast.Plugin.Payments.DejavooPosTerminal.Fields.AdditionalFee");
            this.DeletePluginLocaleResource("Shopfast.Plugin.Payments.DejavooPosTerminal.Fields.AdditionalFeePercentage");
         
            base.Uninstall();
        }

        #endregion         
       
        #region Properties

        /// <summary>
        /// Gets a value indicating whether capture is supported
        /// </summary>
        public bool SupportCapture
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// Gets a value indicating whether partial refund is supported
        /// </summary>
        public bool SupportPartiallyRefund
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// Gets a value indicating whether refund is supported
        /// </summary>
        public bool SupportRefund
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// Gets a value indicating whether void is supported
        /// </summary>
        public bool SupportVoid
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// Gets a recurring payment type of payment method
        /// </summary>
        public RecurringPaymentType RecurringPaymentType
        {
            get
            {
                return RecurringPaymentType.Manual;
            }
        }

        /// <summary>
        /// Gets a payment method type
        /// </summary>
        public PaymentMethodType PaymentMethodType
        {
            get
            {
                return PaymentMethodType.Standard;
            }
        }

        /// <summary>
        /// Gets a value indicating whether we should display a payment information page for this plugin
        /// </summary>
        public bool SkipPaymentInfo
        {
            get
            {
                return false;
            }
        }

        #endregion
    }
}
