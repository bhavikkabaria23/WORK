﻿using System.Web.Mvc;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;

namespace Shopfast.Plugin.Payments.DejavooPosTerminal.Models
{
    public class ConfigurationModel : BaseNopModel
    {
        public int ActiveStoreScopeConfiguration { get; set; }

        [NopResourceDisplayName("Shopfast.Plugin.Payments.DejavooPosTerminal.Fields.AdditionalFeePercentage")]
        public bool AdditionalFeePercentage { get; set; }
        public bool AdditionalFeePercentage_OverrideForStore { get; set; }

        [NopResourceDisplayName("Shopfast.Plugin.Payments.DejavooPosTerminal.Fields.AdditionalFee")]
        public decimal AdditionalFee { get; set; }
        public bool AdditionalFee_OverrideForStore { get; set; }
        [NopResourceDisplayName("Shopfast.Plugin.Payments.DejavooPosTerminal.Fields.PortNumber")]
        public int PortNumber { get; set; }
        public bool PortNumber_OverrideForStore { get; set; }
        [NopResourceDisplayName("Shopfast.Plugin.Payments.DejavooPosTerminal.Fields.IPAddress")]
        public string IPAddress { get; set; }
        public bool IPAddress_OverrideForStore { get; set; }
    }
}