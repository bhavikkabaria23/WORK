﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shopfast.Plugin.Payments.DejavooPosTerminal.Models
{
    public class PaymentInfoModel
    {
        public string CreditCardType { get; set; }
        public string CardholderName { get; set; }
        public string CardNumber { get; set; }
        public string ExpireMonth { get; set; }
        public string ExpireYear { get; set; }
        public string CardCode { get; set; }
        public string Status { get; set; }
    }
}
