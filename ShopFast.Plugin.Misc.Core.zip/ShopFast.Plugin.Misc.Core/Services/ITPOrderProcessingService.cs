﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using Nop.Core;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Common;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Directory;
using Nop.Core.Domain.Discounts;
using Nop.Core.Domain.Localization;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Core.Domain.Shipping;
using Nop.Core.Domain.Tax;
using Nop.Services.Affiliates;
using Nop.Services.Catalog;
using Nop.Services.Common;
using Nop.Services.Configuration;
using Nop.Services.Customers;
using Nop.Services.Directory;
using Nop.Services.Discounts;
using Nop.Services.Events;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Messages;
using Nop.Services.Orders;
using Nop.Services.Payments;
using Nop.Services.Security;
using Nop.Services.Shipping;
using Nop.Services.Tax;
using Nop.Services.Vendors;
using ShopFast.Plugin.Misc.Core.Domain;

namespace ShopFast.Plugin.Misc.Core.Services
{
    /// <summary>
    /// Order processing service with partial payment support
    /// </summary>
    public partial class ITPOrderProcessingService : OrderProcessingService, IITPOrderProcessingService
    {
        #region Fields

        private readonly IOrderService _orderService;
        private readonly IWebHelper _webHelper;
        private readonly ILocalizationService _localizationService;
        private readonly ILanguageService _languageService;
        private readonly IProductService _productService;
        private readonly IPaymentService _paymentService;
        private readonly ILogger _logger;
        private readonly IOrderTotalCalculationService _orderTotalCalculationService;
        private readonly IPriceCalculationService _priceCalculationService;
        private readonly IPriceFormatter _priceFormatter;
        private readonly IProductAttributeParser _productAttributeParser;
        private readonly IProductAttributeFormatter _productAttributeFormatter;
        private readonly IGiftCardService _giftCardService;
        private readonly IShoppingCartService _shoppingCartService;
        private readonly ICheckoutAttributeFormatter _checkoutAttributeFormatter;
        private readonly IShippingService _shippingService;
        private readonly IShipmentService _shipmentService;
        private readonly ITaxService _taxService;
        private readonly ICustomerService _customerService;
        private readonly IDiscountService _discountService;
        private readonly IEncryptionService _encryptionService;
        private readonly IWorkContext _workContext;
        private readonly IWorkflowMessageService _workflowMessageService;
        private readonly IVendorService _vendorService;
        private readonly ICustomerActivityService _customerActivityService;
        private readonly ICurrencyService _currencyService;
        private readonly IAffiliateService _affiliateService;
        private readonly IEventPublisher _eventPublisher;
        private readonly IPdfService _pdfService;
        private readonly IITPPartialPaymentService _partialPaymentService;

        //nop3.7 upgrade begin
        private readonly IRewardPointService _rewardPointService;
        private readonly IStoreContext _storeContext;
        //nop3.7 upgrade begin

        private readonly ShippingSettings _shippingSettings;
        private readonly PaymentSettings _paymentSettings;
        private readonly RewardPointsSettings _rewardPointsSettings;
        private readonly OrderSettings _orderSettings;
        private readonly TaxSettings _taxSettings;
        private readonly LocalizationSettings _localizationSettings;
        private readonly CurrencySettings _currencySettings;

        #endregion

        #region Ctor

        public ITPOrderProcessingService(IOrderService orderService,
            IWebHelper webHelper,
            ILocalizationService localizationService,
            ILanguageService languageService,
            IProductService productService,
            IPaymentService paymentService,
            ILogger logger,
            IOrderTotalCalculationService orderTotalCalculationService,
            IPriceCalculationService priceCalculationService,
            IPriceFormatter priceFormatter,
            IProductAttributeParser productAttributeParser,
            IProductAttributeFormatter productAttributeFormatter,
            IGiftCardService giftCardService,
            IShoppingCartService shoppingCartService,
            ICheckoutAttributeFormatter checkoutAttributeFormatter,
            IShippingService shippingService,
            IShipmentService shipmentService,
            ITaxService taxService,
            ICustomerService customerService,
            IDiscountService discountService,
            IEncryptionService encryptionService,
            IWorkContext workContext,
            IWorkflowMessageService workflowMessageService,
            IVendorService vendorService,
            ICustomerActivityService customerActivityService,
            ICurrencyService currencyService,
            IAffiliateService affiliateService,
            IEventPublisher eventPublisher,
            IPdfService pdfService,
            IRewardPointService rewardPointService,
            IGenericAttributeService genericAttributeService,
            ICountryService countryService,
            IStateProvinceService stateProvinceService,
            ShippingSettings shippingSettings,
            PaymentSettings paymentSettings,
            RewardPointsSettings rewardPointsSettings,
            OrderSettings orderSettings,
            TaxSettings taxSettings,
            LocalizationSettings localizationSettings,
            CurrencySettings currencySettings,
            ICustomNumberFormatter customNumberFormatter,
            IITPPartialPaymentService partialPaymentService,
            IRewardPointService rewardPointService1, 
            IStoreContext storeContext)
            : base(orderService, webHelper, localizationService, languageService, productService, paymentService, logger, 
            orderTotalCalculationService, priceCalculationService, priceFormatter, productAttributeParser, productAttributeFormatter,
            giftCardService, shoppingCartService, checkoutAttributeFormatter, shippingService, shipmentService, taxService,
            customerService, discountService, encryptionService, workContext, workflowMessageService, vendorService, 
            customerActivityService, currencyService, affiliateService, eventPublisher, pdfService, rewardPointService,
            genericAttributeService, countryService, stateProvinceService, shippingSettings, paymentSettings, rewardPointsSettings, orderSettings, taxSettings,
            localizationSettings, currencySettings, customNumberFormatter)
        {
            this._orderService = orderService;
            this._webHelper = webHelper;
            this._localizationService = localizationService;
            this._languageService = languageService;
            this._productService = productService;
            this._paymentService = paymentService;
            this._logger = logger;
            this._orderTotalCalculationService = orderTotalCalculationService;
            this._priceCalculationService = priceCalculationService;
            this._priceFormatter = priceFormatter;
            this._productAttributeParser = productAttributeParser;
            this._productAttributeFormatter = productAttributeFormatter;
            this._giftCardService = giftCardService;
            this._shoppingCartService = shoppingCartService;
            this._checkoutAttributeFormatter = checkoutAttributeFormatter;
            this._workContext = workContext;
            this._workflowMessageService = workflowMessageService;
            this._vendorService = vendorService;
            this._shippingService = shippingService;
            this._shipmentService = shipmentService;
            this._taxService = taxService;
            this._customerService = customerService;
            this._discountService = discountService;
            this._encryptionService = encryptionService;
            this._customerActivityService = customerActivityService;
            this._currencyService = currencyService;
            this._affiliateService = affiliateService;
            this._eventPublisher = eventPublisher;
            this._pdfService = pdfService;
            this._paymentSettings = paymentSettings;
            this._shippingSettings = shippingSettings;
            this._rewardPointsSettings = rewardPointsSettings;
            this._orderSettings = orderSettings;
            this._taxSettings = taxSettings;
            this._localizationSettings = localizationSettings;
            this._currencySettings = currencySettings;
            this._partialPaymentService = partialPaymentService;
            _rewardPointService = rewardPointService1;
            _storeContext = storeContext;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Checks order status
        /// </summary>
        /// <param name="order">Order</param>
        /// <returns>Validated order</returns>
        public override void CheckOrderStatus(Order order)
        {
            if (order == null)
                throw new ArgumentNullException("order");

            var payments = _partialPaymentService.GetOrderPayments(order);
            if (payments.Any())
            {
                if (_partialPaymentService.GetRemainingBalance(order, true) == decimal.Zero
                    && order.PaymentStatus != PaymentStatus.Paid)
                {
                    order.PaymentStatus = PaymentStatus.Paid;
                    _orderService.UpdateOrder(order);
                }
            }

            if (order.PaymentStatus == PaymentStatus.Paid && !order.PaidDateUtc.HasValue)
            {
                //ensure that paid date is set
                order.PaidDateUtc = DateTime.UtcNow;
                _orderService.UpdateOrder(order);
            }

            if (order.OrderStatus == OrderStatus.Pending)
            {
                if (order.PaymentStatus == PaymentStatus.Authorized ||
                    order.PaymentStatus == PaymentStatus.Paid)
                {
                    SetOrderStatus(order, OrderStatus.Processing, false);
                }
            }

            if (order.OrderStatus == OrderStatus.Pending)
            {
                if (order.ShippingStatus == ShippingStatus.PartiallyShipped ||
                    order.ShippingStatus == ShippingStatus.Shipped ||
                    order.ShippingStatus == ShippingStatus.Delivered)
                {
                    SetOrderStatus(order, OrderStatus.Processing, false);
                }
            }

            if (order.OrderStatus != OrderStatus.Cancelled &&
                order.OrderStatus != OrderStatus.Complete)
            {
                if (order.PaymentStatus == PaymentStatus.Paid)
                {
                    if (order.ShippingStatus == ShippingStatus.ShippingNotRequired || order.ShippingStatus == ShippingStatus.Delivered)
                    {
                        SetOrderStatus(order, OrderStatus.Complete, true);
                    }
                }
            }
        }
        
        /// <summary>
        /// Places an order
        /// </summary>
        /// <param name="processPaymentRequest">Process payment request</param>
        /// <param name="paymentOperationType">Payment operation type</param>
        /// <returns>Place order result</returns>
        public virtual PlaceOrderResult PlaceOrder(ProcessPaymentRequest processPaymentRequest, 
            PaymentOperationType paymentOperationType, out Order paymentOrder)
        {
            paymentOrder = null;
            switch (paymentOperationType)
            {
                case PaymentOperationType.Partial:
                    return PlacePartiallyPaidOrder(processPaymentRequest, out paymentOrder);
                case PaymentOperationType.Full:
                default:
                    return base.PlaceOrder(processPaymentRequest);
            }
        }
        
        public virtual PlaceOrderResult PlacePartiallyPaidOrder(ProcessPaymentRequest processPaymentRequest,
            out Order paymentOrder)
        {
            if (processPaymentRequest == null)
                throw new ArgumentNullException("processPaymentRequest");

            paymentOrder = null;

            var paymentAmount = processPaymentRequest.OrderTotal;

            var result = new PlaceOrderResult();
            try
            {
                if (processPaymentRequest.OrderGuid == Guid.Empty)
                    processPaymentRequest.OrderGuid = Guid.NewGuid();

                //prepare order details
                var details = PreparePlaceOrderDetails(processPaymentRequest);

                //Place Initial Order
                #region Save order details

                var initialOrderPaymentResult = new ProcessPaymentResult()
                {
                    NewPaymentStatus = PaymentStatus.Pending
                };

                var order = SaveOrderDetails(processPaymentRequest, initialOrderPaymentResult, details);
                result.PlacedOrder = order;

                //move shopping cart items to order items
                foreach (var sc in details.Cart)
                {
                    //prices
                    decimal taxRate;
                    List<DiscountForCaching> scDiscounts;
                    decimal discountAmount;
                    int? maximumDiscountQty;
                    var scUnitPrice = _priceCalculationService.GetUnitPrice(sc);
                    var scSubTotal = _priceCalculationService.GetSubTotal(sc, true, out discountAmount, out scDiscounts, out maximumDiscountQty);
                    var scUnitPriceInclTax = _taxService.GetProductPrice(sc.Product, scUnitPrice, true, details.Customer, out taxRate);
                    var scUnitPriceExclTax = _taxService.GetProductPrice(sc.Product, scUnitPrice, false, details.Customer, out taxRate);
                    var scSubTotalInclTax = _taxService.GetProductPrice(sc.Product, scSubTotal, true, details.Customer, out taxRate);
                    var scSubTotalExclTax = _taxService.GetProductPrice(sc.Product, scSubTotal, false, details.Customer, out taxRate);
                    var discountAmountInclTax = _taxService.GetProductPrice(sc.Product, discountAmount, true, details.Customer, out taxRate);
                    var discountAmountExclTax = _taxService.GetProductPrice(sc.Product, discountAmount, false, details.Customer, out taxRate);
                    foreach (var disc in scDiscounts)
                        if (!details.AppliedDiscounts.ContainsDiscount(disc))
                            details.AppliedDiscounts.Add(disc);

                    //attributes
                    var attributeDescription = _productAttributeFormatter.FormatAttributes(sc.Product, sc.AttributesXml, details.Customer);

                    var itemWeight = _shippingService.GetShoppingCartItemWeight(sc);

                    //save order item
                    var orderItem = new OrderItem
                    {
                        OrderItemGuid = Guid.NewGuid(),
                        Order = order,
                        ProductId = sc.ProductId,
                        UnitPriceInclTax = scUnitPriceInclTax,
                        UnitPriceExclTax = scUnitPriceExclTax,
                        PriceInclTax = scSubTotalInclTax,
                        PriceExclTax = scSubTotalExclTax,
                        OriginalProductCost = _priceCalculationService.GetProductCost(sc.Product, sc.AttributesXml),
                        AttributeDescription = attributeDescription,
                        AttributesXml = sc.AttributesXml,
                        Quantity = sc.Quantity,
                        DiscountAmountInclTax = discountAmountInclTax,
                        DiscountAmountExclTax = discountAmountExclTax,
                        DownloadCount = 0,
                        IsDownloadActivated = false,
                        LicenseDownloadId = 0,
                        ItemWeight = itemWeight,
                        RentalStartDateUtc = sc.RentalStartDateUtc,
                        RentalEndDateUtc = sc.RentalEndDateUtc
                    };
                    order.OrderItems.Add(orderItem);
                    _orderService.UpdateOrder(order);

                    //gift cards
                    if (sc.Product.IsGiftCard)
                    {
                        string giftCardRecipientName;
                        string giftCardRecipientEmail;
                        string giftCardSenderName;
                        string giftCardSenderEmail;
                        string giftCardMessage;
                        _productAttributeParser.GetGiftCardAttribute(sc.AttributesXml, out giftCardRecipientName,
                            out giftCardRecipientEmail, out giftCardSenderName, out giftCardSenderEmail, out giftCardMessage);

                        for (var i = 0; i < sc.Quantity; i++)
                        {
                            _giftCardService.InsertGiftCard(new GiftCard
                            {
                                GiftCardType = sc.Product.GiftCardType,
                                PurchasedWithOrderItem = orderItem,
                                Amount = sc.Product.OverriddenGiftCardAmount.HasValue ? sc.Product.OverriddenGiftCardAmount.Value : scUnitPriceExclTax,
                                IsGiftCardActivated = false,
                                GiftCardCouponCode = _giftCardService.GenerateGiftCardCode(),
                                RecipientName = giftCardRecipientName,
                                RecipientEmail = giftCardRecipientEmail,
                                SenderName = giftCardSenderName,
                                SenderEmail = giftCardSenderEmail,
                                Message = giftCardMessage,
                                IsRecipientNotified = false,
                                CreatedOnUtc = DateTime.UtcNow
                            });
                        }
                    }

                    //inventory
                    _productService.AdjustInventory(sc.Product, -sc.Quantity, sc.AttributesXml);
                }

                //clear shopping cart
                details.Cart.ToList().ForEach(sci => _shoppingCartService.DeleteShoppingCartItem(sci, false));

                //discount usage history
                foreach (var discount in details.AppliedDiscounts)
                {
                    var d = _discountService.GetDiscountById(discount.Id);
                    if (d != null)
                    {
                        _discountService.InsertDiscountUsageHistory(new DiscountUsageHistory
                        {
                            Discount = d,
                            Order = order,
                            CreatedOnUtc = DateTime.UtcNow
                        });
                    }
                }

                //gift card usage history
                if (details.AppliedGiftCards != null)
                    foreach (var agc in details.AppliedGiftCards)
                    {
                        agc.GiftCard.GiftCardUsageHistory.Add(new GiftCardUsageHistory
                        {
                            GiftCard = agc.GiftCard,
                            UsedWithOrder = order,
                            UsedValue = agc.AmountCanBeUsed,
                            CreatedOnUtc = DateTime.UtcNow
                        });
                        _giftCardService.UpdateGiftCard(agc.GiftCard);
                    }

                //recurring orders
                if (details.IsRecurringShoppingCart)
                {
                    //create recurring payment (the first payment)
                    var rp = new RecurringPayment
                    {
                        CycleLength = processPaymentRequest.RecurringCycleLength,
                        CyclePeriod = processPaymentRequest.RecurringCyclePeriod,
                        TotalCycles = processPaymentRequest.RecurringTotalCycles,
                        StartDateUtc = DateTime.UtcNow,
                        IsActive = true,
                        CreatedOnUtc = DateTime.UtcNow,
                        InitialOrder = order,
                    };
                    _orderService.InsertRecurringPayment(rp);

                    switch (_paymentService.GetRecurringPaymentType(processPaymentRequest.PaymentMethodSystemName))
                    {
                        case RecurringPaymentType.NotSupported:
                            //not supported
                            break;
                        case RecurringPaymentType.Manual:
                            rp.RecurringPaymentHistory.Add(new RecurringPaymentHistory
                            {
                                RecurringPayment = rp,
                                CreatedOnUtc = DateTime.UtcNow,
                                OrderId = order.Id,
                            });
                            _orderService.UpdateRecurringPayment(rp);
                            break;
                        case RecurringPaymentType.Automatic:
                            //will be created later (process is automated)
                            break;
                        default:
                            break;
                    }
                }

                #endregion

                //notifications
                SendNotificationsAndSaveNotes(order);

                //reset checkout data
                var isRecurringShoppingCart = details.IsRecurringShoppingCart;
                _customerService.ResetCheckoutData(details.Customer, processPaymentRequest.StoreId, clearCouponCodes: true, clearCheckoutAttributes: true);
                _customerActivityService.InsertActivity("PublicStore.PlaceOrder", _localizationService.GetResource("ActivityLog.PublicStore.PlaceOrder"), order.Id);

                //Process Partial Payment
                #region Payment workflow

                processPaymentRequest.OrderTotal = paymentAmount;
                processPaymentRequest.OrderGuid = order.OrderGuid;
                processPaymentRequest.InitialOrderId = order.Id;

                //process payment
                ProcessPaymentResult processPaymentResult = null;
                //skip payment workflow if order total equals zero
                var skipPaymentWorkflow = order.OrderTotal == decimal.Zero;
                if (!skipPaymentWorkflow)
                {
                    var paymentMethod = _partialPaymentService
                        .LoadPaymentMethodBySystemName(processPaymentRequest.PaymentMethodSystemName);
                    if (paymentMethod == null)
                        throw new NopException("Payment method couldn't be loaded");

                    //ensure that payment method is active
                    if (!paymentMethod.IsPaymentMethodActive(_paymentSettings))
                        throw new NopException("Payment method is not active");

                    if (isRecurringShoppingCart)
                    {
                        //recurring cart
                        switch (
                            _partialPaymentService.GetRecurringPaymentType(processPaymentRequest.PaymentMethodSystemName)
                            )
                        {
                            case RecurringPaymentType.NotSupported:
                                throw new NopException("Recurring payments are not supported by selected payment method");
                            case RecurringPaymentType.Manual:
                            case RecurringPaymentType.Automatic:
                                processPaymentResult =
                                    _partialPaymentService.ProcessRecurringPayment(processPaymentRequest);
                                break;
                            default:
                                throw new NopException("Not supported recurring payment type");
                        }
                    }
                    else
                    {
                        //standard cart
                        processPaymentResult = _partialPaymentService.ProcessPayment(processPaymentRequest,
                            out paymentOrder);
                    }
                }
                else
                    //payment is not required
                    processPaymentResult = new ProcessPaymentResult { NewPaymentStatus = PaymentStatus.Paid };

                if (processPaymentResult == null)
                    throw new NopException("processPaymentResult is not available");

                #endregion

                if (processPaymentResult.Success)
                {
                    //check order status
                    CheckOrderStatus(order);

                    //raise event       
                    _eventPublisher.Publish(new OrderPlacedEvent(order));
                    //_eventPublisher.Publish(new OrderPlacedEvent(paymentOrder));

                    if (order.PaymentStatus == PaymentStatus.Paid)
                        ProcessOrderPaid(order);
                }
                else
                    foreach (var paymentError in processPaymentResult.Errors)
                        result.AddError(string.Format(_localizationService.GetResource("Checkout.PaymentError"), paymentError));
            }
            catch (Exception exc)
            {
                //_logger.Error(exc.Message, exc);
                result.AddError(exc.Message);
            }

            #region Process errors

            if (!result.Success)
            {
                //log errors
                var logError = result.Errors.Aggregate("Error while placing order. ",
                    (current, next) => string.Format("{0}Error {1}: {2}. ", current, result.Errors.IndexOf(next) + 1, next));
                var customer = _customerService.GetCustomerById(processPaymentRequest.CustomerId);
                //_logger.Error(logError, customer: customer);
            }

            #endregion

            return result;
        }

        //nop3.7 upgrade begin
        /// <summary>
        /// Places an order
        /// </summary>
        /// <param name="processPaymentRequest">Process payment request</param>
        /// <param name="paymentOperationType">Payment operation type</param>
        /// <param name="paymentOrder">Partial Payment order</param>
        /// <returns>Place order result</returns>
        public virtual PlaceOrderResult PlaceOrderOLD(ProcessPaymentRequest processPaymentRequest, out Order paymentOrder,
            PaymentOperationType paymentOperationType = PaymentOperationType.Full)
        {
            paymentOrder = null;
            //think about moving functionality of processing recurring orders (after the initial order was placed) to ProcessNextRecurringPayment() method
            if (processPaymentRequest == null)
                throw new ArgumentNullException("processPaymentRequest");

            var result = new PlaceOrderResult();
            try
            {
                if (processPaymentRequest.OrderGuid == Guid.Empty)
                    processPaymentRequest.OrderGuid = Guid.NewGuid();

                //prepare order details
                var details = PreparePlaceOrderDetails(processPaymentRequest);

                #region Save order details

                var order = new Order
                {
                    StoreId = processPaymentRequest.StoreId,
                    OrderGuid = processPaymentRequest.OrderGuid,
                    CustomerId = details.Customer.Id,
                    CustomerLanguageId = details.CustomerLanguage.Id,
                    CustomerTaxDisplayType = details.CustomerTaxDisplayType,
                    CustomerIp = _webHelper.GetCurrentIpAddress(),
                    OrderSubtotalInclTax = details.OrderSubTotalInclTax,
                    OrderSubtotalExclTax = details.OrderSubTotalExclTax,
                    OrderSubTotalDiscountInclTax = details.OrderSubTotalDiscountInclTax,
                    OrderSubTotalDiscountExclTax = details.OrderSubTotalDiscountExclTax,
                    OrderShippingInclTax = details.OrderShippingTotalInclTax,
                    OrderShippingExclTax = details.OrderShippingTotalExclTax,
                    PaymentMethodAdditionalFeeInclTax = details.PaymentAdditionalFeeInclTax,
                    PaymentMethodAdditionalFeeExclTax = details.PaymentAdditionalFeeExclTax,
                    TaxRates = details.TaxRates,
                    OrderTax = details.OrderTaxTotal,
                    OrderTotal = details.OrderTotal,
                    RefundedAmount = decimal.Zero,
                    OrderDiscount = details.OrderDiscountAmount,
                    CheckoutAttributeDescription = details.CheckoutAttributeDescription,
                    CheckoutAttributesXml = details.CheckoutAttributesXml,
                    CustomerCurrencyCode = details.CustomerCurrencyCode,
                    CurrencyRate = details.CustomerCurrencyRate,
                    AffiliateId = details.AffiliateId,
                    OrderStatus = OrderStatus.Pending,

                    PaidDateUtc = null,
                    BillingAddress = details.BillingAddress,
                    ShippingAddress = details.ShippingAddress,
                    ShippingStatus = details.ShippingStatus,
                    ShippingMethod = details.ShippingMethodName,
                    PickUpInStore = details.PickUpInStore,
                    ShippingRateComputationMethodSystemName = details.ShippingRateComputationMethodSystemName,
                    CustomValuesXml = processPaymentRequest.SerializeCustomValues(),
                    VatNumber = details.VatNumber,
                    CreatedOnUtc = DateTime.UtcNow
                };
                _orderService.InsertOrder(order);
                details.InitialOrder = order;

                //if (!processPaymentRequest.IsRecurringPayment)
                if (details.IsRecurringShoppingCart)
                {
                    //move shopping cart items to order items
                    foreach (var sc in details.Cart)
                    {
                        //prices
                        decimal taxRate;
                        List<DiscountForCaching> scDiscounts;
                        decimal discountAmount;
                        int? maximumDiscountQty;
                        decimal scUnitPrice = _priceCalculationService.GetUnitPrice(sc);
                        decimal scSubTotal = _priceCalculationService.GetSubTotal(sc, true, out discountAmount, out scDiscounts, out maximumDiscountQty);
                        decimal scUnitPriceInclTax = _taxService.GetProductPrice(sc.Product, scUnitPrice, true, details.Customer, out taxRate);
                        decimal scUnitPriceExclTax = _taxService.GetProductPrice(sc.Product, scUnitPrice, false, details.Customer, out taxRate);
                        decimal scSubTotalInclTax = _taxService.GetProductPrice(sc.Product, scSubTotal, true, details.Customer, out taxRate);
                        decimal scSubTotalExclTax = _taxService.GetProductPrice(sc.Product, scSubTotal, false, details.Customer, out taxRate);

                        decimal discountAmountInclTax = _taxService.GetProductPrice(sc.Product, discountAmount, true, details.Customer, out taxRate);
                        decimal discountAmountExclTax = _taxService.GetProductPrice(sc.Product, discountAmount, false, details.Customer, out taxRate);
                        if (scDiscounts != null)
                        {
                            foreach (var discount in scDiscounts)
                            {
                                if (details.AppliedDiscounts.ContainsDiscount(discount))
                                {
                                    details.AppliedDiscounts.Add(discount);
                                }
                            }
                        }

                        //attributes
                        string attributeDescription = _productAttributeFormatter.FormatAttributes(sc.Product, sc.AttributesXml, details.Customer);

                        var itemWeight = _shippingService.GetShoppingCartItemWeight(sc);

                        //save order item
                        var orderItem = new OrderItem
                        {
                            OrderItemGuid = Guid.NewGuid(),
                            Order = order,
                            ProductId = sc.ProductId,
                            UnitPriceInclTax = scUnitPriceInclTax,
                            UnitPriceExclTax = scUnitPriceExclTax,
                            PriceInclTax = scSubTotalInclTax,
                            PriceExclTax = scSubTotalExclTax,
                            OriginalProductCost = _priceCalculationService.GetProductCost(sc.Product, sc.AttributesXml),
                            AttributeDescription = attributeDescription,
                            AttributesXml = sc.AttributesXml,
                            Quantity = sc.Quantity,
                            DiscountAmountInclTax = discountAmountInclTax,
                            DiscountAmountExclTax = discountAmountExclTax,
                            DownloadCount = 0,
                            IsDownloadActivated = false,
                            LicenseDownloadId = 0,
                            ItemWeight = itemWeight,
                            RentalStartDateUtc = sc.RentalStartDateUtc,
                            RentalEndDateUtc = sc.RentalEndDateUtc
                        };
                        order.OrderItems.Add(orderItem);
                        _orderService.UpdateOrder(order);

                        //gift cards
                        if (sc.Product.IsGiftCard)
                        {
                            string giftCardRecipientName, giftCardRecipientEmail,
                                giftCardSenderName, giftCardSenderEmail, giftCardMessage;
                            _productAttributeParser.GetGiftCardAttribute(sc.AttributesXml,
                                out giftCardRecipientName, out giftCardRecipientEmail,
                                out giftCardSenderName, out giftCardSenderEmail, out giftCardMessage);

                            for (int i = 0; i < sc.Quantity; i++)
                            {
                                var gc = new GiftCard
                                {
                                    GiftCardType = sc.Product.GiftCardType,
                                    PurchasedWithOrderItem = orderItem,
                                    Amount = sc.Product.OverriddenGiftCardAmount.HasValue ? sc.Product.OverriddenGiftCardAmount.Value : scUnitPriceExclTax,
                                    IsGiftCardActivated = false,
                                    GiftCardCouponCode = _giftCardService.GenerateGiftCardCode(),
                                    RecipientName = giftCardRecipientName,
                                    RecipientEmail = giftCardRecipientEmail,
                                    SenderName = giftCardSenderName,
                                    SenderEmail = giftCardSenderEmail,
                                    Message = giftCardMessage,
                                    IsRecipientNotified = false,
                                    CreatedOnUtc = DateTime.UtcNow
                                };
                                _giftCardService.InsertGiftCard(gc);
                            }
                        }

                        //inventory
                        _productService.AdjustInventory(sc.Product, -sc.Quantity, sc.AttributesXml);
                    }

                    //clear shopping cart
                    details.Cart.ToList().ForEach(sci => _shoppingCartService.DeleteShoppingCartItem(sci, false));
                }
                else
                {
                    //recurring payment
                    var initialOrderItems = details.InitialOrder.OrderItems;
                    foreach (var orderItem in initialOrderItems)
                    {
                        //save item
                        var newOrderItem = new OrderItem
                        {
                            OrderItemGuid = Guid.NewGuid(),
                            Order = order,
                            ProductId = orderItem.ProductId,
                            UnitPriceInclTax = orderItem.UnitPriceInclTax,
                            UnitPriceExclTax = orderItem.UnitPriceExclTax,
                            PriceInclTax = orderItem.PriceInclTax,
                            PriceExclTax = orderItem.PriceExclTax,
                            OriginalProductCost = orderItem.OriginalProductCost,
                            AttributeDescription = orderItem.AttributeDescription,
                            AttributesXml = orderItem.AttributesXml,
                            Quantity = orderItem.Quantity,
                            DiscountAmountInclTax = orderItem.DiscountAmountInclTax,
                            DiscountAmountExclTax = orderItem.DiscountAmountExclTax,
                            DownloadCount = 0,
                            IsDownloadActivated = false,
                            LicenseDownloadId = 0,
                            ItemWeight = orderItem.ItemWeight,
                            RentalStartDateUtc = orderItem.RentalStartDateUtc,
                            RentalEndDateUtc = orderItem.RentalEndDateUtc
                        };
                        order.OrderItems.Add(newOrderItem);
                        _orderService.UpdateOrder(order);

                        //gift cards
                        if (orderItem.Product.IsGiftCard)
                        {
                            string giftCardRecipientName, giftCardRecipientEmail,
                                giftCardSenderName, giftCardSenderEmail, giftCardMessage;
                            _productAttributeParser.GetGiftCardAttribute(orderItem.AttributesXml,
                                out giftCardRecipientName, out giftCardRecipientEmail,
                                out giftCardSenderName, out giftCardSenderEmail, out giftCardMessage);

                            for (int i = 0; i < orderItem.Quantity; i++)
                            {
                                var gc = new GiftCard
                                {
                                    GiftCardType = orderItem.Product.GiftCardType,
                                    PurchasedWithOrderItem = newOrderItem,
                                    Amount = orderItem.UnitPriceExclTax,
                                    IsGiftCardActivated = false,
                                    GiftCardCouponCode = _giftCardService.GenerateGiftCardCode(),
                                    RecipientName = giftCardRecipientName,
                                    RecipientEmail = giftCardRecipientEmail,
                                    SenderName = giftCardSenderName,
                                    SenderEmail = giftCardSenderEmail,
                                    Message = giftCardMessage,
                                    IsRecipientNotified = false,
                                    CreatedOnUtc = DateTime.UtcNow
                                };
                                _giftCardService.InsertGiftCard(gc);
                            }
                        }

                        //inventory
                        _productService.AdjustInventory(orderItem.Product, -orderItem.Quantity, orderItem.AttributesXml);
                    }
                }
                
                #endregion
                
                #region Payment workflow

                //process payment
                ProcessPaymentResult processPaymentResult = null;
                //skip payment workflow if order total equals zero
                var skipPaymentWorkflow = details.OrderTotal == decimal.Zero;
                if (!skipPaymentWorkflow)
                {
                    var paymentMethod = Nop.Core.Infrastructure.EngineContext.Current.Resolve<IPaymentPluginManager>().LoadPluginBySystemName(processPaymentRequest.PaymentMethodSystemName);
                    if (paymentMethod == null)
                        throw new NopException("Payment method couldn't be loaded");

                    //ensure that payment method is active
                    if (!paymentMethod.IsPaymentMethodActive(_paymentSettings))
                        throw new NopException("Payment method is not active");

                    if (details.IsRecurringShoppingCart)
                    {
                        //recurring cart
                        var recurringPaymentType = _paymentService.GetRecurringPaymentType(processPaymentRequest.PaymentMethodSystemName);
                        switch (recurringPaymentType)
                        {
                            case RecurringPaymentType.NotSupported:
                                throw new NopException("Recurring payments are not supported by selected payment method");
                            case RecurringPaymentType.Manual:
                            case RecurringPaymentType.Automatic:
                                processPaymentResult = _paymentService.ProcessRecurringPayment(processPaymentRequest);
                                break;
                            default:
                                throw new NopException("Not supported recurring payment type");
                        }
                    }
                    else
                    {
                        //standard cart
                        switch (paymentOperationType)
                        {
                            case PaymentOperationType.Full:
                                processPaymentResult = _paymentService.ProcessPayment(processPaymentRequest);
                                break;
                            case PaymentOperationType.Partial:
                                processPaymentRequest.InitialOrderId = order.Id;
                                processPaymentResult = _partialPaymentService.ProcessPayment(processPaymentRequest, out paymentOrder);
                                break;
                        }
                    }
                }
                else
                {
                    //payment is not required
                    if (processPaymentResult == null)
                        processPaymentResult = new ProcessPaymentResult();
                    processPaymentResult.NewPaymentStatus = PaymentStatus.Paid;
                }

                if (processPaymentResult == null)
                    throw new NopException("processPaymentResult is not available");

                #endregion

                if (processPaymentResult.Success)
                {
                    #region Save order payment data

                    var paymentDataOrder = order;
                    if (paymentOperationType == PaymentOperationType.Partial)
                        paymentDataOrder = paymentOrder;

                    //we don't need to store information about payment in the main order
                    if (paymentOperationType != PaymentOperationType.Partial)
                    {
                        order.AllowStoringCreditCardNumber = processPaymentResult.AllowStoringCreditCardNumber;
                        order.CardType = processPaymentResult.AllowStoringCreditCardNumber
                            ? _encryptionService.EncryptText(processPaymentRequest.CreditCardType)
                            : string.Empty;
                        order.CardName = processPaymentResult.AllowStoringCreditCardNumber
                            ? _encryptionService.EncryptText(processPaymentRequest.CreditCardName)
                            : string.Empty;
                        order.CardNumber = processPaymentResult.AllowStoringCreditCardNumber
                            ? _encryptionService.EncryptText(processPaymentRequest.CreditCardNumber)
                            : string.Empty;
                        order.MaskedCreditCardNumber = _encryptionService.EncryptText(
                            _paymentService.GetMaskedCreditCardNumber(processPaymentRequest.CreditCardNumber));
                        order.CardCvv2 = processPaymentResult.AllowStoringCreditCardNumber
                            ? _encryptionService.EncryptText(processPaymentRequest.CreditCardCvv2)
                            : string.Empty;
                        order.CardExpirationMonth = processPaymentResult.AllowStoringCreditCardNumber
                            ? _encryptionService.EncryptText(processPaymentRequest.CreditCardExpireMonth.ToString())
                            : string.Empty;
                        order.CardExpirationYear = processPaymentResult.AllowStoringCreditCardNumber
                            ? _encryptionService.EncryptText(processPaymentRequest.CreditCardExpireYear.ToString())
                            : string.Empty;
                        order.PaymentMethodSystemName = processPaymentRequest.PaymentMethodSystemName;
                        order.AuthorizationTransactionId = processPaymentResult.AuthorizationTransactionId;
                        order.AuthorizationTransactionCode = processPaymentResult.AuthorizationTransactionCode;
                        order.AuthorizationTransactionResult = processPaymentResult.AuthorizationTransactionResult;
                        order.CaptureTransactionId = processPaymentResult.CaptureTransactionId;
                        order.CaptureTransactionResult = processPaymentResult.CaptureTransactionResult;
                        order.SubscriptionTransactionId = processPaymentResult.SubscriptionTransactionId;
                        order.PaymentStatus = processPaymentResult.NewPaymentStatus;

                        _orderService.UpdateOrder(order);
                    }

                    result.PlacedOrder = order;

                    #endregion

                    #region Discounts, GiftCards, Reward Points History, Recurring Orders

                    //discount usage history
                    foreach (var discount in details.AppliedDiscounts)
                    {
                        var d = _discountService.GetDiscountById(discount.Id);
                        if (d != null)
                        {
                            _discountService.InsertDiscountUsageHistory(new DiscountUsageHistory
                            {
                                Discount = d,
                                Order = order,
                                CreatedOnUtc = DateTime.UtcNow
                            });
                        }
                    }

                    //gift card usage history
                    if (details.AppliedGiftCards != null)
                        foreach (var agc in details.AppliedGiftCards)
                        {
                            agc.GiftCard.GiftCardUsageHistory.Add(new GiftCardUsageHistory
                            {
                                GiftCard = agc.GiftCard,
                                UsedWithOrder = order,
                                UsedValue = agc.AmountCanBeUsed,
                                CreatedOnUtc = DateTime.UtcNow
                            });
                            _giftCardService.UpdateGiftCard(agc.GiftCard);
                        }

                    //reward points history
                    if (details.RedeemedRewardPointsAmount > decimal.Zero)
                    {
                        _rewardPointService.AddRewardPointsHistoryEntry(details.Customer,
                            -details.RedeemedRewardPoints, paymentDataOrder.StoreId,
                            string.Format(_localizationService.GetResource("RewardPoints.Message.RedeemedForOrder", 
                            paymentDataOrder.CustomerLanguageId), paymentDataOrder.Id),
                            paymentDataOrder, details.RedeemedRewardPointsAmount);
                        _customerService.UpdateCustomer(details.Customer);
                    }

                    //recurring orders
                    if (details.IsRecurringShoppingCart)
                    {
                        //create recurring payment (the first payment)
                        var rp = new RecurringPayment
                        {
                            CycleLength = processPaymentRequest.RecurringCycleLength,
                            CyclePeriod = processPaymentRequest.RecurringCyclePeriod,
                            TotalCycles = processPaymentRequest.RecurringTotalCycles,
                            StartDateUtc = DateTime.UtcNow,
                            IsActive = true,
                            CreatedOnUtc = DateTime.UtcNow,
                            InitialOrder = paymentDataOrder,
                        };
                        _orderService.InsertRecurringPayment(rp);


                        var recurringPaymentType = _paymentService.GetRecurringPaymentType(processPaymentRequest.PaymentMethodSystemName);
                        switch (recurringPaymentType)
                        {
                            case RecurringPaymentType.NotSupported:
                                {
                                    //not supported
                                }
                                break;
                            case RecurringPaymentType.Manual:
                                {
                                    //first payment
                                    var rph = new RecurringPaymentHistory
                                    {
                                        RecurringPayment = rp,
                                        CreatedOnUtc = DateTime.UtcNow,
                                        OrderId = paymentDataOrder.Id,
                                    };
                                    rp.RecurringPaymentHistory.Add(rph);
                                    _orderService.UpdateRecurringPayment(rp);
                                }
                                break;
                            case RecurringPaymentType.Automatic:
                                {
                                    //will be created later (process is automated)
                                }
                                break;
                            default:
                                break;
                        }
                    }

                    #endregion

                    #region Notifications & notes

                    //notes, messages
                    if (_workContext.OriginalCustomerIfImpersonated != null)
                    {
                        //this order is placed by a store administrator impersonating a customer
                        order.OrderNotes.Add(new OrderNote
                        {
                            Note = string.Format("Order placed by a store owner ('{0}'. ID = {1}) impersonating the customer.",
                                _workContext.OriginalCustomerIfImpersonated.Email, _workContext.OriginalCustomerIfImpersonated.Id),
                            DisplayToCustomer = false,
                            CreatedOnUtc = DateTime.UtcNow
                        });
                        _orderService.UpdateOrder(order);
                    }
                    else
                    {
                        order.OrderNotes.Add(new OrderNote
                        {
                            Note = "Order placed",
                            DisplayToCustomer = false,
                            CreatedOnUtc = DateTime.UtcNow
                        });
                        _orderService.UpdateOrder(order);
                    }


                    //send email notifications
                    int orderPlacedStoreOwnerNotificationQueuedEmailId = _workflowMessageService.SendOrderPlacedStoreOwnerNotification(order, _localizationSettings.DefaultAdminLanguageId);
                    if (orderPlacedStoreOwnerNotificationQueuedEmailId > 0)
                    {
                        order.OrderNotes.Add(new OrderNote
                        {
                            Note = string.Format("\"Order placed\" email (to store owner) has been queued. Queued email identifier: {0}.", orderPlacedStoreOwnerNotificationQueuedEmailId),
                            DisplayToCustomer = false,
                            CreatedOnUtc = DateTime.UtcNow
                        });
                        _orderService.UpdateOrder(order);
                    }

                    var orderPlacedAttachmentFilePath = _orderSettings.AttachPdfInvoiceToOrderPlacedEmail ?
                        _pdfService.PrintOrderToPdf(order, order.CustomerLanguageId) : null;
                    var orderPlacedAttachmentFileName = _orderSettings.AttachPdfInvoiceToOrderPlacedEmail ?
                        "order.pdf" : null;
                    int orderPlacedCustomerNotificationQueuedEmailId = _workflowMessageService
                        .SendOrderPlacedCustomerNotification(order, order.CustomerLanguageId, orderPlacedAttachmentFilePath, orderPlacedAttachmentFileName);
                    if (orderPlacedCustomerNotificationQueuedEmailId > 0)
                    {
                        order.OrderNotes.Add(new OrderNote
                        {
                            Note = string.Format("\"Order placed\" email (to customer) has been queued. Queued email identifier: {0}.", orderPlacedCustomerNotificationQueuedEmailId),
                            DisplayToCustomer = false,
                            CreatedOnUtc = DateTime.UtcNow
                        });
                        _orderService.UpdateOrder(order);
                    }

                    var vendors = GetVendorsInOrder(order);
                    foreach (var vendor in vendors)
                    {
                        int orderPlacedVendorNotificationQueuedEmailId = _workflowMessageService.SendOrderPlacedVendorNotification(order, vendor, order.CustomerLanguageId);
                        if (orderPlacedVendorNotificationQueuedEmailId > 0)
                        {
                            order.OrderNotes.Add(new OrderNote
                            {
                                Note = string.Format("\"Order placed\" email (to vendor) has been queued. Queued email identifier: {0}.", orderPlacedVendorNotificationQueuedEmailId),
                                DisplayToCustomer = false,
                                CreatedOnUtc = DateTime.UtcNow
                            });
                            _orderService.UpdateOrder(order);
                        }
                    }

                    //check order status
                    CheckOrderStatus(order);

                    //reset checkout data
                    _customerService.ResetCheckoutData(details.Customer, processPaymentRequest.StoreId, clearCouponCodes: true, clearCheckoutAttributes: true);
                    _customerActivityService.InsertActivity("PublicStore.PlaceOrder", _localizationService.GetResource("ActivityLog.PublicStore.PlaceOrder"), order.Id);

                    //raise event       
                    _eventPublisher.Publish(new OrderPlacedEvent(order));

                    if (order.PaymentStatus == PaymentStatus.Paid)
                    {
                        ProcessOrderPaid(order);
                    }
                    #endregion
                }
                else
                {
                    result.PlacedOrder = order;

                    foreach (var paymentError in processPaymentResult.Errors)
                        result.AddError(string.Format("Payment error: {0}", paymentError));
                }
            }
            catch (Exception exc)
            {
                //_logger.Error(exc.Message, exc);
                result.AddError(exc.Message);
            }

            #region Process errors

            string error = "";
            for (int i = 0; i < result.Errors.Count; i++)
            {
                error += string.Format("Error {0}: {1}", i + 1, result.Errors[i]);
                if (i != result.Errors.Count - 1)
                    error += ". ";
            }
            if (!String.IsNullOrEmpty(error))
            {
                //log it
                string logError = string.Format("Error while placing order. {0}", error);
                var customer = _customerService.GetCustomerById(processPaymentRequest.CustomerId);
                //_logger.Error(logError, customer: customer);
            }

            #endregion

            return result;
        }
        //nop3.7 upgrade end
        
        #endregion

        
    }
}
