﻿
CREATE TABLE [dbo].[PartialPayment](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[OrderId] [int] NOT NULL,
	[Date] [datetime] NOT NULL,
	[Amount] [decimal] (18,2) NOT NULL,
	[PaymentStatusId] [int],
	[PaymentMethodSystemName] [nvarchar](128),
	--[TransactionType] [int],
	[Comment] [nvarchar](400)
	--, [StatusCode] [int]

PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 


ALTER TABLE [dbo].[PartialPayment]  WITH CHECK ADD  CONSTRAINT [fk_OrderId_payment] FOREIGN KEY([OrderId])
REFERENCES [dbo].[Order] ([Id])

ALTER TABLE [dbo].[PartialPayment] CHECK CONSTRAINT [fk_OrderId_payment]
