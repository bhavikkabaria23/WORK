using System;
using System.Collections.Generic;
using Nop.Core;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Localization;
using Nop.Core.Domain.Payments;

namespace ShopFast.Plugin.Misc.Core.Domain
{
    /// <summary>
    /// Represents a payment operation type
    /// </summary>
    public enum PaymentOperationType
    {
        /// <summary>
        /// Full
        /// </summary>
        Full = 10,
        /// <summary>
        /// Partial
        /// </summary>
        Partial = 20,
    }
}
