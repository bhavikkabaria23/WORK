﻿using Nop.Web.Models.ShoppingCart;

namespace ShopFast.Plugin.Misc.Core.Models
{
    public class CustomOrderTotalsModel : OrderTotalsModel
    {
        public bool ShowPaidUnpaidAmounts { get; set; }
        public string AmountPaid { get; set; }
        public string AmountToPay { get; set; }
    }
}
